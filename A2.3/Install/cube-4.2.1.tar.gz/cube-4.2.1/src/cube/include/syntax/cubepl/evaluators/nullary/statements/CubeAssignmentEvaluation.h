/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __ASSIGNMENT_EVALUATION_H
#define __ASSIGNMENT_EVALUATION_H 0

#include "CubeNullaryEvaluation.h"
#include "CubePL1MemoryManager.h"
#include "string"
namespace cube
{
class AssignmentEvaluation : public NullaryEvaluation
{
protected:
    CubePL1MemoryManager* memory;
    std::string           variable_name;
    MemoryAdress          variable;
    KindOfVariable        kind;
    GeneralEvaluation*    value;
    GeneralEvaluation*    index;


public:
    AssignmentEvaluation( std::string           _v,
                          GeneralEvaluation*    _index,
                          GeneralEvaluation*    _val,
                          CubePL1MemoryManager* _manager
                          ) : NullaryEvaluation(), memory( _manager ), variable_name( _v ), variable( memory->register_variable( _v ) ), value( _val ), index( _index )
    {
        kind = memory->kind_of_variable( variable_name );
    };
    ~AssignmentEvaluation();

    virtual
    double
    eval();

//     virtual
//     double
//     eval( Cnode*             cnode,
//           CalculationFlavour cf,
//           Thread*            th,
//           CalculationFlavour tf );
//
//     virtual
//     double
//     eval( Cnode*             cnode,
//           CalculationFlavour cf,
//           Thread*            th1,
//           Thread*            th2,
//           CalculationFlavour tf  );
//
    virtual
    double
    eval( Cnode*             cnode,
          CalculationFlavour cf,
          Sysres*            sr,
          CalculationFlavour tf  );

//     virtual
//     double
//     eval( Cnode*             cnode,
//           CalculationFlavour cf,
//           Process*           pr,
//           CalculationFlavour tf  );
//
//     virtual
//     double
//     eval( Cnode*             cnode,
//           CalculationFlavour cf,
//           Node*              nd,
//           CalculationFlavour tf );
//
//     virtual
//     double
//     eval( Cnode*             cnode,
//           CalculationFlavour cf,
//           Machine*           mch,
//           CalculationFlavour tf  );
//
    virtual
    double
    eval( Cnode*             cnode,
          CalculationFlavour cf );

    virtual
    void
    print()
    {
        cout << "${" << variable_name << "}[";
        index->print();
        cout << "] = ";
        value->print();
        cout << ";" << endl;
    };
};
};

#endif
