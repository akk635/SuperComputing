/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __GENERAL_EVALUATION_H
#define __GENERAL_EVALUATION_H 0

#include <vector>
#include <iostream>
#include <float.h>
#include <cmath>
#include "CubeMetric.h"
#include "CubeThread.h"
#include "CubeSysres.h"
#include "CubeProcess.h"
#include "CubeNode.h"
#include "CubeMachine.h"
#include "CubeTypes.h"
#include "CubePL1MemoryManager.h"

using namespace std;

namespace cube
{
class GeneralEvaluation
{
protected:
    vector<GeneralEvaluation* > arguments;
protected:


    size_t
    getNumOfParameters();

    virtual size_t
    getNumOfArguments();

public:
    GeneralEvaluation();

    virtual
    ~GeneralEvaluation();

    void
    addArgument( GeneralEvaluation* _arg );

//     virtual
//     double
//     eval( Cnode* _cnode, CalculationFlavour _cf, Thread* _th1, CalculationFlavour _sf )
//     {
//         _cnode = _cnode;
//         _cf    = _cf;
//         _th1   = _th1;
//         _sf    = _sf;
//         return eval();
//     };
//
//     virtual
//     double
//     eval( Cnode* _cnode, CalculationFlavour _cf, Thread* _th1, Thread* _th2, CalculationFlavour _sf )
//     {
//         _cnode = _cnode;
//         _cf    = _cf;
//         _th1   = _th1;
//         _th2   = _th2;
//         _sf    = _sf;
//         return eval();
//     };

    inline
    virtual
    double
    eval( Cnode* _cnode, CalculationFlavour _cf, Sysres* _sys, CalculationFlavour _sf  )
    {
        _cnode++;
        _sys++;
        _sf = _cf;
        _cf = _sf;
        return eval();
    };

//     virtual
//     double
//     eval( Cnode* _cnode, CalculationFlavour _cf, Process* _proc, CalculationFlavour _sf  )
//     {
//         _cnode = _cnode;
//         _cf    = _cf;
//         _proc  = _proc;
//         _sf    = _sf;
//         return eval();
//     };
//
//     virtual
//     double
//     eval( Cnode* _cnode, CalculationFlavour _cf, Node* _node, CalculationFlavour _sf  )
//     {
//         _cnode = _cnode;
//         _cf    = _cf;
//         _node  = _node;
//         _sf    = _sf;
//         return eval();
//     };
//
//     virtual
//     double
//     eval( Cnode* _cnode, CalculationFlavour _cf, Machine* _mach, CalculationFlavour _sf  )
//     {
//         _cnode = _cnode;
//         _cf    = _cf;
//         _mach  = _mach;
//         _sf    = _sf;
//         return eval();
//     };
//
    inline
    virtual
    double
    eval( Cnode* _cnode, CalculationFlavour _cf )
    {
        _cnode++;
        _cf = ( _cf ) ? CUBE_CALCULATE_INCLUSIVE : CUBE_CALCULATE_EXCLUSIVE;
        return eval();
    };


    virtual
    double
    eval();

    virtual
    void
    print()
    {
    };
};
}

#endif
