/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __DIRECT_METRIC_EVALUATION_H
#define __DIRECT_METRIC_EVALUATION_H 0

#include "CubeNullaryEvaluation.h"
#include "CubeCalcFlavorModificators.h"
#include "CubeMetric.h"
#include "CubeTypes.h"
#include "Cube.h"



namespace cube
{
enum  MetricReferenceType { CONTEXT_METRIC = 0, FIXED_METRIC_NO_AGGR, FIXED_METRIC_AGGR_SYS, FIXED_METRIC_FULL_AGGR };


class DirectMetricEvaluation : public NullaryEvaluation
{
private:
    MetricReferenceType    reference_type;
    Cube*                  cube;
    Metric*                metric;
    CalcFlavorModificator* calltree_cf;
    CalcFlavorModificator* systree_sf;
    std::string            metric_uniq_name;
public:
    DirectMetricEvaluation( MetricReferenceType    _reference_type,
                            Cube*                  _cube,
                            Metric*                _met,
                            CalcFlavorModificator* cf = new CalcFlavorModificatorSame(),
                            CalcFlavorModificator* sf = new CalcFlavorModificatorSame() );
    ~DirectMetricEvaluation();

//     virtual
//     double eval( Cnode *, CalculationFlavour, Thread *, CalculationFlavour );
//
//     virtual
//     double eval( Cnode *, CalculationFlavour, Thread *, Thread *, CalculationFlavour   );

    virtual
    double eval( Cnode *, CalculationFlavour, Sysres *, CalculationFlavour   );

//     virtual
//     double eval( Cnode *, CalculationFlavour, Process *, CalculationFlavour   );
//
//     virtual
//     double eval( Cnode *, CalculationFlavour, Node *, CalculationFlavour   );
//
//     virtual
//     double eval( Cnode *, CalculationFlavour, Machine *, CalculationFlavour   );

    virtual
    double eval( Cnode *, CalculationFlavour );

    virtual
    double
    eval();


    virtual
    void
    print()
    {
        cout << "metric::";
        switch ( reference_type )
        {
            case FIXED_METRIC_AGGR_SYS:
            case FIXED_METRIC_FULL_AGGR:
            case FIXED_METRIC_NO_AGGR:
                cout << "fixed::";
                break;
            case CONTEXT_METRIC:
            default:
                cout << "context::";
                break;
        }
        cout << metric_uniq_name << "(";
        calltree_cf->print();
        cout << ", ";
        systree_sf->print();
        cout <<  ")";
    };
};
};
#endif
