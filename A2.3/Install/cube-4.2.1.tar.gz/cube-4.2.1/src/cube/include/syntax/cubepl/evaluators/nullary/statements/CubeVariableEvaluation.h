/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __VARIABLE_EVALUATION_H
#define __VARIABLE_EVALUATION_H 0

#include "string"
#include "CubePL1MemoryManager.h"
#include "CubeStringEvaluation.h"

namespace cube
{
class VariableEvaluation : public StringEvaluation
{
protected:
    CubePL1MemoryManager* memory;
    MemoryAdress          variable;
    std::string           variable_name;
    KindOfVariable        kind;
    GeneralEvaluation*    index;
public:
    VariableEvaluation( std::string           _variable,
                        GeneralEvaluation*    _index,
                        CubePL1MemoryManager* _manager ) : StringEvaluation(), memory( _manager ),  variable( memory->register_variable( _variable ) ), variable_name( _variable ), index( _index )
    {
        kind = memory->kind_of_variable( variable_name );
    };
    ~VariableEvaluation();

    virtual
    double
    eval();

/*
    virtual
    double
    eval( Cnode *, CalculationFlavour, Thread *, CalculationFlavour );

    virtual
    double
    eval( Cnode *, CalculationFlavour, Thread *, Thread *, CalculationFlavour   );
 */
    virtual
    double
    eval( Cnode *, CalculationFlavour, Sysres *, CalculationFlavour   );

//     virtual
//     double
//     eval( Cnode *, CalculationFlavour, Process *, CalculationFlavour   );
//
//     virtual
//     double
//     eval( Cnode *, CalculationFlavour, Node *, CalculationFlavour   );
//
//     virtual
//     double
//     eval( Cnode *, CalculationFlavour, Machine *, CalculationFlavour   );

    virtual
    double
    eval( Cnode *, CalculationFlavour );


    virtual
    string
    strEval();



    virtual
    void
    print()
    {
        cout << "${" << variable_name << "}[";
        index->print();
        cout << "]";
    };
};
};

#endif
