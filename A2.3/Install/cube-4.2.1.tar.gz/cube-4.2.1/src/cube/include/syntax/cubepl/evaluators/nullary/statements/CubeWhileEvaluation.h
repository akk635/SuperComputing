/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __WHILE_EVALUATION_H
#define __WHILE_EVALUATION_H 0

#include "string"

#include "CubeNullaryEvaluation.h"

namespace cube
{
class WhileEvaluation : public NullaryEvaluation
{
protected:
    GeneralEvaluation* condition;
public:
    WhileEvaluation( GeneralEvaluation* _condition ) : NullaryEvaluation(), condition( _condition )
    {
    };
    ~WhileEvaluation();

    virtual
    double
    eval();

//     virtual
//     double
//     eval( Cnode* cnode, CalculationFlavour cf, Thread* th, CalculationFlavour tf )
//     {
//         unsigned counter = 0;
//         while ( condition->eval( cnode, cf, th, tf ) != 0 )
//         {
//             for ( unsigned i = 0; i < getNumOfParameters(); i++ )
//             {
//                 arguments[ i ]->eval( cnode, cf, th, tf );
//             }
//             counter++;
//             if ( counter >= 1000000000 )
//             {
//                 break;
//             }
//         }
//         return 0.;
//     };
//
//     virtual
//     double
//     eval( Cnode* cnode, CalculationFlavour cf, Thread* th1, Thread* th2, CalculationFlavour tf )
//     {
//         unsigned counter = 0;
//         while ( condition->eval( cnode, cf, th1, th2, tf ) != 0. )
//         {
//             for ( unsigned i = 0; i < getNumOfParameters(); i++ )
//             {
//                 arguments[ i ]->eval( cnode, cf, th1, th2, tf );
//             }
//             counter++;
//             if ( counter >= 1000000000 )
//             {
//                 break;
//             }
//         }
//         return 0.;
//     };

    virtual
    double
    eval( Cnode* cnode, CalculationFlavour cf, Sysres* sr, CalculationFlavour tf  )
    {
        unsigned counter = 0;
        while ( condition->eval( cnode, cf, sr, tf ) != 0. )
        {
            for ( unsigned i = 0; i < getNumOfParameters(); i++ )
            {
                arguments[ i ]->eval( cnode, cf, sr, tf );
            }
            counter++;
            if ( counter >= 1000000000 )
            {
                break;
            }
        }
        return 0.;
    };

//     virtual
//     double
//     eval( Cnode* cnode, CalculationFlavour cf, Process* pr, CalculationFlavour tf )
//     {
//         unsigned counter = 0;
//         while ( condition->eval( cnode, cf, pr, tf ) != 0. )
//         {
//             for ( unsigned i = 0; i < getNumOfParameters(); i++ )
//             {
//                 arguments[ i ]->eval( cnode, cf, pr, tf );
//             }
//             counter++;
//             if ( counter >= 1000000000 )
//             {
//                 break;
//             }
//         }
//         return 0.;
//     };
//
//     virtual
//     double
//     eval( Cnode* cnode, CalculationFlavour cf, Node* nd, CalculationFlavour tf  )
//     {
//         unsigned counter = 0;
//         while ( condition->eval( cnode, cf, nd, tf ) )
//         {
//             for ( unsigned i = 0; i < getNumOfParameters(); i++ )
//             {
//                 arguments[ i ]->eval( cnode, cf, nd, tf );
//             }
//             counter++;
//             if ( counter >= 1000000000 )
//             {
//                 break;
//             }
//         }
//         return 0.;
//     };
//
//     virtual
//     double
//     eval( Cnode* cnode, CalculationFlavour cf, Machine* mch, CalculationFlavour tf )
//     {
//         unsigned counter = 0;
//         while ( condition->eval( cnode, cf, mch, tf ) )
//         {
//             for ( unsigned i = 0; i < getNumOfParameters(); i++ )
//             {
//                 arguments[ i ]->eval( cnode, cf, mch, tf );
//             }
//             counter++;
//             if ( counter >= 1000000000 )
//             {
//                 break;
//             }
//         }
//         return 0.;
//     };

    virtual
    double
    eval( Cnode* cnode, CalculationFlavour cf )
    {
        unsigned counter = 0;
        while ( condition->eval( cnode, cf ) )
        {
            for ( unsigned i = 0; i < getNumOfParameters(); i++ )
            {
                arguments[ i ]->eval( cnode, cf );
            }
            counter++;
            if ( counter >= 1000000000 )
            {
                break;
            }
        }
        return 0.;
    };

    virtual
    void
    print()
    {
        cout << "while (";
        condition->print();
        cout << ") " << endl <<  "{" << endl;
        for ( unsigned i = 0; i < getNumOfParameters(); i++ )
        {
            arguments[ i ]->print();
        }
        cout << "};"  << endl;
    };
};
};

#endif
