/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __FULL_IF_EVALUATION_H
#define __FULL_IF_EVALUATION_H 0

#include "string"

#include "CubeNullaryEvaluation.h"

namespace cube
{
class FullIfEvaluation : public NullaryEvaluation
{
protected:
    GeneralEvaluation* condition;
    unsigned           n_true;
    unsigned           n_false;
public:
    FullIfEvaluation( GeneralEvaluation* _condition,
                      unsigned           _n_true,
                      unsigned           _n_false ) : NullaryEvaluation(), condition( _condition ), n_true( _n_true ), n_false( _n_false )
    {
    };
    ~FullIfEvaluation();

    virtual
    double
    eval();

//     virtual
//     double
//     eval( Cnode* cnode, CalculationFlavour cf, Thread* th, CalculationFlavour tf )
//     {
//         double _tmp = condition->eval( cnode, cf, th, tf );
//         if ( _tmp != 0 )
//         {
//             for ( unsigned i = 0; i < n_true; i++ )
//             {
//                 arguments[ i ]->eval( cnode, cf, th, tf );
//             }
//         }
//         else
//         {
//             for ( unsigned i = n_true; i < n_true + n_false; i++ )
//             {
//                 arguments[ i ]->eval( cnode, cf, th, tf  );
//             }
//         }
//         return 0.;
//     };
//
//     virtual
//     double
//     eval( Cnode* cnode, CalculationFlavour cf, Thread* th1, Thread* th2, CalculationFlavour tf )
//     {
//         double _tmp = condition->eval( cnode, cf, th1, th2, tf );
//         if ( _tmp != 0 )
//         {
//             for ( unsigned i = 0; i < n_true; i++ )
//             {
//                 arguments[ i ]->eval( cnode, cf, th1, th2, tf );
//             }
//         }
//         else
//         {
//             for ( unsigned i = n_true; i < n_true + n_false; i++ )
//             {
//                 arguments[ i ]->eval( cnode, cf, th1, th2, tf  );
//             }
//         }
//         return 0.;
//     };

    virtual
    double
    eval( Cnode* cnode, CalculationFlavour cf, Sysres* sr, CalculationFlavour tf  )
    {
        double _tmp = condition->eval( cnode, cf, sr, tf );
        if ( _tmp != 0 )
        {
            for ( unsigned i = 0; i < n_true; i++ )
            {
                arguments[ i ]->eval( cnode, cf, sr, tf );
            }
        }
        else
        {
            for ( unsigned i = n_true; i < n_true + n_false; i++ )
            {
                arguments[ i ]->eval( cnode, cf, sr, tf  );
            }
        }
        return 0.;
    };

//     virtual
//     double
//     eval( Cnode* cnode, CalculationFlavour cf, Process* pr, CalculationFlavour tf )
//     {
//         double _tmp = condition->eval( cnode, cf, pr, tf );
//         if ( _tmp != 0 )
//         {
//             for ( unsigned i = 0; i < n_true; i++ )
//             {
//                 arguments[ i ]->eval( cnode, cf, pr, tf );
//             }
//         }
//         else
//         {
//             for ( unsigned i = n_true; i < n_true + n_false; i++ )
//             {
//                 arguments[ i ]->eval( cnode, cf, pr, tf  );
//             }
//         }
//         return 0.;
//     };
//
//     virtual
//     double
//     eval( Cnode* cnode, CalculationFlavour cf, Node* nd, CalculationFlavour tf  )
//     {
//         double _tmp = condition->eval( cnode, cf, nd, tf );
//         if ( _tmp != 0 )
//         {
//             for ( unsigned i = 0; i < n_true; i++ )
//             {
//                 arguments[ i ]->eval( cnode, cf, nd, tf );
//             }
//         }
//         else
//         {
//             for ( unsigned i = n_true; i < n_true + n_false; i++ )
//             {
//                 arguments[ i ]->eval( cnode, cf, nd, tf  );
//             }
//         }
//         return 0.;
//     };
//
//     virtual
//     double
//     eval( Cnode* cnode, CalculationFlavour cf, Machine* mch, CalculationFlavour tf )
//     {
//         double _tmp = condition->eval( cnode, cf, mch, tf );
//         if ( _tmp != 0 )
//         {
//             for ( unsigned i = 0; i < n_true; i++ )
//             {
//                 arguments[ i ]->eval( cnode, cf, mch, tf );
//             }
//         }
//         else
//         {
//             for ( unsigned i = n_true; i < n_true + n_false; i++ )
//             {
//                 arguments[ i ]->eval( cnode, cf, mch, tf  );
//             }
//         }
//         return 0.;
//     };

    virtual
    double
    eval( Cnode* cnode, CalculationFlavour cf )
    {
        double _tmp = condition->eval( cnode, cf );
        if ( _tmp != 0 )
        {
            for ( unsigned i = 0; i < n_true; i++ )
            {
                arguments[ i ]->eval( cnode, cf );
            }
        }
        else
        {
            for ( unsigned i = n_true; i < n_true + n_false; i++ )
            {
                arguments[ i ]->eval( cnode, cf );
            }
        }
        return 0.;
    };

    virtual
    void
    print()
    {
        cout << "if (";
        condition->print();
        cout << ") " << endl << "{" << endl;
        for ( unsigned i = 0; i < n_true; i++ )
        {
            arguments[ i ]->print();
        }
        cout << "} " << endl << "else "  << endl << "{ " << endl;
        for ( unsigned i = n_true; i < n_true + n_false; i++ )
        {
            arguments[ i ]->print();
        }
        cout << "};" << endl;
    };
};
};

#endif
