/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __STRING_CONSTANT_EVALUATION_H
#define __STRING_CONSTANT_EVALUATION_H 0

#include "string"

#include "CubeStringEvaluation.h"

namespace cube
{
class StringConstantEvaluation : public StringEvaluation
{
protected:
    string constant;

public:
    StringConstantEvaluation( string _const );
    ~StringConstantEvaluation();

    virtual
    string
    strEval()
    {
        return constant;
    };

    virtual
    void
    print()
    {
        cout << "\"" << constant << "\"";
    };
};
};

#endif
