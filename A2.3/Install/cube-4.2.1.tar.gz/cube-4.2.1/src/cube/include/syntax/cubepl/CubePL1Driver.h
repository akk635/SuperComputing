/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __CUBEPL1_DRIVER_H
#define __CUBEPL1_DRIVER_H 0

#include <vector>
#include <iostream>
#include <float.h>
#include <cmath>

#include "Cube.h"
#include "CubeEvaluators.h"


using namespace std;

namespace cubeplparser
{
class CubePL1Driver
{
protected:
    vector<std::string > errors;
    cube::Cube*          cube;
protected:
public:
    CubePL1Driver( cube::Cube* );

    ~CubePL1Driver();

    cube::GeneralEvaluation*
    compile( istream*,
             ostream* errs );

    static
    bool
    test( std::string&,
          std::string& );

    std::string
    printStatus();
};
};

#endif
