/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __CEIL_EVALUATION_H
#define __CEIL_EVALUATION_H 0

#include "CubeUnaryEvaluation.h"
namespace cube
{
class CeilEvaluation : public UnaryEvaluation
{
public:
    CeilEvaluation();
    CeilEvaluation( GeneralEvaluation* _arg ) : UnaryEvaluation( _arg )
    {
    };

    virtual
    ~CeilEvaluation();

    virtual
    double
    eval();

//      virtual
//      double eval( Cnode * , CalculationFlavour, Thread *, CalculationFlavour );
//
//      virtual
//      double eval( Cnode * , CalculationFlavour, Thread *, Thread *, CalculationFlavour   );

    virtual
    double eval( Cnode *, CalculationFlavour, Sysres *, CalculationFlavour   );

//      virtual
//      double eval( Cnode * , CalculationFlavour, Process *, CalculationFlavour   );
//
//      virtual
//      double eval( Cnode * , CalculationFlavour, Node *, CalculationFlavour   );
//
//      virtual
//      double eval( Cnode * , CalculationFlavour, Machine *, CalculationFlavour   );

    virtual
    double eval( Cnode *, CalculationFlavour );

    virtual
    void
    print()
    {
        cout << "ceil( ";
        arguments[ 0 ]->print();
        cout << ")";
    };
};
};

#endif
