/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __CALC_FLAVOR_MODIFICATORS_H
#define __CALC_FLAVOR_MODIFICATORS_H 0

#include <vector>
#include <iostream>
#include <float.h>
#include <cmath>

#include "CubeTypes.h"

using namespace std;
namespace cube
{
class CalcFlavorModificator
{
public:
    virtual
    ~CalcFlavorModificator()
    {
    };

    virtual
    CalculationFlavour
    flavour( CalculationFlavour cf )
    {
        return cf;
    };

    virtual void
    print() = 0;
};


class CalcFlavorModificatorSame : public CalcFlavorModificator
{
    virtual void
    print()
    {
        cout << "*";
    };
};

class CalcFlavorModificatorIncl : public CalcFlavorModificator
{
public:
    virtual
    ~CalcFlavorModificatorIncl()
    {
    };
    CalculationFlavour
    flavour( CalculationFlavour cf )
    {
        cf = CUBE_CALCULATE_INCLUSIVE;
        return cf;
    };
    virtual void
    print()
    {
        cout << "i";
    };
};


class CalcFlavorModificatorExcl : public CalcFlavorModificator
{
public:
    virtual
    ~CalcFlavorModificatorExcl()
    {
    };
    CalculationFlavour
    flavour( CalculationFlavour cf )
    {
        cf = CUBE_CALCULATE_EXCLUSIVE;
        return cf;
    };
    virtual void
    print()
    {
        cout << "e";
    };
};
};

#endif
