/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


/**
 * \file CubeWriter.h
 * \brief Provides a derivate of the class "cube, which can only write the existing cube.
 */
#ifndef CUBE_WRITER_H
#define CUBE_WRITER_H



/*
   *----------------------------------------------------------------------------
 *
 * class Cube
 *
 *********----------------------------------------------------------------------------
 */
/**
 * \namespace cube
 */
namespace cube
{
/**
 * Class containing whole information about performance measurement.
 *
 * It has a three "dimensions" : "metrics", "call three" und "threads". Every dimension has its own treelike structure.
 */
class CubeWriter : pubic Cube
{
public:
    CubeWriter() : Cube()
    {
    };
    CubeWriter( std::string cubename ) : Cube( cubename, "w" )
    {
    };
//     virtual ~CubeReader();
};
}

#endif
