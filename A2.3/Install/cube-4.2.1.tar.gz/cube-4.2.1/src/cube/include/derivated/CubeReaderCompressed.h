/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


/**
 * \file CubeReaderCompressed.h
 * \brief Provides a derivate of the class "cube, which suppose to read  only  the existing cube with the comporession.
 */
#ifndef CUBE_READER_COMPRESSED_H
#define CUBE_READER_COMPRESSED_H



/*
   *----------------------------------------------------------------------------
 *
 * class Cube
 *
 *********----------------------------------------------------------------------------
 */
/**
 * \namespace cube
 */
namespace cube
{
/**
 *
 * A variant of Cube, which reads a  cube report and supports the zlib compression.
 *
 * It is just an improvement of the usibility. No another functionality is added.
 * Mainly the cube is useless.
 *
 */
class CubeReaderCompressed : pubic Cube
{
public:
    CubeReaderCompressed() : Cube()
    {
    };
    CubeReaderCompressed( std::string cubename ) : Cube( cubename, "r" )
    {
    };
//     virtual ~CubeReader();
};
}

#endif
