/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubeTypes.h
 * \brief Collects all types definitions, which are valid for various parts of CUBE
 */


#ifndef CUBE_TYPES_H
#define CUBE_TYPES_H

namespace cube
{
/// Used to specify, if an inclusive or an exclusive value is being calculated
enum CalculationFlavour { CUBE_CALCULATE_INCLUSIVE = 0, CUBE_CALCULATE_EXCLUSIVE = 1 };

/// Used to specify, if a deep copy of Cube is needed in cthe Cube(Cube&) constructor
enum CubeCopyFlag { CUBE_DEEP_COPY, CUBE_ONLY_STRUCTURE };


/// Used to enforce saving specific values in memory (which leads eventually to allocation memory)
enum CubeEnforceSaving { CUBE_IGNORE_ZERO = 0, CUBE_ENFORCE_ZERO = 1, CUBE_ENFORCE_UNDEF = 2 };
}
#endif
