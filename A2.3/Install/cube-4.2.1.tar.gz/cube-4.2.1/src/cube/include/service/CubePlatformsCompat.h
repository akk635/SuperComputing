/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 * \file>CubePlatformsCompat.h...
 * \brief Header with definitions and on other than linux platforms missing calls or with different declaration.
 *
 *
 *
 */


#ifndef CUBE_PLATFORMS_COMPAT_H
#define CUBE_PLATFORMS_COMPAT_H_H

#ifdef __MINGW32__ // for windows we compile only on MinGW32. Here are some calls different or missing

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>


// on windows there is no "mode" for directory creation
#define __MKDIR( path, mode ) ::mkdir( path )
// #define S_IRWXU 0
#define S_IROTH 0
#define S_IXOTH 0
#define S_IRGRP 0
#define S_IXGRP 0


// redefine fopen and stat to be able to open files on windows
#define  __STRUCT_STAT  struct _stat
#define  __STAT( path, pointer ) ::_stat( path, pointer )
#define  __FOPEN( path, mode )   ::_wfopen( path, mode )





// redefine fseeko with standart fseek
// #warning "On MinGW Platform we redefine fseeko using standard fseek."
#define fseeko fseek


typedef unsigned int gid_t;
typedef unsigned int uid_t;


gid_t
getgid( void );

uid_t
getuid( void );


#define FNM_NOMATCH 1
#define fnmatch( A, B, C ) ( FNM_NOMATCH )

#endif

#ifndef __MINGW32__
// on windows there is no "mode" for directory creation
#define __MKDIR( path, mode ) ::mkdir( path, mode )
//  fopen and stat to be able to open files on windows
#define  __STRUCT_STAT  struct stat
#define  __STAT( path, pointer ) ::stat( path, pointer )
#define  __FOPEN( path, mode )   ::fopen( path, mode )


#endif


#endif
