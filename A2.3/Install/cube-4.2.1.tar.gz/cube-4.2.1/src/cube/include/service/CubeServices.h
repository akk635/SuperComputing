/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 * \file CubeServices.h
 * \brief Provides a set of global service operations for cube library.
 */
#ifndef CUBE_SERVICES_H
#define CUBE_SERVICES_H 0

#include <string>
#include <functional>
#include <clocale>
#include <cctype>
#include <algorithm>
#include <inttypes.h>
#include <sys/stat.h>
#include <vector>

#include "Cube.h"

using namespace std;


namespace services
{
std::string
escapeToXML( std::string );           ///< Makes all XML reserved symbols XML-conform notation using  [actronym];
std::string
escapeFromXML( std::string );         ///< Makes all XML-conform notation into plaint text withou restriction by.

std::string
replaceSymbols( unsigned    from,
                unsigned    to,
                std::string str );                                       ///< Internaly used to perform escaping.


int
check_file( const char* );                  ///< Checks the state of the given file and reports, whether one might write to it or it belongs to some another user.


std::string
get_cube_name( std::string );          /// Removes the extansipn .cube from cube3 name.
std::string
get_cube3_name( std::string );         /// Removes the extansipn .cube from cube3 name.
std::string
get_cube3_gzipped_name( std::string ); /// Removes the extansion .cube.gz from gzipped cube3 name.
std::string
get_cube4_name( std::string );         /// Removes the extansipn .cubex from cube4 name.
std::string
get_cube4_hyb_dir_name( std::string ); /// Removes the extansipn .cubex from cube4 name.
bool
is_cube3_name( std::string );          /// checks, if it is the name of cube3 file
bool
is_cube3_gzipped_name( std::string );  /// checks, if it is the name of gzipped cube3 file
bool
is_cube4_name( std::string );          /// checks, whether it is a cube4 file
bool
is_cube4_tared( std::string );         /// checkt, whether it is a tared cube4 file. (only cube4 can be tared)
bool
is_cube4_hyb_dir( std::string );       /// checkt, whether it is a data dir in hybrid layout. (checks extension .cubex.data)
bool
is_cube4_embedded_anchor( std::string );

/*void swap(unsigned&, unsigned &); ///< Swaps two unsiged integers,.
   void swap(unsigned long long &, unsigned long long &);
   void swap(unsigned short&, unsigned short&);
   void swap(char&, char&);*/
void
swap( double&,
      double& );

void
swap( uint64_t&,
      uint64_t& );
void
swap( uint32_t&,
      uint32_t& );               ///< Swaps two unsiged integers,.
void
swap( uint16_t&,
      uint16_t& );
void
swap( uint8_t&,
      uint8_t& );

// --------- Service for file system operations -------------

bool
is_path( std::string );              ///< Checks, if it is a path or just a filename (contans "/" sign)
std::string
dirname( std::string );              ///< systemlie "dirname"

std::string
remove_dotted_path( std::string );   ///< Replace /./ by "/" and /XXXX/../ by /
void
create_path_for_file( std::string ); ///< throws an exception if fails. Otherwise creates the path independend of its depth.

int
_mkdir( const char*, mode_t );       ///< provides an interface to mkdir call, which is different under windows and linuix


std::string
remove_last_slashes( std::string );            ///< Removes a last slash in the path

std::string
create_random_string( unsigned length = 32 );  ///< Creates a random string with given length (32 symbols defualt)

uint64_t
hr_time();                                ///< Returns current time in nanoseconds. Used to initialize random generator.

std::string
get_tmp_files_location();               ///< Returns a path to the directory where cube places temporary files. As separate call to include check and and fall back into current directory if needed


/**
 * STL conform version to get a lowercase of a string.
 */
struct fo_tolower : public std::unary_function<int, int>
{
    int
    operator()( int x ) const
    {
        return std::tolower( x );
    }
};
/**
 * STL conform version to get a uppercase of a string.
 */
struct fo_toupper : public std::unary_function<int, int>
{
    int
    operator()( int x ) const
    {
        return std::toupper( x );
    }
};


std::string
lowercase( const std::string& str );           ///< Returns a lowercase version of str.
std::string
uppercase( const std::string& str );           ///< Returns a uppercase version of str.



uint64_t
parse_clustering_key( std::string& );            ///< Parses key attribute and returnd "iteration" id.

std::vector<uint64_t>
parse_clustering_value( std::string& );          ///< Parses value attribute and returnd "clusters" id.

uint32_t
string2int( const std::string& );                 ///< General transformation string -> int

std::string
numeric2string( int );                          ///< General transformation int -> string

std::string
numeric2string( double );                    ///< General transformation int -> string

std::string
numeric2string( uint64_t );                    ///< General transformation int -> string

std::string
numeric2string( int64_t );                    ///< General transformation int -> string


bool
get_children( std::vector<cube::Cnode*> & roots,
              uint64_t                    cluster_id,
              std::vector<cube::Cnode*> & children
              );          ///< finds in all cnodes and returns children of cnode with id "cluster_id"
bool
get_children( cube::                      Cnode*,
              uint64_t                    cluster_id,
              std::vector<cube::Cnode*> & children
              );          ///< finds recursively and returns children of cnode with id "cluster_id"





void
copy_tree( cube:: Cnode*,
           cube::Cnode* & clusters_root,
           uint64_t cluster_id = ( uint64_t )-1,
           cube::Cnode* parent = NULL,
           cube::Cube* cube = NULL,
           std::map<uint64_t, uint64_t>* normalisation_factor = NULL,
           std::vector<uint64_t>* cluster_position = NULL
           );             ///< Creates a copy of a call tree. Used to merge clusters trees. (-2 -> no copy, -1 -> only one copy, otherwise -> Process id)

void
merge_tree( cube:: Cnode*,
            cube:: Cnode*,
            cube::Cube* cube = NULL,
            std::map<uint64_t, uint64_t>* normalisation_factor = NULL,
            std::vector<uint64_t>* cluster_position = NULL );                                             ///< Merges children of second cnode into the first cnode


void
merge_trees( std:: vector<cube::Cnode*>,
             cube::Cnode* common_parent = NULL,
             cube::Cube* cube = NULL,
             std::map<uint64_t, uint64_t>* normalisation_factor = NULL,
             std::vector<uint64_t>* cluster_position = NULL
             );                                                ///< List of trees is merged onto single one.


void
gather_children( std:: vector<cube::Cnode*> &,
                 cube::Cnode* );                                                ///< Extends vector with the children of cnode



vector<uint64_t>
sort_and_collapse_clusters( vector<uint64_t>& );

map<uint64_t, vector<uint64_t> >
get_cluster_positions( vector<uint64_t>& );
}

#endif
