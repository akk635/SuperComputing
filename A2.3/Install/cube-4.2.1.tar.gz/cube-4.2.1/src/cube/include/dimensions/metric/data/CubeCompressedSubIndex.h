/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 * \file CubeCompressedSubIndex.h
 * \brief Provides an element for the index of the compressed data.
 */

#ifndef __COMPRESSED_SUB_INDEX_H
#define __COMPRESSED_SUB_INDEX_H
namespace cube
{
/**
 *  Index of the compressed Data is a vector of #cnodes elements, every of them describes a compressed row over #threads for given #cnode.
 *  First element is the start position of not compressed buffer. (Usually #cnode * #threads). It grows from element to element.
 *  Second element indicates, when the compressed buffer starts.
 *  Third element saves the size of the compressed buffer.
 *
 *  Element is defined as union of packed structure and byte stream. Byte stream is used to save it into file.
 */
typedef union
{
    struct __attribute__ ( ( __packed__ ) )
    {
        uint64_t start_uncompressed;
        uint64_t start_compressed;
        uint64_t size_compressed;
    } named;
    char as_array[ 1 ];
} SubIndexElement;



/**
 *  For internal data processing, one uses "start_uncompressed" as a key and stores information in the map.
 *
 *  First element is the number of row in the index.
 *  Second element indicates, when the compressed buffer starts.
 *  Third element saves the size of the compressed buffer.
 *
 *  Element is defined as union of packed structure and byte stream. Byte stream is used to save it into file.
 */
typedef union
{
    struct __attribute__ ( ( __packed__ ) )
    {
        uint64_t row_number;
        uint64_t start_compressed;
        uint64_t size_compressed;
    } named;
    char as_array[ 1 ];
} SubIndexInternalElement;
}


#endif
