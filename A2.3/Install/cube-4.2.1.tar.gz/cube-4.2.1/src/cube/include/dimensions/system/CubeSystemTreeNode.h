/****************************************************************************
**  SCALASCA    http://www.scalasca.org/                                   **
**  KOJAK       http://www.fz-juelich.de/jsc/kojak/                        **
*****************************************************************************
**  Copyright (c) 1998-2012                                                **
**  Forschungszentrum Juelich, Juelich Supercomputing Centre               **
**                                                                         **
**  Copyright (c) 2003-2008                                                **
**  University of Tennessee, Innovative Computing Laboratory               **
**                                                                         **
**  See the file COPYRIGHT in the package base directory for details       **
****************************************************************************/

/**
 * \file CubeSystemTreeNode.h
 * \brief Provides a relevant description of a general system tree node.
 */

#ifndef CUBE_SYSTEM_TREE_NODE_H
#define CUBE_SYSTEM_TREE_NODE_H


#include <iosfwd>

#include "CubeSysres.h"
#include "CubeTypes.h"
/*
   *----------------------------------------------------------------------------
 *
 * class Thread
 *
 ******************----------------------------------------------------------------------------
 */


namespace cube
{
// class Process;
class SystemTreeNode;
class LocationGroup;
inline bool
operator==( const SystemTreeNode& a,
            const SystemTreeNode& b );

/**
 * Thread is a basics kind of system resources. It doesn't return any "children"
 */
class SystemTreeNode : public Sysres
{
public:

    SystemTreeNode( const std::string& name,
                    const std::string& desc,
                    const std::string& stn_class,
                    SystemTreeNode*    proc = NULL,
                    uint32_t           id = 0,
                    uint32_t           sysid = 0 )
        : Sysres( ( Sysres* )proc, name, id, sysid ), desc( desc ), stn_class( stn_class )
    {
        own_hash = construct_own_hash();
        kind     = CUBE_SYSTEM_TREE_NODE;
        groups.clear();
    };

    virtual
    ~SystemTreeNode();



    ///< Thread does have a rank.
    SystemTreeNode*
    get_parent() const
    {
        return ( SystemTreeNode* )Vertex::get_parent();
    }


    std::string
    get_desc() const
    {
        return desc;
    }                                            ///< Gets a description of this machine.
    void
    set_desc( std::string newDesc )
    {
        desc = newDesc;
    }

    std::string
    get_class() const
    {
        return stn_class;
    }

    void
    writeXML( std::ostream& out,
              bool          cube3export = false  ) const;    ///< Writes a xml-representation of a thread in a .cube file.

/**
 * Get i-th Thread of this Thread.
 */
    SystemTreeNode*
    get_child( unsigned int i ) const
    {
        return ( SystemTreeNode* )Vertex::get_child( i );
    }



//     virtual bool weakEqual(const Thread * _n)
//     {
//      return (*this) == (*_n);
//     }

    void
    add_location_group( LocationGroup* _lg )
    {
        groups.push_back( _lg );
    };

    LocationGroup*
    get_location_group( unsigned int i ) const
    {
        return ( groups.size() > i ) ? groups[ i ] : NULL;
    }

    std::vector<LocationGroup*>&
    get_groups()
    {
        return groups;
    }


    size_t
    num_groups() const
    {
        return groups.size();
    }

    virtual std::string
    construct_own_hash()
    {
        return stn_class + name;
    };

private:
    std::string                   desc;
    std::string                   stn_class;
    std::vector< LocationGroup* > groups;
};


inline bool
operator==( const SystemTreeNode& a, const SystemTreeNode& b )
{
//     int _a = a.get_id();
//     int _b = b.get_id();
//     return _a == _b;
//     std::string _a = a.get_hash_id();
//     std::string _b = b.get_hash_id();
//     return _a.compare( _b ) == 0;

    std::string _a  = a.get_class();
    std::string _b  = b.get_class();
    std::string __a = a.get_name();
    std::string __b = b.get_name();

    return ( _a.compare( _b ) == 0 ) && ( __a.compare( __b ) == 0 );
}




inline bool
operator<( const SystemTreeNode& a, const SystemTreeNode& b )
{
    int _a = a.get_id();
    int _b = b.get_id();
    return _a < _b;
}


typedef std::pair<SystemTreeNode*, CalculationFlavour> stn_pair;             ///< Used for various calculations
typedef std::vector<stn_pair>                          list_of_stns;         ///< Used to collect a list of threads
}



#endif
