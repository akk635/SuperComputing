/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubeRow.h
 * \brief  Represents a row of values. It stores an object Value, endianess transformation and  and a memory, which is going to be stored in file. It applies endianess transformation, if needed.
 */

#ifndef CUBE_ROW_H
#define CUBE_ROW_H
#include <iostream>

#include "CubeTrafos.h"
#include "CubeValues.h"
#include "CubeRowTypes.h"

namespace cube
{
class Row
{
private:
    /// Pointer on the example of a value, carried by trhe tor
    Value* value;

    /// Number of elements, stored in row.
    uint64_t n;

    /// Pointer on memory, storing data. Used for the upcoming operations "sumRow, getVaue and so on"
    row_t row;


    /// Transformation of endianness
    SingleValueTrafo* endianess;

public:
    Row( size_t _n,
         Value* _v ) :  value( _v ), n( _n )
    {
        endianess = NULL;
        row       = NULL;
    };                                                                                                                                                               // name of file
    ~Row();


    Value*
    getValue()
    {
        return value->clone();
    };                            /// Returns a pointer on used value. Used to get a clone copy of the value for processing

    void
    setPointerToMemory( row_t _row )
    {
        row = _row;
    };                                              /// seting a pointer on memory to use in fwrite or fread*/

    row_t
    getPointerToMemory()
    {
        return row;
    };                                    /// returns a pointer on memory to use in fwrite or fread*/

    void
    correctEndianess( row_t row ); /// applied an endianess transformation on the row.

    void
    setEndianess( SingleValueTrafo* _trafo ); /// to set the endianess

//     void
//     reset( Value*            _v,
//            SingleValueTrafo* _trafo );             /// used to reinitialize internal Trafo and Value. It is adjusted in the case of "read" operation.

    size_t
    getRawRowSize()
    {
        return n * ( value->getSize() );
    }                                                /// returns a full size of a row in bytes

    size_t
    getRowSize()
    {
        return n;
    }                                                    /// returns a size of a row in elements.

    Value*
    sumRow( thread_id_t tid,
            uint64_t    number );             /// summs up the subsequence of elements in a row using algebra of a value.

    void
    setData( Value*,
             thread_id_t tid );        /// sets a value (general)

    void
    setData( double,
             thread_id_t tid );       /// sets a value (double)

    void
    setData( uint64_t, thread_id_t tid ); /// sets a value (uin64_t)

    Value*
    getData( thread_id_t ); /// returns a value (creates a clone copy, should be deleted by an acceptor af a value)


    void
    printRow( std::ostream & );                 ///  prints a content of a row into the strema if row is set

    void
    printRow( row_t, std::ostream & );                           /// Prints a content of any row

    void
    printRawRow( std::ostream & );                 ///  prints a content of a row into the strema if row is set charwise

    void
    printRawRow( row_t, std::ostream & );                           /// Prints a content of any row charwise
};
}

#endif
