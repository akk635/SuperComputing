/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeSignedLongValue.h
 * \brief Provides the "signed long" (64bit) build-in type as "Value"
 ************************************************/
#ifndef __SIGNED_LONG_VALUE_H
#define __SIGNED_LONG_VALUE_H

#include <istream>
#include "CubeValue.h"

#include <iostream>
using namespace std;

namespace cube
{
class SignedLongValue;
extern Preallocator<SignedLongValue> int64_preallocator;


/**
 * Value works with 8 bytes of the signed long as the whole int value, and as 8 bytes (endianess). Therefore it
 * defined a union.
 */
typedef union
{
    int64_t ilValue;
    char    aValue[ sizeof( int64_t ) ];
} il_value_t;

class SignedLongValue : public Value
{
protected:
    il_value_t value;                          /// "heart" of the value.
public:
    SignedLongValue();
//     SignedLongValue( uint16_t );
//     SignedLongValue( int16_t );
//     SignedLongValue( uint32_t );
//     SignedLongValue( int32_t );
//     SignedLongValue( uint64_t );
    SignedLongValue( int64_t );
//     SignedLongValue( double );
//     SignedLongValue( char* );

    virtual
    ~SignedLongValue()
    {
    };
    virtual unsigned
    getSize()
    {
        return sizeof( int64_t );
    }

    inline
    virtual double
    getDouble()
    {
        return ( double )value.ilValue;
    };
    virtual uint16_t
    getUnsignedShort();
    virtual int16_t
    getSignedShort();
    virtual uint32_t
    getUnsignedInt();
    virtual int32_t
    getSignedInt();
    virtual uint64_t
    getUnsignedLong();
    virtual int64_t
    getSignedLong();
    virtual char
    getChar();
    virtual string
    getString();

    virtual char*
    fromStream( char* );
    virtual char*
    toStream( char* );


    inline
    virtual Value*
    clone()
    {
        return new SignedLongValue( 0 );
    }
    inline
    virtual Value*
    copy()
    {
        return new SignedLongValue( value.ilValue );
    }

/*

    virtual SignedLongValue
    operator+( const SignedLongValue& );
    virtual SignedLongValue
    operator-( const SignedLongValue& );*/
    inline
    virtual void
    operator+=( Value* chval )
    {
        if ( chval == NULL )
        {
            return;
        }
        value.ilValue += ( ( SignedLongValue* )chval )->value.ilValue;
    }

    inline
    virtual void
    operator-=( Value* chval )
    {
        if ( chval == NULL )
        {
            return;
        }
        value.ilValue -= ( ( SignedLongValue* )chval )->value.ilValue;
    }

    inline
    virtual void
    operator*=( double dval )
    {
        value.ilValue *= dval;
    }                                 // needed by algebra tools

    inline
    virtual void
    operator/=( double dval )
    {
        if ( dval == 0. )
        {
            cerr << "ERROR: DEVISION BY ZERO!" << endl;
        }
        value.ilValue /= dval;
    }


    void*
    operator new( size_t size );
    void
    operator delete( void* p );


    virtual void
    Free()
    {
        delete ( SignedLongValue* )this;
    }

    virtual void
    operator=( double );

//     virtual void
//     operator=( char );
//     virtual void
//     operator=( uint16_t );
//     virtual void
//     operator=( uint32_t );
//     virtual void
//     operator=( uint64_t );
//     virtual void
//     operator=( int16_t );
//     virtual void
//     operator=( int32_t );
//     virtual void
//     operator=( int64_t );
    virtual void
    operator=( Value* );

//     virtual void
//     operator=( string );
//     virtual SignedLongValue
//     operator=( SignedLongValue );                                /// Assignemnt operator.

    virtual bool
    isZero()
    {
        return value.ilValue == 0L;
    };
    virtual DataType
    myDataType()
    {
        return CUBE_DATA_TYPE_INT64;
    };
    virtual void
    normalizeWithClusterCount( uint64_t );
};
}
#endif
