/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeUnsignedShortValue.h
 * \brief  Provides the "unsigned short" (16bit) build-in type as "Value"
 ************************************************/
#ifndef __UNSIGNED_SHORT_VALUE_H
#define __UNSIGNED_SHORT_VALUE_H

#include <istream>
#include "CubeValue.h"

#include <iostream>
using namespace std;

namespace cube
{
class UnsignedShortValue;
extern Preallocator<UnsignedShortValue> uint16_preallocator;


/**
 * Value works with 2 bytes of the unsigned sort as teh whole int value, and as 2 bytes (endianess). Therefore it
 * defined a union.
 */
typedef union
{
    uint16_t usValue;
    char     aValue[ sizeof( uint16_t ) ];
} us_value_t;

class UnsignedShortValue : public Value
{
protected:
    us_value_t value;                        /// "heart" of the value.
public:
    UnsignedShortValue();
    UnsignedShortValue( uint16_t );
//     UnsignedShortValue( int16_t );
//     UnsignedShortValue( uint32_t );
//     UnsignedShortValue( int32_t );
//     UnsignedShortValue( uint64_t );
//     UnsignedShortValue( int64_t );
//     UnsignedShortValue( double );
//     UnsignedShortValue( char* );

    virtual
    ~UnsignedShortValue()
    {
    };
    inline
    virtual unsigned
    getSize()
    {
        return sizeof( uint64_t );
    }

    inline
    virtual double
    getDouble()
    {
        return ( double )value.usValue;
    };

    virtual uint16_t
    getUnsignedShort();
    virtual int16_t
    getSignedShort();
    virtual uint32_t
    getUnsignedInt();
    virtual int32_t
    getSignedInt();
    virtual uint64_t
    getUnsignedLong();
    virtual int64_t
    getSignedLong();
    virtual char
    getChar();
    virtual string
    getString();

    virtual char*
    fromStream( char* );
    virtual char*
    toStream( char* );

    inline
    virtual Value*
    clone()
    {
        return new UnsignedShortValue( 0 );
    }
    inline
    virtual Value*
    copy()
    {
        return new UnsignedShortValue( value.usValue );
    }

/*
    virtual UnsignedShortValue
    operator+( const UnsignedShortValue& );
    virtual UnsignedShortValue
    operator-( const UnsignedShortValue& );*/

    inline
    virtual void
    operator+=( Value* chval )
    {
        if ( chval == NULL )
        {
            return;
        }
        value.usValue += ( ( UnsignedShortValue* )chval )->value.usValue;
    }

    inline
    virtual void
    operator-=( Value* chval )
    {
        if ( chval == NULL )
        {
            return;
        }
        value.usValue -= ( ( UnsignedShortValue* )chval )->value.usValue;
    }

    inline
    virtual void
    operator*=( double dval )
    {
        value.usValue *= dval;
    }                                 // needed by algebra tools

    inline
    virtual void
    operator/=( double dval )
    {
        if ( dval == 0. )
        {
            cerr << "ERROR: DEVISION BY ZERO!" << endl;
        }
        value.usValue /= dval;
    }


    void*
    operator new( size_t size );
    void
    operator delete( void* p );

    virtual void
    Free()
    {
        delete ( UnsignedShortValue* )this;
    }

    virtual void
    operator=( double );

//     virtual void
//     operator=( char );
//     virtual void
//     operator=( uint16_t );
//     virtual void
//     operator=( uint32_t );
//     virtual void
//     operator=( uint64_t );
//     virtual void
//     operator=( int16_t );
//     virtual void
//     operator=( int32_t );
//     virtual void
//     operator=( int64_t );
    virtual void
    operator=( Value* );

//     virtual void
//     operator=( string );
//     virtual UnsignedShortValue
//     operator=( UnsignedShortValue );                                  /// Assignemnt operator.

    virtual bool
    isZero()
    {
        return value.usValue == 0;
    };

    virtual DataType
    myDataType()
    {
        return CUBE_DATA_TYPE_UINT16;
    };
    virtual void
    normalizeWithClusterCount( uint64_t );
};
}
#endif
