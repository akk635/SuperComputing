/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubeNode.h
 * \brief Describes a node of a machine.
 */

#ifndef CUBE_NODE_H
#define CUBE_NODE_H


#include <iosfwd>

#include "CubeSysres.h"
#include "CubeSystemTreeNode.h"
#include "CubeTypes.h"

/*
   *----------------------------------------------------------------------------
 *
 * class Node
 *
 *********----------------------------------------------------------------------------
 */


namespace cube
{
// class Machine;
// class Process;
// class Node;
// inline bool
// operator==( const Node& a,
//             const Node& b );
//
// /**
//  * Machine containts nodes, nodes contains processes, process contains threads. Heterogen treelike structure.
//  */
// class Node : public SystemTreeNode
// {
// public:
//
//     Node( const std::string& name,
//           Machine*           mach,
//           uint32_t           id = 0,
//           uint32_t           sysid = 0 )
//         :  SystemTreeNode( name, "",  ( SystemTreeNode* )mach,  id, sysid )
//     {
//         own_hash = construct_own_hash();
//         kind     = CUBE_NODE;
//     }
//
// /**
//  * Returns i-th process on this node.
//  */
//     Process*
//     get_child( unsigned int i ) const
//     {
//         return ( Process* )Vertex::get_child( i );
//     }
// /**
//  * Get a machine
//  */
//     Machine*
//     get_parent() const
//     {
//         return ( Machine* )Vertex::get_parent();
//     }
//     void
//     writeXML( std::ostream& out ) const;    ///< Writes a xml-description of this node.
//
// //     virtual bool weakEqual(const Node * _n)
// //     {
// //      return *this == *_n;
// //     }
//     virtual std::string
//     construct_own_hash()
//     {
//         return "node." + name;
//     };
// };
//
// inline bool
// operator==( const Node& a, const Node& b )
// {
//     return a.get_name() == b.get_name();
// }
//

typedef SystemTreeNode                       Node;
typedef std::pair<Node*, CalculationFlavour> node_pair;       ///< Used for calculation of various values.
typedef std::vector<node_pair>               list_of_nodes;   ///< Used to collect a list of nodes
}


#endif
