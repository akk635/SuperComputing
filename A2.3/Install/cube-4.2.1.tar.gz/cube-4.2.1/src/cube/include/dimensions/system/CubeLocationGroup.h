/****************************************************************************
**  SCALASCA    http://www.scalasca.org/                                   **
**  KOJAK       http://www.fz-juelich.de/jsc/kojak/                        **
*****************************************************************************
**  Copyright (c) 1998-2012                                                **
**  Forschungszentrum Juelich, Juelich Supercomputing Centre               **
**                                                                         **
**  Copyright (c) 2003-2008                                                **
**  University of Tennessee, Innovative Computing Laboratory               **
**                                                                         **
**  See the file COPYRIGHT in the package base directory for details       **
****************************************************************************/

/**
 * \file CubeLocationGroup.h
 * \brief Provides a relevant description of a locations group.
 */

#ifndef CUBE_LOCATION_GROUP_H
#define CUBE_LOCATION_GROUP_H


#include <iosfwd>
#include <iostream>

#include "CubeSysres.h"
#include "CubeLocation.h"
#include "CubeSystemTreeNode.h"
#include "CubeTypes.h"
#include "CubeError.h"
/*
   *----------------------------------------------------------------------------
 *
 * class Thread
 *
 ********************----------------------------------------------------------------------------
 */


namespace cube
{
typedef enum LocationGroupType { CUBE_LOCATION_GROUP_TYPE_PROCESS = 0,
                                 CUBE_LOCATION_GROUP_TYPE_METRICS = 1 }
LocationGroupType;



// class Process;
// class LocationGroup;
// class Location;
// class SystemTreeNode;
inline bool
operator==( const LocationGroup& a,
            const LocationGroup& b );

/**
 * Thread is a basics kind of system resources. It doesn't return any "children"
 */
class LocationGroup : public Sysres
{
public:

    LocationGroup( const std::string& name,
                   SystemTreeNode*    stn,
                   int                rank,
                   LocationGroupType  type = cube::CUBE_LOCATION_GROUP_TYPE_PROCESS,
                   uint32_t           id = 0,
                   uint32_t           sysid = 0 )
        : Sysres( name, id, sysid ), rank( rank ), type( type )
    {
        own_hash = construct_own_hash();
        kind     = CUBE_LOCATION_GROUP;
        parent   = stn;
        if ( stn != NULL )
        {
            stn->add_location_group( this );
        }
        else
        {
            throw RuntimeError( "Location Group cannot hav as a parent NULL system tree node." );
        }
    }
    ///< Thread does have a rank.
    int
    get_rank() const
    {
        return rank;
    }

    std::string
    get_type_as_string() const;

    LocationGroupType
    get_type() const
    {
        return type;
    }


    SystemTreeNode*
    get_parent() const
    {
        return ( SystemTreeNode* )Vertex::get_parent();
    }
    void
    writeXML( std::ostream& out,
              bool          cube3export = false  ) const;    ///< Writes a xml-representation of a thread in a .cube file.




/**
 * Get i-th Thread of this Thread.
 */
    Location*
    get_child( unsigned int i ) const
    {
        return ( Location* )Vertex::get_child( i );
    }


    /// returns treu, if ids of all children are gapless monoton increasing. Used on the calculation optimisation
    bool
    isContinous()
    {
        return false;
    }

//     virtual bool weakEqual(const Thread * _n)
//     {
//      return (*this) == (*_n);
//     }
    virtual std::string
    construct_own_hash();


    static
    LocationGroupType
    getLocationGroupType( std::string );

private:
    int               rank;
    LocationGroupType type;
};


inline bool
operator==( const LocationGroup& a, const LocationGroup& b )
{
    int         _a  = a.get_rank();
    int         _b  = b.get_rank();
    std::string __a = a.get_name();
    std::string __b = b.get_name();

    return ( _a == _b ) && ( __a.compare( __b ) == 0 );
}




inline bool
operator<( const LocationGroup& a, const LocationGroup& b )
{
    int _a = a.get_rank();
    int _b = b.get_rank();
    return _a < _b;
}


typedef std::pair<LocationGroup*, CalculationFlavour> loc_group_pair;             ///< Used for various calculations
typedef std::vector<loc_group_pair>                   list_of_location_groups;    ///< Used to collect a list of threads
}



#endif
