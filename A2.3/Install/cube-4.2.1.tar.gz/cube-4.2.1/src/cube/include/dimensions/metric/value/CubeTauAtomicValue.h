/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 * \file CubeTauAtomicValue.h
 * \brief Provide a value for atomic metric of Tau.
 *
 * It saves an int N, MinDouble, MaxDouble and two doubles (\f$ \sum_i^N {x_i} \f$ and \f$ \sum_i^N x_i^2 \f$) for calculation of mean and variance. Values have to be exclusive.
 *
 *
 */

#ifndef __TAU_ATOMIC_VALUE_H
#define __TAU_ATOMIC_VALUE_H

#include <istream>

#include <cstring>
#include <string>
#include <iostream>
#include "CubeValues.h"
#include "CubeTrafos.h"
using namespace std;


namespace cube
{
class TauAtomicValue;
extern Preallocator<TauAtomicValue> tau_preallocator;


/**
 *  The TAU value for atomic metrics. NOT TESTED
 */
class TauAtomicValue : public Value
{
private:
    double Average;                                                                ///< Saves a average value, calculated like \$ \frac{Sum}{N}. \$ Is not saved in file, but calculated always on the fly.
    double Variance;                                                               ///< Saved the variance calculated like \$ (N=0)?0: \sqrt{ \frac{1}{N-1}( Sum2 - \frac{Sum \times Sum}{N}  )}\$. Is not saved in file, but calculated always on the fly.
    void
    calcAvgVar();                                                                  ///< Performs the calcualtion of Average and Variance;

protected:
    UnsignedValue  N;
    MinDoubleValue MinValue;
    MaxDoubleValue MaxValue;
    DoubleValue    Sum;
    DoubleValue    Sum2;



public:
    TauAtomicValue();
    TauAtomicValue( uint32_t,
                    double,
                    double,
                    double,
                    double );
//     TauAtomicValue( char* );

    virtual
    ~TauAtomicValue()
    {
    };                                                                 ///< Vitual destructor allows, that every inherited class destroy itself properly.
    inline
    virtual unsigned
    getSize()
    {
        return
            N.getSize() +
            MinValue.getSize() +
            MaxValue.getSize() +
            Sum.getSize() +
            Sum2.getSize();
    }
    virtual double
    getDouble()
    {
        calcAvgVar();
        return Average;
    }                                                    ///< Returns the double representation of itself, if possible.
    virtual uint16_t
    getUnsignedShort();                                  ///< Returns the unsigned 16bit representation of itself, if possible.
    virtual int16_t
    getSignedShort();                                    ///< Returns the signed 16bit representation of itself, if possible.
    virtual uint32_t
    getUnsignedInt();                                    ///< Returns the unsigned 32bit representation of itself, if possible.
    virtual int32_t
    getSignedInt();                                      ///< Returns the signed 32bit representation of itself, if possible.
    virtual uint64_t
    getUnsignedLong();                                   ///< Returns the unsigned 64bit representation of itself, if possible.
    virtual int64_t
    getSignedLong();                                     ///< Returns the signed 64bit representation of itself, if possible.
    virtual char
    getChar();                                           ///< Returns the single byte representation of itself, if possible.
    virtual string
    getString();                                         ///< Returns the textual representation of itself, if possible. Used to save itself in Cube3 format.

    virtual UnsignedValue
    getN()
    {
        return N;
    };
    virtual MinDoubleValue
    getMinValue()
    {
        return MinValue;
    };
    virtual MaxDoubleValue
    getMaxValue()
    {
        return MaxValue;
    };
    virtual DoubleValue
    getSum()
    {
        return Sum;
    };
    virtual DoubleValue
    getSum2()
    {
        return Sum2;
    };



    virtual char*
    fromStream( char* );                                                        ///< Constructs itself from the stream. The first stream byte used as starting point.
    virtual char*
    toStream( char* );                                                          ///< Write to the stream the stream-representation of itself. The first stream byte used as starting point.
    virtual char*
    transformStream( char*,
                     SingleValueTrafo* );                                           ///< Applyes the transformation on the stream according to its layout. Used to deal with different endianess. Needed for comples types with non trivial layout.

    inline
    virtual Value*
    clone()
    {
        return new TauAtomicValue();
    }
    inline
    virtual Value*
    copy()
    {
        return new TauAtomicValue( N.getUnsignedInt(), MinValue.getDouble(), MaxValue.getDouble(), Sum.getDouble(), Sum2.getDouble() );
    }                                                                   ///< Makes a copy of itself and keeps the value.
/*

    virtual TauAtomicValue
    operator+( const TauAtomicValue& );
    virtual TauAtomicValue
    operator-( const TauAtomicValue& );*/


    inline
    virtual void
    operator+=( Value* chval )
    {
        if ( chval == NULL )
        {
            return;
        }
        N        += ( ( Value* )( &( ( ( TauAtomicValue* )chval )->N ) ) );
        MinValue += ( ( Value* )( &( ( ( TauAtomicValue* )chval )->MinValue ) ) );
        MaxValue += ( ( Value* )( &( ( ( TauAtomicValue* )chval )->MaxValue ) ) );
        Sum      += ( ( Value* )( &( ( ( TauAtomicValue* )chval )->Sum ) ) );
        Sum2     += ( ( Value* )( &( ( ( TauAtomicValue* )chval )->Sum2 ) ) );
    }

    inline
    virtual void
    operator-=( Value* chval )
    {
        if ( chval == NULL )
        {
            return;
        }
        N        -= ( ( Value* )( &( ( ( TauAtomicValue* )chval )->N ) ) );
        MinValue -= ( ( Value* )( &( ( ( TauAtomicValue* )chval )->MinValue ) ) );
        MaxValue -= ( ( Value* )( &( ( ( TauAtomicValue* )chval )->MaxValue ) ) );
        Sum      -= ( ( Value* )( &( ( ( TauAtomicValue* )chval )->Sum ) ) );
        Sum2     -= ( ( Value* )( &( ( ( TauAtomicValue* )chval )->Sum2 ) ) );
    }

    inline
    virtual void
    operator*=( double dval )
    {
        N        *= dval;
        MinValue *= dval;
        MaxValue *= dval;
        Sum      *= dval;
        Sum2     *= dval;
    }                                 // needed by algebra tools

    inline
    virtual void
    operator/=( double dval )
    {
        if ( dval == 0. )
        {
            cerr << "ERROR: DEVISION BY ZERO!" << endl;
        }
        N        /= dval;
        MinValue /= dval;
        MaxValue /= dval;
        Sum      /= dval;
        Sum2     /= dval;
    }

    void*
    operator new( size_t size );
    void
    operator delete( void* p );

    virtual void
    Free()
    {
        delete ( TauAtomicValue* )this;
    }

    virtual void
    operator=( double );                                     ///< Allows to assign its value from the build in double.

//     virtual void
//     operator=( char );                                       ///< Allows to assign its value from the build in char.
//     virtual void
//     operator=( uint16_t );                                   ///< Allows to assign its value from the build in unsigned 16bit value (short int).
//     virtual void
//     operator=( uint32_t );                                   ///< Allows to assign its value from the build in unsigned 32bit value (int).
//     virtual void
//     operator=( uint64_t );                                   ///< Allows to assign its value from the build in unsigned 64bit value (long int).
//     virtual void
//     operator=( int16_t );                                    ///< Allows to assign its value from the build in signed 16bit value (short int).
//     virtual void
//     operator=( int32_t );                                    ///< Allows to assign its value from the build in signed 32bit value (int).
//     virtual void
//     operator=( int64_t );                                    ///< Allows to assign its value from the build in signed 64bit value (long int).
    virtual void
    operator=( Value* );                                     ///< Allows to assign its value from another object of same type. [WARNING, real type is not checked]

//     virtual void
//     operator=( string );                                     ///< Allows to assign its value from the string, if possible.
//     virtual TauAtomicValue
//     operator=( TauAtomicValue );                             /// Assignemnt operator.

    virtual bool
    isZero()
    {
        return Sum.isZero() && Sum2.isZero() && MinValue.isZero() && MaxValue.isZero() && N.isZero();
    };

    virtual bool
    asInclusiveMetric()
    {
        return false;
    }

    virtual DataType
    myDataType()
    {
        return CUBE_DATA_TYPE_TAU_ATOMIC;
    };                                                   // not supported yet
    virtual void
    normalizeWithClusterCount( uint64_t );
};
}



#endif
