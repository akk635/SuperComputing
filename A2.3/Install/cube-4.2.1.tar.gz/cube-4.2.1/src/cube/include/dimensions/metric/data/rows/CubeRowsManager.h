/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubeRowsManager.h
 * \brief  Provides a consistent state of map<int, char*> rows[]. It performs loading/unloading, caching, swapping and so on.
 */

#ifndef CUBE_ROWS_MANAGER_H
#define CUBE_ROWS_MANAGER_H

#include "CubeTrafos.h"
#include "CubeValues.h"
#include "CubeIndexes.h"
#include "CubeIndexManager.h"
#include "CubeStrategies.h"
#include "CubeRowsSuppliers.h"
#include "CubeRowTypes.h"
#include "CubeRow.h"

namespace cube
{
class RowsManager
{
private:
    ///srsPData container, storing the data rows ,
    rows_t* rows;

    /// a pointer got from RowWiseMatrix, signalizing that some row is "absent" row and shouldn't bew deleted
    row_t no_row_pointer;

    /// Strategy to drop/load rows
    BasicStrategy* strategy;

    /// Pointer on the row interface
    Row* row;

    /// Rows Supplier: acts like memory manager, it delivers a row either from memory or from swap file.
    RowsSupplier* row_supplier;



    RowsSupplier*
    selectRowsSupplier( fileplace_t DataPlace,
                        fileplace_t IndexPlace, uint64_t, uint64_t );


public:
    RowsManager( fileplace_t DataPlace,
                 fileplace_t IndexPlace,
                 IndexFormat,
                 rows_t*,
                 Row*,
                 BasicStrategy*,
                 row_t       no_row_pointer = NULL
                 );                                                                                                                                    // name of file
    RowsManager( fileplace_t DataPlace,
                 fileplace_t IndexPlace,
                 rows_t*,
                 Row*,
                 BasicStrategy*,
                 row_t       no_row_pointer = NULL
                 );                                                                                                                       // name of file
    virtual
    ~RowsManager();


    void
    setStrategy( BasicStrategy* _str, bool release = false )
    {
        if ( release )
        {
            delete strategy;
        }
        strategy = _str;
        strategy->initialize( rows );
    };

    void
    provideRows( std::vector<cnode_id_t>&,
                 bool for_writing = false  );

    void
    provideRow( cnode_id_t&,
                bool for_writing = false );

    void
    dropAllRows();

    void
    dropRows( std::vector<cnode_id_t>& );

    void
    dropRow( cnode_id_t & );

    void
    finalize();                         ///< initiates writing on disk
};
}

#endif
