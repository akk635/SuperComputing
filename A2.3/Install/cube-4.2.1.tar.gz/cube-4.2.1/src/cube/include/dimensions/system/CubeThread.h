/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubeThread.h
 * \brief Provides a relevant description of a thread.
 */

#ifndef CUBE_THREAD_H
#define CUBE_THREAD_H


#include <iosfwd>
#include <iostream>

#include "CubeSysres.h"
#include "CubeLocation.h"
#include "CubeTypes.h"
/*
   *----------------------------------------------------------------------------
 *
 * class Thread
 *
 *********----------------------------------------------------------------------------
 */

namespace cube
{
// class Process;
// class Thread;
// inline bool
// operator==( const Thread& a,
//             const Thread& b );
//
// /**
//  * Thread is a basics kind of system resources. It doesn't return any "children"
//  */
// class Thread : public Location
// {
// public:
//
//     Thread( const std::string& name,
//             int                rank,
//             Process*           proc,
//             uint32_t           id = 0,
//             uint32_t           sysid = 0 )
//         : Location( name, rank,  ( LocationGroup* )proc, id, sysid )
//     {
//         own_hash = construct_own_hash();
//         kind     = CUBE_THREAD;
//     }
//
//     int
//     get_rank() const
//     {
//         return rank;
//     }                                     ///< Thread does have a rank.
//     Process*
//     get_parent() const
//     {
//         return ( Process* )Vertex::get_parent();
//     }                                       ///< Thread belongs always to some process.
//     void
//     writeXML( std::ostream& out ) const;    ///< Writes a xml-representation of a thread in a .cube file.
//
// /**
//  * Get i-th Thread of this Thread.
//  */
//     Thread*
//     get_child( unsigned int i ) const
//     {
//         return ( Thread* )Vertex::get_child( i );
//     }
//
// //     virtual bool weakEqual(const Thread * _n)
// //     {
// //      return (*this) == (*_n);
// //     }
//     virtual std::string
//     construct_own_hash();
//
// private:
//
//     int rank;
// };
//
//
// inline bool
// operator==( const Thread& a, const Thread& b )
// {
//     int _a = a.get_rank();
//     int _b = b.get_rank();
//     return _a == _b;
// }
//
//
//
//
// inline bool
// operator<( const Thread& a, const Thread& b )
// {
//     int _a = a.get_rank();
//     int _b = b.get_rank();
//     return _a < _b;
// }
//

typedef Location                               Thread;
typedef std::pair<Thread*, CalculationFlavour> thread_pair;             ///< Used for various calculations
typedef std::vector<thread_pair>               list_of_threads;         ///< Used to collect a list of threads
}




#endif
