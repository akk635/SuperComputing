/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeScaleFuncValue.h
 * \brief  Provides the "scaling function value" as a symbolic functoiun of the form "a * ln (x)^b * x^c "
 ************************************************/
#ifndef __SCALE_FUNC_VALUE_H
#define __SCALE_FUNC_VALUE_H

#include <istream>
#include "CubeValue.h"

#include <iostream>
using namespace std;

namespace cube
{
class ScaleFuncValue;
extern Preallocator<ScaleFuncValue> scale_func_preallocator;


/**
 * Value represents a term of the scaling behaviour.
 */


class ScaleFuncValue : public NDoublesValue
{
private:
    std::pair<unsigned, unsigned>
    get_powers( unsigned );

public:
    ScaleFuncValue();
    ScaleFuncValue( double* );
    virtual
    ~ScaleFuncValue()
    {
    };
    virtual double
    getDouble();
    virtual uint16_t
    getUnsignedShort();
    virtual int16_t
    getSignedShort();
    virtual uint32_t
    getUnsignedInt();
    virtual int32_t
    getSignedInt();
    virtual uint64_t
    getUnsignedLong();
    virtual int64_t
    getSignedLong();
    virtual char
    getChar();
    virtual string
    getString();

    virtual Value*
    clone();
    virtual Value*
    copy();

    void*
    operator new( size_t size );
    void
    operator delete( void* p );


    virtual void
    Free()
    {
        delete ( ScaleFuncValue* )this;
    }

    using NDoublesValue::operator=;
    virtual ScaleFuncValue
    operator=( ScaleFuncValue );                            /// Assignemnt operator.

    virtual DataType
    myDataType()
    {
        return CUBE_DATA_TYPE_SCALE_FUNC;
    };
};
}
#endif
