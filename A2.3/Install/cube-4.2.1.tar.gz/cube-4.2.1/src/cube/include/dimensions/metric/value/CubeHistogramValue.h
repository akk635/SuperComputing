/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeHistogramValue.h
 * \brief  Provides the experimental value, savinng a histogram.
 ************************************************/
#ifndef __HISTOGRAM_VALUE_H
#define __HISTOGRAM_VALUE_H

#include <istream>
#include "CubeNDoublesValue.h"

#include <iostream>
using namespace std;

namespace cube
{
class HistogramValue;
extern Preallocator<HistogramValue> histogram_preallocator;

class HistogramValue : public NDoublesValue
{
protected:

public:
    HistogramValue();
    HistogramValue( uint64_t );
//                                 HistogramValue(double);
    HistogramValue( uint64_t,
                    double* );

    virtual
    ~HistogramValue()
    {
    };
    virtual Value*
    clone();
    virtual Value*
    copy();

    void*
    operator new( size_t size );
    void
    operator delete( void* p );


    virtual void
    Free()
    {
        delete ( HistogramValue* )this;
    }

//     virtual HistogramValue
//     operator+( const HistogramValue& );
//     virtual HistogramValue
//     operator-( const HistogramValue& );
//     virtual HistogramValue
//     operator=( HistogramValue );                               /// Assignemnt operator.

    using NDoublesValue::operator+=;
    using NDoublesValue::operator-=;
    using NDoublesValue::operator=;
    virtual DataType
    myDataType()
    {
        return CUBE_DATA_TYPE_NONE;
    };                                             // not supported yet
    virtual void
    normalizeWithClusterCount( uint64_t );
};
}
#endif
