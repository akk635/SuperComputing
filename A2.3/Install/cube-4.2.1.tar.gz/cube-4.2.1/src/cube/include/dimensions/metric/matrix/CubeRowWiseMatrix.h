/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubeRowWiseMatrix.h
 * \brief  Provides a variante of the Matix, which holds values rowwise in memory and uses different strategies for caching. Matrix doesn't care about caching, and loading, but assumes, that rows[] is contains at any  time needed rows for calculations. RowsManager d
   assures the consistent state of rows[], performig load-unload, swaping , droping, row allocations.
 */

#ifndef __ROWWISE_MATRIX_H
#define __ROWWISE_MATRIX_H

#include "CubeAdvMatrix.h"
#include "CubeTrafos.h"
#include "CubeValues.h"
#include "CubeIndexes.h"
// #include "CubeData.h"
#include "CubeIndexManager.h"
#include "CubeFileFinder.h"
#include "CubeStrategies.h"
#include "CubeRowTypes.h"
#include "CubeRow.h"
#include "CubeRowsManager.h"

namespace cube
{
/**
 * Keeps all values in the couple "index-data". Index provides transformation (cnode_id, thread_id)-> position in "data" in terms of  "Value"
 * Data delivers or saves. the "Value" on "position".
 * IndexManager reads the header of the index file and decides, which kind(dense, sparse) of index is really used and which kind of data is used(continues, paged, compressed and so on).
 */
class RowWiseMatrix : public advMatrix
{
private:
    /// Object containing the data.
//     Data*                 data;
    /// Object, which provides tha transformation (cnode_id, thread_id) -> position in the "Data"
    Index* index;
    /// Reads the header of .index file, creates corresponding Index object, Value object, Trafo object (die deal with endianess) and delivers the sizes of matricies (#cnodes x #trreads).
//     IndexManager* manager;
    /// The memory limit, which defines, whether incremental reading via PagedData wil be applied or no.
//     static const uint64_t MemorySize =      1024lu * 1024lu * 1024lu * 1lu;
    string indexfile;
    string datafile;

    /// Data container, storing the data rows
    rows_t rows;

    /// an artificial pointer, which is used to signalize that some row is missing in the cube file and "default" value should be used
    char* _no_row_pointer;

    /// An object, acting like an interface for any access to the memory rows[i].
    Row* row_interface;

    /// Pointer to the caching strategy (used, if no external strategies set)
    BasicStrategy* strategy;

    /// Pointer to the row supplier : it provides a consistent state of rows[] according some.It get a poiner on "rows", but doesn not delete it.
    RowsManager* rows_manager;

public:
    RowWiseMatrix( fileplace_t,
                   fileplace_t,
                   thread_id_t,
                   DataType,
                   BasicStrategy* );                                                        // name of file
    RowWiseMatrix( fileplace_t,
                   fileplace_t,
                   thread_id_t,
                   DataType,
                   IndexFormat,
                   BasicStrategy* );                                                                  // name of file

    RowWiseMatrix( fileplace_t,
                   fileplace_t,
                   thread_id_t,
                   DataType );                                                        // name of file
    RowWiseMatrix( fileplace_t,
                   fileplace_t,
                   thread_id_t,
                   DataType,
                   IndexFormat );                                                                  // name of file



    virtual
    ~RowWiseMatrix();


    void
    setStrategy( CubeStrategy strategy );

    void
    setStrategy( BasicStrategy* _str )
    {
        if ( strategy != NULL )
        {
            delete strategy;
        }
        strategy = _str;
        rows_manager->setStrategy( _str );
    };


    void
    dropRow( cnode_id_t id );

    virtual void
    writeData();

    virtual Value* getValue( cnode_id_t, thread_id_t );
    virtual void   setValue( Value *, cnode_id_t, thread_id_t );
    virtual void   setValue( double, cnode_id_t, thread_id_t );
    virtual void   setValue( uint64_t, cnode_id_t, thread_id_t );
    virtual Value*
    getValue()
    {
        return row_interface->getValue();
    };

    virtual Value* sumRow( cnode_id_t, thread_id_t, uint64_t );

    virtual void
    writeXML( std::ostream& out );
};
}

#endif
