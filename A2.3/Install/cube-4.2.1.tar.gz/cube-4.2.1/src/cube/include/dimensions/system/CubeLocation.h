/****************************************************************************
**  SCALASCA    http://www.scalasca.org/                                   **
**  KOJAK       http://www.fz-juelich.de/jsc/kojak/                        **
*****************************************************************************
**  Copyright (c) 1998-2012                                                **
**  Forschungszentrum Juelich, Juelich Supercomputing Centre               **
**                                                                         **
**  Copyright (c) 2003-2008                                                **
**  University of Tennessee, Innovative Computing Laboratory               **
**                                                                         **
**  See the file COPYRIGHT in the package base directory for details       **
****************************************************************************/

/**
 * \file CubeLocation.h
 * \brief Provides a relevant description of a location.
 */

#ifndef CUBE_LOCATION_H
#define CUBE_LOCATION_H


#include <iosfwd>

#include "CubeSysres.h"
#include "CubeTypes.h"
/*
   *----------------------------------------------------------------------------
 *
 * class Thread
 *
 *********----------------------------------------------------------------------------
 */


namespace cube
{
typedef enum LocationType { CUBE_LOCATION_TYPE_CPU_THREAD = 0,
                            CUBE_LOCATION_TYPE_GPU        = 1,
                            CUBE_LOCATION_TYPE_METRIC     = 2 }
LocationType;

// class Process;
class Location;
class LocationGroup;
// class SystemTreeNode;
inline bool
operator==( const Location& a,
            const Location& b );

/**
 * Thread is a basics kind of system resources. It doesn't return any "children"
 */
class Location : public Sysres
{
public:

    Location( const std::string& name,
              int                rank,
              LocationGroup*     proc,
              LocationType       type = cube::CUBE_LOCATION_TYPE_CPU_THREAD,
              uint32_t           id = 0,
              uint32_t           sysid = 0 );
    ///< Thread does have a rank.
    int
    get_rank() const
    {
        return rank;
    }
    std::string
    get_type_as_string() const;

    LocationType
    get_type() const
    {
        return type;
    }

    LocationGroup*
    get_parent() const
    {
        return ( LocationGroup* )Vertex::get_parent();
    }
    void
    writeXML( std::ostream& out,
              bool          cube3export = false  ) const;  ///< Writes a xml-representation of a thread in a .cube file.

//     virtual bool weakEqual(const Thread * _n)
//     {
//      return (*this) == (*_n);
//     }
    virtual std::string
    construct_own_hash();


    static
    LocationType
    getLocationType( std::string );



private:
    int          rank;
    LocationType type;
};


inline bool
operator==( const Location& a, const Location& b )
{
    int _a = a.get_rank();
    int _b = b.get_rank();
    return _a == _b;
}




inline bool
operator<( const Location& a, const Location& b )
{
    int _a = a.get_rank();
    int _b = b.get_rank();
    return _a < _b;
}


typedef std::pair<Location*, CalculationFlavour> loc_pair;             ///< Used for various calculations
typedef std::vector<loc_pair>                    list_of_location;     ///< Used to collect a list of threads
}



#endif
