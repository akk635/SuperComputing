/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeSignedShortValue.h
 * \brief   Provides the "signed short" (16bit) build-in type as "Value"
 ************************************************/
#ifndef __SIGNED_SHORT_VALUE_H
#define __SIGNED_SHORT_VALUE_H

#include <istream>
#include "CubeValue.h"

#include <iostream>
using namespace std;

namespace cube
{
class SignedShortValue;
extern Preallocator<SignedShortValue> int16_preallocator;

/**
 * Value works with 2 bytes of the signed sort as teh whole int value, and as 2 bytes (endianess). Therefore it
 * defined a union.
 */
typedef union
{
    int16_t isValue;
    char    aValue[ sizeof( int16_t ) ];
} is_value_t;

class SignedShortValue : public Value
{
protected:
    is_value_t value;                        /// "heart" of the value.
public:
    SignedShortValue();
//     SignedShortValue( uint16_t );
    SignedShortValue( int16_t );
//     SignedShortValue( uint32_t );
//     SignedShortValue( int32_t );
//     SignedShortValue( uint64_t );
//     SignedShortValue( int64_t );
//     SignedShortValue( double );
//     SignedShortValue( char* );

    virtual
    ~SignedShortValue()
    {
    };

    inline
    virtual unsigned
    getSize()
    {
        return sizeof( int16_t );
    }

    inline
    virtual double
    getDouble()
    {
        return ( double )value.isValue;
    };
    virtual uint16_t
    getUnsignedShort();
    virtual int16_t
    getSignedShort();
    virtual uint32_t
    getUnsignedInt();
    virtual int32_t
    getSignedInt();
    virtual uint64_t
    getUnsignedLong();
    virtual int64_t
    getSignedLong();
    virtual char
    getChar();
    virtual string
    getString();

    virtual char*
    fromStream( char* );
    virtual char*
    toStream( char* );

    inline
    virtual Value*
    clone()
    {
        return new SignedShortValue( 0 );
    }
    inline
    virtual Value*
    copy()
    {
        return new SignedShortValue( value.isValue );
    }

//     virtual SignedShortValue
//     operator+( const SignedShortValue& );
//     virtual SignedShortValue
//     operator-( const SignedShortValue& );

    inline
    virtual void
    operator+=( Value* chval )
    {
        if ( chval == NULL )
        {
            return;
        }
        value.isValue += ( ( SignedShortValue* )chval )->value.isValue;
    }

    inline
    virtual void
    operator-=( Value* chval )
    {
        if ( chval == NULL )
        {
            return;
        }
        value.isValue -= ( ( SignedShortValue* )chval )->value.isValue;
    }

    inline
    virtual void
    operator*=( double dval )
    {
        value.isValue *= dval;
    }                                 // needed by algebra tools

    inline
    virtual void
    operator/=( double dval )
    {
        if ( dval == 0. )
        {
            cerr << "ERROR: DEVISION BY ZERO!" << endl;
        }
        value.isValue /= dval;
    }

    void*
    operator new( size_t size );
    void
    operator delete( void* p );

    virtual void
    Free()
    {
        delete ( SignedShortValue* )this;
    }


    virtual void
    operator=( double );

//     virtual void
//     operator=( char );
//     virtual void
//     operator=( uint16_t );
//     virtual void
//     operator=( uint32_t );
//     virtual void
//     operator=( uint64_t );
//     virtual void
//     operator=( int16_t );
//     virtual void
//     operator=( int32_t );
//     virtual void
//     operator=( int64_t );
    virtual void
    operator=( Value* );

//     virtual void
//     operator=( string );
//     virtual SignedShortValue
//     operator=( SignedShortValue );                                /// Assignemnt operator.

    virtual bool
    isZero()
    {
        return value.isValue == 0;
    };

    virtual DataType
    myDataType()
    {
        return CUBE_DATA_TYPE_INT16;
    };
    virtual void
    normalizeWithClusterCount( uint64_t );
};
}
#endif
