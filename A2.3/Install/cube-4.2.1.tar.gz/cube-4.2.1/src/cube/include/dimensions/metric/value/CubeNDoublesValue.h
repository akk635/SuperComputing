/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeNDoublesValue.h
 * \brief  Provides the experimental complex value, consisting of N "DoubleValue"'s. Needed for future to support atomic events.
 ************************************************/
#ifndef __NDOUBLES_VALUE_H
#define __NDOUBLES_VALUE_H

#include <istream>
#include <stdlib.h>
#include "CubeError.h"
#include "CubeValues.h"

#include <iostream>
using namespace std;

namespace cube
{
class NDoublesValue;
extern Preallocator<NDoublesValue> ndoubles_preallocator;

class NDoublesValue : public Value
{
protected:
    UnsignedLongValue N;                       /// Number of values.
    DoubleValue**     values;                  /// "heart" of the value.


public:
    NDoublesValue();
    NDoublesValue( uint64_t );
//                                 NDoublesValue(double);
    NDoublesValue( uint64_t,
                   double* );

    virtual
    ~NDoublesValue()
    {
        for ( unsigned i = 0; i < N.getUnsignedLong(); i++ )
        {
            delete values[ i ];
        }
        delete[] values;
    }
    inline
    virtual unsigned
    getSize()
    {
        return ( N.getUnsignedLong() == 0 ) ? 0 : N.getUnsignedLong() * ( values[ 0 ]->getSize() );
    }

    inline
    virtual double
    getDouble()
    {
        return 0.;
    }
    virtual uint16_t
    getUnsignedShort();
    virtual int16_t
    getSignedShort();
    virtual uint32_t
    getUnsignedInt();
    virtual int32_t
    getSignedInt();
    virtual uint64_t
    getUnsignedLong();
    virtual int64_t
    getSignedLong();
    virtual char
    getChar();
    virtual string
    getString();
    virtual DoubleValue
    getValue( unsigned idx );

    virtual char*
    fromStream( char* );
    virtual char*
    toStream( char* );
    virtual char*
    transformStream( char*,
                     SingleValueTrafo* );

    inline
    virtual Value*
    clone()
    {
        return new NDoublesValue( N.getUnsignedLong() );
    }
    virtual Value*
    copy();

/*
    virtual NDoublesValue
    operator+( const NDoublesValue& );
    virtual NDoublesValue
    operator-( const NDoublesValue& );*/

    virtual void
    operator+=( Value* );
    virtual void
    operator-=( Value* );
    virtual void
    operator*=( double );                            // needed by algebra tools
    virtual void
    operator/=( double );                            // needed by algebra tools

    void*
    operator new( size_t size );
    void
    operator delete( void* p );


    virtual void
    Free()
    {
        delete ( NDoublesValue* )this;
    }

    virtual void
    operator=( double );

//     virtual void
//     operator=( char );
//     virtual void
//     operator=( uint16_t );
//     virtual void
//     operator=( uint32_t );
//     virtual void
//     operator=( uint64_t );
//     virtual void
//     operator=( int16_t );
//     virtual void
//     operator=( int32_t );
//     virtual void
//     operator=( int64_t );
    virtual void
    operator=( Value* );

//     virtual void
//     operator=( string );
//     virtual NDoublesValue
//     operator=( NDoublesValue );                              /// Assignemnt operator.

    virtual bool
    isZero();                        // faked check. Should be fixed if NDoubles get to use in cube.

    virtual DataType
    myDataType()
    {
        return CUBE_DATA_TYPE_NONE;
    };                                             // not supported yet
    virtual void
    normalizeWithClusterCount( uint64_t );
};
}
#endif
