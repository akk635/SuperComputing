/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 * \file CubePreallocator.h
 * \brief Provide a general preallocator of any Cube4 value.
 *
 *
 */

#ifndef __PREALLOCATOR_H
#define __PREALLOCATOR_H

#include <iostream>
#include <vector>
using namespace std;


namespace cube
{
template<typename T>
class Preallocator
{
protected:
    uint32_t        current_index;
    std::vector<T*> pool;
//     uint32_t        max_index;
//     uint32_t        num_up;
//     uint32_t        num_down;
public:
    Preallocator<T>( uint32_t size = 1000 );
    ~Preallocator<T>();
    T*
    Get();
    void
    Put( T* );
};



template<typename T>
inline
Preallocator<T>::Preallocator( uint32_t _size )
{
    pool.resize( _size );
    for ( uint64_t i = 0; i < _size; i++ )
    {
        pool[ i ] = ( ::new T() );
    }
    current_index = 0;
//     max_index     = 0;
//     num_down      = 0;
//     num_up        = 0;
}



template<typename T>
inline
Preallocator<T>::~Preallocator()
{
//     cout << " Statistics: " << pool.size() << " " << max_index << " " << num_up << " " << num_down << endl;
    for ( uint64_t i = 0; i < pool.size(); i++ )
    {
        ::delete pool[ i ];
    }
}

// overloaded new operator
template<typename T>
inline
T*
Preallocator<T>::Get()
{
    if ( current_index >= pool.size() )
    {
        pool.resize( 2 * pool.size() );
        for ( uint64_t i = current_index; i < pool.size(); i++ )
        {
            pool[ i ] = ( ::new T() );
        }
    }
//     num_up++;
//     max_index = std::max( current_index, max_index );
    T* _v = /*return*/ pool[ current_index ];
    pool[ current_index ] = NULL;
    current_index++;
    return _v;
}

// overloaded new operator
template<typename T>
inline
void
Preallocator<T>::Put( T* element )
{
    if ( current_index == 0 )
    {
        throw std::bad_alloc();
    }
    current_index--;
    pool[ current_index ] = element;
//     num_down++;
}
}



#endif
