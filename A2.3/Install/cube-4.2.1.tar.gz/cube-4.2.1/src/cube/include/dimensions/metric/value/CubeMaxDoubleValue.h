/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeMaxDoubleValue.h
 * \brief  Provides the "double" (64bit) build-in type as "Value" with the operation "+" as "max". Operator"-" is "min".
 ************************************************/
#ifndef __MAX_DOUBLE_VALUE_H
#define __MAX_DOUBLE_VALUE_H

#include <istream>
#include "CubeDoubleValue.h"

#include <iostream>
#include <float.h>

#ifndef DBL_MAX
#define DBL_MAX 1.7976931348623158e+308
#endif

using namespace std;

namespace cube
{
class MaxDoubleValue;
extern Preallocator<MaxDoubleValue> max_double_preallocator;


class MaxDoubleValue : public DoubleValue
{
public:
    MaxDoubleValue() : DoubleValue( -DBL_MAX )
    {
    };
//     MaxDoubleValue( uint16_t u ) : DoubleValue( u )
//     {
//     };
//     MaxDoubleValue( int16_t u ) : DoubleValue( u )
//     {
//     };
//     MaxDoubleValue( uint32_t u ) : DoubleValue( u )
//     {
//     };
//     MaxDoubleValue( int32_t u ) : DoubleValue( u )
//     {
//     };
//     MaxDoubleValue( uint64_t u ) : DoubleValue( u )
//     {
//     };
//     MaxDoubleValue( int64_t u ) : DoubleValue( u )
//     {
//     };
    MaxDoubleValue( double d ) : DoubleValue( d )
    {
    };
//     MaxDoubleValue( char* c ) : DoubleValue( c )
//     {
//     };
/*
    virtual MaxDoubleValue
    operator+( const MaxDoubleValue& );
    virtual MaxDoubleValue
    operator-( const MaxDoubleValue& );*/

    inline
    virtual void
    operator+=( Value* chval )
    {
        if ( chval == NULL )
        {
            return;
        }
        value.dValue = max( value.dValue, ( ( MaxDoubleValue* )chval )->value.dValue );
    }
    inline
    virtual void
    operator-=( Value* chval )
    {
        if ( chval == NULL )
        {
            return;
        }
        value.dValue = min( value.dValue, ( ( MaxDoubleValue* )chval )->value.dValue );
    }

    virtual string
    getString();

//     using DoubleValue::operator+;
//     using DoubleValue::operator-;
    using DoubleValue::operator=;
    virtual Value*
    clone()
    {
        return new MaxDoubleValue( 0. );
    }
    virtual Value*
    copy()
    {
        return new MaxDoubleValue( value.dValue );
    };

    void*
    operator new( size_t size );
    void
    operator delete( void* p );

    virtual void
    Free()
    {
        delete ( MaxDoubleValue* )this;
    }
//         virtual     void          operator*=(double);  // needed by algebra tools
//         virtual     void          operator/=(double);  // needed by algebra tools

//         virtual     void         operator=(string);
//     virtual MaxDoubleValue
//     operator=( MaxDoubleValue );                               /// Assignemnt operator.

    virtual bool
    isZero()
    {
        return value.dValue == -DBL_MAX;
    };

    virtual bool
    asInclusiveMetric()
    {
        return false;
    }

    virtual DataType
    myDataType()
    {
        return CUBE_DATA_TYPE_MAX_DOUBLE;
    };                                             // not supported yet
    virtual void
    normalizeWithClusterCount( uint64_t );
};
}
#endif
