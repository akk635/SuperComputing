/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubeSimpleCache.h
 * \brief Provides an interface for simple caching mechanisms in metrics, using three maps
 */

#ifndef __SIMPLE_CACHE_H
#define __SIMPLE_CACHE_H

#include <iostream>
#include "CubeCache.h"


using namespace std;

namespace cube
{
typedef int64_t simple_cache_key_t;
typedef int64_t sysres_id_t;
typedef int64_t cnode_id_t;

/**
 * Class "SimpleCache" is a class, which stores all values without any evaluatioin of probability
 * Drawback: memoryfootprint is too big. But this simple realization allows to test another functionalities
 */
class SimpleCache : public Cache
{
private:


    cnode_id_t  number_cnodes;
    sysres_id_t number_loc;
//     sysres_id_t  number_lg;
//     sysres_id_t  number_stn;

    CalculationFlavour myf;


    simple_cache_key_t              treashold;

    map<simple_cache_key_t, Value*> stn_container;
    map<simple_cache_key_t, Value*> lg_container;
    map<simple_cache_key_t, Value*> loc_container;
    map<simple_cache_key_t, Value*> sum_container;

    simple_cache_key_t
    get_key( Cnode *, CalculationFlavour, Sysres *, CalculationFlavour );



public:

    SimpleCache( cnode_id_t         _n_cnode,
                 sysres_id_t        _n_loc,
                 CalculationFlavour metric_flavor = CUBE_CALCULATE_EXCLUSIVE
                 ) : number_cnodes( _n_cnode ), number_loc( _n_loc ), myf( metric_flavor )
    {
//         number_stn = number_loc; // assume thant number of locations is bigger than location groups and system tree nodes.
//         number_lg = number_stn;


        treashold = 0.7 * number_cnodes;

        stn_container.clear();
        lg_container.clear();
        loc_container.clear();
        sum_container.clear();

//         stn_container.resize(100*number_stn);
//         lg_container.resize(number_cnodes*number_lg*4);
//         loc_container.resize(number_cnodes*number_loc*4);
//         sum_container.resize(number_cnodes*2);
    }

    virtual
    ~SimpleCache();

    virtual Value*
    getCachedValue( Cnode*             cnode,
                    CalculationFlavour cf,
                    Sysres*            sysres = NULL,
                    CalculationFlavour sf = CUBE_CALCULATE_INCLUSIVE );                                                                                    ///< Returns Value or NULL, if not present

    virtual void
    setCachedValue( Value*,
                    Cnode*             cnode,
                    CalculationFlavour cf,
                    Sysres*            sysres = NULL,
                    CalculationFlavour sf = CUBE_CALCULATE_INCLUSIVE );                                                                                ///< Stores or not (if not needed) a Value.
};
}

#endif
