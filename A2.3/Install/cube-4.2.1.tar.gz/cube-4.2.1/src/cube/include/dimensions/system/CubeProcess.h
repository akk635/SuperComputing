/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubeProcess.h
 * \brief Describes a node of a process.
 */
#ifndef CUBE_PROCESS_H
#define CUBE_PROCESS_H


#include <iosfwd>

#include "CubeSysres.h"
#include "CubeLocationGroup.h"
#include "CubeTypes.h"

/*
   *----------------------------------------------------------------------------
 *
 * class Process
 *
 *********----------------------------------------------------------------------------
 */

namespace cube
{
// // // class Node;
// // // class Thread;
// // // class Process;
// // // inline bool
// // // operator==( const Process& a,
// // //             const Process& b );
// // //
// // // /**
// // //  * Machine containts nodes, nodes contains processes, process contains threads. Heterogen treelike structure.
// // //  */
// // // class Process : public LocationGroup
// // // {
// // // public:
// // //
// // //     Process( const std::string& name,
// // //              int                rank,
// // //              Node*              node,
// // //              uint32_t           id = 0,
// // //              uint32_t           sysid = 0 )
// // //         : LocationGroup( name, "",  rank,  ( SystemTreeNode* )node,  id, sysid )
// // //     {
// // //         own_hash = construct_own_hash();
// // //         kind     = CUBE_PROCESS;
// // //     }
// // //
// // //     int
// // //     get_rank() const
// // //     {
// // //         return rank;
// // //     }                                     ///< Returns a rank of the process.
// // //
// // // /**
// // //  * Get i-th Thread of this process.
// // //  */
// // //     Thread*
// // //     get_child( unsigned int i ) const
// // //     {
// // //         return ( Thread* )Vertex::get_child( i );
// // //     }
// // // /**
// // //  * On what node does this Process run?
// // //  */
// // //     Node*
// // //     get_parent() const
// // //     {
// // //         return ( Node* )Vertex::get_parent();
// // //     }
// // //     void
// // //     writeXML( std::ostream& out ) const;
// // //
// // // //     virtual bool weakEqual(const Process * _n)
// // // //     {
// // // //      return *this == *_n;
// // // //     }
// // // //
// // //     virtual std::string
// // //     construct_own_hash();
// // //
// // // private:
// // //
// // //     int rank;
// // // };
// // //
// // // inline bool
// // // operator==( const Process& a, const Process& b )
// // // {
// // //     return a.get_rank() == b.get_rank();
// // // }
// // // inline bool
// // // operator<( const Process& a, const Process& b )
// // // {
// // //     return a.get_rank() < b.get_rank();
// // // }
// // //

typedef LocationGroup                           Process;

typedef std::pair<Process*, CalculationFlavour> process_pair;       ///< Used for calculations of varios types.
typedef std::vector<process_pair>               list_of_processes;  ///< Used to collect a list of processes
}



#endif
