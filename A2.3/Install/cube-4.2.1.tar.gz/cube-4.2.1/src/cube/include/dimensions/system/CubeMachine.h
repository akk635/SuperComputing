/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 * \file CubeMachine.h
 * \brief Describes a machine, on which an application was running.
 */
#ifndef CUBE_MACHINE_H
#define CUBE_MACHINE_H


#include "CubeSysres.h"
#include "CubeSystemTreeNode.h"
#include "CubeTypes.h"

/*
   *----------------------------------------------------------------------------
 *
 * class Machine
 *
 *********----------------------------------------------------------------------------
 */

namespace cube
{
// class Node;
// class Machine;
// inline bool
// operator==( const Machine& a,
//             const Machine& b );
//
// /**
//  * A machine as a kind of system resources.
//  */
// class Machine : public SystemTreeNode
// {
// public:
//
//     Machine( const std::string& name,
//              const std::string& desc,
//              uint32_t           id,
//              uint32_t           sysid )
//         : SystemTreeNode( name, desc, NULL,  id, sysid )
//     {
//         own_hash = construct_own_hash();
//         kind     = CUBE_MACHINE;
//     }
//
//     Node*
//     get_child( unsigned int i ) const
//     {
//         return ( Node* )Vertex::get_child( i );
//     }
//     Sysres*
//     get_parent() const
//     {
//         return NULL;
//     }                                          ///< Machine is a upper object of abstraction. (GRID?)
//     std::string
//     get_desc() const
//     {
//         return desc;
//     }                                            ///< Gets a description of this machine.
//     void
//     set_desc( std::string newDesc )
//     {
//         desc = newDesc;
//     }                                                     ///< Describe the machine.
//
//     void
//     writeXML( std::ostream& out ) const;   ///< Write a xml-output for the machine in .cube file.
//
// //   virtual bool weakEqual(const Machine * _m)
// //   {
// //       return *this == *(Machine*)(_m);
// //   }
//
//     virtual std::string
//     construct_own_hash()
//     {
//         return "machine." + name;
//     };
//
// private:
//
//     std::string desc; ///< Description of the machine.
// };
//
// inline bool
// operator==( const Machine& a, const Machine& b )
// {
//     return a.get_name() == b.get_name();
// }
//
//
//

typedef SystemTreeNode                          Machine;
typedef std::pair<Machine*, CalculationFlavour> machine_pair;           ///< Used for calculations of various values.
typedef std::vector<machine_pair>               list_of_machines;       ///< Used to collect a list of machines
}






#endif
