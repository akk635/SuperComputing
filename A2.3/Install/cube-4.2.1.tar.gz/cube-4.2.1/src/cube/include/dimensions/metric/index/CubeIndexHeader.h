/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 * \file CubeIndexHeader.h
 * \brief Provides a format of the header at the beginning of the Index-File. It provides general information about the layout (#cnodes, #threads), endianess, saved value and so on.
 */

#ifndef __INDEX_HEADER_H
#define __INDEX_HEADER_H

#include <fstream>
#include "CubeTrafos.h"
#include "CubeValues.h"
#include "CubeIndexes.h"
#include "CubeFileFinder.h"
using namespace std;



namespace cube
{
/**
 * Header lyout is represented as packed structure.
 * One need an access to different fields of the header and as char stream for io operations. - therefore one defines it like a n union.
 */
typedef union
{
    struct
    {
        /// If this Value "1" -> no endianess transformation is needed. If "16777216" or "0x1000000" - then one has to apply "SwapBytes" Trafo. Only two endianesses are supported : Little endian and Big Endian. Middle Endian is not supported directly, but it is trivial to support by adding additional "SingleValueTrafo"
        uint32_t endianess;
        /// Current version of the header and index layout. Current == "0"
        uint16_t version;
/*
        /// Number of processes.
        unsigned int process_count;
        /// Number of all threads.
        unsigned int thread_count;
        /// Number of all cnodes.
        unsigned int cnode_count;
        /// Byte, indicationg a data type.  Possible data types are defined in "Values.h"
        char         data_type;
 */
        /// Byte, indicationg a format of the used index.  Possible index types are defined in "Indexes.h"
        uint8_t format;
    }  __attribute__ ( ( __packed__ ) ) named;
    /// To save header in the file one uses representation of the header as a array of bytes.
    char as_array[ 1 ];
} Header;



/**
 * Provides methods to get the general information about data lyout, endianess and transformation.
 *
 */
class IndexHeader
{
private:
    /// Heart of  the class, Physical representation of the header.
    Header            header;
    /// Saves the transformation, which is needed to deal with endianess.
    SingleValueTrafo* trafo;
//     /// Exemplar of the saved Value. Created using switch-case
//     Value*            value;
    /// Index , used to acces he data. Can be Sparse or Dense
    Index*           index;
    /// Field, holding the value of the data
    char             data_type;
    /// Field, holding the sizes of underlying data
    threads_number_t threads_count;
    cnodes_number_t  cnodes_count;

    /// applies the trafo to adjust endianess
    void
    applyTrafo();

//     /// checks the header.data_type and creates a corresponding Value
//     void
//     selectValue();

    /// checks the header.format and creates a corresponding Index
    void
    selectIndex();


public:
    /// Constructor  used if one reads existing header.
    IndexHeader( cnodes_number_t,
                 threads_number_t );
    /// Constructor  used if one will save header.
    IndexHeader( cnodes_number_t,
                 threads_number_t,
                 IndexFormat format );
    virtual
    ~IndexHeader();

    /// Reads the first sizeof(Header) bytes into Header from fstream
    virtual void
    readHeader( fstream& );

    /// Reads the first sizeof(Header) bytes into Header from "file"
    virtual void readHeader( fileplace_t );
    /// Writes into the first sizeof(Header) bytes of the fstream the  Header
    virtual void
    writeHeader( fstream& );

    /// Writes into the first sizeof(Header) bytes of the fstream the  Header
    virtual void
    writeHeader( FILE* );


    /// Writes into the first sizeof(Header) bytes of the file the  Header
    virtual void writeHeader( fileplace_t );

    /// Prints the saved information into STDOUT. Used for Debugging
    virtual void
    printSelf();

    uint32_t
    getEndianess()
    {
        return header.named.endianess;
    };
    uint16_t
    getVersion()
    {
        return header.named.version;
    };
//       unsigned int          getProcessNumber() {    return header.named.process_count; };
//       unsigned int          getThreadNumber() {     return header.named.thread_count; };
//       unsigned int          getCNodeNumber() {      return header.named.cnode_count; };
//       char                  getDataType() {         return header.named.data_type; };
    char
    getIndexFormat()
    {
        return header.named.format;
    };

    SingleValueTrafo*
    getTrafo()
    {
        return trafo;
    };
//     Value*
//     getValue()
//     {
//         return value;
//     };
    Index*
    getIndex()
    {
        return index;
    };
};
}

#endif
