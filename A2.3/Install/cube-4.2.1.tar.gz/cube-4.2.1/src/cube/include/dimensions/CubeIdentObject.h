/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubeIdentObject.h
 * \brief Provides an object with an internal ID.
 */

#ifndef CUBE_IDENTOBJECT_H
#define CUBE_IDENTOBJECT_H


#include <inttypes.h>


/*
   *----------------------------------------------------------------------------
 *
 * class IdentObject
 *
 **********----------------------------------------------------------------------------
 */

namespace cube
{
class IdentObject
{
public:
    IdentObject( uint32_t id = 0 ) : m_id( id )
    {
    }
    virtual
    ~IdentObject()
    {
    }

    void
    set_id( uint32_t id )
    {
        m_id = id;
    }                                       ///< Set an ID.
    uint32_t
    get_id() const
    {
        return m_id;
    }                                        ///< Gets the ID of the object.
    std::string
    get_hash_id() const
    {
        return hash_id;
    };                                                                  ///<



    void
    calculate_hash()
    {
        hash_id = construct_hash_id();
    };

protected:
    std::string hash_id;        ///< Hash ID of the object. Independent on ID and depends only on "properties" of object, but not on the place in the creation sequence (which is ID).
    virtual std::string
    construct_hash_id()
    {
        return "_ident_object_hash_";
    };

    uint32_t m_id; ///< The ID of the object.
};
}

#endif
