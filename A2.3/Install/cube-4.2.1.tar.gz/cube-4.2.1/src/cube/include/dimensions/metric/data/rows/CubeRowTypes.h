/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubeRowTypes.h
 * \brief  Defines a type for the row
 */

#ifndef CUBE_ROW_TYPES_H
#define CUBE_ROW_TYPES_H 0

// #include <pair>
#include <utility>
#include <vector>
#include <map>
#include <limits>
#include <inttypes.h>
#include <sys/types.h>
namespace cube
{
/// position in data stream is 64bit to support big files.
typedef  uint64_t position_t;

/// value iof invalid position, which is used to indicate missing row in the cube file.
static const position_t non_position = std::numeric_limits<position_t>::max();

/// position in data stream is 64bit to support big files.
typedef  uint32_t index_size_t;
/// position in data stream is 64bit to support big files.
typedef  uint32_t index_t;
/// value of index, indication missing row
static const index_t non_index = std::numeric_limits<index_t>::max();
/// the range of the coordinates in the mapping are as big as position in the file
typedef  int64_t cnode_id_t;
/// the range of the coordinates in the mapping are as big as position in the file
typedef  int64_t thread_id_t;

typedef  int64_t cnodes_number_t;
typedef  int64_t threads_number_t;

/// mapping (cnode_id, thread_id) <-> position is bijectiv and tuplet collects two-valued argument of the right side.
typedef  std::pair<cnode_id_t, thread_id_t> tuplet;

/// for optimisation of the index (sorting) one deals with the pairs of rows. A single step of the optimisation prescription is the exchange of two rows.
typedef  std::pair<cnode_id_t, cnode_id_t> rows_pair;

/// one of the underlying steps during calculation of incl/excl value is calculation of the ranges in id-space. Ranges collects the result of such calculation and allows to collect in one variable all needed parts in Data stream.
typedef  std::vector< std::pair< position_t, position_t > > Ranges;

/// Collection of Rows, which participate in single calculation.
typedef  std::vector< cnode_id_t  > Rows;


/// a type of memory, storing raw row data
typedef char* row_t;

/// type of a memory collection
typedef std::map<cnode_id_t, row_t> rows_t;
}

#endif
