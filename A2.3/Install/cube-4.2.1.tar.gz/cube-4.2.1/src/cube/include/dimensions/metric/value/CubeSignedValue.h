/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeSignedValue.h
 * \brief   Provides the "signed int" (32bit) build-in type as "Value"
 ************************************************/
#ifndef __SIGNED_VALUE_H
#define __SIGNED_VALUE_H

#include <istream>
#include "CubeValue.h"

#include <iostream>
using namespace std;

namespace cube
{
class SignedValue;
extern Preallocator<SignedValue> int32_preallocator;


/**
 * Value works with 4 bytes of the nsigned int as teh whole int value, and as 4 bytes (endianess). Therefore it
 * defined a union.
 */
typedef union
{
    int32_t iValue;
    char    aValue[ sizeof( int32_t ) ];
} i_value_t;

class SignedValue : public Value
{
protected:
    i_value_t value;                     /// "heart" of the value.
public:
    SignedValue();
//     SignedValue( uint16_t );
//     SignedValue( int16_t );
//     SignedValue( uint32_t );
    SignedValue( int32_t );
//     SignedValue( uint64_t );
//     SignedValue( int64_t );
//     SignedValue( double );
//     SignedValue( char* );

    virtual
    ~SignedValue()
    {
    };
    inline
    virtual unsigned
    getSize()
    {
        return sizeof( int32_t );
    }

    inline
    virtual double
    getDouble()
    {
        return ( double )value.iValue;
    };
    virtual uint16_t
    getUnsignedShort();
    virtual int16_t
    getSignedShort();
    virtual uint32_t
    getUnsignedInt();
    virtual int32_t
    getSignedInt();
    virtual uint64_t
    getUnsignedLong();
    virtual int64_t
    getSignedLong();
    virtual char
    getChar();
    virtual string
    getString();

    virtual char*
    fromStream( char* );
    virtual char*
    toStream( char* );

    inline
    virtual Value*
    clone()
    {
        return new SignedValue( 0 );
    }
    inline
    virtual Value*
    copy()
    {
        return new SignedValue( value.iValue );
    }


//     virtual SignedValue
//     operator+( const SignedValue& );
//     virtual SignedValue
//     operator-( const SignedValue& );
//

    inline
    virtual void
    operator+=( Value* chval )
    {
        if ( chval == NULL )
        {
            return;
        }
        value.iValue += ( ( SignedValue* )chval )->value.iValue;
    }

    inline
    virtual void
    operator-=( Value* chval )
    {
        if ( chval == NULL )
        {
            return;
        }
        value.iValue -= ( ( SignedValue* )chval )->value.iValue;
    }

    inline
    virtual void
    operator*=( double dval )
    {
        value.iValue *= dval;
    }                                 // needed by algebra tools

    inline
    virtual void
    operator/=( double dval )
    {
        if ( dval == 0. )
        {
            cerr << "ERROR: DEVISION BY ZERO!" << endl;
        }
        value.iValue /= dval;
    }

    void*
    operator new( size_t size );
    void
    operator delete( void* p );

    virtual void
    Free()
    {
        delete ( SignedValue* )this;
    }

    virtual void
    operator=( double );

/*    virtual void
    operator=( char );
    virtual void
    operator=( uint16_t );
    virtual void
    operator=( uint32_t );
    virtual void
    operator=( uint64_t );
    virtual void
    operator=( int16_t );
    virtual void
    operator=( int32_t );
    virtual void
    operator=( int64_t );*/
    virtual void
    operator=( Value* );

/*    virtual void
    operator=( string );
    virtual SignedValue
    operator=( SignedValue ); */                                                                     /// Assignemnt operator.

    virtual bool
    isZero()
    {
        return value.iValue == 0;
    };

    virtual DataType
    myDataType()
    {
        return CUBE_DATA_TYPE_INT32;
    };                                              // not supported yet
    virtual void
    normalizeWithClusterCount( uint64_t );
};
}
#endif
