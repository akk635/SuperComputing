/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 * \file CubeRegion.h
 * \brief Provides a description of a region of the source code.
 */
#ifndef CUBE_REGION_H
#define CUBE_REGION_H


#include <functional>
#include <iosfwd>

#include "CubeVertex.h"
#include "CubeTypes.h"

/*
   *----------------------------------------------------------------------------
 *
 * class Region
 *
 ****************----------------------------------------------------------------------------
 */

namespace cube
{
class Cnode;
class Region;
bool
operator==( const Region& a,
            const Region& b );

/**
 * Functions contain Loops, Loops contains blocks and so on. Heterogen treelike structure.
 */
class Region : public Vertex
{
public:
/**
 * Regions is defined by name, startline and endline ogf the source code, url as onilne help
 */
    Region( const std::string& name,
            long               begln,
            long               endln,
            const std::string& url,
            const std::string& descr,
            const std::string& mod,
            uint32_t           id = 0 )
        : Vertex( id ), name( name ), begln( begln ), endln( endln ),
          url( url ), descr( descr ), mod( mod )
    {
        own_hash              = construct_own_hash();
        subroutines_of_region = false;
    }

    std::string
    get_name()  const
    {
        return name;
    }
    std::string
    get_url()   const
    {
        return url;
    }
    std::string
    get_descr() const
    {
        return descr;
    }
    std::string
    get_mod()   const
    {
        return mod;
    }
    long
    get_begn_ln()      const
    {
        return begln;
    }
    long
    get_end_ln()        const
    {
        return endln;
    }



    void
    set_name( std::string nm )
    {
        name = nm;
    }                                                 /**< Sets the name of the region after it is created. Needed by cube4_canonize */
    void
    set_url( std::string rl )
    {
        url = rl;
    }                                                 /**< Sets the url of the region after it is created. Needed by cube4_canonize */
    void
    set_descr( std::string dscr )
    {
        descr = dscr;
    }                                                 /**< Sets the description of the region after it is created. Needed by cube4_canonize */
    void
    set_mod( std::string md )
    {
        mod = md;
    }                                                 /**< Sets the mode of the region after it is created. Needed by cube4_canonize */
    void
    set_begn_ln( int ln )
    {
        begln = ln;
    }                                                 /**< Sets the begin line of source code of the region after it is created. Needed by cube4_canonize */
    void
    set_end_ln( int ln )
    {
        endln = ln;
    }                                                 /**< Sets the end line of the source code of the region after it is created. Needed by cube4_canonize */

    int
    num_children()     const
    {
        return cnodev.size();
    }
    void
    add_cnode( Cnode* cnode );

    const std::vector<Cnode*>&
    get_cnodev() const
    {
        return cnodev;
    }
    const std::vector<Cnode*>&
    get_excl_cnodev() const
    {
        return excl_cnodev;
    }
    const std::vector<Cnode*>&
    get_incl_cnodev() const
    {
        return incl_cnodev;
    }

    void
    writeXML( std::ostream& out,
              bool          cube3_export = false ) const;

    void
    set_as_subroutines()
    {
        subroutines_of_region = true;
    }                                                               ///< sets an internal poiner in cnode, to
    void
    unset_as_subroutines()
    {
        subroutines_of_region = false;
    }                                                                  ///< sets an internal poiner in cnode, to
    bool
    is_subroutines()
    {
        return subroutines_of_region == true;
    }


//     virtual bool weakEqual(Region * _r) { return *this == *_r; };
    virtual std::string
    construct_own_hash();                                               ///< Constructs hash using name, mod, url and  lines.

private:

    friend class Cnode; ///< Cnodes are friends, They may call private members.

    void
    add_incl_cnode( Cnode* cnode )
    {
        incl_cnodev.push_back( cnode );
    }
    void
    add_excl_cnode( Cnode* cnode )
    {
        excl_cnodev.push_back( cnode );
    }

    std::string         name;
    long                begln;
    long                endln;
    std::string         url;
    std::string         descr;
    std::string         mod;
    std::vector<Cnode*> cnodev;

    bool                subroutines_of_region;


    std::vector<Cnode*> excl_cnodev; ///< call paths calling this region
    std::vector<Cnode*> incl_cnodev; ///< call paths calling this region without recursive calls
};




inline bool
operator<( const Region& a, const Region& b )
{
    return a.get_name() < b.get_name();
}

inline bool
operator==( const Region& a, const std::string b )
{
    return a.get_name() == b ? true : false;
}



template<class T>
class GenLess : public std::binary_function<T, T, bool>
{
public:
    bool
    operator()( const T a, const T b ) const
    {
        return *a < *b;
    }
};



typedef std::pair<Region*, CalculationFlavour> region_pair;             ///< Used in the calculations of values in the flattree.
typedef std::vector<region_pair>               list_of_regions;         ///< Used to collect a list of regions
}




#endif
