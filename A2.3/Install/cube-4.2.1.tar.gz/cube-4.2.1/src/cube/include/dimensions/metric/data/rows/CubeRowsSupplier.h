/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubeRowsSupplier.h
 * \brief  Provides an abstract interface for all rows suppliers.
 */

#ifndef CUBE_ROWS_SUPPLIER_H
#define CUBE_ROWS_SUPPLIER_H

#include "CubeRowTypes.h"
#include "CubeFileFinder.h"
#include "CubePlatformsCompat.h"
#include "CubeTrafos.h"

namespace cube
{
class RowsSupplier
{
protected:
    uint64_t row_size;
    SingleValueTrafo*
             endianess;                        ///<  Holds the endianess correction.

    bool     _dummy_creation;
public:

    RowsSupplier()
    {
        _dummy_creation = true;
    };                                           /// used only to invoke late "probe"... does not creat fully initialized instance

    RowsSupplier( uint64_t rs ) : row_size( rs )
    {
        _dummy_creation = false;
    };

    virtual
    ~RowsSupplier()
    {
//       delete endianess; // is deleted in IndexHeader
    };

    virtual row_t
    provideRow( cnode_id_t, bool for_writing = false ) = 0;

    virtual void
    dropRow( row_t, cnode_id_t ) = 0;

    virtual SingleValueTrafo*
    getEndianess()
    {
        return endianess;
    };


    virtual void
    finalize()
    {
    };              ///< gets invoked in destructor, to performe final format transformation if needed. Standard realizasion - nop operation. Inj WOZ case -> compressing data.


    /// Gets invoked by RowsManager to test, if that or another wors suplier can provide rows. Used in the decision if existing cube or new one, compressed or not.
    static
    bool
    probe( fileplace_t DataPlace,
           fileplace_t IndexPlace )
    {
        DataPlace  = DataPlace;  // just to avoind warning of unused (here) argument
        IndexPlace = IndexPlace; // just to avoind warning of unused (here) argument
        return true;
    }
};
}

#endif
