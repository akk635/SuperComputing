/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 * \file CubeStrategies.h
 * \brief Collects all headers of all strategies in one place.
 * storing matrices.
 */
#ifndef CUBE_BASIC_STRATEGIES_H
#define CUBE_BASIC_STRATEGIES_H 0


namespace cube
{
enum CubeStrategy { CUBE_MANUAL_STRATEGY = 0, CUBE_ALL_IN_MEMORY_STRATEGY = 1, CUBE_LAST_N_ROWS_STRATEGY = 2 };
}



#include "CubeBasicStrategy.h"
#include "CubeAllInMemoryStrategy.h"
#include "CubeLastNRowsStrategy.h"
#include "CubeManualStrategy.h"


#endif
