/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


/**
 * \file Cube.h
 * \brief Provides a class "cube".
 */
#ifndef __CUBE_H
#define __CUBE_H


#include <inttypes.h>
#include <stdint.h>
#include <map>
#include <string>
#include <vector>
#include <iostream>
#include <iosfwd>

#ifndef CUBE_AS_SVN_EXTERNAL
#  include  "cube-version.h"
#endif
#include "CubeTypes.h"
#include "CubeMetric.h"
#include "CubeRegion.h"
#include "CubeSysres.h"
#include "CubeThread.h"
#include "CubeProcess.h"
#include "CubeNode.h"
#include "CubeMachine.h"
#include "CubeSystemTreeNode.h"
#include "CubeLocationGroup.h"
#include "CubeLocation.h"

#include "CubeFileFinder.h"
#include "CubeLayoutDetector.h"

#include "CubeStrategies.h"

namespace cubeparser
{
//  class Cube2Parser;
class Cube4Parser;
}

// CUBE library version number
#define CUBE_VERSION_MAJOR  4
#define CUBE_VERSION_MINOR  0


/*
   *----------------------------------------------------------------------------
 *
 * class Cube
 *
 *******************************----------------------------------------------------------------------------
 */
/**
 * \namespace cube
 */
namespace cube
{
/// sets a flavour of the alculation of a single dimension.



class Cartesian;
class Cnode;
class Region;
class Matrix;
class Metric;


/**
 * Class containing whole information about performance measurement.
 *
 * It has a three "dimensions" : "metrics", "call three" und "threads". Every dimension has its own treelike structure.
 */
class Cube
{
public:
    Cube(         CubeEnforceSaving _enforce_saving = CUBE_IGNORE_ZERO );
    Cube( Cube&             _cube,
          CubeCopyFlag      copy_flag = CUBE_ONLY_STRUCTURE,
          CubeEnforceSaving _enforce_saving = CUBE_IGNORE_ZERO
          );                                                      ///< Copying the structure of the _cube. If "copy" set to CUBE_DEEP_COPY - also data gets copied. If 0 -> Cube ignores undefs and zeroes
    void
    openCubeReport( std::string cubename,
                    bool        disable_clustering = false );                 // enable clustering by default.
    void
    writeCubeReport( std::string cubename );
    void
    closeCubeReport();
    void
    writeMetricsData( std::string cubename );

    virtual
    ~Cube();
    /**************************************************************
     * CUBE write API
     *************************************************************/

    // The order of children in any hierarchical structure is defined by
    // the order of child creation. For example, the first performance metric
    // created as child of a given metric is the first child.

    /// set attributes
    void
    def_attr( const std::string& key,
              const std::string& value );

    /// set mirror URLs
    void
    def_mirror( const std::string& url );

    // build metric dimension

    // url is a URL or a file path, or a string of "@mirror@...".
    // descr is simply a short string.

/**
 * Defines a metric and its parent in the dimension "metrix" of the cube.
 *
 * url is a URL or a file path, or a string of "@mirror@...", descr is simply a short string.
 */
    Metric*
    def_met( const std::string& disp_name,
             const std::string& uniq_name,
             const std::string& dtype,
             const std::string& uom,
             const std::string& val,
             const std::string& url,
             const std::string& descr,
             Metric*            parent,
             TypeOfMetric       type_of_metric = CUBE_METRIC_EXCLUSIVE,
             const std::string& expression = "",
             const std::string& init_expression = "",
             TypeOfMetric       is_ghost = CUBE_METRIC_NO_GHOST
             );

    // build program dimension
/**
 * Define a region in a program.
 */
    Region*
    def_region( const std::string& name,
                long               begln,
                long               endln,
                const std::string& url,
                const std::string& descr,
                const std::string& mod );

    // if source-code info available
/**
 * Define a call node with a known source code.
 */
    Cnode*
    def_cnode( Region*            callee,
               const std::string& mod,
               int                line,
               Cnode*             parent,
               uint32_t           id = ( uint32_t )-1 // -! signalizes, that automatical id assignent should be performed
               );

    // if source-code info not available
/**
 * Define a call node without a known source code.
 */
    Cnode*
    def_cnode( Region* callee,
               Cnode*  parent );

    // build system dimension
/**
 * Define machine, on which the measurement was done.
 */
    Machine*
    def_mach( const std::string& name,
              const std::string& desc );

/**
 * Define node of the machine.
 */
    Node*
    def_node( const std::string& name,
              Machine*           mach );

/**
 * Define process of a programm.
 */
    Process*
    def_proc( const std::string& name,
              int                rank,
              Node*              node );

/**
 * Define thread.
 */
    Thread*
    def_thrd( const std::string& name,
              int                rank,
              Process*           proc );


/**
 * Define system tree node, on which the measurement was done.
 */
    SystemTreeNode*
    def_system_tree_node( const std::string& name,
                          const std::string& desc,
                          const std::string& stn_class,
                          SystemTreeNode*    parent = NULL
                          );

/**
 * Define location group for the measured values.
 */
    LocationGroup*
    def_location_group( const std::string& name,
                        int                rank,
                        LocationGroupType  type,
                        SystemTreeNode*    parent
                        );

/**
 * Define the location, which carreis the measured value.
 */
    Location*
    def_location( const std::string& name,
                  int                rank,
                  LocationType       type,
                  LocationGroup*     parent
                  );

    // define topology
/**
 * Set to every thread coordinates in the topology.
 */
    Cartesian*
    def_cart( long                     ndims,
              const std::vector<long>& dimv,
              const std::vector<bool>& periodv );
    void
    def_coords( Cartesian*               cart,
                const Sysres*            sys,
                const std::vector<long>& coordv );



/**
 * Set a vector of topologies
 */
    void
    add_cart( std::vector<Cartesian*>& cart )
    {
        cartv = cart;
    };



    /**************************************************************
     * CUBE read API
     *************************************************************/

    // get vector of entities
    const std::vector<Metric*>&
    get_metv()      const
    {
        return metv;
    };                                                                                          ///<  Get a vector of metrics.


    Metric*
    get_met( std::string& );                                                            ///< Returns a metric with given unique name or NULL.

    Metric*
    get_met( uint32_t );                                                                     ///< Returns a metric with given id or NULL.


    const std::vector<Region*>&
    get_regv()      const
    {
        return regv;
    };                                                                                          ///<  Get a vector of regions.
    const std::vector<Cnode*>&
    get_cnodev()    const
    {
        return cnodev;
    };                                                                                  ///<  Get a vector of call nodes.
    const std::vector<Sysres*>&
    get_sysv()      const
    {
        return sysv;
    };                                                                                          ///<  Get a vector of system resources.

    const std::vector<SystemTreeNode*>&
    get_stnv()     const
    {
        return stnv;
    };
    const std::vector<SystemTreeNode*>&
    get_root_stnv()     const
    {
        return root_stnv;
    };
    const std::vector<SystemTreeNode*>&
    get_non_root_stnv()     const
    {
        return non_root_stnv;
    };
    const std::vector<LocationGroup*>&
    get_location_groupv()     const
    {
        return location_groupv;
    };
    const std::vector<Location*>&
    get_locationv()     const
    {
        return locationv;
    };


    const std::vector<Machine*>&
    get_machv()     const
    {
        return machv;
    };                                                                                          ///<  Get a vector of machines.
    const std::vector<Node*>&
    get_nodev()     const
    {
        return nodev;
    };                                                                                          ///<  Get a vector of nodes.
    const std::vector<Process*>&
    get_procv()     const
    {
        return location_groupv;
    };                                                                                          ///<  Get a vector of processes.
    const std::vector<Thread*>&
    get_thrdv()     const
    {
        return locationv;
    };                                                                                          ///<  Get a vector of threads.
    const std::vector<Cartesian*>&
    get_cartv()     const
    {
        return cartv;
    };                                                                                          ///<  Get a vector of cartesian topologies.

    const Cartesian*
    get_cart( int i )  const;

    /// get the roots of metric and program dimension
    const std::vector<Metric*>&
    get_root_metv()   const
    {
        return root_metv;
    };
    /// get the roots of program dimension
    const std::vector<Cnode*>&
    get_root_cnodev() const
    {
        return root_cnodev;
    };


// ----------- GETIING DIFFERENT VALUES ------------

/**
 * Set a severity "value" for triplet (metric, cnode, thread). It sets just a value in the
 * metric "met" without taking into account, its this value inclusive or exclusive.
 */
    void
    set_sev( Metric* met,
             Cnode*  cnode,
             Thread* thrd,
             double  value );

/**
 * Add a value "inc" to severiti for triplet (metric, cnode, thread). It adds a value to the  saved value in the
 * metric "met" without taking into account, its this value inclusive or exclusive.
 */
    void
    add_sev( Metric* met,
             Cnode*  cnode,
             Thread* thrd,
             double  incr );

    // flat-tree only



// -------------------- WONT WORK!!!! -----
// ----------ALL REGIOS HAVE TO BE DECLATRED BEFORE set_sev is called----------------
/**
 * Set a severity "value" for triplet (metric, region, thread). All cnodes with the "region" as callee gets the value.
 */
    void
    set_sev( Metric* met,
             Region* region,
             Thread* thrd,
             double  value );

/**
 * Add a value "inc" to severiti for triplet (metric, region, thread). All cnodes with the "region" as callee add the value.
 */
    void
    add_sev( Metric* met,
             Region* region,
             Thread* thrd,
             double  incr );

//--------------------------------------------------------------------------





// ------------------- adv part


/**
 * Set a severity "value" for triplet (metric, cnode, thread). General call. All another calls uses this call to operate with values.
 */
    void
    set_sev( Metric* met,
             Cnode*  cnode,
             Thread* thrd,
             Value*  value );


/**
 * Add a value "inc" to severiti for triplet (metric, cnode, thread)
 */
    void
    add_sev( Metric* met,
             Cnode*  cnode,
             Thread* thrd,
             Value*  val );

    // flat-tree only



// -------------------- WONT WORK!!!! -----
// ----------ALL REGIOS HAVE TO BE DECLATRED BEFORE set_sev is called----------------
/**
 * Set a severity "value" for triplet (metric, region, thread). All cnodes with the "region" as callee gets the value.
 */
    void
    set_sev( Metric* met,
             Region* region,
             Thread* thrd,
             Value*  val );

/**
 * Add a value "inc" to severiti for triplet (metric, region, thread). All cnodes with the "region" as callee add the value.
 */
    void
    add_sev( Metric* met,
             Region* region,
             Thread* thrd,
             Value*  incr );

//---------------------------------------------------------------------------



/**
 * Returns a severity "value" for triplet (metric, cnode, thread) (metric, excl cnode, thread). In the case,
 * if metric is inclusive, an exclusive value along calltree gets calculated
 */
    double
    get_sev( Metric* met,
             Cnode*  cnode,
             Thread* thrd );

    /// get severity, advanced
    Value*
    get_sev_adv( Metric* met,
                 Cnode*  cnode,
                 Thread* thrd );


// ---------------------- ANALYSIS PART -----------------------------
/**
 * Returns direct saved severity "value" for triplet (metric, cnode, thread), without taking into account inclusivity os exclusivity
 */
    double
    get_saved_sev( Metric*   met,
                   Cnode*    cnode,
                   Location* thrd );

    /// get severity, advanced
    Value*
    get_saved_sev_adv( Metric*   met,
                       Cnode*    cnode,
                       Location* thrd );



//        ---- for the begining it is not needed ---------------------
    //
    /// Calculates an exclusive or an inclusive  value for given Metric, Cnode and Thread.
    /// Expansion along the metric dimension assumes their inclusive nature.
    /// Expansion in calltree dimension is done by corresponding metric.
    Value*
    get_sev_adv( Metric*            metric,
                 CalculationFlavour mf,
                 Region*            region,
                 CalculationFlavour rf,
                 Sysres*            sys,
                 CalculationFlavour sf );


    //
    /// Calculates an exclusive or an inclusive  value for given Metric, Cnode and Thread.
    /// Expansion along the metric dimension assumes their inclusive nature.
    /// Expansion in calltree dimension is done by corresponding metric.
    Value*
    get_sev_adv( Metric*            metric,
                 CalculationFlavour mf,
                 Cnode*             cnode,
                 CalculationFlavour cnf,
                 Sysres*            sys,
                 CalculationFlavour sf );

    /// Calculates an exclusive or an inclusive  Value for given Metric, Cnode..
    ///Expansion along the metric dimension assumes their inclusive nature.
    ///Expansion in calltree dimension is done by corresponding metric.
    /// Along the system dimension (over all threads) the value is summed up.
    Value*
    get_sev_adv( Metric*            metric,
                 CalculationFlavour mf,
                 Cnode*             cnode,
                 CalculationFlavour cnf );

    /// Calculates an exclusive or an inclusive  Value for given Metric, Cnode..
    ///Expansion along the metric dimension assumes their inclusive nature.
    ///Expansion in calltree dimension is done by corresponding metric.
    /// Along the system dimension (over all threads) the value is summed up.
    Value*
    get_sev_adv( Metric*            metric,
                 CalculationFlavour mf,
                 Region*            region,
                 CalculationFlavour rf );

    /// Calculates an exclusive or an inclusive  Value for given Metric, Cnode..
    ///Expansion along the metric dimension assumes their inclusive nature.
    ///Expansion in calltree dimension is done by corresponding metric.
    /// Along the system dimension (over all threads) the value is summed up.
    Value*
    get_sev_adv( Metric*            metric,
                 CalculationFlavour mf,
                 Sysres*            sys,
                 CalculationFlavour sf );

    /// Calculates an exclusive or an inclusive  Value for given Metric and over whole calltree.
    ///Expansion along the metric dimension assumes their inclusive nature.
    /// Along the system dimension (over all threads) and calltree dimensions ( over all roots of hte calltree) the value is summed up.
    Value*
    get_sev_adv( Metric*            metric,
                 CalculationFlavour mf );


// Version of the methods above with another return value.

    /// Calculates an exclusive or an inclusive  Value for given Metric, Cnode and Thread.
    /// Returns the "double" representation of the internal "Value" if possible.
    /// Uses the corresponding call "get_excl_sev_adv(...)"
    double
    get_sev( Metric*            metric,
             CalculationFlavour mf,
             Region*            region,
             CalculationFlavour rf,
             Sysres*            sys,
             CalculationFlavour sf );

    /// Calculates an exclusive or an inclusive  Value for given Metric, Cnode and Thread.
    /// Returns the "double" representation of the internal "Value" if possible.
    /// Uses the corresponding call "get_excl_sev_adv(...)"
    double
    get_sev( Metric*            metric,
             CalculationFlavour mf,
             Cnode*             cnode,
             CalculationFlavour cnf,
             Sysres*            sys,
             CalculationFlavour sf );

    /// Calculates an exclusive or an inclusive  Value for given Metric, Cnode and  and whole Machine (over all threads).
    /// Returns the "double" representation of the internal "Value" if possible.
    /// Uses the corresponding call "get_excl_sev_adv(...)"
    double
    get_sev( Metric*            metric,
             CalculationFlavour mf,
             Cnode*             cnode,
             CalculationFlavour cnf );

    /// Calculates an exclusive or an inclusive  Value for given Metric, Cnode and  and whole Machine (over all threads).
    /// Returns the "double" representation of the internal "Value" if possible.
    /// Uses the corresponding call "get_excl_sev_adv(...)"
    double
    get_sev( Metric*            metric,
             CalculationFlavour mf,
             Region*            region,
             CalculationFlavour rf );

    /// Calculates an exclusive or an inclusive  Value for given Metric, Cnode..
    ///Expansion along the metric dimension assumes their inclusive nature.
    ///Expansion in calltree dimension is done by corresponding metric.
    /// Along the system dimension (over all threads) the value is summed up.
    double
    get_sev( Metric*            metric,
             CalculationFlavour mf,
             Sysres*            sys,
             CalculationFlavour sf );

    /// Calculates an exclusive or an inclusive Value for given Metric, whole calltree and whole machine.
    /// Returns the "double" representation of the internal "Value" if possible.
    /// Uses the corresponding call "get_excl_sev_adv(...)"
    double
    get_sev( Metric*            metric,
             CalculationFlavour mf );


    // to complete call list
    double
    get_sev( Cnode*             cnode,
             CalculationFlavour cf );
    double
    get_sev( Region*            region,
             CalculationFlavour rf );
    double
    get_sev( Sysres*            sys,
             CalculationFlavour sf );





// ----------- analysis part with aggregation  (used by GUI. )  ---------------------



    Value*
    get_sev_adv( list_of_metrics &  metrics,
                 Cnode*             cnode,
                 CalculationFlavour cf );
    double
    get_sev( list_of_metrics &  metrics,
             Cnode*             cnode,
             CalculationFlavour cf );





    Value*
    get_sev_adv( list_of_metrics &  metrics,
                 Region*            region,
                 CalculationFlavour rf );
    double
    get_sev( list_of_metrics &  metrics,
             Region*            region,
             CalculationFlavour rf );

    Value*
    get_sev_adv( list_of_metrics &  metrics,
                 Sysres*            sysres,
                 CalculationFlavour sf );
    double
    get_sev( list_of_metrics &  metrics,
             Sysres*            sysres,
             CalculationFlavour sf );


    Value*
    get_sev_adv( list_of_cnodes &   cnodes,
                 Metric*            metric,
                 CalculationFlavour mf );
    double
    get_sev( list_of_cnodes &   cnodes,
             Metric*            metric,
             CalculationFlavour mf );


    double
    get_sev( list_of_cnodes &   cnodes,
             Sysres*            sysres,
             CalculationFlavour sf );


    Value*
    get_sev_adv( list_of_regions &  regions,
                 Metric*            metric,
                 CalculationFlavour mf );
    double
    get_sev( list_of_regions &  regions,
             Metric*            metric,
             CalculationFlavour mf );


    double
    get_sev( list_of_regions &  regions,
             Sysres*            sysres,
             CalculationFlavour sf );


    Value*
    get_sev_adv( list_of_sysresources & sysres,
                 Metric*                metric,
                 CalculationFlavour     mf );
    double
    get_sev( list_of_sysresources & sysres,
             Metric*                metric,
             CalculationFlavour     mf );

    double
    get_sev( list_of_sysresources & sysres,
             Cnode*                 cnode,
             CalculationFlavour     cf );
    double
    get_sev( list_of_sysresources & sysres,
             Region*                region,
             CalculationFlavour     rf );

    //------------------------- right panel ---------------------------------

    Value*
    get_sev_adv( list_of_metrics &  metrics,
                 list_of_cnodes &   cnodes,
                 Sysres*            sys,
                 CalculationFlavour sf );
    double
    get_sev( list_of_metrics &  metrics,
             list_of_cnodes &   cnodes,
             Sysres*            sys,
             CalculationFlavour sf );

    Value*
    get_sev_adv( list_of_metrics &  metrics,
                 list_of_regions &  regions,
                 Sysres*            sys,
                 CalculationFlavour sf );
    double
    get_sev( list_of_metrics &  metrics,
             list_of_regions &  regions,
             Sysres*            sys,
             CalculationFlavour sf );

    Value*
    get_sev_adv( list_of_metrics &      metrics,
                 list_of_sysresources & sys_res,
                 Cnode*                 cnode,
                 CalculationFlavour     cf );
    double
    get_sev( list_of_metrics &      metrics,
             list_of_sysresources & sys_res,
             Cnode*                 cnode,
             CalculationFlavour     cf );


    Value*
    get_sev_adv( list_of_metrics &      metrics,
                 list_of_sysresources & sys_res,
                 Region*                region,
                 CalculationFlavour     rf );
    double
    get_sev( list_of_metrics &      metrics,
             list_of_sysresources & sys_res,
             Region*                region,
             CalculationFlavour     rf );



    Value*
    get_sev_adv( list_of_cnodes &       cnodes,
                 list_of_sysresources & sys_res,
                 Metric*                metric,
                 CalculationFlavour     mf );
    double
    get_sev( list_of_cnodes &       cnodes,
             list_of_sysresources & sys_res,
             Metric*                metric,
             CalculationFlavour     mf );


    Value*
    get_sev_adv( list_of_regions &      regions,
                 list_of_sysresources & sys_res,
                 Metric*                metric,
                 CalculationFlavour     mf );
    double
    get_sev( list_of_regions &      regions,
             list_of_sysresources & sys_res,
             Metric*                metric,
             CalculationFlavour     mf );




    //-------------------- end of analysis part  ------------------------


// ---------------- optimisation of writting ------------------
    /// Gives the user of Cube an opportunity to write every metric in for it
    /// optimal way. If the user does it, metric doesn't have to make optimisation of the
    /// underlying AdvancedMatrix for faster reading.
    /// Returns the sequence of the callnodes. By writing in this order one avoids the optimisation delay
    /// and gets from the beginnnig the optimal data file.
    vector<Cnode* >
    get_optimal_sequence( Metric* metric );

// _---------------------- end of ADVANCED PART ------------------------



    /// setting the cubewide stratedy
    void
    setGlobalMemoryStrategy( CubeStrategy strategy );

    /// setting the metric own stratedy
    void
    setMetricMemoryStrategy( Metric*      met,
                             CubeStrategy strategy );


    /// droping row  if strategy will allow it (manual for example)
    void
    dropRowInMetric( Metric* met,
                     Cnode*  row );

    /// drop specific row in all metrics
    void
    dropRowInAllMetrics( Cnode* row );




    /// get attribute
    std::string
    get_attr( const std::string& key ) const;

    /// get attributes
    const std::map<std::string, std::string>&
    get_attrs() const
    {
        return attrs;
    }

    /// get mirrors
    const std::vector<std::string>&
    get_mirrors() const;

    /// get mirrors
    std::vector<std::string>&
    get_mirror()
    {
        return mirror_urlv;
    }

    /// returns the number of threads
    int
    max_num_thrd() const;

    /// search for metrics
    Metric*
    get_met( const std::string& uniq_name ) const;

    /// get a root of metrics
    Metric*
    get_root_met( Metric* met );

    /// search for cnodes
    Cnode*
    get_cnode( Cnode& cn ) const;

    /// search for sysres (machines, nodes)
    Machine*
    get_mach( Machine& mach ) const;

    /// get a machine node
    Node*
    get_node( Node& node ) const;

// ------ additinal writing ----------------
    void
    writeXML_header( std::ostream&,
                     bool cube3_export );                               ///< Writes a meta part in the cube3 file or a metafile of cube4. cube3_export signalize, that one exports into cube3 format.
    void
    writeXML_data( std::ostream& );                                     ///< Writes a data part in cube3 format. Used to transform cube4 into cube3 format.
    void
    writeXML_closing( std::ostream& );                                  ///< Finisches the metafile by writing "</cube>"

//------------------------------------------


//     void
//     restore_calltree()							///< Restores a calltree form backop copy.
//     {
//      cnodev = fullcnodev;
//      root_cnodev = root_cnodev_backup;
//
//     }
//
    void
    reroot_cnode( Cnode* );                                               ///< Sets this cnode as a root element.

    void
    prune_cnode( Cnode* );                                                ///< Cuts this cnode and sets the parent as a leaf. If this cnode is a root, it removes it from call tree. Backup copy is not touched.

    void
    set_cnode_as_leaf( Cnode* );


    void
    set_statistic_name( const std::string& _stat )
    {
        def_attr( "statisticfile", _stat );
    };                                           ///< Sets the name of the statistic file in cube.
    std::string
    get_statistic_name();                        ///< Returns the name of the statistic file in cube.


    void
    enable_flat_tree( const bool status )
    {
        def_attr( "withflattree", ( status ) ? "yes" : "no" );
    };                                                                                                      ///< Saves attribute "withflattree" to "yes", if it should be enabled

    bool
    is_flat_tree_enabled();                         ///< Returns true -> if flattree is enabled.



    void
    set_metrics_title( const std::string& _metrics )
    {
        metrics_title = _metrics;
    };                                                                                              ///< Sets the name of the metrics dimension in cube.
    std::string
    get_metrics_title()
    {
        return metrics_title;
    };                                                                   ///< Returns the name of the metrics dimension in cube.

    void
    set_calltree_title( const std::string& _calltree )
    {
        calltree_title = _calltree;
    };                                                                                                  ///< Sets the name of the program dimension in cube.
    std::string
    get_calltree_title()
    {
        return calltree_title;
    };                                                                     ///< Returns the name of the program dimension in cube.

    void
    set_systemtree_title( const std::string& _systemtree )
    {
        systemtree_title = _systemtree;
    };                                                                      ///< Sets the name of the system dimension in cube.
    std::string
    get_systemtree_title()
    {
        return systemtree_title;
    };                                                                         ///< Returns the name of the system dimension in cube.


    uint32_t
    get_number_void_threads();                                                  ///< Calculates number of void threads. Used in setup_cubepl1_memory()
    uint32_t
    get_number_void_processes();                                                ///< Calculates number of void processes. Used in setup_cubepl1_memory()
    void
    setup_cubepl1_memory();                                                     ///< Stores in the memory manager for CubePL1 evaluations a set of values, related to the calculation context: number of metrics, number of regions, etc.




    void
    set_post_initialization( bool _v )
    {
        postcompilation_of_derived_metrics = _v;
    };                                                                             ///< sets the postinitialization of metrics. Open this interface for different parsers.


    void
    compile_derived_metric_expressions();                       ///< After reading in the cube and creationg the structure, one runs over all metrics and compiles their expressions.


    vector<string>
    get_misc_data();                                                    ///< Returns a list of file names, stored in the cube. Including cube-format related files.

    vector<char>
    get_misc_data( string & dataname );                           ///< Returns a vector with the content of the file "dataname" if present, otherwise empty;
    void
    write_misc_data( string &    dataname,
                     const char* buffer,
                     size_t      len );                                                              ///< stores anydata inside of cube. C-like call
    void
    write_misc_data( string & dataname,
                     vector<char>& );                                                   ///< stores anydata inside of cube.

    bool
    is_clustering_on()                                                                  ///< Returns, if one expands clusters
    {
        return !disable_clustering;
    };

    void
    enable_clustering( bool status )
    {
        disable_clustering = !status;
    }
    void
    set_clusters_count( std::map<uint64_t, std::map<uint64_t, uint64_t > > counter )                            ///< Sets cluster counters in cube. It is set syntax parser if clustering is enabled. Otherwise it stays empty.
    {
        cluster_counter = counter;
    }
    std::map<uint64_t,  std::map<uint64_t, uint64_t > > &
    get_clusters_counter()                                                                              ///< Sets cluster counters in cube. It is set syntax parser if clustering is enabled. Otherwise it stays empty.
    {
        return cluster_counter;
    }

    void
    set_original_root_cnodev( std::vector<cube::Cnode*> & vec )
    {
        original_root_cnodev = vec;
    }

    CubePL1MemoryManager*
    get_cubepl_memory_manager()
    {
        return cubepl1_memory_manager;
    }

    // here one can store all working copies of cnodes, which should be removed if Cube object is deleted and which are not direct part
    // of calltree dimension. (clustering remapping cnodes)
    void
    store_ghost_cnode( Cnode* _cnode )
    {
        remapping_cnodev[ _cnode ] = 1;
    }


protected:

    // metric dimension
    std::vector<Metric*> metv;                     ///<  Vector of metrics. Plain storage. Tree hierarchy is saved inside of metric.
    // program dimension
    std::vector<Region*> regv;                     ///<  Vector of region. Plain storage. Tree hierarchy is saved inside of region.
    std::vector<Cnode*>  cnodev;                   ///<  Vector of call threes after operation prune.
    std::vector<Cnode*>  fullcnodev;               ///<  Full vector of call threes. Plain storage. Tree hierarchy is saved inside of cnode.
    // system dimension
    std::vector<Sysres*> sysv;                     ///<  Vector of system resources.
//     std::vector<Machine*>        machv;            ///<  Vector of machines.
//     std::vector<Node*>           nodev;            ///<  Vector of nodes.
//     std::vector<Process*>        procv;            ///<  Vector of processes.
//     std::vector<Thread*>         thrdv;            ///< Vector of threads
    std::vector<SystemTreeNode*> stnv;             ///<  Vector of SystemTreeNodes.
    std::vector<SystemTreeNode*> root_stnv;        ///<  Vector of root systen tree nodes.
    std::vector<SystemTreeNode*> non_root_stnv;    ///<  Vector of not  root systen tree nodes. (nodes in old model)
    std::vector<SystemTreeNode*> machv;            ///<  Vector of systen tree nodes , wich are "machines"
    std::vector<SystemTreeNode*> nodev;            ///<  Vector of systen tree nodes, which are  "nodes"

    std::vector<LocationGroup*>  location_groupv;  ///<  Vector of location groups.
    std::vector<Location*>       locationv;        ///<  Vector of locations.



    std::vector<Cartesian*>            cartv;       ///< Vector of topologie, used in cube.
    std::map<std::string, std::string> attrs;       ///< attributes <key, value>
    std::vector<std::string>           mirror_urlv; ///< mirror urls


    //severity.
//     std::map<Metric*, Matrix*> sev_matm; // ABSOLETE
//     Matrix* get_sev_matrix(Metric* metric);  // ABSOLETE

    /// roots of metric dimension
    std::vector<Metric*> root_metv;
    /// roots of call tree (actual, also after reroot operations)
    std::vector<Cnode*>  root_cnodev;

    // vector storing original calltree, if clastering id on.
    std::vector<Cnode*> original_root_cnodev;

    // vector storing ghost cnodes, which are used in clustering algorith but not deleted.
    // just bookeeping to delete them and to avoid memory leak
    // Map is used to avoid multiple storing
    std::map<Cnode*, uint8_t> remapping_cnodev;

//     /// roots of call tree stored in cube
//     std::vector<Cnode*>  root_cnodev_backup;



    uint32_t cur_cnode_id;
    uint32_t cur_metric_id;
    uint32_t cur_region_id;
//     uint32_t cur_machine_id;
//     uint32_t cur_node_id;
//     uint32_t cur_process_id;
//     uint32_t cur_thread_id;
    uint32_t cur_stn_id;
    uint32_t cur_location_group_id;
    uint32_t cur_location_id;


// ------------------------ Additional part (for AdvancedMatrix) -----------------
    cube::CubePL1MemoryManager* cubepl1_memory_manager;

    // ghost metrics
    std::vector<Metric*> ghost_metv;                            ///<  Vector of ghost metrics. They are invisible in  Cube and get returned onyl if uniqname is known via get_met

    std::string          cubename;                              ///< Saves the name of the cube. Files get then name [cubename].cubex , [cubename].cubex.data/...

    FileFinder*          filefinder;                            ///< Compoment, which delivers name of the files, according to he different layouts.

    std::string          metrics_title;                         ///< Title of metrics dimension
    std::string          calltree_title;                        ///< Title of program dimension
    std::string          systemtree_title;                      ///< Title of system dimension

///    std::string     filemode;                                   ///< ???????? NOT USED
//     bool              first_call;                               ///< Indicates, that there are no data containers in metrics yet. Ifter creating container no changes in dimensions are allowed.
//     bool              writing_mode;                             ///< Indicates, whether Cube already writed some values. If yes, no changes in dimensions are allowes. Probably redundand with "first_call".
    bool                                                mode_read_only;                     ///< Indicates, that no severities cann be added. Makes "set_sev" having no effect.

    bool                                                postcompilation_of_derived_metrics; ///< Signalizes, that we are in "operator << " and def_met should omit compilation of expression of derived metric.
    bool                                                disable_clustering;                 ///<  Parser disables cllustering reconstruction.
    std::map<uint64_t,   std::map<uint64_t, uint64_t> > cluster_counter;                    ///< Stores count of clusters.



//     bool              only_memory;                              ///< Indicates, that Cube doesn't create any files regular cube4 in the filesystem. Needed to work with old cube2/cube3 files. To storage their values it uses temporary files.
    CubeEnforceSaving enforce_saving;                           ///< Makes cube ignore zeroes or enforce saving.
    void
    create_metrics_data_containers( Metric* met );              ///< Will be called by first call "set_sev_...". Initializes metric
    void
    create_metrics_existing_data_containers( Metric* met );     ///< Creates containers AdvancedMatrix to the existing data file the by first call of "get_sev"
    std::string
    create_prefix( std::string );                               ///< Creates a prefix "[cubename].binary_data/" for the AdvancedMatrix data files.
    void
    assign_ids( Metric* met );                                  ///< Sets the proper ids for given metric in every dimension.
    void
    assign_id_metrics();                                        ///< Sets the proper ids in the metric dimension. Currently empty , coz no special prescription than order of creation is needed.
    void
    create_calltree_ids( Metric* met );                         ///< Sets the proper ids in the calltree dimension for every metric separately.
    void
    create_system_ids();                                        ///< Sets the proper ids in the system dimension. Currently empty, coz no spetial  prescription than order of creation is needed.


    bool
    system_tree_cube3_compatibility_check();                    ///< Checks whether the current system tree can be represented in cube3 model. Used in streaming >> operator.


// --------------------------------------------------------------------------


/**
 * Actual method to create a metric.
 */
    Metric*
    def_met( const std::string& disp_name,
             const std::string& uniq_name,
             const std::string& dtype,
             const std::string& uom,
             const std::string& val,
             const std::string& url,
             const std::string& descr,
             Metric*            parent,
             uint32_t           id,
             TypeOfMetric       type_of_metric = CUBE_METRIC_EXCLUSIVE,
             const std::string& expression = "",
             const std::string& init_expression = "",
             TypeOfMetric       is_ghost = CUBE_METRIC_NO_GHOST );

/**
 * Actual method to create a region.
 */
    Region*
    def_region( const std::string& name,
                long               begln,
                long               endln,
                const std::string& url,
                const std::string& descr,
                const std::string& mod,
                uint32_t           id );

/**
 * Actual method to create a cnode.
 */
//     Cnode*
//     def_cnode( Region*            callee,
//                const std::string& mod,
//                int                line,
//                Cnode*             parent,
//                uint32_t           id );

/**
 * Actual method to create a machine.
 */
    Machine*
    def_mach( const std::string& name,
              const std::string& desc,
              uint32_t           id );

/**
 * Actual method to create a node.
 */
    Node*
    def_node( const std::string& name,
              Machine*           mach,
              uint32_t           id );

/**
 * Actual method to create a process.
 */
    Process*
    def_proc( const std::string& name,
              int                rank,
              Node*              node,
              uint32_t           id );

/**
 * Actual method to create a thread.
 */
    Thread*
    def_thrd( const std::string& name,
              int                rank,
              Process*           proc,
              uint32_t           id );

/**
 * Actual method to create system tree node
 */
    SystemTreeNode*
    def_system_tree_node( const std::string& name,
                          const std::string& desc,
                          const std::string& stn_class,
                          SystemTreeNode*    parent,
                          uint32_t           id
                          );

/**
 * Actual method to create location group
 */
    LocationGroup*
    def_location_group( const std::string& name,
                        int                rank,
                        LocationGroupType  type,
                        SystemTreeNode*    parent,
                        uint32_t           id
                        );

/**
 * Actual method to create a location
 */
    Location*
    def_location( const std::string& name,
                  int                rank,
                  LocationType       type,
                  LocationGroup*     parent,
                  uint32_t           id
                  );


// ------------------ Calls needed by construcor Cube(Cube&)-------------------------------------------------------

/**
 * Creates a copy of metric _met. To set parent, it uses the mapping met_map. All parents should be already present in the mapping table.
 */
    Metric*
    def_met( Metric* _met,
             map<Metric*, Metric*>& met_map );



/**
 * Creates a copy of region _region.
 */
    Region*
    def_region( Region* _region );


/**
 * Creates a copy of cnode _cnode. To set parent, it uses the mapping cnode_map. All parents should be already present in the mapping table. To set a region, it uses mapping region_map
 */
    Cnode*
    def_cnode( Cnode* _cnode,
               map<Cnode*, Cnode*>& cnode_map,
               map<Region*, Region*>& region_map,
               bool copy_id = false
               );


    /**
     * Creates a copy of machines _machine.
     */
    Machine*
    def_mach( Machine* _machine );

    /**
     * Creates a copy of node _node. To set a parent, it uses mapping mach_map
     */
    Node*
    def_node( Node* _node,
              map< Machine*, Machine*> & mach_map );

    /**
     * Creates a copy of process _process. To set a parent, it uses mapping node_map
     */
    Process*
    def_proc( Process* _process,
              map< Node*, Node*> & node_map );

    /**
     * Creates a copy of node _node. To set a parent, it uses mapping mach_map
     */
    Thread*
    def_thrd( Thread* _thread,
              map< Process*, Process*> & process_map );

    /**
     * Creates a copy of system tree nodes _machine.
     */
    SystemTreeNode*
    def_system_tree_node( SystemTreeNode* _stn,
                          map< SystemTreeNode*, SystemTreeNode*> & stn_map  );

    /**
     * Creates a copy of location group _locationGroup. To set a parent, it uses mapping stn_map
     */
    LocationGroup*
    def_location_group( LocationGroup* _locationGroup,
                        map< SystemTreeNode*, SystemTreeNode*> & stn_map );

    /**
     * Creates a copy of node _node. To set a parent, it uses mapping locationGroup_map
     */
    Location*
    def_location( Location* _locationGroup,
                  map< LocationGroup*, LocationGroup*> & locationGroup_map );





    /**
     * Creates a copy of topology _node. To set a parent, it uses mapping mach_map
     */
//     Cartesian*   def_cart(Cartesian * _topo, map< Thread*, Thread*> & thread_map);



//    friend class MdAggrCube; ///< Extension of Student M.Meyer (or whoever).. class MdAggrCube is a part of tools. should be them moved into library...
    friend class Parser;                  ///< Parser (not defined anywhere)
    friend class cubeparser::Cube4Parser; ///< Parser of saved .cube v4.0
//    friend class cubeparser::Cube3Parser; ///< Parser of saved .cube v3.0


    // write to a file
/**
 * Write a cube3 file.
 */
    void
    write( const std::string& filename );
};

// I/O operators
/// Read a cube meta part. If it reads the cube3, it sets "only_memory", "writing_mode" flag during the reading of the "<severity>...</severity>" part of the cube2/cube3 file.
std::istream&
operator>>( std::istream& in,
            Cube&         cb );

/// Writes a cube3 version of the cube.
std::ostream&
operator<<( std::ostream& out,
            Cube&         cb );
}

#endif
