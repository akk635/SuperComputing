/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


/**
 * \file CubeFileTmpLayout.cpp
 * \brief Implements common parts of the interface for temporary (only memory) layout of CUBE report, containgin an anchor and directory with data.
 */
#ifndef __FILE_TMP_LAYOUT_CPP
#define __FILE_TMP_LAYOUT_CPP


#include <inttypes.h>
#include <stdint.h>
#include <map>
#include <string>
#include <vector>
#include <iostream>

#include "CubeMetric.h"
#include "CubeFileTmpLayout.h"

using namespace cube;
using namespace std;


std::string
FileTmpLayout::getPathToAnchor()
{
    return "";
}
std::string
FileTmpLayout::getPathToData()
{
    return "";
}
std::string
FileTmpLayout::getPathToMetricData( cube::Metric* met )
{
    return "";
}

std::string
FileTmpLayout::getPathToMetricIndex( cube::Metric* met )
{
    return "";
}

std::string
FileTmpLayout::getAnchorName()
{
    return "";
}

std::string
FileTmpLayout::getMetricDataName( cube::Metric* met )
{
    return getDataExtension();
}

std::string
FileTmpLayout::getMetricIndexName( cube::Metric* met )
{
    return getIndexExtension();
}


#endif
