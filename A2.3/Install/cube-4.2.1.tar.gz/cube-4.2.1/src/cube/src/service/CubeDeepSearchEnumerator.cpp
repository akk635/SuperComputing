/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubeDeepSearchEnumerator.cpp
 * \brief Implements methods of the object DeepSearchEnumerator.
 */
#ifndef CUBE_DEEP_SEARCH_ENUMERATOR_CPP
#define CUBE_DEEP_SEARCH_ENUMERATOR_CPP

#include "CubeDeepSearchEnumerator.h"

#include <iostream>


using namespace cube;
using namespace std;

row_of_objects_t*
DeepSearchEnumerator::traverse( row_of_objects_t* row,  Vertex* root )
{
    if ( root == NULL )
    {
        return row;             // no children any more ;
    }
    row->push_back( root );
    for ( unsigned i = 0; i < root->num_children(); i++ )
    {
        row = traverse( row, root->get_child( i ) );
    }
    return row;
}







#endif
