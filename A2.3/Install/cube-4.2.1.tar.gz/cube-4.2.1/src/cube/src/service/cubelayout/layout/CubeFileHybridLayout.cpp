/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


/**
 * \file CubeFileHybridLayout.cpp
 * \brief Implements common parts of the interface for hybrid layout of CUBE report, containgin an anchor and directory with data.
 */
#ifndef __FILE_HYBRID_LAYOUT_CPP
#define __FILE_HYBRID_LAYOUT_CPP


#include <inttypes.h>
#include <stdint.h>
#include <map>
#include <string>
#include <vector>
#include <iostream>

#include "CubeMetric.h"
#include "CubeFileHybridLayout.h"

using namespace cube;
using namespace std;

std::string
FileHybridLayout::getPathToAnchor()
{
    return "";
}
std::string
FileHybridLayout::getPathToData()
{
    return reportname + getAnchorExtension() + ".misc/";
}
std::string
FileHybridLayout::getPathToMetricData( cube::Metric* met )
{
    return reportname + getAnchorExtension() + ".data/";
}

std::string
FileHybridLayout::getPathToMetricIndex( cube::Metric* met )
{
    return reportname + getAnchorExtension() + ".data/";
}

std::string
FileHybridLayout::getAnchorName()
{
    return reportname + getAnchorExtension();
}

std::string
FileHybridLayout::getMetricDataName( cube::Metric* met )
{
    return met->get_uniq_name() + getDataExtension();
}

std::string
FileHybridLayout::getMetricIndexName( cube::Metric* met )
{
    return met->get_uniq_name() + getIndexExtension();
}


#endif
