/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubeObjectsEnumerator.cpp
 * \brief Implements methods of the object ObjectsEnumerator.
 */
#ifndef CUBE_OBJECT_ENUMERATOR_CPP
#define CUBE_OBJECT_ENUMERATOR_CPP

#include "CubeObjectsEnumerator.h"


using namespace cube;

row_of_objects_t*
ObjectsEnumerator::get_objects_to_enumerate( Vertex* root, row_of_objects_t* row )
{
//     calltree_strides.clear();
    if ( row == NULL )
    {
        row = new row_of_objects_t();
    }
    row = traverse( row, root );
    return row;
}


/*

   row_of_objects_t*
   ObjectsEnumerator::get_objects_to_enumerate( Machine* root, row_of_objects_t* row )
   {
   //     calltree_strides.clear();
    if ( row == NULL )
    {
        row = new row_of_objects_t();
    }
    if ( root == NULL )
    {
        return row;               // return empty row, if there is no machine object
    }
    if ( root->num_children() == 0 )
    {
        return row;                            // return empty row, if there is no nodes in the machine
    }
    for ( unsigned i = 0; i < root->num_children(); i++ )
    {
        row = get_objects_to_enumerate( root->get_child( i ), row );
    }
    return row;
   }



   row_of_objects_t*
   ObjectsEnumerator::get_objects_to_enumerate( Node* root, row_of_objects_t* row )
   {
   //     calltree_strides.clear();
    if ( row == NULL )
    {
        row = new row_of_objects_t();
    }
    if ( root == NULL )
    {
        return row;               // return empty row, if there is no machine object
    }
    if ( root->num_children() == 0 )
    {
        return row;                            // return empty row, if there is no nodes in the machine
    }
    for ( unsigned i = 0; i < root->num_children(); i++ )
    {
        row = get_objects_to_enumerate( root->get_child( i ), row );
    }
    return row;
   }



   row_of_objects_t*
   ObjectsEnumerator::get_objects_to_enumerate( Process* root, row_of_objects_t* row )
   {
   //     calltree_strides.clear();
    if ( row == NULL )
    {
        row = new row_of_objects_t();
    }
    if ( root == NULL )
    {
        return row;               // return empty row, if there is no machine object
    }
    if ( root->num_children() == 0 )
    {
        return row;                            // return empty row, if there is no nodes in the machine
    }
    for ( unsigned i = 0; i < root->num_children(); i++ )
    {
        row = get_objects_to_enumerate( root->get_child( i ), row );
    }
    return row;
   }

   row_of_objects_t*
   ObjectsEnumerator::get_objects_to_enumerate( Thread* root, row_of_objects_t* row )
   {
   //     calltree_strides.clear();
    if ( row == NULL )
    {
        row = new row_of_objects_t();
    }
    if ( root == NULL )
    {
        return row;               // return empty row, if there is no machine object
    }
    if ( root->num_children() == 0 )
    {
        return row;                            // return empty row, if there is no nodes in the machine
    }
    for ( unsigned i = 0; i < root->num_children(); i++ )
    {
        row = traverse( row, root->get_child( i ) );
    }
    return row;
   }

 */


/*
   void
   ObjectsEnumerator::get_strides( std::map<unsigned, signed int>  & strides )
   {
    for ( std::map<unsigned, signed int >::iterator iter = calltree_strides.begin(); iter != calltree_strides.end(); iter++ )
    {
        strides[ ( *iter ).first ] = ( *iter ).second;
    }
    return;
   }*/


// ------------------ protected part -----------------------------


row_of_objects_t*
ObjectsEnumerator::traverse( row_of_objects_t* row,  Vertex* root )
{
    if ( root == NULL )
    {
        return row;             // no children any more ;
    }

    if ( row->size() <= root->get_id() )
    {
        row->resize( root->get_id() + 1 );
    }

    ( *row )[ ( root->get_id() ) ] = root;
    for ( unsigned i = 0; i < root->num_children(); i++ )
    {
        row = traverse( row, root->get_child( i ) );
    }

    return row;
}







#endif
