/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


/**
 * \file CubeFileEmbeddedLayout.cpp
 * \brief Implements common parts of the interface for embedded layout of CUBE report.
 */
#ifndef __FILE_EMBEDDED_LAYOUT_CPP
#define __FILE_EMBEDDED_LAYOUT_CPP


#include <inttypes.h>
#include <stdint.h>
#include <map>
#include <string>
#include <vector>
#include <iostream>
#include <sstream>

#include "CubeMetric.h"
#include "CubeFileEmbeddedLayout.h"

using namespace cube;
using namespace std;

std::string
FileEmbeddedLayout::getPathToAnchor()
{
    return "";
}
std::string
FileEmbeddedLayout::getPathToData()
{
    return "";
}

std::string
FileEmbeddedLayout::getPathToMetricData( cube::Metric* met )
{
    return "";
}

std::string
FileEmbeddedLayout::getPathToMetricIndex( cube::Metric* met )
{
    return "";
}

std::string
FileEmbeddedLayout::getAnchorName()
{
    return "anchor" + getOwnAnchorExtension();
}

std::string
FileEmbeddedLayout::getMetricDataName( cube::Metric* met )
{
    std::ostringstream stream;
    stream << met->get_id();

    return stream.str() + getDataExtension();
}

std::string
FileEmbeddedLayout::getMetricIndexName( cube::Metric* met )
{
    std::ostringstream stream;
    stream << met->get_id();

    return stream.str() + getIndexExtension();
}


#endif
