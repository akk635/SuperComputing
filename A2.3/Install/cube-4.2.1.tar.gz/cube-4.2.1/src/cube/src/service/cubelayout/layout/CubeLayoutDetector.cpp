/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


/**
 * \file CubeLayoutDetector.cpp
 * \brief Provides a method to select a proper Lyout and Container to use in Cube
 */

#ifndef __LAYOUT_DETECTOR_CPP
#define __LAYOUT_DETECTOR_CPP

#include <string>
#include <cstdlib>
#include <iostream>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "CubeLayoutDetector.h"
#include "CubeError.h"
#include "CubeFileFinder.h"
#include "CubeLayouts.h"
#include "CubeSimpleReader.h"
#include "CubeTarReader.h"
#include "CubeServices.h"


using namespace std;
using namespace cube;




FileFinder*
LayoutDetector::getFileFinder( const std::string & cubename )
{
    static std::string extensions[ 1 ];
    extensions[ 0 ] = ".tar";
    // first check , whether it is a directory.
    struct stat stat_of_file;
    if ( stat( cubename.c_str(), &stat_of_file ) != -1 )
    {
        if ( S_ISDIR( stat_of_file.st_mode ) )
        {   // it is a directors, therefore
            if ( services::is_cube4_hyb_dir( cubename ) )
            {
                FILE* f = fopen( ( services::get_cube4_hyb_dir_name( cubename ) + ".cubex" ).c_str(), "r" );
                if ( f != NULL )
                {
                    fclose( f );
                    return new FileFinder( new SimpleReader(), new FileHybridLayout( services::get_cube4_hyb_dir_name( cubename ) ) );
                }
            }
            return new FileFinder( new SimpleReader(), new FileDirLayout( cubename ) );
        }
    }
    bool        istar = false;

    std::string tarname = ( services::get_cube4_name( cubename ) + ".cubex" );

    FILE*       tar = fopen( tarname.c_str(), "r" );
    if ( tar != NULL )
    {
        tar_gnu_header header;
        size_t         readedsize = fread( ( char* )&header, 1, sizeof( tar_gnu_header ), tar );
        if ( readedsize == sizeof( tar_gnu_header ) )
        {   // readed 512 bytes .... good signn
            if (
                ( strcmp( header.magic, "ustar" ) == 0 ) ||
                ( strcmp( header.magic, "ustar  " ) == 0 ) ||
                ( strcmp( header.magic, "ustar 00" ) == 0 )
                )
            {   // it is a tar archive
                istar = true;
                fclose( tar );
            }
        }
    }
    // then according the header and marker "ustar"
    if ( istar )
    {
        TarReader* tr = new TarReader( tarname );
        if ( tr->contains( ".cubex.data/" ) && tr->contains_ending( ".cubex" ) )
        {
            string name = services::get_cube4_name( tr->get_file_before( ".cubex" ) );

            return new FileFinder( tr, new FileHybridLayout( name ) );   // special case, if hte archive named "anchor" but has a hybrid layout.
        }
        if ( tr->contains( ".cubex/" ) && tr->contains_ending( ".cubex" ) )
        {
            string name = services::remove_last_slashes( tr->get_file_before( ".cubex/" ) );

            return new FileFinder( tr, new FileDirLayout( name ) );   // special case, if hte archive named "anchor" but has a hybrid layout.
        }
        if ( tr->contains( "/" ) && tr->contains_ending( "/anchor.cubex" ) )
        {
            string name = services::remove_last_slashes( tr->get_file_before( "/" ) );

            return new FileFinder( tr, new FileDirLayout( name ) );   // special case, if hte archive named "anchor" but has a hybrid layout.
        }

        if ( tr->contains_ending( "anchor.xml" ) )
        {
            return new FileFinder( tr, new FileEmbeddedLayout( cubename ) );   // special case, if hte archive named "anchor" but has a hybrid layout.
        }
        throw NoFileInTarError( "anchor.xml" );
    }
    int found1 = ( int )cubename.rfind( "anchor" + FileBaseLayout::getAnchorExtension() );
    int found2 = ( int )cubename.rfind( "anchor" );
    int found  = -1;
    if ( found1 ==  ( int )( ( int )cubename.length() - ( 6 + FileBaseLayout::getAnchorExtension().length() ) ) )
    {
        found = found1;
    }
    if ( found2 ==  ( int )( ( int )cubename.length() - ( 6 ) ) )
    {
        found = found2;
    }

    if ( found != -1 )    // it means, something was found
    {
        std::string datadir = ( services::get_cube4_hyb_dir_name( cubename ) + FileHybridLayout::getDataDirExtension() );

        if ( stat( datadir.c_str(), &stat_of_file ) != -1 )
        {
//

            if ( S_ISDIR( stat_of_file.st_mode ) )
            {             // it is a directors, therefore it is a hybrid layout
                return new FileFinder( new SimpleReader(), new FileHybridLayout( services::get_cube4_name( cubename ) ) );
            }
            throw RuntimeError( datadir + " is expected to be a directory. But it is not a directory." );
        }
        else
        {
            // there is no directory and it is "anchor.cubex."
            // shoukld be DirLyout
            std::string dircube = cubename.substr( 0, found );
            if ( dircube == "" )
            {
                return new FileFinder( new SimpleReader(), new FileEmbeddedLayout( dircube ) );
            }
            return new FileFinder( new SimpleReader(), new FileDirLayout( dircube ) );
        }
        // there is no directory and it is  "anchor.cubex."
        // therefore it should be a hybrid case
        //  return new FileFinder( new SimpleReader(), new FileEmbeddedLayout( services::get_cube4_name( cubename ) ) );
    }
    // assume simply container and hybrid layout.
    return new FileFinder( new SimpleReader(), new FileHybridLayout( services::get_cube4_name( cubename ) ) );
//    throw RuntimeError( "All tests failed. Cannot determine what layout to use to create CUBE object. No file " + cubename );
}


FileFinder*
LayoutDetector::getDefaultFileFinderForWriting()
{
    bool        creating_mode = true;
    std::string name          = services::get_tmp_files_location() + "./cubex." + services::create_random_string( 10 ) + "/" + services::create_random_string( 5 ) + ".cubex/";
    return new FileFinder( new TarReader( name, creating_mode ), new FileEmbeddedLayout( services::get_cube4_name( name ) ), creating_mode );
}


FileFinder*
LayoutDetector::getTmpFileFinder()
{
    bool        creating_mode = true;
    std::string name          = services::get_tmp_files_location() + "./cubex." + services::create_random_string( 10 ) + "/" + services::create_random_string( 5 ) + ".cubex";
    return new FileFinder( new TarReader( name, creating_mode ), new FileEmbeddedLayout( services::get_cube4_name( name ) ), creating_mode );
//     return new FileFinder( new SimpleReader(), new FileTmpLayout() );
}



#endif
