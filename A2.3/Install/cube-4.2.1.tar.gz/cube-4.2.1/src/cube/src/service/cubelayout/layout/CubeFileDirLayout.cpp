/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/


/**
 * \file CubeFileDirLayout.cpp
 * \brief Implements common parts of the interface for  layout of CUBE report in commone directory.
 */
#ifndef __FILE_DIR_LAYOUT_CPP
#define __FILE_DIR_LAYOUT_CPP


#include <inttypes.h>
#include <stdint.h>
#include <map>
#include <string>
#include <vector>
#include <iostream>

#include "CubeMetric.h"
#include "CubeFileDirLayout.h"

using namespace cube;
using namespace std;


std::string
FileDirLayout::getPathToAnchor()
{
    return reportname + "/";
}
std::string
FileDirLayout::getPathToData()
{
    return reportname + "/";
}
std::string
FileDirLayout::getPathToMetricData( cube::Metric* met )
{
    return reportname + "/";
}

std::string
FileDirLayout::getPathToMetricIndex( cube::Metric* met )
{
    return reportname + "/";
}

std::string
FileDirLayout::getAnchorName()
{
    return "anchor" + getAnchorExtension();
}

std::string
FileDirLayout::getMetricDataName( cube::Metric* met )
{
    return met->get_uniq_name() + getDataExtension();
}

std::string
FileDirLayout::getMetricIndexName( cube::Metric* met )
{
    return met->get_uniq_name() + getIndexExtension();
}


#endif
