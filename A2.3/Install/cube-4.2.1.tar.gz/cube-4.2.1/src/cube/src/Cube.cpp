/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 * \file Cube.cpp
 * \brief Defines methods of the class cube and IO-interface.
 *
 */

// PGI compiler replaces all ofstream.open() calls by open64 and then cannot find a propper one. Result -> compilation error
#if !defined( __PGI ) && !defined( __CRAYXT )  && !defined( __CRAYXE )
#define _FILE_OFFSET_BITS 64
#endif

#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <stdio.h>
// #ifndef CUBE_COMPRESSED
#include <fstream>
// #include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

// #else
#include "CubeZfstream.h"
// #endif

#include "CubeCartesian.h"
#include "CubeCnode.h"
#include "CubeMetric.h"
#include "CubeInclusiveMetric.h"
#include "CubeExclusiveMetric.h"
#include "CubePostDerivedMetric.h"
#include "CubePreDerivedInclusiveMetric.h"
#include "CubePreDerivedExclusiveMetric.h"
#include "CubeEnumerators.h"
// #include "CubeIDassigner.h"
#include "CubeMachine.h"
//#include "CubeMatrix.h"
#include "CubeNode.h"
#include "CubeProcess.h"
#include "CubeRegion.h"
//#include "CubeRow.h"
#include "CubeSysres.h"
#include "CubeThread.h"

#include "CubeDriver.h"
#include "CubePL1Driver.h"
#include "CubePL1MemoryManager.h"
#include "CubeServices.h"
#include "CubeError.h"

#include "Cube.h"


using namespace std;
using namespace cube;






Cube::Cube( CubeEnforceSaving _enforce_saving )
    : cur_cnode_id( 0 ),
      cur_metric_id( 0 ),
      cur_region_id( 0 ),
      cur_stn_id( 0 ),
      cur_location_group_id( 0 ),
      cur_location_id( 0 )
{
    cubepl1_memory_manager = new CubePL1MemoryManager();
    disable_clustering     = true;
    ghost_metv.clear();
    mode_read_only                     = false;
    postcompilation_of_derived_metrics = false;
    enforce_saving                     = _enforce_saving;
    cubename                           = "";
    filefinder                         = LayoutDetector::getDefaultFileFinderForWriting();
}




Cube::Cube( Cube&             _cube,
            CubeCopyFlag      copy_flag,
            CubeEnforceSaving _enforce_saving
            )
    : cur_cnode_id( 0 ),
      cur_metric_id( 0 ),
      cur_region_id( 0 ),
      cur_stn_id( 0 ),
      cur_location_group_id( 0 ),
      cur_location_id( 0 )
{
    cubepl1_memory_manager = new CubePL1MemoryManager();
    disable_clustering     = true;
    ghost_metv.clear();
    mode_read_only = false;
    set_post_initialization( true );
    enforce_saving = _enforce_saving;

    filefinder = LayoutDetector::getDefaultFileFinderForWriting();



    attrs = _cube.attrs;

    std::map<std::string, std::string>::const_iterator _iter = attrs.find( "CLUSTERING" );
    if ( _iter != attrs.end() )
    {
        attrs[ "CLUSTERING" ] = "OFF"; // disable clustering coz copy contains expanded call tree
    }


    mirror_urlv = _cube.mirror_urlv;

    map<Metric*, Metric*> met_map;

    vector<Metric*>       _metrics = _cube.get_metv();
    for ( vector<Metric*>::iterator m_iter = _metrics.begin(); m_iter != _metrics.end(); m_iter++ )
    {
        Metric* _met = *m_iter;
        if ( _met->isInactive()  )
        {
            continue;
        }
        Metric* my_met = def_met( _met, met_map );
        // create mapping _met -> my_met
        met_map[ _met ] = my_met;
    }

    map<Region*, Region*> region_map;
    vector<Region*>       _regions = _cube.get_regv();

    for ( vector<Region*>::iterator r_iter = _regions.begin(); r_iter != _regions.end(); r_iter++ )
    {
        Region* _reg   = *r_iter;
        Region* my_reg = def_region( _reg );
        // create mapping _reg -> my_reg
        region_map[ _reg ] = my_reg;
    }

    map<Cnode*, Cnode*> cnodes_map;
    vector<Cnode*>      _cnodes = _cube.get_cnodev();

    for ( vector<Cnode*>::iterator c_iter = _cnodes.begin(); c_iter != _cnodes.end(); c_iter++ )
    {
        Cnode* _cnode = *c_iter;

        if ( _cnode->isHidden() ) // do not store hidden cnodes.
        {
            continue;
        }

        Cnode*                                                my_cnode  = def_cnode( _cnode, cnodes_map, region_map );
        std::vector < std::pair < std::string, double> >      _num_pars = _cnode->get_num_parameters();
        std::vector < std::pair < std::string, std::string> > _str_pars = _cnode->get_str_parameters();

        for ( std::vector < std::pair < std::string, double> >::iterator _n_iter = _num_pars.begin(); _n_iter != _num_pars.end(); _n_iter++ )
        {
            my_cnode->add_num_parameter( ( *_n_iter ).first, ( *_n_iter ).second );
        }
        for ( std::vector < std::pair < std::string, std::string> >::iterator _s_iter = _str_pars.begin(); _s_iter != _str_pars.end(); _s_iter++ )
        {
            my_cnode->add_str_parameter( ( *_s_iter ).first, ( *_s_iter ).second );
        }
        cnodes_map[ _cnode ] = my_cnode;
        // create mapping _cnode -> my_cnode
    }


    map<SystemTreeNode*, SystemTreeNode*> stn_map;
    const std::vector<SystemTreeNode*>    _stns  =    _cube.get_root_stnv();
    std::vector<SystemTreeNode*>          _stns2 = _stns;

    for ( size_t i = 0; i < _stns2.size(); i++ )
    {
        SystemTreeNode* _stn   = _stns2[ i ];
        SystemTreeNode* my_stn = def_system_tree_node( _stn, stn_map );
        for ( unsigned int j = 0; j < _stn->num_children(); j++ )
        {
            _stns2.push_back( _stn->get_child( j ) );
        }

        // create mapping _machine -> my_machine
        stn_map[ _stn ] = my_stn;
    }


    map<LocationGroup*, LocationGroup*> lg_map;
    std::vector<LocationGroup*>         _lgs =    _cube.get_procv();
    for ( vector<LocationGroup*>::iterator lg_iter = _lgs.begin(); lg_iter != _lgs.end(); lg_iter++ )
    {
        LocationGroup* _lg   = *lg_iter;
        LocationGroup* my_lg = def_location_group( _lg, stn_map );
        // create mapping _process -> my_process
        lg_map[ _lg ] = my_lg;
    }

    map<Location*, Location*> locs_map;
    std::vector<Location*>    _locations =    _cube.get_locationv();
    for ( vector<Location*>::iterator loc_iter = _locations.begin(); loc_iter != _locations.end(); loc_iter++ )
    {
        Location* _location   = *loc_iter;
        Location* my_location = def_location( _location, lg_map );
        // create mapping _thread -> my_thread
        locs_map[ _location ] = my_location;
    }

    // Copy the cartesian vector.
    vector<Cartesian*> _topos = _cube.get_cartv();
    for ( vector<Cartesian*>::const_iterator topo_iter = _topos.begin(); topo_iter != _topos.end(); topo_iter++ )
    {
        Cartesian* _topo = def_cart( ( *topo_iter )->get_ndims(), ( *topo_iter )->get_dimv(), ( *topo_iter )->get_periodv() );
        _topo->set_name( ( *topo_iter )->get_name() );
        _topo->set_namedims( ( *topo_iter )->get_namedims() );
        std::multimap<const Sysres*, std::vector<long> >           _sys_coords = ( *topo_iter )->get_cart_sys();
        std::multimap<const Sysres*, std::vector<long> >::iterator _siter;
        for ( _siter = _sys_coords.begin(); _siter != _sys_coords.end(); _siter++ )
        {
            Sysres*           _sys = ( Sysres* )( ( *_siter ).first );
            std::vector<long> _v   = ( *_siter ).second;
            if ( _sys->isSystemTreeNode() )
            {
                _topo->def_coords( stn_map[ ( SystemTreeNode* )_sys ], _v );
            }
            if ( _sys->isLocationGroup() )
            {
                _topo->def_coords( lg_map[ ( LocationGroup* )_sys ], _v );
            }
            if ( _sys->isLocation() )
            {
                _topo->def_coords( locs_map[ ( Location* )_sys ], _v );
            }
        }
    }
/*    map<Cartesian*, Cartesian*> topos_map;
    std::vector<Cartesian*> _topologies =    _cube.get_cartv();
    for(vector<Cartesian*>::iterator topo_iter = _topologies.begin(); topo_iter != _topologies.end(); topo_iter++)
    {
        Cartesian * _topo   = *topo_iter;
        Cartesian * my_topo = def_cart(_topo, threads_map);
        // create mapping _topo-> my_topo
        topos_map[_topo] = my_topo;
    }  */

    if ( copy_flag == CUBE_DEEP_COPY ) // data should be copied too
    {
        vector<Metric*>   _metrics = _cube.get_metv();
        vector<Cnode*>    _cnodes  = _cube.get_cnodev();
        vector<Location*> _locs    = _cube.get_locationv();
        for ( vector<Metric*>::iterator m_iter = _metrics.begin(); m_iter != _metrics.end(); m_iter++ )
        {
            Metric* _met = *m_iter;
            if ( _met->get_type_of_metric() != CUBE_METRIC_EXCLUSIVE &&  _met->get_type_of_metric() != CUBE_METRIC_INCLUSIVE  )
            {
                continue; // we do not copy data from derivedc metrics.
            }
            CalculationFlavour cf = ( _met->get_type_of_metric() == CUBE_METRIC_EXCLUSIVE ) ?  cube::CUBE_CALCULATE_EXCLUSIVE : cube::CUBE_CALCULATE_INCLUSIVE;
            if ( _met->isInactive() )
            {
                continue;
            }
            for ( vector<Cnode*>::iterator c_iter = _cnodes.begin(); c_iter != _cnodes.end(); c_iter++ )
            {
                Cnode* _cnode = *c_iter;
                if ( _cnode->isVisible() ) // do not store hidden elements and cnodes. Their value is in value of parent
                {
                    for ( vector<Location*>::iterator loc_iter = _locs.begin(); loc_iter != _locs.end(); loc_iter++ )
                    {
                        Location* _loc = *loc_iter;
                        Value*    _val = _cube.get_sev_adv( _met, cube::CUBE_CALCULATE_INCLUSIVE,  _cnode, cf, _loc, cube::CUBE_CALCULATE_INCLUSIVE );
                        set_sev( met_map[ _met ], cnodes_map[ _cnode ], locs_map[ _loc ],  _val );
                        delete _val;
                    }
                }
            }
        }
    }

    setup_cubepl1_memory();
    compile_derived_metric_expressions();
    set_post_initialization( false );
}



void
Cube::openCubeReport( std::string _cubename, bool _disable_clustering )
{
    disable_clustering = _disable_clustering;
    closeCubeReport();
    cubename = _cubename;
    set_post_initialization( true );


    cubename = services::remove_dotted_path( cubename );


    if ( services::is_cube3_name( cubename ) || services::is_cube3_gzipped_name( cubename ) )
    {
        mode_read_only = false;

        filefinder = LayoutDetector::getTmpFileFinder();
#if defined( FRONTEND_CUBE_COMPRESSED ) || defined ( FRONTEND_CUBE_COMPRESSED_READONLY )
        gzifstream in;
#else
        ifstream   in;
#endif
//      ifstream in;


        in.open( cubename.c_str(), ios::in | ios::binary );

        in >> *this;
        in.close();
    }
    else
    {
        mode_read_only = true;
        filefinder     = LayoutDetector::getFileFinder( cubename );
        fileplace_t anchor = filefinder->getAnchor();

        if ( services::check_file( anchor.first.c_str() ) == 0 )
        {
#if defined( FRONTEND_CUBE_COMPRESSED ) || defined( FRONTEND_CUBE_COMPRESSED_READONLY )
            int ffile = open(  anchor.first.c_str(), O_RDONLY  );
            if ( ( off_t )anchor.second.first != lseek( ffile, anchor.second.first, SEEK_CUR ) )
            {
                cerr << "Cannot seek to the metadata of cube " <<  cubename << endl;
                throw FatalError( "Cannot seek to the metadata of cube " + cubename );
            }

            gzifstream in( ffile, ios::in | ios::binary );
#else
            ifstream   in;
            in.open( anchor.first.c_str(), ios::in | ios::binary );
            in.seekg( anchor.second.first );
#endif
            in >> *this;
            in.close();
        }
        else
        {
            cerr << "Cube \"" << cubename << "\"  cannot be created" << endl;
            throw FatalError( "Cube " + cubename + "cannot be created" );
        }
    }
    setup_cubepl1_memory();
    compile_derived_metric_expressions();
    set_post_initialization( false );
}




Cube::~Cube()
{
    closeCubeReport();
    delete cubepl1_memory_manager;
}


void
Cube::closeCubeReport()
{
    cubepl1_memory_manager->init();
    for ( unsigned int i = 0; i < metv.size(); i++ )
    {
        delete metv[ i ];
    }
    metv.clear();
    for ( unsigned int i = 0; i < ghost_metv.size(); i++ )
    {
        delete ghost_metv[ i ];
    }
    ghost_metv.clear();
    for ( unsigned int i = 0; i < regv.size(); i++ )
    {
        delete regv[ i ];
    }
    regv.clear();
    for ( unsigned int i = 0; i < fullcnodev.size(); i++ )
    {
        delete fullcnodev[ i ];
    }
    cnodev.clear();
    root_cnodev.clear();

    for ( std::map<Cnode*, uint8_t>::iterator iter = remapping_cnodev.begin(); iter != remapping_cnodev.end(); iter++ )
    {
        delete ( *iter ).first;
    }


    for ( unsigned int i = 0; i < stnv.size(); i++ )
    {
        delete stnv[ i ];
    }
    stnv.clear();
    for ( unsigned int i = 0; i < location_groupv.size(); i++ )
    {
        delete location_groupv[ i ];
    }
    location_groupv.clear();
    for ( unsigned int i = 0; i < locationv.size(); i++ )
    {
        delete locationv[ i ];
    }
    locationv.clear();
    for ( unsigned int i = 0; i < cartv.size(); i++ )
    {
        delete cartv[ i ];
    }
    cartv.clear();
    delete filefinder;
    filefinder = NULL;

    cur_cnode_id          = 0;
    cur_metric_id         = 0;
    cur_region_id         = 0;
    cur_stn_id            = 0;
    cur_location_group_id = 0;
    cur_location_id       = 0;
}


void
Cube::writeCubeReport( std::string name )
{
    try
    {
        if ( services::is_path( cubename ) )
        {
            cubename = services::remove_dotted_path( cubename );
            services::create_path_for_file( cubename );
        }
#if defined( FRONTEND_CUBE_COMPRESSED )
        gzofstream out;
#else
        ofstream   out;
        // we write meta part always uncompressed so far - till compression in cubew is implemented
#endif

        fileplace_t anchor = filefinder->getAnchor();
        if ( services::is_path( anchor.first.c_str() ) )
        {
            services::create_path_for_file( anchor.first.c_str() );
        }
        out.open( anchor.first.c_str(), ios::binary );
        out.seekp( anchor.second.first );
        writeXML_header( out, false );
        writeXML_closing( out );
        out.close();
        name = services::remove_dotted_path( name );
        writeMetricsData( name );
//         }
    }
    catch ( FinalizeFilesError err )
    {
        cerr << err.get_msg() << endl;
        cerr << "Clean up...";
        if ( remove( string( name + ".cubex" ).c_str() ) != 0 )
        {
            perror( "" );
        }
        else
        {
            cerr << "done." << endl;
        }
    }
}



void
Cube::writeMetricsData( std::string name )
{
    for ( unsigned int i = 0; i < metv.size(); i++ )
    {
        metv[ i ]->writeData();
    }
    filefinder->finalizeFiles( name );
}



void
Cube::setGlobalMemoryStrategy( CubeStrategy strategy )
{
    for ( unsigned int i = 0; i < metv.size(); i++ )
    {
        setMetricMemoryStrategy( metv[ i ], strategy );
    }
}

void
Cube::setMetricMemoryStrategy( Metric* met,  CubeStrategy strategy )
{
    met->setStrategy( strategy );
}


void
Cube::dropRowInAllMetrics( Cnode* cnode )
{
    for ( unsigned int i = 0; i < metv.size(); i++ )
    {
        dropRowInMetric( metv[ i ], cnode );
    }
}




void
Cube::dropRowInMetric( Metric* met, Cnode* cnode )
{
    met->dropRow( cnode );
}









void
Cube::def_attr( const string& key, const string& value )
{
    attrs[ key ] = value;
}

string
Cube::get_attr( const std::string& key ) const
{
    map<std::string, std::string>::const_iterator it = attrs.find( key );
    if ( it != attrs.end() )
    {
        return it->second;
    }

    return string();
}

void
Cube::def_mirror( const std::string& url )
{
    mirror_urlv.push_back( url );
}

const vector<string>&
Cube::get_mirrors() const
{
    return mirror_urlv;
}

Metric*
Cube::def_met( const string& disp_name,
               const string& uniq_name,
               const string& dtype,
               const string& uom,
               const string& val,
               const string& url,
               const string& descr,
               Metric*       parent,
               TypeOfMetric  type_of_metric,
               const string& expression,
               const string& init_expression,
               TypeOfMetric  is_ghost
               )
{
    if ( is_ghost != CUBE_METRIC_GHOST )
    {
        return def_met( disp_name, uniq_name, dtype, uom, val, url,
                        descr, parent, cur_metric_id, type_of_metric, expression, init_expression, is_ghost );
    }
    else
    {
        return def_met( disp_name, uniq_name, dtype, uom, val, url,
                        descr, parent, ghost_metv.size(), type_of_metric, expression, init_expression, is_ghost );
    }
}

Metric*
Cube::def_met( const string& disp_name,
               const string& uniq_name,
               const string& dtype,
               const string& uom,
               const string& val,
               const string& url,
               const string& descr,
               Metric*       parent,
               uint32_t      id,
               TypeOfMetric  type_of_metric,
               const string& expression,
               const string& init_expression,
               TypeOfMetric  is_ghost )
{
    Metric*                      met = NULL;
    std::string                  derived_metric_error;
    std::string                  derived_metric_init_error;
    cubeplparser::CubePL1Driver* driver      = new cubeplparser::CubePL1Driver( this );
    cubeplparser::CubePL1Driver* init_driver = new cubeplparser::CubePL1Driver( this );
    switch ( type_of_metric )
    {
        case CUBE_METRIC_POSTDERIVED:
        {
            std::string parent_dtype = dtype;
            if ( parent != NULL )
            {
                parent_dtype = parent->get_dtype();
                if (
                    !( strcmp( parent_dtype.c_str(), "FLOAT" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "DOUBLE" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "INTEGER" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "UINT64" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "INT64" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "INT32" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "UINT32" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "INT16" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "UINT16" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "INT8" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "UINT8" ) == 0
                       )
                    )
                {
                    cerr << " Derivated metrics can be created only for parent metrics, which do have data numerical single value data type. Ignode cube::def_met(...) and return NULL";
                    delete driver;
                    delete init_driver;
                    return NULL;
                }
            }
            met = new PostDerivedMetric( disp_name, uniq_name,  parent_dtype, uom, val, url,
                                         descr, filefinder, parent, id, expression, init_expression, is_ghost );
            met->setMemoryManager( cubepl1_memory_manager );
            if ( !postcompilation_of_derived_metrics )
            {
                std::string cubepl_program      = string( "<cubepl>" ) + expression + string( "</cubepl>" );
                std::string cubepl_init_program = string( "<cubepl>" ) + init_expression + string( "</cubepl>" );
                if ( driver->test( cubepl_program, derived_metric_error ) &&
                     driver->test( cubepl_init_program, derived_metric_init_error )
                     )
                {
                    stringstream       strin2( cubepl_init_program );
                    GeneralEvaluation* formula2 = driver->compile( &strin2, &cerr );
                    met->setInitEvaluation( formula2 );
                    stringstream       strin1( cubepl_program );
                    GeneralEvaluation* formula1 = driver->compile( &strin1, &cerr );
                    met->setEvaluation( formula1 );
                }
                else
                {     // cannot create metric, cou compilerr reported an error (??? )
                    cerr << " Cannot create postderived metric with an expression : " << endl << expression <<  endl << " and and init expression " << init_expression << endl << "because of the following error: " <<  derived_metric_error << " " << derived_metric_init_error << endl;
                    delete driver;
                    delete init_driver;
                    return NULL;
                }
            }
            break;
        }
        case CUBE_METRIC_PREDERIVED_INCLUSIVE:
        {
            std::string parent_dtype = dtype;
            if ( parent != NULL )
            {
                parent_dtype = parent->get_dtype();
                if (
                    !( strcmp( parent_dtype.c_str(), "FLOAT" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "DOUBLE" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "INTEGER" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "UINT64" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "INT64" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "INT32" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "UINT32" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "INT16" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "UINT16" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "INT8" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "UINT8" ) == 0
                       )
                    )
                {
                    cerr << " Derivated metrics can be created only for parent metrics, which do have data numerical single value data type. Ignode cube::def_met(...) and return NULL";
                    delete driver;
                    delete init_driver;
                    return NULL;
                }
            }
            met = new PreDerivedInclusiveMetric( disp_name, uniq_name,  parent_dtype, uom, val, url,
                                                 descr, filefinder, parent, id, expression, init_expression, is_ghost  );
            met->setMemoryManager( cubepl1_memory_manager );
            if ( !postcompilation_of_derived_metrics )
            {
                std::string cubepl_program      = string( "<cubepl>" ) + expression + string( "</cubepl>" );
                std::string cubepl_init_program = string( "<cubepl>" ) + init_expression + string( "</cubepl>" );
                if ( driver->test( cubepl_program, derived_metric_error ) &&
                     driver->test( cubepl_init_program, derived_metric_init_error )
                     )
                {
                    stringstream       strin2( cubepl_init_program );
                    GeneralEvaluation* formula2 = driver->compile( &strin2, &cerr );
                    met->setInitEvaluation( formula2 );
                    stringstream       strin1( cubepl_program );
                    GeneralEvaluation* formula1 = driver->compile( &strin1, &cerr );
                    met->setEvaluation( formula1 );
                }
                else
                {     // cannot create metric, cou compilerr reported an error (??? )
                    cerr << " Cannot create prederived inclusive metric with an expression : " << endl << expression <<  endl << " and and init expression " << init_expression << endl << "because of the following error: " <<  derived_metric_error << " " << derived_metric_init_error << endl;
                    delete driver;
                    delete init_driver;
                    return NULL;
                }
            }
            break;
        }
        case CUBE_METRIC_PREDERIVED_EXCLUSIVE:
        {
            std::string parent_dtype = dtype;
            if ( parent != NULL )
            {
                parent_dtype = parent->get_dtype();
                if (
                    !( strcmp( parent_dtype.c_str(), "FLOAT" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "DOUBLE" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "INTEGER" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "UINT64" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "INT64" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "INT32" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "UINT32" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "INT16" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "UINT16" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "INT8" ) == 0
                       ||
                       strcmp( parent_dtype.c_str(), "UINT8" ) == 0
                       )
                    )
                {
                    cerr << " Derivated metrics can be created only for parent metrics, which do have data numerical single value data type. Ignode cube::def_met(...) and return NULL";
                    delete driver;
                    delete init_driver;
                    return NULL;
                }
            }
            met = new PreDerivedExclusiveMetric( disp_name, uniq_name, parent_dtype, uom, val, url,
                                                 descr, filefinder, parent, id, expression, init_expression, is_ghost  );
            met->setMemoryManager( cubepl1_memory_manager );
            if ( !postcompilation_of_derived_metrics )
            {
                std::string cubepl_program      = string( "<cubepl>" ) + expression + string( "</cubepl>" );
                std::string cubepl_init_program = string( "<cubepl>" ) + init_expression + string( "</cubepl>" );
                if ( driver->test( cubepl_program, derived_metric_error ) &&
                     driver->test( cubepl_init_program, derived_metric_init_error )
                     )
                {
                    stringstream       strin2( cubepl_init_program );
                    GeneralEvaluation* formula2 = driver->compile( &strin2, &cerr );
                    met->setInitEvaluation( formula2 );
                    stringstream       strin1( cubepl_program );
                    GeneralEvaluation* formula1 = driver->compile( &strin1, &cerr );
                    met->setEvaluation( formula1 );
                }
                else
                {     // cannot create metric, cou compilerr reported an error (??? )
                    cerr << " Cannot create prederived exclusive metric with an expression : " << endl << expression <<  endl << " and and init expression " << init_expression << endl << "because of the following error: " <<  derived_metric_error << " " << derived_metric_init_error << endl;
                    delete driver;
                    delete init_driver;
                    return NULL;
                }
            }
            break;
        }
        case CUBE_METRIC_EXCLUSIVE:
            met = new ExclusiveMetric( disp_name, uniq_name, dtype, uom, val, url,
                                       descr, filefinder, parent, id, is_ghost  );
            if ( !met->asExclusiveMetric() )
            {
                cerr << " Metric " << uniq_name << " with type " << dtype << " cannot be declared as an exclusive metric" << endl;
                delete met;
                met = NULL;
            }
            break;
        case CUBE_METRIC_INCLUSIVE:
        default:
            met = new InclusiveMetric( disp_name, uniq_name, dtype, uom, val, url,
                                       descr, filefinder, parent, id, is_ghost  );
            if ( !met->asInclusiveMetric() )
            {
                cerr << " Metric " << uniq_name << " with type " << dtype << " cannot be declared as an inclusive metric" << endl;
                delete met;
                met = NULL;
            }
            break;
    }
    if ( met != NULL )
    {
        if ( !met->isGhost() )
        {
            if ( parent == NULL )
            {
                root_metv.push_back( met );
            }

            if ( metv.size() <= id )
            {
                metv.resize( id + 1 );
            }
            else if ( metv[ id ] )
            {
                throw RuntimeError( "Metric with this ID exists" );
            }
            metv[ id ]    = met;
            cur_metric_id = metv.size();
        }
        else // add ghost metrics into another vector.
        {
            ghost_metv.push_back( met );
        }
        met->calculate_hash(); // calles virtual functions. therefore should be here...
    }
    delete driver;
    delete init_driver;
    return met;
}



Metric*
Cube::def_met( Metric* _met, map<Metric*, Metric*>& met_map )
{
    const string& disp_name       = _met->get_disp_name();
    const string& uniq_name       = _met->get_uniq_name();
    const string& dtype           = _met->get_dtype();
    const string& uom             = _met->get_uom();
    const string& val             = _met->get_val();
    const string& url             = _met->get_url();
    const string& descr           = _met->get_descr();
    Metric*       parent          = met_map[ _met->get_parent() ];
    TypeOfMetric  type_of_metric  = _met->get_type_of_metric();
    const string& expression      = _met->get_expression();
    const string& init_expression = _met->get_init_expression();

    return def_met( disp_name, uniq_name, dtype, uom, val, url,
                    descr, parent, _met->get_id(), type_of_metric, expression, init_expression );
}







Region*
Cube::def_region( const string& name,
                  long          begln,
                  long          endln,
                  const string& url,
                  const string& descr,
                  const string& mod )
{
    return def_region( name, begln, endln, url, descr, mod, cur_region_id );
}

Region*
Cube::def_region( const string& name,
                  long          begln,
                  long          endln,
                  const string& url,
                  const string& descr,
                  const string& mod,
                  uint32_t      id )
{
    Region* reg = new Region( name, begln, endln, url, descr, mod, id );
    reg->calculate_hash(); // calles virtual functions. therefore should be here...

    if ( regv.size() <= id )
    {
        regv.resize( id + 1 );
    }
    else if ( regv[ id ] )
    {
        throw RuntimeError( "Region with this ID exists" );
    }

    regv[ id ]    = reg;
    cur_region_id = regv.size();

    return reg;
}



Region*
Cube::def_region( Region* _reg )
{
    const string& name  = _reg->get_name();
    const long    begln = _reg->get_begn_ln();
    const long    endln = _reg->get_end_ln();
    const string& url   = _reg->get_url();
    const string& descr = _reg->get_descr();
    const string& mod   = _reg->get_mod();

    return def_region( name, begln, endln, url, descr, mod, _reg->get_id() );
}





Cnode*
Cube::def_cnode( Region* callee, Cnode* parent )
{
    return def_cnode( callee, "", -1, parent, cur_cnode_id );
}

Cnode*
Cube::def_cnode( Region*       callee,
                 const string& mod,
                 int           line,
                 Cnode*        parent,
                 uint32_t      id )
{
    if ( id == ( uint32_t )( -1 ) )
    {
        id = cur_cnode_id;                     // automatical id assignment.
    }
    Cnode* cnode = new Cnode( callee, mod, line, parent, id );
    cnode->calculate_hash(); // calles virtual functions. therefore should be here...
    if ( !parent )
    {
        root_cnodev.push_back( cnode );
//      root_cnodev ( cnode );
    }
    callee->add_cnode( cnode );
    if ( cnodev.size() <= id )
    {
        cnodev.resize( id + 1 );
        fullcnodev.resize( id + 1 );
    }
    else
    if ( cnodev[ id ] )
    {
        throw RuntimeError( "Cnode with this ID exists" );
    }
    cnodev[ id ]     = cnode;
    fullcnodev[ id ] = cnode;
    cur_cnode_id     = cnodev.size();
//     cnodev.push_back( cnode );
//     fullcnodev.push_back( cnode );
//     cur_cnode_id++;



    return cnode;
}



Cnode*
Cube::def_cnode( Cnode* _cnode, map<Cnode*, Cnode*>& cnodes_map, map<Region*, Region*> &regions_map, bool copy_id )
{
    Region*        callee = regions_map[ _cnode->get_callee() ];
    const string & mod    = _cnode->get_mod();
    const long     line   = _cnode->get_line();
    Cnode*         parent = cnodes_map[ _cnode->get_parent() ];
    return def_cnode( callee, mod, line, parent, ( copy_id ) ? _cnode->get_id() : ( uint32_t )( -1 ) );
}






Machine*
Cube::def_mach( const string& name, const string& desc )
{
    return def_mach( name, desc, cur_stn_id );
}

Machine*
Cube::def_mach( const string& name,
                const string& desc,
                uint32_t      id )
{
    std::string _class = "machine";
    return def_system_tree_node( name, desc, _class, NULL );
/*
    Machine* mach = new Machine( name, desc, NULL, id, sysv.size() );
    mach->calculate_hash(); // calles virtual functions. therefore should be here...

    if ( stnv.size() <= id )
    {
        stnv.resize( id + 1 );
    }
    else if ( stnv[ id ] )
    {
        throw RuntimeError( "Root system tree node with this ID exists" );
    }

    stnv[ id ] = mach;
    root_stnv.push_back( mach );
    cur_stn_id = stnv.size();
    sysv.push_back( mach );

    return mach;*/
}



Machine*
Cube::def_mach( Machine* _mach )
{
    const string& name = _mach->get_name();
    const string& desc = _mach->get_desc();
    return def_mach( name, desc, _mach->get_id() );
}





Node*
Cube::def_node( const string& name, Machine* mach )
{
    return def_node( name,  mach, cur_stn_id );
}

Node*
Cube::def_node( const string& name,
                Machine*      mach,
                uint32_t      id )
{
    std::string _class = "node";
    return def_system_tree_node( name, "", _class, mach );
/*
    Node* node = new Node( name, "", mach, id, sysv.size() );
    node->calculate_hash(); // calles virtual functions. therefore should be here...

    if ( stnv.size() <= id )
    {
        stnv.resize( id + 1 );
    }
    else if ( stnv[ id ] )
    {
        throw RuntimeError( "Node with this ID exists" );
    }

    stnv[ id ] = node;
    non_root_stnv.push_back( node );
    cur_stn_id = stnv.size();
    sysv.push_back( node );

    return node;*/
}



Node*
Cube::def_node( Node* _node, map<Machine*, Machine*> & machines_map )
{
    const string name = _node->get_name();
    Machine*     mach = machines_map[ _node->get_parent() ];

    return def_node( name, mach, _node->get_id() );
}




Process*
Cube::def_proc( const string& name, int rank, Node* node )
{
    return def_proc( name, rank, node, cur_location_group_id );
}

Process*
Cube::def_proc( const string& name,
                int           rank,
                Node*         node,
                uint32_t      id )
{
    return def_location_group( name, rank, cube::CUBE_LOCATION_GROUP_TYPE_PROCESS, node );
//     Process* proc = new Process( name, node, rank, id, sysv.size() );
//     proc->calculate_hash(); // calles virtual functions. therefore should be here...
//
//     if ( location_groupv.size() <= id )
//     {
//         location_groupv.resize( id + 1 );
//     }
//     else if ( location_groupv[ id ] )
//     {
//         throw RuntimeError( "Process with this ID exists" );
//     }
//
//     location_groupv[ id ] = proc;
//     cur_location_group_id = location_groupv.size();
//     sysv.push_back( proc );
//
//     return proc;
}


Process*
Cube::def_proc( Process* _process, map<Node*, Node*> & nodes_map )
{
    const string name = _process->get_name();
    const int    rank = _process->get_rank();
    Node*        node = nodes_map[ _process->get_parent() ];

    return def_proc( name, rank,  node, _process->get_id() );
}






Thread*
Cube::def_thrd( const string& name, int rank, Process* proc )
{
    return def_thrd( name, rank, proc, cur_location_id );
}

Thread*
Cube::def_thrd( const string& name,
                int           rank,
                Process*      proc,
                uint32_t      id )
{
    return def_location( name, rank, cube::CUBE_LOCATION_TYPE_CPU_THREAD, proc );
/*
    // one starts to fill the cube with values - therefore no changes in Calnode/Systree dimensions are allowed
    Thread* thrd = new Thread( name, rank, proc, id, sysv.size() );
    thrd->calculate_hash(); // calles virtual functions. therefore should be here...

    if ( locationv.size() <= id )
    {
        locationv.resize( id + 1 );
    }
    else if ( locationv[ id ] )
    {
        throw RuntimeError( "Thread with this ID already exists" );
    }

    locationv[ id ] = thrd;
    cur_location_id = locationv.size();
    sysv.push_back( thrd );

    return thrd;*/
}


Thread*
Cube::def_thrd( Thread* _thread, map<Process*, Process*>& processes_map )
{
    const string name    = _thread->get_name();
    const int    rank    = _thread->get_rank();
    Process*     process = processes_map[ _thread->get_parent() ];

    return def_thrd( name, rank, process, _thread->get_id() );
}






SystemTreeNode*
Cube::def_system_tree_node( const string&   name,
                            const string&   desc,
                            const string&   stn_class,
                            SystemTreeNode* parent )
{
    return def_system_tree_node( name, desc, stn_class, parent,  cur_stn_id );
}

SystemTreeNode*
Cube::def_system_tree_node( const string&   name,
                            const string&   desc,
                            const string&   stn_class,
                            SystemTreeNode* parent,
                            uint32_t        id )
{
    SystemTreeNode* stn = new SystemTreeNode( name, desc, stn_class, parent, id, sysv.size() );
    stn->calculate_hash(); // calles virtual functions. therefore should be here...

    if ( stnv.size() <= id )
    {
        stnv.resize( id + 1 );
    }
    else if ( stnv[ id ] )
    {
        throw RuntimeError( "SystemTreeNode with this ID exists" );
    }

    stnv[ id ] = stn;
    if ( parent == NULL )
    {
        root_stnv.push_back( stn );
    }
    else
    {
        non_root_stnv.push_back( stn );
    }

    if ( stn_class.compare( "machine" ) == 0 )
    {
        machv.push_back( stn );
    }
    if ( stn_class.compare( "node" ) == 0 )
    {
        nodev.push_back( stn );
    }




    cur_stn_id = stnv.size();
    sysv.push_back( stn );

    return stn;
}



SystemTreeNode*
Cube::def_system_tree_node( SystemTreeNode* _stn, map<SystemTreeNode*, SystemTreeNode*> & nodes_map  )
{
    const string&   name    = _stn->get_name();
    const string&   desc    = _stn->get_desc();
    const string&   _class  = _stn->get_class();
    SystemTreeNode* _parent = nodes_map[ _stn->get_parent() ];
    return def_system_tree_node( name, desc, _class, _parent, cur_stn_id );
}






LocationGroup*
Cube::def_location_group( const string& name,  int rank, LocationGroupType type, SystemTreeNode* node )
{
    return def_location_group( name, rank, type, node, cur_location_group_id );
}

LocationGroup*
Cube::def_location_group( const string&     name,
                          int               rank,
                          LocationGroupType type,
                          SystemTreeNode*   node,
                          uint32_t          id )
{
    LocationGroup* lg = new LocationGroup( name, node, rank, type, id, sysv.size() );
    lg->calculate_hash(); // calles virtual functions. therefore should be here...

    if ( location_groupv.size() <= id )
    {
        location_groupv.resize( id + 1 );
    }
    else if ( location_groupv[ id ] )
    {
        throw RuntimeError( "Process with this ID exists" );
    }

    location_groupv[ id ] = lg;
    cur_location_group_id = location_groupv.size();
    sysv.push_back( lg );

    return lg;
}


LocationGroup*
Cube::def_location_group( LocationGroup* _group, map<SystemTreeNode*, SystemTreeNode*> & nodes_map )
{
    const string      name = _group->get_name();
    const int         rank = _group->get_rank();
    LocationGroupType type = _group->get_type();
    SystemTreeNode*   node = nodes_map[ _group->get_parent() ];

    return def_location_group( name, rank, type, node, cur_location_group_id );
}




Location*
Cube::def_location( const string& name, int rank, LocationType type, LocationGroup* parent )
{
    return def_location( name, rank, type, parent, cur_location_id );
}

Location*
Cube::def_location( const string&  name,
                    int            rank,
                    LocationType   type,
                    LocationGroup* parent,
                    uint32_t       id )
{
    // one starts to fill the cube with values - therefore no changes in Calnode/Systree dimensions are allowed
    Location* loc = new Location( name, rank, parent, type, id, sysv.size() );
    loc->calculate_hash(); // calles virtual functions. therefore should be here...

    if ( locationv.size() <= id )
    {
        locationv.resize( id + 1 );
    }
    else if ( locationv[ id ] )
    {
        throw RuntimeError( "Location with this ID already exists" );
    }

    locationv[ id ] = loc;
    cur_location_id = locationv.size();
    sysv.push_back( loc );

    return loc;
}


Location*
Cube::def_location( Location* _location, map<LocationGroup*, LocationGroup*>& locgroups_map )
{
    const string   name   = _location->get_name();
    const int      rank   = _location->get_rank();
    LocationType   type   = _location->get_type();
    LocationGroup* parent = locgroups_map[ _location->get_parent() ];

    return def_location( name, rank, type, parent, cur_location_id );
}











Cartesian*
Cube::def_cart( long ndims, const vector<long>& dimv,
                const vector<bool>& periodv )
{
    Cartesian* newc = new Cartesian( ndims, dimv, periodv );
    cartv.push_back( newc );
    return newc;
}






const Cartesian*
Cube::get_cart( int i ) const
{
    if ( cartv.size() > 0 )
    {
        return cartv[ i ];
    }
    else
    {
        return NULL;
    }
}

void
Cube::def_coords( Cartesian* cart, const Sysres* sys,
                  const vector<long>& coordv )
{
    cart->def_coords( sys, coordv );
}




Metric*
Cube::get_met( std::string & _uniq_name )
{
    for ( std::vector<Metric*>::iterator iter = metv.begin(); iter != metv.end(); iter++ )
    {
        if ( ( ( ( *iter )->get_uniq_name() ).compare( _uniq_name ) ) == 0 )
        {
            return *iter;
        }
    }
    for ( std::vector<Metric*>::iterator iter = ghost_metv.begin(); iter != ghost_metv.end(); iter++ )
    {
        if ( ( ( ( *iter )->get_uniq_name() ).compare( _uniq_name ) ) == 0 )
        {
            return *iter;
        }
    }
    return NULL; // didn't find any metrics
}


Metric*
Cube::get_met( uint32_t _id  )
{
    for ( std::vector<Metric*>::iterator iter = metv.begin(); iter != metv.end(); iter++ )
    {
        if ( ( ( *iter )->get_id() ) == _id )
        {
            return *iter;
        }
    }
    for ( std::vector<Metric*>::iterator iter = ghost_metv.begin(); iter != ghost_metv.end(); iter++ )
    {
        if (  ( ( *iter )->get_id() ) == _id )
        {
            return *iter;
        }
    }
    return NULL; // didn't find any metrics
}
// ------------------ SEVERITIES PART START --------------------------------

vector<Cnode* >
Cube::get_optimal_sequence( Metric* metric )
{
    if ( !metric->isInitialized() )
    {
        metric->set_dimensions( cnodev, root_cnodev, root_stnv, locationv );
        if ( mode_read_only )
        {
            create_metrics_existing_data_containers( metric );
        }
        else
        {
            create_metrics_data_containers( metric );
        }
        assign_ids( metric );
    }
//     }
    return metric->get_optimal_sequence( get_cnodev() );
}

void
Cube::create_metrics_data_containers( Metric* met )
{
    uint32_t ncid = fullcnodev.size();
    uint32_t ntid = locationv.size();
    met->create_data_container( ncid, ntid /*, only_memory*/ );
}

void
Cube::create_metrics_existing_data_containers( Metric* met )
{
    uint32_t ncid = fullcnodev.size();
    uint32_t ntid = locationv.size();
    met->create_existing_data_container( ncid, ntid );
}




void
Cube::set_sev( Metric* met, Cnode* cnode, Thread* thrd,
               Value* val )
{
    if ( ( val == NULL ) || ( enforce_saving == CUBE_IGNORE_ZERO  && val->isZero() ) )
    {
        return;
    }

    if ( met != NULL )
    {
        if ( !met->isInitialized() )
        {
            met->set_dimensions( cnodev, root_cnodev, root_stnv, locationv );
            if ( mode_read_only )
            {
                create_metrics_existing_data_containers( met );
            }
            else
            {
                create_metrics_data_containers( met );
            }
            assign_ids( met );
        }
        met->set_adv_sev_adv( cnode, thrd, val );
    }
}



void
Cube::set_sev( Metric* met, Cnode* cnode, Thread* thrd,
               double value )
{
    if ( enforce_saving == CUBE_IGNORE_ZERO && value == 0. )
    {
        return;
    }

    if ( met != NULL )
    {
        if ( !met->isInitialized() )
        {
            met->set_dimensions( cnodev, root_cnodev, root_stnv, locationv );
            if ( mode_read_only )
            {
                create_metrics_existing_data_containers( met );
            }
            else
            {
                create_metrics_data_containers( met );
            }
            assign_ids( met );
        }
        met->set_adv_sev( cnode, thrd, value );
    }
}

void
Cube::set_sev( Metric* met, Region* region, Thread* thrd,
               double value )

{
    if ( enforce_saving == CUBE_IGNORE_ZERO && value == 0. )
    {
        return;
    }

    Cnode* v_cnode = NULL;

    for ( unsigned int i = 0; i < cnodev.size(); i++ )
    {
        const Region* tmp = cnodev[ i ]->get_callee();
        if ( tmp == region )
        {
            v_cnode = cnodev[ i ];
            break;
        }
    }
    if ( v_cnode == NULL )
    {
        cerr << " REGION MUST BE DEFINED BEFORE ONE SAVES ANY VALUES" << endl;
        return; // NO ACTION; IF REGION IS NOT DECLARES
    }

    set_sev( met, v_cnode, thrd, value );
}


void
Cube::set_sev( Metric* met, Region* region, Thread* thrd,
               Value* value )
{
    if (  ( value == NULL ) || ( enforce_saving == CUBE_IGNORE_ZERO  && value->isZero() ) )
    {
        return;
    }

    Cnode* v_cnode = NULL;

    for ( unsigned int i = 0; i < cnodev.size(); i++ )
    {
        const Region* tmp = cnodev[ i ]->get_callee();
        if ( tmp == region )
        {
            v_cnode = cnodev[ i ];
            break;
        }
    }
    if ( v_cnode == NULL )
    {
        cerr << " REGION MUST BE DEFINED BEFORE ONE SAVES ANY VALUES" << endl;
        return; // NO ACTION; IF REGION IS NOT DECLARES
    }

    set_sev( met, v_cnode, thrd, value );
}


void
Cube::add_sev( Metric* met, Cnode*  cnode, Thread* thrd, double incr )
{
    Cnode* _parent = NULL;
    if ( met->get_type_of_metric() == CUBE_METRIC_INCLUSIVE )
    {
        _parent = cnode->get_parent();
    }
    cube::CalculationFlavour calc_flavor = ( met->get_type_of_metric() == CUBE_METRIC_INCLUSIVE )
                                           ? cube::CUBE_CALCULATE_INCLUSIVE : cube::CUBE_CALCULATE_EXCLUSIVE;
    double                   val = get_sev( met, cube::CUBE_CALCULATE_INCLUSIVE,
                                            cnode, calc_flavor,
                                            thrd, cube::CUBE_CALCULATE_EXCLUSIVE );
    set_sev(  met, cnode, thrd, incr + val );
    if ( _parent != NULL )
    {
        add_sev( met, _parent, thrd, incr );
    }
}

void
Cube::add_sev( Metric* met, Cnode*  cnode, Thread* thrd, Value* incr )
{
    Cnode* _parent = NULL;
    if ( met->get_type_of_metric() == CUBE_METRIC_INCLUSIVE )
    {
        _parent = cnode->get_parent();
    }
    cube::CalculationFlavour calc_flavor = ( met->get_type_of_metric() == CUBE_METRIC_INCLUSIVE )
                                           ? cube::CUBE_CALCULATE_INCLUSIVE : cube::CUBE_CALCULATE_EXCLUSIVE;
    Value*                   val = get_sev_adv(  met, cube::CUBE_CALCULATE_INCLUSIVE,
                                                 cnode, calc_flavor,
                                                 thrd, cube::CUBE_CALCULATE_EXCLUSIVE );
    *val += ( incr );
    set_sev( met, cnode, thrd, val );
    delete val;
    if ( _parent != NULL )
    {
        add_sev( met, _parent, thrd, incr );
    }
}




//


void
Cube::add_sev( Metric* met, Region* region, Thread* thrd, double incr )
{
    Cnode* v_cnode = NULL;

    for ( unsigned int i = 0; i < cnodev.size(); i++ )
    {
        const Region* tmp = cnodev[ i ]->get_callee();
        if ( tmp == region )
        {
            v_cnode = cnodev[ i ];
            break;
        }
    }
    if ( v_cnode == NULL )
    {
        cerr << " REGION MUST BE DEFINED BEFORE ONE SAVES ANY VALUES" << endl;
        return; // NO ACTION; IF REGION IS NOT DECLARES
//     v_cnode = def_cnode(region, region->get_mod(), -1, NULL);
    }
    double val = get_sev( met, v_cnode, thrd );
    set_sev( met, v_cnode, thrd, incr + val );
}


void
Cube::add_sev( Metric* met, Region* region, Thread* thrd, Value* incr )
{
    Cnode* v_cnode = NULL;

    for ( unsigned int i = 0; i < cnodev.size(); i++ )
    {
        const Region* tmp = cnodev[ i ]->get_callee();
        if ( tmp == region )
        {
            v_cnode = cnodev[ i ];
            break;
        }
    }
    if ( v_cnode == NULL )
    {
        cerr << " REGION MUST BE DEFINED BEFORE ONE SAVES ANY VALUES" << endl;
        return; // NO ACTION; IF REGION IS NOT DECLARES
//     v_cnode = def_cnode(region, region->get_mod(), -1, NULL);
    }
    Value* val = get_sev_adv( met, v_cnode, thrd );
    *val += ( incr );
    set_sev( met, v_cnode, thrd, val );
    delete val;
}







double
Cube::get_saved_sev( Metric* met, Cnode*  cnode, Thread* thrd )
{
    double ret = 0.;
    Value* v   = get_saved_sev_adv( met, cnode, thrd );
    if ( v == NULL )
    {
        return 0.;
    }
    ret = v->getDouble();
    delete v;
    return ret;
}

Value*
Cube::get_saved_sev_adv( Metric* met, Cnode*  cnode, Thread* thrd )
{
    if ( met != NULL )
    {
        if ( !met->isInitialized() )
        {
            met->set_dimensions( cnodev, root_cnodev, root_stnv, locationv );
            if ( mode_read_only )
            {
                create_metrics_existing_data_containers( met );
            }
            else
            {
                create_metrics_data_containers( met );
            }
            assign_ids( met );
        }
        return met->get_sev_adv( cnode, thrd );
    }
    throw RuntimeError( "Metric in the call \"get_saved_sev_adv\" is NULL" );
//    return met->get_sev(cnode, thrd);
}





double
Cube::get_sev( Metric* met, Cnode*  cnode, Thread* thrd )
{
    if ( met != NULL )
    {
        if ( !met->isInitialized() )
        {
            met->set_dimensions( cnodev, root_cnodev, root_stnv, locationv );
            if ( mode_read_only )
            {
                create_metrics_existing_data_containers( met );
            }
            else
            {
                create_metrics_data_containers( met );
            }
            assign_ids( met );
        }
        return met->get_sev( cnode, cube::CUBE_CALCULATE_EXCLUSIVE, thrd, cube::CUBE_CALCULATE_INCLUSIVE );
        ;
    }
    throw RuntimeError( "Metric in the call \"get_sev\" is NULL" );
}

Value*
Cube::get_sev_adv( Metric* met, Cnode*  cnode, Thread* thrd )
{
    if ( met != NULL )
    {
        if ( !met->isInitialized() )
        {
            met->set_dimensions( cnodev, root_cnodev, root_stnv, locationv );
            if ( mode_read_only )
            {
                create_metrics_existing_data_containers( met );
            }
            else
            {
                create_metrics_data_containers( met );
            }
            assign_ids( met );
        }
        Value* _v =  met->get_sev_adv( cnode, cube::CUBE_CALCULATE_EXCLUSIVE, thrd, cube::CUBE_CALCULATE_INCLUSIVE );
        return _v;
    }
    throw RuntimeError( "Metric in the call \"get_sev_adv\" is NULL" );
//    return met->get_sev(cnode, thrd);
}


// ------------------ SEVERITIES PART END --------------------------------

// ------------------- ANALYSIS PART --------------------------


Value*
Cube::get_sev_adv( Metric* metric, CalculationFlavour mf, Cnode* cnode, CalculationFlavour cnf, Sysres* sys, CalculationFlavour sf )
{
    if ( metric == NULL )
    {
        return NULL;               // if metric is 0 - return NULL.
    }
    if ( !metric->isInitialized() )
    {
        metric->set_dimensions( cnodev, root_cnodev, root_stnv, locationv );
        if ( mode_read_only )
        {
            create_metrics_existing_data_containers( metric );
        }
        else
        {
            create_metrics_data_containers( metric );
        }
        assign_ids( metric );
    }
    Value* v = metric->get_sev_adv( cnode, cnf, sys, sf );
    if ( v == NULL )
    {
        return v;
    }
    if ( mf == cube::CUBE_CALCULATE_EXCLUSIVE )
    {
        for ( unsigned i = 0; i < metric->num_children(); i++ )  // recursiv call for  children of the metric
        {
            Metric* _met = metric->get_child( i );
            Value*  _v   = get_sev_adv( _met, cube::CUBE_CALCULATE_INCLUSIVE, cnode, cnf, sys, sf );
            if ( _v == NULL )
            {
                continue;
            }
            ( *v ) -= _v;
            delete _v;
        }
    }
    return v;
}





Value*
Cube::get_sev_adv( Metric* metric, CalculationFlavour mf, Region* region, CalculationFlavour rf, Sysres* sys, CalculationFlavour sf )
{
    CalculationFlavour _rf = rf;


    if ( metric == NULL )
    {
        return NULL;                           // if metric is 0 - return NULL.
    }
    if ( region == NULL )
    {
        return NULL;
    }
    if ( sys == NULL )
    {
        return NULL;
    }


    if ( !metric->isInitialized() )
    {
        metric->set_dimensions( cnodev, root_cnodev, root_stnv, locationv );
        if ( mode_read_only )
        {
            create_metrics_existing_data_containers( metric );
        }
        else
        {
            create_metrics_data_containers( metric );
        }
        assign_ids( metric );
    }


    Value*              value = NULL;
    // collectiong cnodes, which have to be calculated for region
    std::vector<Cnode*> v;
    std::vector<Cnode*> cnodes = get_cnodev();
    if ( region->is_subroutines() )           // subrouties have to be calculated
    {
        for ( std::vector<Cnode*>::iterator citer = cnodes.begin(); citer != cnodes.end(); citer++ )
        {
            //if the call item's callee is the selected region
            //then take all its subroutines
            if ( ( *citer )->get_callee() == region )
            {
                for ( unsigned j = 0; j < ( *citer )->num_children(); j++ )
                {
                    if (  ( ( *citer )->get_child( j ) )->get_callee() != region )
                    {
                        v.push_back( ( *citer )->get_child( j ) );
                    }
                }
            }
        }
        for ( unsigned i = 0; i < v.size(); i++ )
        {
            for ( unsigned j = 0; j < v[ i ]->num_children(); j++ )
            {
                if ( ( v[ i ]->get_child( j ) )->get_callee() != region )
                {
                    v.push_back( v[ i ]->get_child( j ) );
                }
            }
        }
        _rf = cube::CUBE_CALCULATE_EXCLUSIVE; // force the exclusve calculation it the case of subroutines calculation.
    }
    else                                      // region
    {
        for ( std::vector<Cnode*>::iterator citer = cnodes.begin(); citer != cnodes.end(); citer++ )
        {
            if ( ( *citer )->get_callee() == region )
            {
                v.push_back( *citer );
            }
        }
    }

    for ( std::vector<Cnode*>::iterator viter = v.begin(); viter != v.end(); viter++ )
    {
        Value* _v = get_sev_adv( metric, cube::CUBE_CALCULATE_INCLUSIVE, ( *viter ), _rf, sys, sf );
        if ( value == NULL )
        {
            value = _v;
        }
        else
        {
            if ( _v != NULL )
            {
                ( *value ) += _v;
                delete _v;
            }
        }
    }


    if ( mf == cube::CUBE_CALCULATE_EXCLUSIVE )
    {
        for ( unsigned i = 0; i < metric->num_children(); i++ )  // recursiv call for  children of the metric
        {
            Metric* _met = metric->get_child( i );
            Value*  _v   = get_sev_adv( _met, cube::CUBE_CALCULATE_INCLUSIVE, region, rf, sys, sf );
            if ( _v == NULL )
            {
//                 cerr << " get_sev_adv(_met, cube::CUBE_CALCULATE_INCLUSIVE, region, rf, sys, sf) returned NULL" << endl;
                continue;
            }
            if ( value == NULL )
            {
                value = _v->clone();
            }
            ( *value ) -= _v;
            delete _v;
        }
    }
    return value;
}












Value*
Cube::get_sev_adv( Metric* metric, CalculationFlavour mf, Cnode* cnode, CalculationFlavour cnf )
{
    if ( metric == NULL )
    {
        return NULL;               // if metric is 0 - return NULL.
    }

    if ( !metric->isInitialized() )
    {
        metric->set_dimensions( cnodev, root_cnodev, root_stnv, locationv );
        if ( mode_read_only )
        {
            create_metrics_existing_data_containers( metric );
        }
        else
        {
            create_metrics_data_containers( metric );
        }
        assign_ids( metric );
    }

////// ----------------------------- here is clustering breaks in ---------------------------
    Value* v = metric->get_sev_adv( cnode, cnf );
///// -----------------------------------------

    if ( v == NULL )
    {
//         cerr << " get_sev_adv(cnode, cnf) returned NULL " << endl;
        return v;
    }

    if ( mf == cube::CUBE_CALCULATE_EXCLUSIVE )
    {
        for ( unsigned i = 0; i < metric->num_children(); i++ )  // recursiv call for  children of the metric
        {
            Metric* _met = metric->get_child( i );
            Value*  _v   = get_sev_adv( _met, cube::CUBE_CALCULATE_INCLUSIVE, cnode, cnf );
            if ( _v == NULL )
            {
//                 cerr << "get_sev_adv(_met, cube::CUBE_CALCULATE_INCLUSIVE, cnode, cnf) returned NULL " << endl;
                continue;
            }
            ( *v ) -= _v;
            delete _v;
        }
    }
    return v;
}





Value*
Cube::get_sev_adv( Metric* metric, CalculationFlavour mf, Sysres* sys, CalculationFlavour sf )
{
    if ( metric == NULL )
    {
        return NULL;               // if metric is 0 - return NULL.
    }

    if ( !metric->isInitialized() )
    {
        metric->set_dimensions( cnodev, root_cnodev, root_stnv, locationv );
        if ( mode_read_only )
        {
            create_metrics_existing_data_containers( metric );
        }
        else
        {
            create_metrics_data_containers( metric );
        }
        assign_ids( metric );
    }

    // over cnode roots

    std::vector<Cnode*> roots = get_root_cnodev();
    Value*              v     = NULL;
    for ( std::vector<Cnode*>::iterator citer = roots.begin(); citer != roots.end(); citer++ )
    {
        Cnode* cnode_root = ( *citer );

        Value* inc_metric_v = metric->get_sev_adv( cnode_root, cube::CUBE_CALCULATE_INCLUSIVE, sys, sf );
        if ( inc_metric_v == NULL )
        {
//             cerr << "get_sev_adv(cnode_root, cube::CUBE_CALCULATE_INCLUSIVE, sys, sf)  returned NULL " << endl;
            return inc_metric_v;
        }

        if ( mf == cube::CUBE_CALCULATE_EXCLUSIVE )
        {
            for ( unsigned i = 0; i < metric->num_children(); i++ ) // recursiv call for  children of the metric
            {
                Metric* _met = metric->get_child( i );
                Value*  _v   = get_sev_adv( _met, cube::CUBE_CALCULATE_INCLUSIVE, sys, sf );
                if ( _v == NULL )
                {
//                     cerr << "get_sev_adv(_met, cube::CUBE_CALCULATE_INCLUSIVE, sys, sf) returned NULL " << endl;
                    continue;
                }
                ( *inc_metric_v ) -= _v;
                delete _v;
            }
        }
        if ( v == NULL )
        {
            v = inc_metric_v;
        }
        else
        {
            ( *v ) += inc_metric_v;
            delete inc_metric_v;
        }
    }
    return v;
}




Value*
Cube::get_sev_adv( Metric* metric, CalculationFlavour mf, Region* region, CalculationFlavour rf )
{
    CalculationFlavour _rf = rf;


    if ( metric == NULL )
    {
        return NULL;                   // if metric is 0 - return NULL.
    }
    if ( region == NULL )
    {
        return NULL;
    }
    if ( !metric->isInitialized() )
    {
        metric->set_dimensions( cnodev, root_cnodev, root_stnv, locationv );
        if ( mode_read_only )
        {
            create_metrics_existing_data_containers( metric );
        }
        else
        {
            create_metrics_data_containers( metric );
        }
        assign_ids( metric );
    }

    Value*              value = NULL;
    // collectiong cnodes, which have to be calculated for region
    std::vector<Cnode*> v;
    std::vector<Cnode*> cnodes = get_cnodev();

    if ( region->is_subroutines() )   // subrouties have to be calculated
    {
        for ( std::vector<Cnode*>::iterator citer = cnodes.begin(); citer != cnodes.end(); citer++ )
        {
            //if the call item's callee is the selected region
            //then take all its subroutines
            if ( ( *citer )->get_callee() == region )
            {
                for ( unsigned j = 0; j < ( *citer )->num_children(); j++ )
                {
                    if (  ( ( *citer )->get_child( j ) )->get_callee() != region )
                    {
                        v.push_back( ( *citer )->get_child( j ) );
                    }
                }
            }
        }
        for ( unsigned i = 0; i < v.size(); i++ )
        {
            for ( unsigned j = 0; j < v[ i ]->num_children(); j++ )
            {
                if ( ( v[ i ]->get_child( j ) )->get_callee() != region )
                {
                    v.push_back( v[ i ]->get_child( j ) );
                }
            }
        }
        _rf = cube::CUBE_CALCULATE_EXCLUSIVE; // force the exclusve calculation it the case of subroutines calculation.
    }
    else                                      // region->is_subroutines()
    {
        for ( std::vector<Cnode*>::iterator citer = cnodes.begin(); citer != cnodes.end(); citer++ )
        {
            if ( ( *citer )->get_callee() == region )
            {
                v.push_back( *citer );
            }
        }
    }

    for ( std::vector<Cnode*>::iterator viter = v.begin(); viter != v.end(); viter++ )
    {
        Value* _v = get_sev_adv( metric, cube::CUBE_CALCULATE_INCLUSIVE, ( *viter ), _rf );
        if ( value == NULL )
        {
            value = _v;
        }
        else
        {
            if ( _v != NULL )
            {
                ( *value ) += _v;
                delete _v;
            }
        }
    }


    if ( mf == cube::CUBE_CALCULATE_EXCLUSIVE )
    {
        for ( unsigned i = 0; i < metric->num_children(); i++ ) // recursiv call for  children of the metric
        {
            Metric* _met = metric->get_child( i );
            Value*  _v   = get_sev_adv( _met, cube::CUBE_CALCULATE_INCLUSIVE, region, rf );
            if ( _v == NULL )
            {
//                 cerr << "get_sev_adv(_met, cube::CUBE_CALCULATE_INCLUSIVE, region, rf) returned NULL " << endl;
                continue;
            }
            ( *value ) -= _v;
            delete _v;
        }
    }
    return value;
}

Value*
Cube::get_sev_adv( Metric* metric, CalculationFlavour mf )          // sum over roots of calltree
{
    if ( metric == NULL )
    {
        return NULL;               // if metric is 0 - return NULL.
    }
    if ( !metric->isInitialized() )
    {
        metric->set_dimensions( cnodev, root_cnodev, root_stnv, locationv );
        if ( mode_read_only )
        {
            create_metrics_existing_data_containers( metric );
        }
        else
        {
            create_metrics_data_containers( metric );
        }
        assign_ids( metric );
    }


    vector<Cnode*> croots = get_root_cnodev();
    Value*         v      = NULL;

    for ( unsigned i = 0; i < croots.size(); i++ )
    {
        Value* _v = get_sev_adv( metric, cube::CUBE_CALCULATE_INCLUSIVE, croots[ i ], cube::CUBE_CALCULATE_INCLUSIVE );
        if ( _v == NULL )
        {
//             cerr << "get_sev_adv(metric, mf, croots[i], cube::CUBE_CALCULATE_INCLUSIVE) returned NULL " << endl;
            continue;
        }
        if ( v == NULL )
        {
            v = _v;
        }
        else
        {
            ( *v ) += _v;
            delete _v;
        }
    }
    if ( mf == cube::CUBE_CALCULATE_INCLUSIVE )
    {
        return v;
    }

    if ( mf == cube::CUBE_CALCULATE_EXCLUSIVE )
    {
        Value* _v = NULL;
        for ( unsigned j = 0; j < metric->num_children(); j++ )  // recursiv call for  children of the metric
        {
            Metric* _met = metric->get_child( j );
            if ( !_met->isInitialized() )
            {
                _met->set_dimensions( cnodev, root_cnodev, root_stnv, locationv );
                if ( mode_read_only )
                {
                    create_metrics_existing_data_containers( _met );
                }
                else
                {
                    create_metrics_data_containers( _met );
                }
                assign_ids( _met );
            }
            Value* __v = get_sev_adv( _met, cube::CUBE_CALCULATE_INCLUSIVE );

            if ( __v == NULL )
            {
//                 cerr << "Second get_sev_adv(croots[i], cube::CUBE_CALCULATE_INCLUSIVE) returned NULL " << endl;
                continue;
            }
            if ( _v == NULL )
            {
                _v = __v;
            }
            else
            {
                ( *_v ) += __v;
                delete __v;
            }
        }

        if ( _v != NULL )
        {
            if ( v == NULL )
            {
//                 cerr << " Inclusive value of metric is NULL" << endl;
                v = _v;
            }
            else
            {
                ( *v ) -= _v;
                delete _v;
            }
        }
        return v;
    }
    throw RuntimeError( "Unknown flavour of calculation" );
}




double
Cube::get_sev( Metric* metric, CalculationFlavour mf, Region* region, CalculationFlavour rnf, Sysres* sysres, CalculationFlavour sf )
{
    Value* v = get_sev_adv( metric, mf, region, rnf, sysres, sf );
    if ( v == NULL )
    {
//         cerr << "get_sev_adv(metric, mf, region, rnf, sysres, sf) returned NULL" << endl;
        return 0.;
    }
    double d = v->getDouble();
    delete v;
    return d;
}


double
Cube::get_sev( Metric* metric, CalculationFlavour mf, Cnode* cnode, CalculationFlavour cnf, Sysres* sysres, CalculationFlavour sf )
{
    Value* v = get_sev_adv( metric, mf, cnode, cnf, sysres, sf );
    if ( v == NULL )
    {
//         cerr << "get_sev_adv(metric, mf, cnode, cnf, sysres, sf) returned NULL" << endl;
        return 0.;
    }
    double d = v->getDouble();
    delete v;
    return d;
}





double
Cube::get_sev( Metric* metric, CalculationFlavour mf, Cnode* cnode, CalculationFlavour cnf )
{
    Value* v = get_sev_adv( metric, mf, cnode, cnf );
    if ( v == NULL )
    {
//         cerr << "get_sev_adv(metric, mf, cnode, cnf) returned NULL" << endl;
        return 0.;
    }
    double d = v->getDouble();
    delete v;
    return d;
}


double
Cube::get_sev( Metric* metric, CalculationFlavour mf, Region* region, CalculationFlavour rf )
{
    Value* v = get_sev_adv( metric, mf, region, rf );
    if ( v == NULL )
    {
//         cerr << "get_sev_adv(metric, mf, region, rf) returned NULL" << endl;
        return 0.;
    }
    double d = v->getDouble();
    delete v;
    return d;
}


double
Cube::get_sev( Metric* metric, CalculationFlavour mf, Sysres* sys, CalculationFlavour sf )
{
    Value* v = get_sev_adv( metric, mf, sys, sf );
    if ( v == NULL )
    {
//         cerr << "get_sev_adv(metric, mf, sys, sf) returned NULL" << endl;
        return 0.;
    }
    double d = v->getDouble();
    delete v;
    return d;
}


double
Cube::get_sev( Metric* metric, CalculationFlavour mf )         // sum over roots of calltree
{
    Value* v = get_sev_adv( metric, mf );
    if ( v == NULL )
    {
//         cerr << "get_sev_adv(metric, mf) returned NULL" << endl;
        return 0.;
    }
    double d = v->getDouble();
    delete v;
    return d;
}

double
Cube::get_sev( Cnode* cnode, CalculationFlavour cf )
{
    return 0.;     // coz this call is done by call tree, being in almost left panel
}

double
Cube::get_sev( Region* region, CalculationFlavour rf )
{
    return 0.;     // coz this call is done by flattree, being in almost left panel
}

double
Cube::get_sev( Sysres* sys, CalculationFlavour sf )
{
    return 0.;     // coz this call is done by system tree, being in almost left panel
}



// --------------- calls with lists--------------------------------------------------------------------------------


Value*
Cube::get_sev_adv( list_of_metrics & metrics, Cnode* cnode, CalculationFlavour cf )
{
    if ( metrics.size() == 0 )
    {
        throw RuntimeError( "Error in calculation call  get_sev_adv(list_of_metrics, Cnode*, CalculationFlavour ): No metrics are spezified. Empty list." );
    }
    if ( cnode == NULL )
    {
        throw RuntimeError( "No cnode is specified for the calculation." );
    }

    Value* value = NULL;

    for ( unsigned i = 0; i < metrics.size(); i++ )
    {
        if ( value == NULL )
        {
            value = get_sev_adv( metrics[ i ].first, metrics[ i ].second, cnode, cf );
        }
        else
        {
            Value* _v =  get_sev_adv( metrics[ i ].first, metrics[ i ].second, cnode, cf );
            if ( _v != NULL )
            {
                ( *value ) += _v;
                delete _v;
            }
        }
    }
    return value;
}



double
Cube::get_sev( list_of_metrics & metrics, Cnode* cnode, CalculationFlavour cf )       // sum over roots of calltree
{
    if ( metrics.size() == 0 )
    {
        return 0;
    }
    if ( cnode == NULL )
    {
        return 0;
    }
    Value* v = get_sev_adv( metrics, cnode,  cf );
    if ( v == NULL )
    {
//         cerr << "get_sev_adv(metrics, cnode,  cf) returned NULL " << endl;
        return 0.;
    }
    double d = v->getDouble();
    delete v;
    return d;
}






Value*
Cube::get_sev_adv( list_of_metrics & metrics, Region* region, CalculationFlavour rf )
{
    if ( metrics.size() == 0 )
    {
        throw RuntimeError( "Error in calculation call  get_sev_adv(list_of_metrics, Region*, CalculationFlavour ): No metrics are spezified. Empty list." );
    }
    if ( region == NULL )
    {
        throw RuntimeError( "No region is specified for the calculation." );
    }

    Value* value = NULL;
    for ( unsigned i = 0; i < metrics.size(); i++ )
    {
        if ( value == NULL )
        {
            value = get_sev_adv( metrics[ i ].first, metrics[ i ].second, region, rf );
        }
        else
        {
            Value* _v =  get_sev_adv( metrics[ i ].first, metrics[ i ].second, region, rf );
            if ( _v != NULL )
            {
                ( *value ) += _v;
                delete _v;
            }
        }
    }
    return value;
}


double
Cube::get_sev( list_of_metrics & metrics, Region* region, CalculationFlavour rf )       // sum over roots of calltree
{
    if ( metrics.size() == 0 )
    {
        return 0;
    }
    if ( region == NULL )
    {
        return 0;
    }

    Value* v = get_sev_adv( metrics, region,  rf );
    if ( v == NULL )
    {
//         cerr << "get_sev_adv(metrics, region,  rf) returned NULL" << endl;
        return 0.;
    }
    double d = v->getDouble();
    delete v;
    return d;
}





Value*
Cube::get_sev_adv( list_of_metrics & metrics, Sysres* sysres, CalculationFlavour sf )
{
    if ( metrics.size() == 0 )
    {
        throw RuntimeError( "Error in calculation call  get_sev_adv(list_of_metrics, Sysres*, CalculationFlavour ): No metrics are spezified. Empty list." );
    }
    if ( sysres == NULL )
    {
        throw RuntimeError( "No system resource (machine, node, process or thread) is specified for the calculation." );
    }

    Value* value = NULL;
    for ( unsigned i = 0; i < metrics.size(); i++ )
    {
        if ( value == NULL )
        {
            value = get_sev_adv( metrics[ i ].first, metrics[ i ].second, sysres, sf );
        }
        else
        {
            Value* _v =  get_sev_adv( metrics[ i ].first, metrics[ i ].second, sysres, sf );
            if ( _v != NULL )
            {
                ( *value ) += _v;
                delete _v;
            }
        }
    }
    return value;
}



double
Cube::get_sev( list_of_metrics & metrics, Sysres* sysres, CalculationFlavour sf )       // sum over roots of calltree
{
    if ( metrics.size() == 0 )
    {
        return 0.;
    }
    if ( sysres == NULL )
    {
        return 0.;
    }
    Value* v = get_sev_adv( metrics, sysres,  sf );
    if ( v == NULL )
    {
//         cerr << "get_sev_adv(metrics, sysres,  sf) returned NULL" << endl;
        return 0.;
    }
    double d = v->getDouble();
    delete v;
    return d;
}





Value*
Cube::get_sev_adv( list_of_cnodes & cnodes, Metric* metric, CalculationFlavour mf )
{
    if ( cnodes.size() == 0 )
    {
        throw RuntimeError( "Error in calculation call  get_sev_adv(list_of_cnodes, Metric*, CalculationFlavour ): No cnodes are spezified. Empty list." );
    }
    if ( metric == NULL )
    {
        throw RuntimeError( "No metric is specified for the calculation" );
    }
    Value* value = NULL;
    for ( unsigned i = 0; i < cnodes.size(); i++ )
    {
        if ( value == NULL )
        {
            value = get_sev_adv( metric, mf,   cnodes[ i ].first, cnodes[ i ].second );
        }
        else
        {
            Value* _v =  get_sev_adv( metric, mf,   cnodes[ i ].first, cnodes[ i ].second );
            if ( _v != NULL )
            {
                ( *value ) += _v;
                delete _v;
            }
        }
    }
    return value;
}




double
Cube::get_sev( list_of_cnodes & cnodes, Metric* metric, CalculationFlavour mf )       // sum over roots of calltree
{
    if ( cnodes.size() == 0 )
    {
        return 0.;
    }
    if ( metric == NULL )
    {
        return 0;
    }
    Value* v = get_sev_adv( cnodes, metric,  mf );
    if ( v == NULL )
    {
//         cerr << "get_sev_adv(cnodes, metric,  mf) returned NULL" << endl;
        return 0.;
    }
    double d = v->getDouble();
    delete v;
    return d;
}








double
Cube::get_sev( list_of_cnodes & cnodes, Sysres* sysres, CalculationFlavour sf ) // sum over roots of calltree
{
    return 0;                                                                   // any combination of that call return 0, coz metric is not specified
}






Value*
Cube::get_sev_adv( list_of_regions & regions, Metric* metric, CalculationFlavour mf )
{
    if ( regions.size() == 0 )
    {
        throw RuntimeError( "Error in calculation call  get_sev_adv(list_of_regions, Metric*, CalculationFlavour ): No regions are spezified. Empty list." );
    }
    if ( metric == NULL )
    {
        throw RuntimeError( "No metric is specified for calculation" );
    }
    Value* value = NULL;
    for ( unsigned i = 0; i < regions.size(); i++ )
    {
        if ( value == NULL )
        {
            value = get_sev_adv( metric, mf,   regions[ i ].first, regions[ i ].second );
        }
        else
        {
            Value* _v =  get_sev_adv( metric, mf,   regions[ i ].first, regions[ i ].second );
            if ( _v != NULL )
            {
                ( *value ) += _v;
                delete _v;
            }
        }
    }
    return value;
}

double
Cube::get_sev( list_of_regions & regions, Metric* metric, CalculationFlavour mf )       // sum over roots of calltree
{
    if ( regions.size() == 0 )
    {
        return 0.;
    }
    if ( metric == NULL )
    {
        return 0;
    }
    Value* v = get_sev_adv( regions, metric,  mf );
    if ( v == NULL )
    {
//         cerr << "get_sev_adv(regions, metric,  mf) returned NULL" << endl;
        return 0.;
    }
    double d = v->getDouble();
    delete v;
    return d;
}








double
Cube::get_sev( list_of_regions & regions, Sysres* sysres, CalculationFlavour sf ) // sum over roots of calltree
{
    return 0;                                                                     // any combination of that call return 0, coz metric is not specified
}





Value*
Cube::get_sev_adv( list_of_sysresources & sysres, Metric* metric, CalculationFlavour mf )
{
    if ( sysres.size() == 0 )
    {
        throw RuntimeError( "Error in calculation call  get_sev_adv(list_of_sysresources, Metric*, CalculationFlavour ): No system resources (machines, nodes, processes or lists) are spezified. Empty list." );
    }
    if ( metric == NULL )
    {
        throw RuntimeError( "No metric is specified for the calculation" );
    }
    Value* value = NULL;
    for ( unsigned i = 0; i < sysres.size(); i++ )
    {
        if ( value == NULL )
        {
            value = get_sev_adv( metric, mf,   sysres[ i ].first, sysres[ i ].second );
        }
        else
        {
            Value* _v =  get_sev_adv( metric, mf,   sysres[ i ].first, sysres[ i ].second );
            if ( _v != NULL )
            {
                ( *value ) += _v;
                delete _v;
            }
        }
    }
    return value;
}

double
Cube::get_sev( list_of_sysresources & sysres, Metric* metric, CalculationFlavour mf )       // sum over roots of calltree
{
    if ( sysres.size() == 0 )
    {
        return 0.;
    }
    if ( metric == NULL )
    {
        return 0;
    }
    Value* v = get_sev_adv( sysres, metric, mf );
    if ( v == NULL )
    {
//         cerr << "get_sev_adv(sysres, metric, mf) returned NULL" << endl;
        return 0.;
    }
    double d = v->getDouble();
    delete v;
    return d;
}



double
Cube::get_sev( list_of_sysresources & sysres, Cnode* cnode, CalculationFlavour cf ) // sum over roots of calltree
{
    return 0.;                                                                      // any combination of that call return 0, coz metric is not specified
}


double
Cube::get_sev( list_of_sysresources & sysres, Region* region, CalculationFlavour rf ) // sum over roots of calltree
{
    return 0.;                                                                        // any combination of that call return 0, coz metric is not specified
}


//------------------------- right panel ---------------------------------

Value*
Cube::get_sev_adv( list_of_metrics & metrics, list_of_cnodes & cnodes, Sysres* sys, CalculationFlavour sf )
{
    if ( metrics.size() == 0 )
    {
        throw RuntimeError( "Error in calculation call  get_sev_adv(list_of_metrics, list_of_cnodes , Sysres *,  CalculationFlavour ): No metrics are spezified. Empty list." );
    }
    if ( cnodes.size() == 0 )
    {
        throw RuntimeError( "Error in calculation call  get_sev_adv(list_of_metrics, list_of_cnodes , Sysres *,  CalculationFlavour): No cnodes are spezified. Empty list." );
    }
    if ( sys == NULL )
    {
        throw RuntimeError( "No system resource (machine, node, process or thread) is specified for the calculation" );
    }

    Value* value = NULL;
    for ( unsigned i = 0; i < metrics.size(); i++ )
    {
        for ( unsigned j = 0; j < cnodes.size(); j++ )
        {
            if ( value == NULL )
            {
                value = get_sev_adv( metrics[ i ].first, metrics[ i ].second,  cnodes[ j ].first, cnodes[ j ].second,   sys, sf );
            }
            else
            {
                Value* _v =  get_sev_adv( metrics[ i ].first, metrics[ i ].second,  cnodes[ j ].first, cnodes[ j ].second,   sys, sf );
                if ( _v != NULL )
                {
                    ( *value ) += _v;
                    delete _v;
                }
            }
        }
    }
    return value;
}

double
Cube::get_sev( list_of_metrics & metrics, list_of_cnodes & cnodes, Sysres* sys, CalculationFlavour sf )       // sum over roots of calltree
{
    if ( metrics.size() == 0 )
    {
        return 0;
    }
    if ( cnodes.size() == 0 )
    {
        return 0;
    }
    if ( sys == NULL )
    {
        return 0;
    }

    Value* v = get_sev_adv( metrics, cnodes, sys, sf );
    if ( v == NULL )
    {
//         cerr << "get_sev_adv(metrics, cnodes, sys, sf) returned NULL" << endl;
        return 0.;
    }
    double d = v->getDouble();
    delete v;
    return d;
}




Value*
Cube::get_sev_adv( list_of_metrics & metrics, list_of_regions & regions, Sysres* sys, CalculationFlavour sf )
{
    if ( metrics.size() == 0 )
    {
        throw RuntimeError( "Error in calculation call  get_sev_adv(list_of_metrics, list_of_regions , Sysres *,  CalculationFlavour ): No metrics are spezified. Empty list." );
    }
    if ( regions.size() == 0 )
    {
        throw RuntimeError( "Error in calculation call  get_sev_adv(list_of_metrics, list_of_regions , Sysres *,  CalculationFlavour ): No regions are spezified. Empty list." );
    }
    if ( sys == NULL )
    {
        throw RuntimeError( "No system resource (machine, node, process or thread) is specified for the calculation" );
    }

    Value* value = NULL;
    for ( unsigned i = 0; i < metrics.size(); i++ )
    {
        for ( unsigned j = 0; j < regions.size(); j++ )
        {
            if ( regions[ j ].first == NULL )
            {
                continue;
            }
            if ( value == NULL )
            {
                value = get_sev_adv( metrics[ i ].first, metrics[ i ].second,  regions[ j ].first, regions[ j ].second,   sys, sf );
            }
            else
            {
                Value* _v =  get_sev_adv( metrics[ i ].first, metrics[ i ].second,  regions[ j ].first, regions[ j ].second,   sys, sf );
                if ( _v != NULL )
                {
                    ( *value ) += _v;
                    delete _v;
                }
            }
        }
    }
    return value;
}

double
Cube::get_sev( list_of_metrics & metrics, list_of_regions & regions, Sysres* sys, CalculationFlavour sf )       // sum over roots of calltree
{
    if ( metrics.size() == 0 )
    {
        return 0;
    }
    if ( regions.size() == 0 )
    {
        return 0;
    }
    if ( sys == NULL )
    {
        return 0;
    }

    Value* v = get_sev_adv( metrics, regions, sys, sf );
    if ( v == NULL )
    {
//         cerr << "get_sev_adv(metrics, regions, sys, sf) returned NULL" << endl;
        return 0.;
    }
    double d = v->getDouble();
    delete v;
    return d;
}




Value*
Cube::get_sev_adv( list_of_metrics & metrics, list_of_sysresources & sys_res, Cnode* cnode, CalculationFlavour cf )
{
    if ( metrics.size() == 0 )
    {
        throw RuntimeError( "Error in calculation call  get_sev_adv(list_of_metrics, list_of_sysresources , Cnode *,  CalculationFlavour ): No metrics are spezified. Empty list." );
    }
    if ( sys_res.size() == 0 )
    {
        throw RuntimeError( "Error in calculation call  get_sev_adv(list_of_metrics, list_of_sysresources , Cnode *,  CalculationFlavour ): No system resources (machines, nodes, processes  and threads) are spezified. Empty list." );
    }
    if ( cnode == NULL )
    {
        throw RuntimeError( "No cnode  is specified for the calculation" );
    }

    Value* value = NULL;
    for ( unsigned i = 0; i < metrics.size(); i++ )
    {
        for ( unsigned j = 0; j < sys_res.size(); j++ )
        {
            if ( value == NULL )
            {
                value = get_sev_adv( metrics[ i ].first, metrics[ i ].second, cnode, cf, sys_res[ j ].first, sys_res[ j ].second );
            }
            else
            {
                Value* _v =  get_sev_adv( metrics[ i ].first, metrics[ i ].second, cnode, cf, sys_res[ j ].first, sys_res[ j ].second );
                if ( _v != NULL )
                {
                    ( *value ) += _v;
                    delete _v;
                }
            }
        }
    }
    return value;
}

double
Cube::get_sev( list_of_metrics & metrics, list_of_sysresources & sys_res, Cnode* cnode, CalculationFlavour cf )       // sum over roots of calltree
{
    if ( metrics.size() == 0 )
    {
        return 0;
    }
    if ( sys_res.size() == 0 )
    {
        return 0;
    }
    if ( cnode == NULL )
    {
        return 0;
    }

    Value* v = get_sev_adv( metrics, sys_res, cnode, cf );
    if ( v == NULL )
    {
//         cerr << "get_sev_adv(metrics, sys_res, cnode, cf) returnd NULL" << endl;
        return 0.;
    }
    double d = v->getDouble();
    delete v;
    return d;
}






Value*
Cube::get_sev_adv( list_of_metrics & metrics, list_of_sysresources & sys_res, Region* region, CalculationFlavour rf )
{
    if ( metrics.size() == 0 )
    {
        throw RuntimeError( "Error in calculation call  get_sev_adv(list_of_metrics, list_of_sysresources , Region *,  CalculationFlavour ): No metrics are spezified. Empty list." );
    }
    if ( sys_res.size() == 0 )
    {
        throw RuntimeError( "Error in calculation call  get_sev_adv(list_of_metrics, list_of_sysresources , Region *,  CalculationFlavour ): No system resources (machines, nodes, processes  and threads) are spezified. Empty list." );
    }
    if ( region == NULL )
    {
        throw RuntimeError( "No region is specified for the calculation" );
    }

    Value* value = NULL;
    for ( unsigned i = 0; i < metrics.size(); i++ )
    {
        for ( unsigned j = 0; j < sys_res.size(); j++ )
        {
            if ( value == 0 )
            {
                value = get_sev_adv( metrics[ i ].first, metrics[ i ].second, region, rf, sys_res[ j ].first, sys_res[ j ].second );
            }
            else
            {
                Value* _v =  get_sev_adv( metrics[ i ].first, metrics[ i ].second, region, rf, sys_res[ j ].first, sys_res[ j ].second );
                if ( _v != NULL )
                {
                    ( *value ) += _v;
                    delete _v;
                }
            }
        }
    }
    return value;
}

double
Cube::get_sev( list_of_metrics & metrics, list_of_sysresources & sys_res, Region* region, CalculationFlavour rf )       // sum over roots of calltree
{
    if ( metrics.size() == 0 )
    {
        return 0;
    }
    if ( sys_res.size() == 0 )
    {
        return 0;
    }
    if ( region == NULL )
    {
        return 0;
    }

    Value* v = get_sev_adv( metrics, sys_res, region, rf );
    if ( v == NULL )
    {
//         cerr << "get_sev_adv(metrics, sys_res, region, rf) returned NULL" << endl;
        return 0.;
    }
    double d = v->getDouble();
    delete v;
    return d;
}






Value*
Cube::get_sev_adv( list_of_cnodes & cnodes, list_of_sysresources & sys_res, Metric* metric, CalculationFlavour mf )
{
    if ( cnodes.size() == 0 )
    {
        throw RuntimeError( "Error in calculation call  get_sev_adv(list_of_cnodes, list_of_sysresources , Metric *,  CalculationFlavour ): No cnodes are spezified. Empty list." );
    }
    if ( sys_res.size() == 0 )
    {
        throw RuntimeError( "Error in calculation call  get_sev_adv(list_of_cnodes, list_of_sysresources , Metric *,  CalculationFlavour ): No system resources (machines, nodes, processes  and threads) are spezified. Empty list." );
    }
    if ( metric == NULL )
    {
        throw RuntimeError( "No metric is specified for the calculation." );
    }

    Value* value = NULL;
    for ( unsigned i = 0; i < cnodes.size(); i++ )
    {
        for ( unsigned j = 0; j < sys_res.size(); j++ )
        {
            if ( value == NULL )
            {
                value = get_sev_adv( metric, mf, cnodes[ i ].first, cnodes[ i ].second, sys_res[ j ].first, sys_res[ j ].second );
            }
            else
            {
                Value* _v =  get_sev_adv( metric, mf, cnodes[ i ].first, cnodes[ i ].second, sys_res[ j ].first, sys_res[ j ].second );
                if ( _v != NULL )
                {
                    ( *value ) += _v;
                    delete _v;
                }
            }
        }
    }
    return value;
}

double
Cube::get_sev( list_of_cnodes & cnodes, list_of_sysresources & sys_res, Metric* metric, CalculationFlavour mf )       // sum over roots of calltree
{
    if ( cnodes.size() == 0 )
    {
        return 0;
    }
    if ( sys_res.size() == 0 )
    {
        return 0;
    }
    if ( metric == NULL )
    {
        return 0;
    }

    Value* v = get_sev_adv( cnodes, sys_res, metric, mf );
    if ( v == NULL )
    {
//         cerr << "get_sev_adv(cnodes, sys_res, metric, mf) returned NULL" << endl;
        return 0.;
    }
    double d = v->getDouble();
    delete v;
    return d;
}









Value*
Cube::get_sev_adv( list_of_regions & regions, list_of_sysresources & sys_res, Metric* metric, CalculationFlavour mf )
{
    if ( regions.size() == 0 )
    {
        throw RuntimeError( "Error in calculation call  get_sev_adv(list_of_regions, list_of_sysresources , Metric *,  CalculationFlavour ): No regions are spezified. Empty list." );
    }
    if ( sys_res.size() == 0 )
    {
        throw RuntimeError( "Error in calculation call  get_sev_adv(list_of_regions, list_of_sysresources , Metric *,  CalculationFlavour ): No system resources (machines, nodes, processes  and threads) are spezified. Empty list." );
    }
    if ( metric == NULL )
    {
        throw RuntimeError( "No metric is specified for the calculation" );
    }

    Value* value = NULL;
    for ( unsigned i = 0; i < regions.size(); i++ )
    {
        for ( unsigned j = 0; j < sys_res.size(); j++ )
        {
            if ( value == NULL )
            {
                value = get_sev_adv( metric, mf, regions[ i ].first, regions[ i ].second, sys_res[ j ].first, sys_res[ j ].second );
            }
            else
            {
                Value* _v =  get_sev_adv( metric, mf, regions[ i ].first, regions[ i ].second, sys_res[ j ].first, sys_res[ j ].second );
                if ( _v != NULL )
                {
                    ( *value ) += _v;
                    delete _v;
                }
            }
        }
    }
    return value;
}

double
Cube::get_sev( list_of_regions & regions, list_of_sysresources & sys_res, Metric* metric, CalculationFlavour mf )       // sum over roots of calltree
{
    if ( regions.size() == 0 )
    {
        return 0;
    }
    if ( sys_res.size() == 0 )
    {
        return 0;
    }
    if ( metric == NULL )
    {
        return 0;
    }

    Value* v = get_sev_adv( regions, sys_res, metric, mf );
    if ( v == NULL )
    {
//         cerr << "get_sev_adv(regions, sys_res, metric, mf) returned NULL" << endl;
        return 0.;
    }
    double d = v->getDouble();
    delete v;
    return d;
}








// --------------- end of calls with lists-----------



// -------------------ANALYSIS PART  END -------------------------


// ------------------- ID ASSIGNATION START -----------------------
void
Cube::assign_ids( Metric* met )
{
    assign_id_metrics();
    create_calltree_ids( met ); // caltree depending, system is always exclusive and 0
    create_system_ids();        // caltree depending, system is always exclusive and 0
}

void
Cube::assign_id_metrics()
{
//     IDassigner id_assigner(new IDdeliverer(), new WideSearchEnumerator);
//     for (std::vector<Metric *>::iterator m_iter = root_metv.begin(); m_iter<root_metv.end(); m_iter++)
//     {
//         id_assigner.assign_ids((*m_iter));
//     }
}


void
Cube::create_calltree_ids( Metric* met )
{
//     for ( std::vector<Metric*>::iterator m_iter = metv.begin(); m_iter < metv.end(); m_iter++ )
//     {
    IDdeliverer*         ids                 = new IDdeliverer();
    row_of_objects_t*    _row                = NULL;
    std::vector<Cnode*>* _roots_to_enumerate = NULL;
    if ( is_clustering_on() )
    {
        _roots_to_enumerate = &original_root_cnodev;
    }
    else
    {
        _roots_to_enumerate = &root_cnodev;
    }
    for ( std::vector<Cnode*>::iterator c_iter = _roots_to_enumerate->begin(); c_iter < _roots_to_enumerate->end(); c_iter++ )
    {
        _row = met->create_calltree_id_maps( ids, ( *c_iter ), _row );
    }
    delete ids;
    delete _row;
//     }
}


void
Cube::create_system_ids()
{
    return; // currently no spezial dealing with Thread IDs is needed.
}





// -------------- Call tree modification calls


void
Cube::reroot_cnode( Cnode* _cnode )
{
    if ( _cnode == NULL ) // ignore everything, if the parameter it NULL
    {
        cerr << "Call Cube::reroot_cnode( Cnode* _cnode) with _cnode== NULL" << endl;
        return;
    }
    if ( _cnode->get_parent() == NULL ) // if it is a root already, do nothing
    {
        return;
    }

    Cnode* _myroot = _cnode->get_parent();
    while ( _myroot->get_parent() != NULL )
    {
        _myroot = _myroot->get_parent();
    }                                                                                           // find a root cnode of the current _cnode.

    vector<Cnode*>::iterator root_it = find( root_cnodev.begin(), root_cnodev.end(), _myroot ); // find a index of the current tree in the vector of root elements . It will be replaced

    // Now one has to remove all elements from cnodev , which are in same tree like _cnode. but are not in subtree of _cnode.
    // Element are not getting lost, coz cnodevfull keeps all elements and delete operator acts on it.

    for ( vector<Cnode*>::iterator _it = cnodev.begin(); _it != cnodev.end(); _it++ )
    {
        bool _subtree_of_cnode = false;
        if ( *_it == _cnode )
        {
            continue; // we do not remove _cnode itself;
        }
        Cnode* __myroot = ( *_it )->get_parent();
        if ( __myroot != NULL )
        {
            while ( __myroot->get_parent() != NULL )
            {
                _subtree_of_cnode = _subtree_of_cnode || ( __myroot == _cnode );
                __myroot          = __myroot->get_parent();
            } // find a root cnode of the current  _cnode.
        }
        else
        {
            __myroot = *_it;
        }
        _subtree_of_cnode = _subtree_of_cnode ||  ( __myroot == _cnode );


        if ( _subtree_of_cnode )  // we do not remove elements, which are in subtree of _cnode.
        {
            continue;
        }

        if ( __myroot == _myroot ) // if the root of the *__it element is _myroot, remove it (replace my 0.)
        {
            ( *_it ) = ( Cnode* )NULL;
        }
    }

    // all removed elements are replaced by zero.
    // now one has to remove all zeroes (moving all elements towards)
    vector<Cnode*>::iterator new_end =  remove( cnodev.begin(), cnodev.end(), ( Cnode* )NULL );
    cnodev.erase( new_end, cnodev.end() );

    // now cnodev has another size
    *root_it = _cnode; // set the selected subtree as a root. all paretns and cousins are not lost, cos they are not removed from cnodevfull.
    _cnode->set_parent( NULL );


//     vector<Cnode*>::iterator it = find( cnodev.begin(), cnodev.end(), _cnode);
//     root_cnodev.push_back( *it );
//     (*it)->hide(); // becomes hidden and contributes to exclusive value, but not to exclusive
//     (*it)->set_parent( NULL); // ???? should it be if
}




void
Cube::prune_cnode( Cnode* _cnode )
{
    if ( _cnode == NULL ) // ignore everything, if the parameter it NULL
    {
        cerr << "Call Cube::prune_cnode( Cnode* _cnode) with _cnode== NULL" << endl;
        return;
    }


//     vector<Cnode*> _to_remove = _cnode->get_all_children();
//     for (vector<Cnode*>::iterator _iter = _to_remove.begin(); _iter!= _to_remove.end(); _iter++)
//     {
//      vector<Cnode*>::iterator __it = find( cnodev.begin(), cnodev.end(), (*_iter));
//      cnodev.erase(__it);
//     }
//     vector<Cnode*>::iterator __it = find( cnodev.begin(), cnodev.end(), _cnode);
//     cnodev.erase(__it);
    if ( _cnode->get_parent() == NULL ) // if it is a root already, do nothing
    {
        vector<Cnode*>::iterator it = find( root_cnodev.begin(), root_cnodev.end(), _cnode );
        ( *it )->hide(); // hide it and all its children (needed to avoid not necesarry storing if copied)
        root_cnodev.erase( it );
    }
    else  // parent doesnt
    {
        _cnode->hide(); // hide it and all its children (needed to avoid not necesarry storing if copied)
    }
}



void
Cube::set_cnode_as_leaf( Cnode* _cnode )
{
    if ( _cnode == NULL ) // ignore everything, if the parameter it NULL
    {
        cerr << "Call Cube::set_cnode_as_leaf( Cnode* _cnode) with _cnode== NULL" << endl;
        return;
    }

    _cnode->set_as_leaf();
}






// -------------------- ID ASSIGNATION END -------------------------




void
Cube::write( const string& filename )
{
    ofstream out;
    out.open( filename.c_str() );
    if ( !out.good() )
    {
        throw RuntimeError( "Cube::write(string): file name doesn't exist" );
    }
    out << *this;
    out.close();
}

int
Cube::max_num_thrd() const
{
    unsigned int ret = 0;
    for ( unsigned int i = 0; i < stnv.size(); i++ )
    {
        int _num_of_groups = stnv[ i ]->num_groups();
        for ( int j = 0; j < _num_of_groups; j++ )
        {
            const LocationGroup* p = stnv[ i ]->get_location_group( j );
            if ( p->num_children() > ret )
            {
                ret = p->num_children();
            }
        }
    }
    return ret;
}
/**
 * \details Gives a metric with "uniq_name".
 */
Metric*
Cube::get_met( const string& uniq_name ) const
{
    for ( unsigned int i = 0; i < metv.size(); i++ )
    {
        if ( metv[ i ]->get_uniq_name() == uniq_name )
        {
            return metv[ i ];
        }
    }
    return NULL;
}
/**
 * \details Gives a root metric.
 */
Metric*
Cube::get_root_met( Metric* met )
{
    if ( met == NULL )
    {
        return 0;
    }
    while ( met->get_parent() != NULL )
    {
        met = met->get_parent();
    }
    return met;
}
/**
 * \details Gives not NULL only if cn exists in a cube..
 */
Cnode*
Cube::get_cnode( Cnode& cn ) const
{
    const vector<Cnode*> &_cnodev = get_cnodev();
    for ( unsigned int i = 0; i < _cnodev.size(); i++ )
    {
        if ( *_cnodev[ i ] == cn )
        {
            return _cnodev[ i ];
        }
    }
    return NULL;
}
/**
 * \details Gives not NULL only if mach exists in a cube..
 */
Machine*
Cube::get_mach( Machine& mach ) const
{
    const vector<Machine*> &_root_stnv = get_machv();
    for ( unsigned int i = 0; i < _root_stnv.size(); i++ )
    {
        if ( *_root_stnv[ i ] == mach )
        {
            return _root_stnv[ i ];
        }
    }
    return NULL;
}

/**
 * \details Gives not NULL only if node exists in a cube..
 */
Node*
Cube::get_node( Node& node ) const
{
    const vector<Node*> &_nodev = get_nodev();
    for ( unsigned int i = 0; i < _nodev.size(); i++ )
    {
        if ( *_nodev[ i ] == node )
        {
            return _nodev[ i ];
        }
    }
    return NULL;
}



void
Cube::writeXML_header( ostream& out, bool cube3_export )
{
    if ( cube3_export && !system_tree_cube3_compatibility_check() )
    {
        throw Cube3SystemTreeMismatchError( "System tree cannot be represented in cube3 format." );
    }



    const vector<Cnode*>&          cnv    = get_root_cnodev();
    const vector<SystemTreeNode*>& _stnv  = get_root_stnv();
    const vector<Metric*>&         _rmetv = get_root_metv();
//     const vector<Metric*>& metv      = get_metv(); // unused

    const vector<Region*>&     rv = get_regv();
//     const vector<Thread*>& thrdv     = get_thrdv(); // unused
    const map<string, string>& _attrs   = get_attrs();
    const vector<string>&      _mirrors = get_mirrors();




    if ( !cube3_export )
    {
        def_attr( "CUBE Library version", CUBE_FULL_NAME " r" CUBE_REVISION_STRING );
    }

    // xml header
    out << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" << '\n' << '\n';
    if ( cube3_export )
    {
        out << "<cube " << "version=\"3.0\">" << '\n';
    }
    else
    {
        out << "<cube " << "version=\"4.3\">" << '\n';
    }


    // metadata info
    map<string, string>::const_iterator ai;
    for ( ai = _attrs.begin(); ai != _attrs.end(); ai++ )
    {
        if ( ai->first.compare( "CUBE Library version" ) == 0 && cube3_export )
        {
            continue;
        }
        out << "  <attr " << "key=" << "\"" << services::escapeToXML( ai->first ) << "\" "
            << "value=" << "\"" << services::escapeToXML( ai->second ) << "\"/>" << '\n';
    }
    // mirrored URLs
    out << "  <doc>" << '\n';
    out << "    <mirrors>" << '\n';
    for ( unsigned int i = 0; i < _mirrors.size(); i++ )
    {
        out << "      <murl>" << services::escapeToXML( _mirrors[ i ] ) << "</murl>" << '\n';
    }
    out << "    </mirrors>" << '\n';
    out << "  </doc>" << '\n';


    // metrics
    out << "  <metrics";
    if ( get_metrics_title() != "" )
    {
        out << " title=\"" << services::escapeToXML( get_metrics_title() ) << "\"";
    }
    out << ">" << '\n';
    for ( unsigned int i = 0; i < _rmetv.size(); i++ )  // write metrics
    {
        if ( !_rmetv[ i ]->isInactive() )
        {
            _rmetv[ i ]->writeXML( out, cube3_export );
        }
    }
    out << "  </metrics>"  << '\n';

    // programfor
    out << "  <program";
    if ( get_calltree_title() != "" )
    {
        out << " title=\"" << services::escapeToXML( get_calltree_title() ) << "\"";
    }
    out << ">" << '\n';

    for ( unsigned int i = 0; i < rv.size(); i++ )     // write regions
    {
        rv[ i ]->writeXML( out, cube3_export  );
    }

    for ( unsigned int i = 0; i < cnv.size(); i++ )    // write cnodes
    {
        cnv[ i ]->writeXML( out, cube3_export );
    }

    out << "  </program>"   << '\n';

    // system
    out << "  <system";
    if ( get_systemtree_title() != "" )
    {
        out << " title=\"" << services::escapeToXML( get_systemtree_title() ) << "\"";
    }
    out << ">" << '\n';
    for ( unsigned int i = 0; i < _stnv.size(); i++ )     // write system resources
    {
        _stnv[ i ]->writeXML( out, cube3_export );
    }

    // topologies
    out << "    <topologies>" << '\n';
    for ( unsigned int i = 0; i < get_cartv().size(); i++ ) // write topologies
    {
        get_cart( i )->writeXML( out, cube3_export  );
    }
    out << "    </topologies>" << '\n';

    out << "  </system>" << '\n';
    return;
}


void
Cube::writeXML_data( ostream& out )
{
    out << "<severity>"   << '\n';

    for ( unsigned int i = 0; i < metv.size(); i++ )
    {
        if ( !metv[ i ]->isInitialized() )
        {
            metv[ i ]->set_dimensions( cnodev, root_cnodev, root_stnv, locationv );
            if ( mode_read_only )
            {
                create_metrics_existing_data_containers( metv[ i ] );
            }
            else
            {
                create_metrics_data_containers( metv[ i ] );
            }
            assign_ids( metv[ i ] );
        }
        if ( !metv[ i ]->isInactive() )
        {
            metv[ i ]->writeXML_data( out, cnodev, locationv );
        }
    }

    out << "</severity>"  << '\n';
}

void
Cube::writeXML_closing( ostream& out )
{
    out << "</cube>"      << '\n';
}






std::string
Cube::get_statistic_name()
{
    return get_attr( "statisticfile" );
}




bool
Cube::is_flat_tree_enabled()
{
    std::string res = get_attr( "statisticfile" );
    return ( res == "" || res  == "yes" ) ? true : false;
}


uint32_t
Cube::get_number_void_processes()
{
    uint32_t num_void_procs = 0;
    for ( size_t i = 0; i < location_groupv.size(); i++ )
    {
        LocationGroup* proc  = location_groupv[ i ];
        std::string    _name = proc->get_name();
        if ( _name.find( "VOID" ) != string::npos )
        {
            num_void_procs++;
        }
    }
    return num_void_procs;
}

uint32_t
Cube::get_number_void_threads()
{
    uint32_t num_void_thrds = 0;
    for ( size_t i = 0; i < locationv.size(); i++ )
    {
        LocationGroup* proc = locationv[ i ]->get_parent();
        if ( proc->get_name().find( "VOID" ) != string::npos )
        {
            num_void_thrds++;
        }
    }
    return num_void_thrds;
}



void
Cube::setup_cubepl1_memory()
{
    cubepl1_memory_manager->init();
    cubepl1_memory_manager->put( CUBE_NUM_MIRRORS, 0, mirror_urlv.size(), CUBEPL_RESERVED_VARIABLE );
    cubepl1_memory_manager->put( CUBE_NUM_METRICS, 0, metv.size(), CUBEPL_RESERVED_VARIABLE  );
    cubepl1_memory_manager->put( CUBE_NUM_ROOT_METRICS, 0, root_metv.size(), CUBEPL_RESERVED_VARIABLE  );
    cubepl1_memory_manager->put( CUBE_NUM_REGIONS, 0, regv.size(), CUBEPL_RESERVED_VARIABLE  );
    cubepl1_memory_manager->put( CUBE_NUM_CALLPATHS, 0, cnodev.size(), CUBEPL_RESERVED_VARIABLE  );
    cubepl1_memory_manager->put( CUBE_NUM_ROOT_CALLPATHS, 0, root_cnodev.size(), CUBEPL_RESERVED_VARIABLE );
    cubepl1_memory_manager->put( CUBE_NUM_LOCATIONS, 0, locationv.size(), CUBEPL_RESERVED_VARIABLE  );
    cubepl1_memory_manager->put( CUBE_NUM_LOCATION_GROUPS, 0, location_groupv.size(), CUBEPL_RESERVED_VARIABLE  );
    cubepl1_memory_manager->put( CUBE_NUM_STNS, 0, stnv.size(), CUBEPL_RESERVED_VARIABLE  );
    cubepl1_memory_manager->put( CUBE_NUM_ROOT_STNS, 0, root_stnv.size(), CUBEPL_RESERVED_VARIABLE  );

    cubepl1_memory_manager->put( CUBE_FILENAME, 0, cubename, CUBEPL_RESERVED_VARIABLE  );

    uint32_t num_void_procs    = get_number_void_processes();
    uint32_t num_void_thrds    = get_number_void_threads();
    uint32_t num_nonvoid_procs = location_groupv.size() - num_void_procs;
    uint32_t num_nonvoid_thrds = locationv.size() - num_void_thrds;

    cubepl1_memory_manager->put( CUBE_NUM_VOID_LGS, 0, num_void_procs, CUBEPL_RESERVED_VARIABLE  );
    cubepl1_memory_manager->put( CUBE_NUM_VOID_LOCS, 0, num_void_thrds, CUBEPL_RESERVED_VARIABLE  );
    cubepl1_memory_manager->put( CUBE_NUM_NONVOID_LGS, 0, num_nonvoid_procs, CUBEPL_RESERVED_VARIABLE  );
    cubepl1_memory_manager->put( CUBE_NUM_NONVOID_LOCS, 0, num_nonvoid_thrds, CUBEPL_RESERVED_VARIABLE  );


    // now setup the metrics insformation
    for ( vector<Metric*>::iterator miter = metv.begin(); miter != metv.end(); miter++ )
    {
        Metric*  _metric = *miter;
        uint32_t _id     = _metric->get_id();
        cubepl1_memory_manager->put( CUBE_METRIC_UNIQ_NAME, _id,  _metric->get_uniq_name(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_METRIC_DISP_NAME, _id, _metric->get_disp_name(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_METRIC_URL, _id, _metric->get_url(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_METRIC_DESCRIPTION, _id, _metric->get_descr(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_METRIC_DTYPE, _id, _metric->get_dtype(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_METRIC_UOM, _id, _metric->get_uom(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_METRIC_EXPRESSION, _id, _metric->get_expression(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_METRIC_INIT_EXPRESSION, _id, _metric->get_init_expression(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_METRIC_NUM_CHILDREN, _id, _metric->num_children(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_METRIC_PARENT_ID, _id, ( _metric->get_parent() != 0 ) ? _metric->get_parent()->get_id() : -1., CUBEPL_RESERVED_VARIABLE  );
    }

/*    // now setup the ghost metrics insformation
    for (vector<Metric*>::iterator miter = ghost_metv.begin(); miter != ghost_metv.end(); miter++)
    {
      Metric * _metric = *miter;
      uint32_t _id = _metric->get_id();

    }
 */
// now setup the regions information
    for ( vector<Region*>::iterator riter = regv.begin(); riter != regv.end(); riter++ )
    {
        Region*  _region = *riter;
        uint32_t _id     = _region->get_id();
        cubepl1_memory_manager->put( CUBE_REGION_NAME, _id,  _region->get_name(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_REGION_URL, _id, _region->get_url(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_REGION_DESCRIPTION, _id,  _region->get_descr(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_REGION_MOD, _id,  _region->get_mod(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_REGION_BEGIN_LINE, _id,  _region->get_begn_ln(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_REGION_END_LINE, _id,  _region->get_end_ln(), CUBEPL_RESERVED_VARIABLE  );
    }
    // now setup the callpath information
    for ( vector<Cnode*>::iterator citer = fullcnodev.begin(); citer != fullcnodev.end(); citer++ )
    {
        Cnode*   _cnode = *citer;
        uint32_t _id    = _cnode->get_id();
        cubepl1_memory_manager->put( CUBE_CALLPATH_MOD, _id,  _cnode->get_mod(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_CALLPATH_LINE, _id,  _cnode->get_line(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_CALLPATH_NUM_CHILDREN, _id,  _cnode->num_children(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_CALLPATH_PARENT_ID, _id,  ( _cnode->get_parent() != NULL ) ? _cnode->get_parent()->get_id() : -1., CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_CALLPATH_CALLEE_ID, _id,  ( _cnode->get_callee() != NULL ) ? _cnode->get_callee()->get_id() : -1., CUBEPL_RESERVED_VARIABLE  );
    }

    // now setup the system informatoin (machines)
    for ( vector<SystemTreeNode*>::iterator stniter = stnv.begin(); stniter != stnv.end(); stniter++ )
    {
        SystemTreeNode* _stn = *stniter;
        uint32_t        _id  = _stn->get_id();
        cubepl1_memory_manager->put( CUBE_STN_NAME, _id, _stn->get_name(), CUBEPL_RESERVED_VARIABLE   );
//         cubepl1_memory_manager->put( CUBE_STN_DESCRIPTION, _id, _stn->get_description(), CUBEPL_RESERVED_VARIABLE   );
        cubepl1_memory_manager->put( CUBE_STN_CLASS, _id, _stn->get_class(), CUBEPL_RESERVED_VARIABLE   );
        cubepl1_memory_manager->put( CUBE_STN_PARENT_ID, _id, ( _stn->get_parent() != NULL ) ? _stn->get_parent()->get_id() : -1., CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_STN_NUM_CHILDREN, _id,  _stn->num_children(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_STN_NUM_LOCATION_GROUPS, _id,  _stn->num_groups(), CUBEPL_RESERVED_VARIABLE  );
    }


    // now setup the system informatoin (location groups)
    for ( vector<LocationGroup*>::iterator lgiter = location_groupv.begin(); lgiter != location_groupv.end(); lgiter++ )
    {
        LocationGroup* _lg     = *lgiter;
        uint32_t       _id     = _lg->get_id();
        bool           is_void = false;
        cubepl1_memory_manager->put( CUBE_LOCATION_GROUP_NAME, _id, _lg->get_name(), CUBEPL_RESERVED_VARIABLE   );
        cubepl1_memory_manager->put( CUBE_LOCATION_GROUP_RANK,   _id, _lg->get_rank(), CUBEPL_RESERVED_VARIABLE );
        cubepl1_memory_manager->put( CUBE_LOCATION_GROUP_TYPE,   _id, _lg->get_type(), CUBEPL_RESERVED_VARIABLE );
        cubepl1_memory_manager->put( CUBE_LOCATION_GROUP_PARENT_ID, _id,  _lg->get_parent()->get_id(), CUBEPL_RESERVED_VARIABLE  );
        is_void = ( _lg->get_name().find( "VOID" ) != string::npos );
        cubepl1_memory_manager->put( CUBE_LOCATION_GROUP_VOID, _id, ( is_void ) ? 1 : 0, CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_LOCATION_GROUP_PARENT_ID, _id, _lg->get_parent()->get_id(), CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_LOCATION_GROUP_NUM_LOCATIONS, _id,  _lg->num_children(), CUBEPL_RESERVED_VARIABLE  );
    }
    // now setup the system informatoin (locations)
    for ( vector<Location*>::iterator liter = locationv.begin(); liter != locationv.end(); liter++ )
    {
        Location* _loc    = *liter;
        uint32_t  _id     = _loc->get_id();
        bool      is_void = false;
        cubepl1_memory_manager->put( CUBE_LOCATION_NAME, _id, _loc->get_name(), CUBEPL_RESERVED_VARIABLE   );
        cubepl1_memory_manager->put( CUBE_LOCATION_RANK,   _id, _loc->get_rank(), CUBEPL_RESERVED_VARIABLE );
        cubepl1_memory_manager->put( CUBE_LOCATION_TYPE,   _id, _loc->get_type(), CUBEPL_RESERVED_VARIABLE );
        cubepl1_memory_manager->put( CUBE_LOCATION_PARENT_ID, _id,  _loc->get_parent()->get_id(), CUBEPL_RESERVED_VARIABLE  );
        is_void = ( _loc->get_name().find( "VOID" ) != string::npos );
        cubepl1_memory_manager->put( CUBE_LOCATION_VOID, _id, ( is_void ) ? 1 : 0, CUBEPL_RESERVED_VARIABLE  );
        cubepl1_memory_manager->put( CUBE_LOCATION_PARENT_ID, _id, _loc->get_parent()->get_id(), CUBEPL_RESERVED_VARIABLE  );
    }
}



void
Cube::compile_derived_metric_expressions()
{
    cubeplparser::CubePL1Driver driver( this ); // create driver for
    std::string                 errors;



    for ( vector<Metric*>::iterator iter = metv.begin(); iter != metv.end(); iter++ )
    {
        Metric*     met = *iter;
        std::string derived_metric_init_error;

        if (
            met->get_type_of_metric() == CUBE_METRIC_POSTDERIVED
            ||
            met->get_type_of_metric() == CUBE_METRIC_PREDERIVED_EXCLUSIVE
            ||
            met->get_type_of_metric() == CUBE_METRIC_PREDERIVED_INCLUSIVE
            )
        {
            std::string init_expression     = met->get_init_expression();
            std::string cubepl_init_program = string( "<cubepl>" ) + init_expression + string( "</cubepl>" );
            if (
                driver.test( cubepl_init_program, derived_metric_init_error )
                )
            {
                stringstream       strin2( cubepl_init_program );
                GeneralEvaluation* formula2 = driver.compile( &strin2, &cerr );
                met->setInitEvaluation( formula2 );
            }
            else
            {     // cannot create metric, cou compilerr reported an error (??? )
                cerr << " Error in the compilation of expression for metric : " << met->get_uniq_name() << endl;
                cerr << " Cannot compile an initialization expression : " << endl << init_expression <<  endl << "because of the following error: " <<  derived_metric_init_error << endl;

                errors += "Error in: ";
                errors += met->get_uniq_name();
                errors += " : ";
                errors += derived_metric_init_error;
                errors += "\n\n";
            }
        }
    }

    for ( vector<Metric*>::iterator iter = metv.begin(); iter != metv.end(); iter++ )
    {
        Metric*     met = *iter;
        std::string derived_metric_error;
        if (
            met->get_type_of_metric() == CUBE_METRIC_POSTDERIVED
            ||
            met->get_type_of_metric() == CUBE_METRIC_PREDERIVED_EXCLUSIVE
            ||
            met->get_type_of_metric() == CUBE_METRIC_PREDERIVED_INCLUSIVE
            )
        {
            std::string expression     = met->get_expression();
            std::string cubepl_program = string( "<cubepl>" ) + expression + string( "</cubepl>" );
            if ( driver.test( cubepl_program, derived_metric_error )
                 )
            {
                stringstream       strin1( cubepl_program );
                GeneralEvaluation* formula1 = driver.compile( &strin1, &cerr );
                met->setEvaluation( formula1 );
            }
            else
            {     // cannot create metric, cou compilerr reported an error (??? )
                cerr << " Error in the compilation of expression for metric : " << met->get_uniq_name() << endl;
                cerr << " Cannot compile  an expression : " << endl << expression <<  endl << "because of the following error: " <<  derived_metric_error << endl;

                errors += "Error in: ";
                errors += met->get_uniq_name();
                errors += " : ";
                errors += derived_metric_error;
                errors += "\n\n";
            }
        }
    }
}




vector<string>
Cube::get_misc_data()
{
    return filefinder->getAllData();
}


vector<char>
Cube::get_misc_data( string & dataname )
{
    int   ffile  = -1;
    char* buffer = NULL;
    try
    {
        fileplace_t data = filefinder->getMiscData( dataname );
        ffile = open(  data.first.c_str(), O_RDONLY  );
        if ( ffile == -1 )
        {
            throw NoFileInTarError( "Cannot find file " + dataname );
        }
        if ( ( off_t )data.second.first != lseek( ffile, data.second.first, SEEK_CUR ) )
        {
            cerr << "Cannot seek to the miscelaneous data " << dataname << " in the cube " <<  cubename << endl;
            close( ffile );
            throw FatalError( "Cannot seek to the metadata " + dataname + " of cube " + cubename );
        }
        buffer = new char[ data.second.second ]; // we extend the buffer for one symbol to create a legal C-like string, with 0 at the end
        memset( buffer, 0, data.second.second );
        if ( ( int )data.second.second != read( ffile, buffer, data.second.second ) )
        {
            cerr << "Error while reading miscelaneous data " << dataname << " stored in the cube " <<  cubename << endl;
            close( ffile );
            throw RuntimeError( "Error while reading miscelaneous data " + dataname + " of cube " + cubename );
        }
        close( ffile );
        vector<char> to_return( buffer, buffer + data.second.second );
        delete[] buffer;
        return to_return;
    }
    catch ( NoFileInTarError err )
    {
        close( ffile );
        delete[] buffer;
        vector<char> to_return;
        delete[] buffer;
        return to_return;
    }
}

void
Cube::write_misc_data( string & dataname, const char* buffer, size_t len )
{
    fileplace_t data  = filefinder->getMiscData( dataname );
    FILE*       ffile = fopen( data.first.c_str(), "wb+" );
    if ( ffile == NULL )
    {
        perror( "Error opening file" );
//       printf( "Error opening file: %s\n", strerror( errno ) );
        cerr << "Cannot create file "  <<  data.first.c_str() << "  to store the miscelaneous data " << dataname << " in the cube " <<  cubename << endl;
        throw FatalError( "Cannot store the metadata " + dataname + " of cube " + cubename );
    }
    if ( fseeko( ffile, data.second.first, SEEK_SET ) != 0 )
    {
        cerr << "Cannot seek to the miscelaneous data " << dataname << " in the cube " <<  cubename << endl;
        fclose( ffile );
        throw FatalError( "Cannot seek to the metadata " + dataname + " of cube " + cubename );
    }
    if ( len != fwrite( buffer, 1, len, ffile ) )
    {
        cerr << "Error while reading miscelaneous data " << dataname << " stored in the cube " <<  cubename << endl;
        fclose( ffile );
        throw RuntimeError( "Error while reading miscelaneous data " + dataname + " of cube " + cubename );
    }
    fclose( ffile );
}

void
Cube::write_misc_data( string & dataname, vector<char>& data )
{
    char* tmp = new char[ data.size() ];
    for ( size_t i = 0; i < data.size(); i++ )
    {
        tmp[ i ] = data[ i ];
    }
    write_misc_data( dataname, tmp, data.size() );
    delete[] tmp;
}



namespace cube
{
/**
 * \details Writes a xml .cube file. First general header, then structure of every dimension and then the data.
 */
ostream&
operator<<( ostream& out,  Cube& cube )
{
    try
    {
        cube.writeXML_header( out, true );
        cube.writeXML_data( out );
        cube.writeXML_closing( out );
    }
    catch ( Cube3SystemTreeMismatchError e )
    {
        cerr << e;
        throw e;
    }
    return out;
}
/**
 * \details Let "driver" to read the xml .cube file and creates a cube.
 */
istream&
operator>>( std::istream& in, Cube& cb )
{
    cubeparser::Driver* driver = NULL;
    try {
        driver = new cubeparser::Driver();
        driver->parse_stream( in, cb );
    }
    catch ( RuntimeError e )
    {
        cerr << e.get_msg();
        throw;
    }
    delete driver;

    cb.setGlobalMemoryStrategy( cube::CUBE_ALL_IN_MEMORY_STRATEGY );

    return in;
}



bool
Cube::system_tree_cube3_compatibility_check()
{
    const vector<SystemTreeNode*>& _stnv = get_non_root_stnv();
    for ( vector<SystemTreeNode*>::const_iterator iter = _stnv.begin(); iter != _stnv.end(); iter++ )
    {
        if ( ( *iter )->get_parent() == NULL )
        {
            throw RuntimeError( "Non root system tree node has a NULL parent. Something is wrong." );
        }
        if ( ( *iter )->get_parent()->get_parent() != NULL ) // case, if it is more than 2 level.
        {
            return false;
        }
        if ( ( *iter )->num_children() != 0 ) // case, if it there are subsystem tree nodes. Processes are stored in groups.
        {
            return false;
        }
    }
    return true;
}
}
