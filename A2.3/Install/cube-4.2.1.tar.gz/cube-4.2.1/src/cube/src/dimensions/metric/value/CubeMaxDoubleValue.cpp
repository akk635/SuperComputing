/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeMaxDoubleValue.cpp
 * \brief   Defines the methods of the "MaxDoubleValue".
 ************************************************/

#ifndef __MAX_DOUBLE_VALUE_CPP
#define __MAX_DOUBLE_VALUE_CPP

#include <cstring>
#include <iomanip>
#include <string>
#include <sstream>
#include <iostream>
#include <algorithm>
#include "CubeValues.h"

using namespace std;
using namespace cube;

/*
   MaxDoubleValue
   MaxDoubleValue::operator+( const MaxDoubleValue& ch )
   {
    MaxDoubleValue tmp = *this;
    tmp.value.dValue = max( tmp.value.dValue,  ch.value.dValue );
    return tmp;
   }

   MaxDoubleValue
   MaxDoubleValue::operator-( const MaxDoubleValue& ch )
   {
    MaxDoubleValue tmp = *this;
    tmp.value.dValue = min( tmp.value.dValue,  ch.value.dValue );
    return tmp;
   }*/


// void
// MaxDoubleValue::operator+=( Value* chval )
// {
//     if ( chval == NULL )
//     {
//         return;
//     }
//     value.dValue = max( value.dValue, ( ( DoubleValue* )chval )->getDouble() );
// }
//
// void
// MaxDoubleValue::operator-=( Value* chval )
// {
//     if ( chval == NULL )
//     {
//         return;
//     }
//     value.dValue = min( value.dValue, ( ( DoubleValue* )chval )->getDouble() );
// }

/*
   MaxDoubleValue
   MaxDoubleValue::operator=( MaxDoubleValue v )
   {
    if ( &v == this )
    {
        return *this;
    }
    value.dValue = v.getDouble();
    return *this;
   }

   Value*
   MaxDoubleValue::clone()
   {
    return new MaxDoubleValue();
   }*/

string
MaxDoubleValue::getString()
{
    stringstream sstr;
    string       str;
    if ( value.dValue != -DBL_MAX )
    {
        sstr <<  setprecision( 12 ) << value.dValue;
    }
    else
    {
        sstr <<  "-";
    }

    sstr >> str;
    return str;
}

// overloaded new operator
void*
MaxDoubleValue::operator new( size_t size )
{
    return ( void* )max_double_preallocator.Get();
}
// delete operator overloaded
void
MaxDoubleValue::operator delete( void* p )
{
    max_double_preallocator.Put( ( MaxDoubleValue* )p );
}

/*
   void MaxDoubleValue::operator=(string v)
   {
    (DoubleValue)(*this) = v;
   }
 */

void
MaxDoubleValue::normalizeWithClusterCount( uint64_t N )
{
}

#endif
