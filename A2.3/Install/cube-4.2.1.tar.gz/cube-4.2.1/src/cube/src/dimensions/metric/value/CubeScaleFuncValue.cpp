/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeScaleFuncValue.cpp
 * \brief   Defines the methods of the "ScaleFuncValue".
 ************************************************/

#ifndef __SCALE_FUNC_VALUE_CPP
#define __SCALE_FUNC_VALUE_CPP

#include <sstream>
#include <cstring>
#include <string>
#include <iostream>
#include "CubeValues.h"

using namespace std;
using namespace cube;

const
static int scaling_order[ 27 ] =
{
    26, 25, 23, 24, 22, 20, 21, 19, 17, 18, 16, 14, 15, 13, 11, 12, 10, 8, 9, 7, 5, 6, 4, 2, 3, 1, 0
};


ScaleFuncValue::ScaleFuncValue() : NDoublesValue( 27 )
{
}


ScaleFuncValue::ScaleFuncValue(
    double* vals ) : NDoublesValue( 27, vals )
{
//     this->fromStream( ( char* )vals );
}

/**
 * Create ScaleFuncValue from the stream assuming that real part is first, imaginary part next.
 */
/*
   ScaleFuncValue::ScaleFuncValue(char * cv)
   {
    DoubleValue re(cv);
    DoubleValue im(cv+re.getSize());

    r_value = re;
    i_value = im;

   }*/


// unsigned
// ScaleFuncValue::ScaleFuncValue::getSize()
// {
//     return ( N.getUnsignedLong() == 0 ) ? 0 : N.getUnsignedLong() * ( values[ 0 ].getSize() );
// }


double
ScaleFuncValue::getDouble()
{
//     throw RuntimeError( "Impossible to return single double value from ScaleFuncValue" );
    unsigned i = 0;
    for (; i  < N.getUnsignedLong(); i++ )
    {
        if ( !values[ scaling_order[ i ] ]->isZero() )
        {
            break;
        }
    }
    std::pair<unsigned, unsigned> _powers = get_powers( scaling_order[ i ] );
    return ( 1.5 * _powers.second + _powers.first ) * 100;
}

uint16_t
ScaleFuncValue::getUnsignedShort()
{
//     throw RuntimeError( "Impossible to return single unsigned short value from ScaleFuncValue" );
    return ( uint16_t )getDouble();
}
int16_t
ScaleFuncValue::getSignedShort()
{
//     throw RuntimeError( "Impossible to return single signed short value from ScaleFuncValue" );
    return ( int16_t )getDouble();
}
uint32_t
ScaleFuncValue::getUnsignedInt()
{
//     throw RuntimeError( "Impossible to return single unsigned integer value from ScaleFuncValue" );
    return ( uint32_t )getDouble();
}
int32_t
ScaleFuncValue::getSignedInt()
{
//     throw RuntimeError( "Impossible to return single signed integer value from ScaleFuncValue" );
    return ( int32_t )getDouble();
}

uint64_t
ScaleFuncValue::getUnsignedLong()
{
//     throw RuntimeError( "Impossible to return single unsigned long value from ScaleFuncValue" );
    return ( uint64_t )getDouble();
}
int64_t
ScaleFuncValue::getSignedLong()
{
//     throw RuntimeError( "Impossible to return single signed long value from ScaleFuncValue" );
    return ( uint64_t )getDouble();
}


char
ScaleFuncValue::getChar()
{
//     throw RuntimeError( "Impossible to return single char value from ScaleFuncValue" );
    return ' ';
}

string
ScaleFuncValue::getString()
{
    string   tmp   = "(";
    unsigned terms = 0;
    unsigned i     = 0;
    for (; i < N.getUnsignedLong(); i++  )
    {
        int                           index   = scaling_order[ i ];
        std::pair<unsigned, unsigned> _powers = get_powers( index );

        stringstream                  sstr1;
        sstr1 << _powers.first;
        string                        _a;
        sstr1 >> _a;
        stringstream                  sstr2;
        sstr2 << _powers.second / 2.;
        string                        _b;
        sstr2 >> _b;

        if ( !values[ index ]->isZero() )
        {
            if ( terms > 0 )
            {
                tmp += " + ";
            }
            terms++;
            tmp += values[ index ]->getString();
            if ( _powers.first  != 0 )
            {
                if ( _powers.first != 1 )
                {
                    tmp += ( "ln(x)^" + _a );
                }
                else
                {
                    tmp += ( "ln(x)" );
                }
            }
            if ( _powers.second != 0 )
            {
                if ( _powers.second != 2 )
                {
                    tmp += ( "x^" + _b );
                }
                else
                {
                    tmp += ( "x" );
                }
            }
        }
        if ( terms >= 3 )
        {
            tmp += "+ ...";
            break;
        }
    }
    tmp += ") ";
    return tmp;
}

Value*
ScaleFuncValue::clone()
{
    return new ScaleFuncValue();
}

Value*
ScaleFuncValue::copy()
{
    double*         tmp_d = new double[ N.getUnsignedLong() ];
    toStream( ( char* )tmp_d );
    ScaleFuncValue* _return =  new ScaleFuncValue(  tmp_d );
    delete[] tmp_d;
    return _return;
}

ScaleFuncValue
ScaleFuncValue::operator=( ScaleFuncValue comp )
{
    for ( unsigned i = 0; i < N.getUnsignedLong(); i++ )
    {
        delete values[ i ];
    }
    if ( values != NULL )
    {
        delete[] values;
    }
    values = new DoubleValue *[ N.getUnsignedLong() ];
    for ( unsigned i = 0; i < N.getUnsignedLong(); i++ )
    {
        values[ i ] = new DoubleValue();
    }

    double* tmp_d = new double[ N.getUnsignedLong() ];
    comp.toStream( ( char* )tmp_d );
    fromStream( ( char* )tmp_d );
    delete[] tmp_d;
    return *this;
}

// overloaded new operator
void*
ScaleFuncValue::operator new( size_t size )
{
    return ( void* )scale_func_preallocator.Get();
}
// delete operator overloaded
void
ScaleFuncValue::operator delete( void* p )
{
    scale_func_preallocator.Put( ( ScaleFuncValue* )p );
}



std::pair<unsigned, unsigned>
ScaleFuncValue::get_powers( unsigned index )
{
    unsigned                      b = index % 3;
    unsigned                      c = index / 3;
    std::pair<unsigned, unsigned> pair;
    pair.first  = b;
    pair.second = c;
    return pair;
}



#endif
