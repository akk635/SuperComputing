/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubePostDerivedMetric.cpp
 * \brief Defines methods to calculate incl/exclusve values if the metric is defined as an expression

 ********************************************/


#include <iostream>

#include "CubePostDerivedMetric.h"

using namespace std;
using namespace cube;


PostDerivedMetric::~PostDerivedMetric()
{
}


// inclusive value and exclusive value in this metric are same
Value*
PostDerivedMetric::get_sev_adv( Cnode* cnode, CalculationFlavour cnf, Sysres* sys, CalculationFlavour sf )
{
    pre_calculation_preparation( cnode, sys );
    if ( init_evaluation != NULL )
    {
        init_evaluation->eval();
        delete init_evaluation;
        init_evaluation = NULL;
    }
    Value* cached_value = cache->getCachedValue( cnode, cnf, sys, sf );
    if ( cached_value != NULL )
    {
        return cached_value;
    }

    Value* _v =  selectValueOnDataType( own_data_type  );
    if ( evaluation != NULL )
    {
        double _value = evaluation->eval( cnode, cnf, sys, sf );
        ( *_v ) = _value;
    }
    cache->setCachedValue( _v, cnode, cnf, sys, sf );
    post_calculation_cleanup();
    return _v;
}






Value*
PostDerivedMetric::get_sev_adv( Cnode* cnode, CalculationFlavour cnf )
{
    if ( cnode == NULL )
    {
        return NULL;
    }

    pre_calculation_preparation( cnode );
    if ( init_evaluation != NULL )
    {
        init_evaluation->eval();
        delete init_evaluation;
        init_evaluation = NULL;
    }
    Value* cached_value = cache->getCachedValue( cnode, cnf );
    if ( cached_value != NULL )
    {
        return cached_value;
    }

    Value* _v =  selectValueOnDataType( own_data_type );
    if ( evaluation != NULL )
    {
        double _value = evaluation->eval( cnode, cnf );
        ( *_v ) = _value;
    }
    cache->setCachedValue( _v, cnode, cnf );
    post_calculation_cleanup();
    return _v;
}
