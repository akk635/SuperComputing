/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubeRowWiseMatrix.cpp
 * \brief Definces methods of the RowWiseMatrix class.
 */



#ifndef __ROWWISE_MATRIX_CPP
#define __ROWWISE_MATRIX_CPP

#include <string>
#include <cstring>
#include <iostream>

#include "CubeTrafos.h"
#include "CubeValues.h"
#include "CubeIndexes.h"
#include "CubeIndexManager.h"
#include "CubeRowWiseMatrix.h"

using namespace std;
using namespace cube;


RowWiseMatrix::RowWiseMatrix(
    fileplace_t DataPlace,
    fileplace_t IndexPlace,
    thread_id_t nt,
    DataType    type )
{
    _no_row_pointer = new char[ 1 ];
    strategy        = new AllInMemoryStrategy( true );
    row_interface   = new Row( nt, selectValueOnDataType( type ) ); // create Row with standart interfaces, which do get replaces later on in initialization of RowsSupplier
    rows_manager    = new RowsManager( DataPlace, IndexPlace, &rows, row_interface,  strategy, _no_row_pointer );
}


RowWiseMatrix::RowWiseMatrix(
    fileplace_t DataPlace,
    fileplace_t IndexPlace,
    thread_id_t nt,
    DataType    type,
    IndexFormat format )
{
    _no_row_pointer = new char[ 1 ];
    strategy        = new AllInMemoryStrategy( true );
    row_interface   = new Row( nt, selectValueOnDataType( type ) ); // create Row with standart interfaces, which do get replaces later on in initialization of RowsSupplier
    rows_manager    = new RowsManager( DataPlace, IndexPlace, format, &rows, row_interface,  strategy, _no_row_pointer );
}


RowWiseMatrix::RowWiseMatrix(
    fileplace_t    DataPlace,
    fileplace_t    IndexPlace,
    thread_id_t    nt,
    DataType       type,
    BasicStrategy* _strategy )
{
    RowWiseMatrix( DataPlace, IndexPlace, nt, type );
    if ( _strategy != NULL )
    {
        setStrategy( _strategy );
    }
}


RowWiseMatrix::RowWiseMatrix(
    fileplace_t    DataPlace,
    fileplace_t    IndexPlace,
    thread_id_t    nt,
    DataType       type,
    IndexFormat    format,
    BasicStrategy* _strategy )
{
    RowWiseMatrix( DataPlace, IndexPlace, nt, type, format );
    if ( _strategy != NULL )
    {
        setStrategy( _strategy );
    }
}



RowWiseMatrix::~RowWiseMatrix()
{
    delete row_interface;
    delete rows_manager;
    delete strategy;
    delete[] _no_row_pointer;
}


void
RowWiseMatrix::writeData()
{
    if ( rows_manager  != NULL )
    {
        rows_manager->dropAllRows();
    }
    rows_manager->finalize();
}


void
RowWiseMatrix::setStrategy( CubeStrategy _strategy )
{
    switch ( _strategy )
    {
        case CUBE_MANUAL_STRATEGY:
            setStrategy( new ManualStrategy( true ) );
            break;
        case CUBE_ALL_IN_MEMORY_STRATEGY:
            setStrategy( new AllInMemoryStrategy( true ) );
            break;
        case CUBE_LAST_N_ROWS_STRATEGY:
            setStrategy( new LastNRowsStrategy( true, 50 ) );
            break;
        default: // default is all in memory, recursiv call this call
            setStrategy( CUBE_ALL_IN_MEMORY_STRATEGY );
            break;
    }
}



void
RowWiseMatrix::dropRow( cnode_id_t cid )
{
    rows_manager->dropRow( cid );
}



Value*
RowWiseMatrix::getValue( cnode_id_t cid, thread_id_t tid )
{
    if ( rows[ cid ] == _no_row_pointer )
    {
        return row_interface->getValue();
    }
    row_t _tmp = rows[ cid ];
    if ( _tmp == NULL )
    {
        rows_manager->provideRow( cid );
        if ( rows[ cid ] == NULL )
        {
            rows[ cid ] = _no_row_pointer;
            return row_interface->getValue();
        }
    }
    row_interface->setPointerToMemory( rows[ cid ] );
    return row_interface->getData( tid );
}

void
RowWiseMatrix::setValue( Value* v, cnode_id_t cid, thread_id_t tid )
{
    row_t _tmp = rows[ cid ];
    if ( _tmp == NULL || _tmp == _no_row_pointer )
    {
//         cout << "1 PROVIDE ROW ! " << endl;
        rows_manager->provideRow( cid, true );
    }
    row_interface->setPointerToMemory( rows[ cid ] );
    row_interface->setData( v, tid );
    return;
}


void
RowWiseMatrix::setValue( double val, cnode_id_t cid, thread_id_t tid )
{
    row_t _tmp = rows[ cid ];
    if ( _tmp == NULL || _tmp == _no_row_pointer )
    {
//         cout << "21 PROVIDE ROW ! " << (uint64_t)(rows[ cid ]) << " " << NULL << " " << (uint64_t)_no_row_pointer  << endl;
        rows_manager->provideRow( cid, true );
//         cout << "22 PROVIDE ROW ! " << (uint64_t)(rows[ cid ]) << " " << NULL << " " << (uint64_t)_no_row_pointer  << endl;
    }
    row_interface->setPointerToMemory( rows[ cid ] );
    row_interface->setData( val, tid );
}

void
RowWiseMatrix::setValue( uint64_t val, cnode_id_t cid, thread_id_t tid )
{
    row_t _tmp = rows[ cid ];
    if ( _tmp == NULL || _tmp == _no_row_pointer )
    {
//         cout << "3 PROVIDE ROW ! " << endl;
        rows_manager->provideRow( cid, true );
    }
    row_interface->setPointerToMemory( rows[ cid ] );
    row_interface->setData( val, tid );
}



Value*
RowWiseMatrix::sumRow( cnode_id_t cid, thread_id_t tid, uint64_t number )
{
    if ( rows[ cid ] == _no_row_pointer )
    {
        return row_interface->getValue();
    }
    row_t _tmp = rows[ cid ];
    if ( _tmp == NULL )
    {
        rows_manager->provideRow( cid );
        if ( rows[ cid ] == NULL )
        {
            rows[ cid ] = _no_row_pointer;
            return row_interface->getValue();
        }
    }
    row_interface->setPointerToMemory( rows[ cid ] );
    return row_interface->sumRow( tid, number );
}

void
RowWiseMatrix::writeXML( std::ostream& out )
{
// writen on Cube level
}






#endif
