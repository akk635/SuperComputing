/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeTauAtomicValue.cpp
 * \brief Defines the methods of the "TauAtomicValue".
 ************************************************/
#ifndef __TAU_ATOMIC_VALUE_CPP
#define __TAU_ATOMIC_VALUE_CPP

#include <sstream>
#include <cstring>
#include <string>
#include <cmath>
#include <iostream>
#include "CubeValues.h"
#include "CubeError.h"

using namespace std;
using namespace cube;


TauAtomicValue::TauAtomicValue() : N( 0 ), MinValue(), MaxValue(), Sum( 0. ), Sum2( 0. )
{
    isSingleValue = false;
}

TauAtomicValue::TauAtomicValue( unsigned n,
                                double   min,
                                double   max,
                                double   sum,
                                double   sum2 ) : N( n ), MinValue( min ), MaxValue( max ), Sum( sum ), Sum2( sum2 )
{
    isSingleValue = false;
}

// TauAtomicValue::TauAtomicValue( char* cv )
// {
//     isSingleValue = false;
//
//     UnsignedValue  _n( cv );
//     MinDoubleValue _min( cv + _n.getSize() );
//     MaxDoubleValue _max( cv + _n.getSize() + _min.getSize() );
//     DoubleValue    _sum( cv + _n.getSize() + _min.getSize() + _max.getSize() );
//     DoubleValue    _sum2( cv + _n.getSize() + _min.getSize() + _max.getSize() + _sum.getSize() );
//
//     N        = _n;
//     MinValue = _min;
//     MaxValue = _max;
//     Sum      = _sum;
//     Sum2     = _sum2;
// }
// /*
// unsigned
// TauAtomicValue::getSize()
// {
//     return
//         N.getSize() +
//         MinValue.getSize() +
//         MaxValue.getSize() +
//         Sum.getSize() +
//         Sum2.getSize();
// }
//
// double
// TauAtomicValue::getDouble()
// {
//     calcAvgVar();
//     return Average;
// }*/

uint16_t
TauAtomicValue::getUnsignedShort()
{
    calcAvgVar();
    return ( uint16_t )Average;
}

int16_t
TauAtomicValue::getSignedShort()
{
    calcAvgVar();
    return ( int16_t )Average;
}

uint32_t
TauAtomicValue::getUnsignedInt()
{
    calcAvgVar();
    return ( uint32_t )Average;
}

int32_t
TauAtomicValue::getSignedInt()
{
    calcAvgVar();
    return ( int32_t )Average;
}


uint64_t
TauAtomicValue::getUnsignedLong()
{
    calcAvgVar();
    return ( uint64_t )Average;
}

int64_t
TauAtomicValue::getSignedLong()
{
    calcAvgVar();
    return ( int64_t )Average;
}


/**
 * As char will be returned just first char of the char representation
 */
char
TauAtomicValue::getChar()
{
    return ' ';
}



/**
 * Creates the string representation of the value.
 */
string
TauAtomicValue::getString()
{
// #warning " STRING representation of TAV Value should be developed"
    calcAvgVar();
    stringstream sstr;
    string       str;
    sstr << "(" <<  N.getString() << "," << MinValue.getString() << "," << MaxValue.getString() << "):";
    if ( N.getUnsignedInt() != 0. )
    {
        sstr << Average << "," << Variance << endl;
    }
    else
    {
        sstr << "-" << "," << "-" << endl;
    }
    sstr >> str;
    return str;
}


// overloaded new operator
void*
TauAtomicValue::operator new( size_t size )
{
    return ( void* )tau_preallocator.Get();
}
// delete operator overloaded
void
TauAtomicValue::operator delete( void* p )
{
    tau_preallocator.Put( ( TauAtomicValue* )p );
}

// /*
// /**
//  * Creates the copy and sets the value to 0.
//  */
// Value*
// TauAtomicValue::clone()
// {
//     return new TauAtomicValue();
// }
//
//
// /**
//  * Creates the copy.
//  */
// Value*
// TauAtomicValue::copy()
// {
// // #warning "Missing interface for unsigned long long"
//     return new TauAtomicValue( N.getUnsignedInt(), MinValue.getDouble(), MaxValue.getDouble(), Sum.getDouble(), Sum2.getDouble() );
// }*/


/**
 * Sets the value from stream and returns the position in stream right after the value.
 */
char*
TauAtomicValue::fromStream( char* cv )
{
    return Sum2.fromStream( Sum.fromStream( MaxValue.fromStream( MinValue.fromStream( N.fromStream( cv ) ) ) ) );
}

/**
 * Saves the value in the stream and returns the position in stream right after the value.
 */
char*
TauAtomicValue::toStream( char* cv )
{
    return Sum2.toStream( Sum.toStream( MaxValue.toStream( MinValue.toStream( N.toStream( cv ) ) ) ) );
}

/**
 * Transforms the endianness in the stream according its layout
 */
char*
TauAtomicValue::transformStream( char* cv, SingleValueTrafo* trafo )
{
    return Sum2.transformStream( Sum.transformStream( MaxValue.transformStream( MinValue.transformStream( N.transformStream( cv, trafo ), trafo ), trafo ), trafo ), trafo );
}



/*

   TauAtomicValue
   TauAtomicValue::operator+( const TauAtomicValue& ch )
   {
    TauAtomicValue tmp = *this;
    tmp.N        = tmp.N + ch.N;
    tmp.MinValue = tmp.MinValue + ch.MinValue;
    tmp.MaxValue = tmp.MaxValue + ch.MaxValue;
    tmp.Sum      = tmp.Sum + ch.Sum;
    tmp.Sum2     = tmp.Sum2 + ch.Sum2;
    return tmp;
   }

   TauAtomicValue
   TauAtomicValue::operator-( const TauAtomicValue& ch )
   {
    TauAtomicValue tmp = *this;
    tmp.N        = tmp.N - ch.N;
    tmp.MinValue = tmp.MinValue - ch.MinValue;
    tmp.MaxValue = tmp.MaxValue - ch.MaxValue;
    tmp.Sum      = tmp.Sum - ch.Sum;
    tmp.Sum2     = tmp.Sum2 - ch.Sum2;
    return tmp;
   }


   void
   TauAtomicValue::operator+=( Value* chval )
   {
    if ( chval == NULL )
    {
        return;
    }
    N        += ( ( Value* )( &( ( ( TauAtomicValue* )chval )->N ) ) );
    MinValue += ( ( Value* )( &( ( ( TauAtomicValue* )chval )->MinValue ) ) );
    MaxValue += ( ( Value* )( &( ( ( TauAtomicValue* )chval )->MaxValue ) ) );
    Sum      += ( ( Value* )( &( ( ( TauAtomicValue* )chval )->Sum ) ) );
    Sum2     += ( ( Value* )( &( ( ( TauAtomicValue* )chval )->Sum2 ) ) );
   }

   void
   TauAtomicValue::operator-=( Value* chval )
   {
    if ( chval == NULL )
    {
        return;
    }
    N        -= ( ( Value* )( &( ( ( TauAtomicValue* )chval )->N ) ) );
    MinValue -= ( ( Value* )( &( ( ( TauAtomicValue* )chval )->MinValue ) ) );
    MaxValue -= ( ( Value* )( &( ( ( TauAtomicValue* )chval )->MaxValue ) ) );
    Sum      -= ( ( Value* )( &( ( ( TauAtomicValue* )chval )->Sum ) ) );
    Sum2     -= ( ( Value* )( &( ( ( TauAtomicValue* )chval )->Sum2 ) ) );
   }


   void
   TauAtomicValue::operator*=( double dval )
   {
    N        *= dval;
    MinValue *= dval;
    MaxValue *= dval;
    Sum      *= dval;
    Sum2     *= dval;
   }

   void
   TauAtomicValue::operator/=( double dval )
   {
    if ( dval == 0. )
    {
        cerr << "ERROR: DEVISION BY ZERO!" << endl;
    }
    N        /= dval;
    MinValue /= dval;
    MaxValue /= dval;
    Sum      /= dval;
    Sum2     /= dval;
   }*/


void
TauAtomicValue::operator=( double d )
{
    throw  RuntimeError( "Impossible to assign a  single double to TauAtomicValue" );
}
/*
   void
   TauAtomicValue::operator=( char c )
   {
    throw  RuntimeError( "Impossible to assign a  single char to TauAtomicValue" );
   }


   void
   TauAtomicValue::operator=( uint16_t ui )
   {
    throw  RuntimeError( "Impossible to assign a single unsigned  short int to TauAtomicValue" );
   }

   void
   TauAtomicValue::operator=( uint32_t i )
   {
    throw  RuntimeError( "Impossible to assign a single unsigned  int to TauAtomicValue" );
   }

   void
   TauAtomicValue::operator=( uint64_t ul )
   {
    throw  RuntimeError( "Impossible to assign a  single unswigned long long  int to TauAtomicValue" );
   }

   void
   TauAtomicValue::operator=( int16_t si )
   {
    throw  RuntimeError( "Impossible to assign a  single signed  short int to TauAtomicValue" );
   }

   void
   TauAtomicValue::operator=( int32_t i )
   {
    throw  RuntimeError( "Impossible to assign a single  int to TauAtomicValue" );
   }

   void
   TauAtomicValue::operator=( int64_t sl )
   {
    throw  RuntimeError( "Impossible to assign a single signed long long  short int to TauAtomicValue" );
   }

   void
   TauAtomicValue::operator=( string v )
   {
   // #warning " TauAtomicValue method operator=(string) is not implemented yet"
   }


   TauAtomicValue
   TauAtomicValue::operator=( TauAtomicValue v )
   {
    if ( &v == this )
    {
        return *this;
    }
    N        = v.getN();
    MinValue = v.getMinValue();
    MaxValue = v.getMaxValue();
    Sum      = v.getSum();
    Sum2     = v.getSum2();
    return *this;
   }
 */


void
TauAtomicValue::operator=( Value* v )
{
    throw  RuntimeError( "Impossible to assign a singlegeneral Value to TauAtomicValue" );
}


// -------------------- PRIVATE METHODS- ------------------------

void
TauAtomicValue::calcAvgVar()
{
    uint32_t n  = N.getUnsignedInt();
    double   dn = N.getDouble();
    double   s  = Sum.getDouble();
    double   s2 = Sum2.getDouble();

    Average  =  ( n == 0 ) ? s / ( dn + 1e-256 )  : s / dn;
    Variance = ( n == 0 ) ? 0.             : sqrt( 1. / ( dn ) * ( s2 - 1. / dn * s * s ) );
}


void
TauAtomicValue::normalizeWithClusterCount( uint64_t _N )
{
    N.normalizeWithClusterCount( _N );
//   MinValue.normalizeWithClusterCount(N);
//   MaxValue.normalizeWithClusterCount(N);
    Sum.normalizeWithClusterCount( _N );
    Sum2.normalizeWithClusterCount( _N );
}


#endif
