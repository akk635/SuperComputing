/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubeRow.cpp
 * \brief  Implements methods of class Row
 */

#ifndef CUBE_ROW_CPP
#define CUBE_ROW_CPP

#include "CubeRow.h"

using namespace cube;


Row::~Row()
{
    delete value;
}


void
Row::correctEndianess( row_t _row )
{
    row_t ptr_value = _row;

    while ( ptr_value < _row + getRawRowSize() )
    {
        row_t _tmp = value->transformStream( ptr_value, endianess );
        if ( _tmp == ptr_value )
        {
            break;
        }
        ptr_value = _tmp;
    }
}


void
Row::setEndianess( SingleValueTrafo* _trafo )
{
    delete endianess;
    endianess = _trafo;
}



void
Row::setData( Value* v, thread_id_t tid )
{
    if ( ( uint64_t )tid > n )
    {
        return;
    }
    // by that time internal pointer should be set on the memoery
    if ( row == NULL )
    {
        throw NotAllocatedMemoryForRow( "Row::setData(...) tries to set the value on not available memory. Please allocate memory first." );
    }
    v->toStream( row + tid * ( v->getSize() ) );
}


void
Row::setData( double v, thread_id_t tid )
{
    if ( ( uint64_t )tid > n )
    {
        return;
    }
    // by that time internal pointer should be set on the memoery
    if ( row == NULL )
    {
        throw NotAllocatedMemoryForRow( "Row::setData(...) tries to set the value on not available memory. Please allocate memory first." );
    }

    *value = v;
    value->toStream( row + tid * value->getSize() );
}



void
Row::setData( uint64_t v, thread_id_t tid )
{
    if ( ( uint64_t )tid > n )
    {
        return;
    }
    // by that time internal pointer should be set on the memoery
    if ( row == NULL )
    {
        throw NotAllocatedMemoryForRow( "Row::setData(...) tries to set the value on not available memory. Please allocate memory first." );
    }

    *value = v;
    value->toStream( row + tid * value->getSize() );
}


Value*
Row::getData( thread_id_t tid )
{
    if ( row == NULL )
    {
        throw NotAllocatedMemoryForRow( "Row::getData(...) tries to create a value on the not available memory. Please allocate memory first." );
    }

    Value* v = value->clone();
    if ( ( uint64_t )tid > n )
    {
        return v;
    }
    v->fromStream( row + tid * value->getSize() );
//     cout << " __ " <<  v->getString() << endl;
    return v;
}



Value*
Row::sumRow( thread_id_t tid, uint64_t number )
{
    if ( row == NULL )
    {
        throw NotAllocatedMemoryForRow( "Row::sumRow(...) tries to sum up a value on the not available memory. Please allocate memory first." );
    }

    Value* to_return = value->clone();


    // check ranges and adjust them if they are wrong
    if ( ( uint64_t )tid > n )
    {
        return to_return;
    }
    if ( tid + number > n )
    {
        number = n - tid;
    }

    // ranges are ok. Prepare a temparary working copy of an object of Value
    Value* _v = value->clone();
    // calculate memory range
    char*  pos    = row + tid * ( _v->getSize() );
    char*  endpos = row  + ( tid + number ) * ( _v->getSize() );

    // sum up the values in the memory
    while ( pos < endpos  )
    {
        pos = _v->fromStream( pos );

        ( *to_return ) += _v;
//      cout << " TO RETURN " << _v->getDouble () << " " <<  to_return->getDouble() << endl;
    }

    // remove the internal working exemplat
    delete _v;

    // return a sum
    return to_return;
}



void
Row::printRow( std::ostream & _cout )
{
    printRow( row, _cout );
}

void
Row::printRawRow( std::ostream & _cout )
{
    printRawRow( row, _cout );
}

void
Row::printRow( row_t _row, std::ostream & _cout )
{
    if ( _row == NULL )
    {
        _cout << "0xNULL" << endl;
        return;
    }
    Value* _v     = value->clone();
    char*  pos    = _row;
    char*  endpos = _row  + ( n ) * ( _v->getSize() );
    // sum up the values in the memory
    _cout << " ================================================ " << endl;
    while ( pos < endpos  )
    {
        pos = _v->fromStream( pos );
        _cout << _v->getString() << " ";
    }
    _cout << endl << " ================================================ " << endl;
    delete _v;
}

void
Row::printRawRow( row_t _row, std::ostream & _cout )
{
    if ( _row == NULL )
    {
        _cout << "0xNULL" << endl;
        return;
    }
    Value* _v     = value->clone();
    char*  pos    = _row;
    char*  endpos = _row  + ( n ) * ( _v->getSize() );
    // sum up the values in the memory
    _cout << " =====================charwise =========================== " << endl;
    cout << hex;
    while ( pos < endpos  )
    {
        _cout << ( unsigned short )( *( ( uint8_t* )( pos ) ) ) << " ";
        pos++;
    }
    cout << dec;
    _cout << endl << " ================================================ " << endl;
    delete _v;
}



#endif
