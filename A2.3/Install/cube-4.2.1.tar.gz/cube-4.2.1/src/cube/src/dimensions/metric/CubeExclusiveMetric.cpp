/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubeExclusiveMetric.cpp
 * \brief Defines methods to calculate incl/exclusve values if the metric contains only exclusive values

 ********************************************/


#include <iostream>

#include "CubeExclusiveMetric.h"

using namespace std;
using namespace cube;


ExclusiveMetric::~ExclusiveMetric()
{
}


row_of_objects_t*
ExclusiveMetric::create_calltree_id_maps( IDdeliverer* ids, Cnode* root, row_of_objects_t* _row  )
{
    ids->reset();
    DeepSearchEnumerator enumerator;
    _row = enumerator.get_objects_to_enumerate( root, _row );
//     enumerator.get_strides( calltree_strides ); // should be caled after ".get_objects_to_enumerate()"
    for ( row_of_objects_t::iterator iter = _row->begin(); iter < _row->end(); iter++ )
    {
        calltree_local_ids[ ( *iter )->get_id() ] = ids->get_next_id();
    }

    return _row;
}



// inclusive value and exclusive value in this metric are same
Value*
ExclusiveMetric::get_sev_adv( Cnode* cnode, CalculationFlavour cnf, Sysres* sys, CalculationFlavour sf )
{
    if ( adv_sev_mat == NULL )
    {
        return NULL;
    }
    if ( cnode == NULL )
    {
        return NULL;
    }
    if ( sys == NULL )
    {
        return NULL;
    }

    Value* v = adv_sev_mat->getValue();
    if ( ( sys->isSystemTreeNode() || sys->isLocationGroup() ) && sf == cube::CUBE_CALCULATE_EXCLUSIVE )
    {
        return v;
    }

    Value* cached_value = cache->getCachedValue( cnode, cnf, sys, sf );
    if ( cached_value != NULL )
    {
        delete v;
        return cached_value;
    }

    if ( sys->isSystemTreeNode() )
    {
        SystemTreeNode* _sys = ( SystemTreeNode* )sys;
        // first add values of all sub system nodes
        for ( unsigned i = 0; i < _sys->num_children(); i++ )
        {
            Value* _v = get_sev_adv( cnode, cnf, _sys->get_child( i ), cube::CUBE_CALCULATE_INCLUSIVE );
            ( *v ) += _v;
            delete _v;
        }
        // then add all values of all sub local groups
        for ( unsigned i = 0; i < _sys->num_groups(); i++ )
        {
            Value* _v = get_sev_adv( cnode, cnf, _sys->get_location_group( i ), cube::CUBE_CALCULATE_INCLUSIVE );
            ( *v ) += _v;
            delete _v;
        }
    }
    if ( sys->isLocationGroup() )
    {
        LocationGroup* _lg = ( LocationGroup* )sys;

        for ( unsigned i = 0; i < _lg->num_children(); i++ )
        {
            Value* _v = get_sev_adv( cnode, cnf, _lg->get_child( i ), cube::CUBE_CALCULATE_INCLUSIVE );
            ( *v ) += _v;
            delete _v;
        }
    }
    if ( sys->isLocation() )
    {
        Location*      _loc    = ( Location* )sys;
        LocationGroup* _lg     = _loc->get_parent();
        int64_t        lg_rank = _lg->get_rank();
        Value*         _v      = adv_sev_mat->getValue( calltree_local_ids[ cnode->get_remapping_cnode( lg_rank  )->get_id() ], _loc->get_id() );
        int64_t        _norm   = cnode->get_cluster_normalization( lg_rank );
        if ( _norm > 0 )
        {
            _v->normalizeWithClusterCount( ( uint64_t )_norm );
        }
        Value* sum =   NULL;
        for ( cnode_id_t cid = 0; cid < cnode->num_children(); cid++ )
        {
            if ( cnode->get_child( cid )->isHidden() ) // ad as well inclusive value of hidden cnodes
            {
                sum      = get_sev_adv( cnode->get_child( cid ), CUBE_CALCULATE_INCLUSIVE, _loc, cube::CUBE_CALCULATE_INCLUSIVE  );
                ( *_v ) += sum;
                delete sum;
            }
        }
        if ( cnf == CUBE_CALCULATE_INCLUSIVE )
        {
            sum =   NULL;
            for ( cnode_id_t cid = 0; cid < cnode->num_children(); cid++ )
            {
                if ( cnode->get_child( cid )->isVisible() ) // add only visible children, coz the hidden have been added in excl value
                {
                    sum      = get_sev_adv( cnode->get_child( cid ), CUBE_CALCULATE_INCLUSIVE, _loc, cube::CUBE_CALCULATE_INCLUSIVE  );
                    ( *_v ) += sum;
                    delete sum;
                }
            }
        }
        ( *v ) += _v;
        delete _v;
    }
    cache->setCachedValue( v, cnode, cnf, sys, sf );
    return v;
}






Value*
ExclusiveMetric::get_sev_adv( Cnode* cnode, CalculationFlavour cnf )
{
    if ( adv_sev_mat == NULL )
    {
        return selectValueOnDataType( own_data_type );
    }
    if ( cnode == NULL )
    {
        return NULL;
    }



    Value* v = cache->getCachedValue( cnode, cnf );
    if ( v != NULL )
    {
        return v;
    }


    v = adv_sev_mat->getValue();



    for ( size_t i = 0; i < sysv.size(); i++ )
    {
        Thread*  _thrd        = sysv[ i ];
        Process* _proc        = _thrd->get_parent();
        int64_t  process_rank = _proc->get_rank();
        Value*   tmp          = adv_sev_mat->getValue( calltree_local_ids[ cnode->get_remapping_cnode( process_rank  )->get_id() ], _thrd->get_id() );
        int64_t  _norm        = cnode->get_cluster_normalization( process_rank );
        if ( _norm > 0 )
        {
            tmp->normalizeWithClusterCount( ( uint64_t )_norm );
        }
        ( *v ) += tmp;
        delete tmp;
    }
    Value* sum =   NULL;
    for ( cnode_id_t cid = 0; cid < cnode->num_children(); cid++ )
    {
        if ( cnode->get_child( cid )->isHidden() ) // ad as well inclusive value of hidden cnodes
        {
            sum     = get_sev_adv( cnode->get_child( cid ), CUBE_CALCULATE_INCLUSIVE );
            ( *v ) += sum;
            delete sum;
        }
    }
    if ( cnf == CUBE_CALCULATE_INCLUSIVE )
    {
        sum =   NULL;
        for ( cnode_id_t cid = 0; cid < cnode->num_children(); cid++ )
        {
            if ( cnode->get_child( cid )->isVisible() ) // add only visible children, coz the hidden have been added in excl value
            {
                sum     = get_sev_adv( cnode->get_child( cid ), CUBE_CALCULATE_INCLUSIVE );
                ( *v ) += sum;
                delete sum;
            }
        }
    }
    cache->setCachedValue( v,  cnode, cnf );
    return v;
}
