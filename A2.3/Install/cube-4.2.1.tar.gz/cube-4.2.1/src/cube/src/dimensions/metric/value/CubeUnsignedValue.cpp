/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeUnsignedValue.cpp
 * \brief Defines the methods of the "UnsignedValue".
 ************************************************/
#ifndef __UNSIGNED_VALUE_CPP
#define __UNSIGNED_VALUE_CPP

#include <sstream>
#include <cstring>
#include <string>
#include <iostream>
#include "CubeValues.h"

using namespace std;
using namespace cube;


UnsignedValue::UnsignedValue()
{
    isSingleValue = true;
    value.uValue  = 0;
}
// UnsignedValue::UnsignedValue( uint16_t uv )
// {
//     isSingleValue = true;
//     value.uValue  = ( uint32_t )uv;
// }
//
// UnsignedValue::UnsignedValue( int16_t uv )
// {
//     isSingleValue = true;
//     value.uValue  = ( uint32_t )uv;
// }

UnsignedValue::UnsignedValue( uint32_t uv )
{
    isSingleValue = true;
    value.uValue  = ( uint32_t )uv;
}

// // UnsignedValue::UnsignedValue( int32_t uv )
// // {
// //     isSingleValue = true;
// //     value.uValue  = ( uint32_t )uv;
// // }
// // UnsignedValue::UnsignedValue( uint64_t uv )
// // {
// //     isSingleValue = true;
// //     value.uValue  = ( uint32_t )uv;
// // }
// //
// // UnsignedValue::UnsignedValue( int64_t uv )
// // {
// //     isSingleValue = true;
// //     value.uValue  = ( uint32_t )uv;
// // }
// //
// //
// // UnsignedValue::UnsignedValue( double dv )
// // {
// //     isSingleValue = true;
// //     value.uValue  = ( uint32_t )dv;
// // }
// // UnsignedValue::UnsignedValue( char* cv )
// // {
// //     isSingleValue = true;
// //     memcpy( value.aValue, cv,  sizeof( uint32_t ) );
// // }
// //
// // unsigned
// // UnsignedValue::getSize()
// // {
// //     return sizeof( uint32_t );
// // }
// // double
// // UnsignedValue::getDouble()
// // {
// //     return ( double )value.uValue;
// // }
// //
// //
uint16_t
UnsignedValue::getUnsignedShort()
{
    return ( uint16_t )value.uValue;
}
int16_t
UnsignedValue::getSignedShort()
{
    return ( int16_t )value.uValue;
}

uint32_t
UnsignedValue::getUnsignedInt()
{
    return ( uint32_t )value.uValue;
}
int32_t
UnsignedValue::getSignedInt()
{
    return ( int32_t )value.uValue;
}


uint64_t
UnsignedValue::getUnsignedLong()
{
    return ( uint64_t )value.uValue;
}
int64_t
UnsignedValue::getSignedLong()
{
    return ( int64_t )value.uValue;
}


/**
 * As char will be returned just first char of the char representation
 */
char
UnsignedValue::getChar()
{
    return ( char )value.uValue;
}


/**
 * Creates the string representation of the value.
 */
string
UnsignedValue::getString()
{
    stringstream sstr;
    string       str;
    sstr << value.uValue;
    sstr >> str;
    return str;
}


// overloaded new operator
void*
UnsignedValue::operator new( size_t size )
{
    return ( void* )uint32_preallocator.Get();
}
// delete operator overloaded
void
UnsignedValue::operator delete( void* p )
{
    uint32_preallocator.Put( ( UnsignedValue* )p );
}



// /*
// /**
//  * Creates the copy and sets the value to 0.
//  */
// Value*
// UnsignedValue::clone()
// {
//     return new UnsignedValue( 0 );
// }
//
//
// /**
//  * Creates the copy.
//  */
// Value*
// UnsignedValue::copy()
// {
//     return new UnsignedValue( value.uValue );
// }
// */

/**
 * Sets the value from stream and returns the position in stream right after the value.
 */
char*
UnsignedValue::fromStream( char* cv )
{
    memcpy( value.aValue, cv, sizeof( uint32_t ) );
    return cv + sizeof( uint32_t );
}

/**
 * Saves the value in the stream and returns the position in stream right after the value.
 */
char*
UnsignedValue::toStream( char* cv )
{
    memcpy( cv, value.aValue,  sizeof( uint32_t ) );
    return cv + sizeof( uint32_t );
}
/*
   UnsignedValue
   UnsignedValue::operator+( const UnsignedValue& ch )
   {
    UnsignedValue tmp = *this;
    tmp.value.uValue += ch.value.uValue;
    return tmp;
   }

   UnsignedValue
   UnsignedValue::operator-( const UnsignedValue& ch )
   {
    UnsignedValue tmp = *this;
    tmp.value.uValue -= ch.value.uValue;
    return tmp;
   }

   void
   UnsignedValue::operator+=( Value* chval )
   {
    if ( chval == NULL )
    {
        return;
    }
    value.uValue += ( ( UnsignedValue* )chval )->value.uValue;
   }

   void
   UnsignedValue::operator-=( Value* chval )
   {
    if ( chval == NULL )
    {
        return;
    }
    value.uValue -= ( ( UnsignedValue* )chval )->value.uValue;
   }


   void
   UnsignedValue::operator*=( double dval )
   {
    double _d = ( double )value.uValue;
    _d          *= dval;
    value.uValue = ( uint32_t )_d;
   }

   void
   UnsignedValue::operator/=( double dval )
   {
    if ( dval == 0. )
    {
        cerr << "ERROR: DEVISION BY ZERO!" << endl;
    }
    double _d = ( double )value.uValue;
    _d          /= dval;
    value.uValue = ( uint32_t )dval;
   }
 */

void
UnsignedValue::operator=( double d )
{
// #warning LOST PRECISION
    value.uValue = ( uint32_t )d;
}
// /*
// void
// UnsignedValue::operator=( char c )
// {
//     value.uValue = ( uint32_t )c;
// }
//
//
// void
// UnsignedValue::operator=( uint16_t ui )
// {
//     value.uValue = ( uint32_t )ui;
// }
//
// void
// UnsignedValue::operator=( uint32_t i )
// {
//     value.uValue = ( uint32_t )i;
// }
//
// void
// UnsignedValue::operator=( uint64_t ul )
// {
// // #warning LOST PRECISION
//     value.uValue = ( uint64_t )ul;
// }
//
// void
// UnsignedValue::operator=( int16_t si )
// {
//     value.uValue = ( uint32_t )si;
// }
//
// void
// UnsignedValue::operator=( int32_t i )
// {
//     value.uValue = ( uint32_t )i;
// }
//
// void
// UnsignedValue::operator=( int64_t sl )
// {
// // #warning LOST PRECISION
//     value.uValue = ( uint32_t )sl;
// }
//
// void
// UnsignedValue::operator=( string v )
// {
//     stringstream sstr;
//     sstr << v;
//     sstr >> value.uValue;
// }
//

//
// UnsignedValue
// UnsignedValue::operator=( UnsignedValue v )
// {
// // #warning MISSED INTERFACE FOR LONG LONG
//     if ( &v == this )
//     {
//         return *this;
//     }
//     value.uValue = v.getUnsignedInt();
//     return *this;
// }
// */
void
UnsignedValue::operator=( Value* v )
{
    value.uValue = v->getUnsignedInt();
}




void
UnsignedValue::normalizeWithClusterCount( uint64_t N )
{
    value.uValue = ( uint32_t )( ( double )value.uValue / ( double )N );
}


#endif
