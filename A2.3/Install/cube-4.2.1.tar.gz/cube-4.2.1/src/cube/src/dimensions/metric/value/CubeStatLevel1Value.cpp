/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeStatLevel1Value.cpp
 * \brief Defines the methods of the "StatLevel1Value".
 ************************************************/
#ifndef __STAT_LEVEL1_VALUE_CPP
#define __STAT_LEVEL1_VALUE_CPP

#include <sstream>
#include <cstring>
#include <string>
#include <cmath>
#include <iostream>
#include "CubeValues.h"
#include "CubeError.h"

using namespace std;
using namespace cube;


StatLevel1Value::StatLevel1Value() : N( 1 ), Sum( 0. )
{
    isSingleValue = false;
}

StatLevel1Value::StatLevel1Value( uint32_t n,
                                  double   sum ) : N( n ), Sum( sum )
{
    isSingleValue = false;
}

// StatLevel1Value::StatLevel1Value( char* cv )
// {
//     isSingleValue = false;
//     UnsignedValue _n( cv );
//     DoubleValue   _sum( cv + _n.getSize() );
//     N   = _n;
//     Sum = _sum;
// }

unsigned
StatLevel1Value::getSize()
{
    return
        N.getSize() +
        Sum.getSize();
}

/**
 * Single value of StatLevel1Value is possible. It is the average value,.
 */
double
StatLevel1Value::getDouble()
{
    return Sum.getDouble() / N.getDouble();
}

/**
 * Single value of StatLevel1Value is possible. It is the average value, but casted to unsigned. Might be wrong, if average value is negative..
 */
uint16_t
StatLevel1Value::getUnsignedShort()
{
    return ( uint16_t )getDouble();
}

/**
 * Single value of StatLevel1Value is possible. It is the average value, but casted to unsigned.
 */
int16_t
StatLevel1Value::getSignedShort()
{
    return ( int16_t )getDouble();
}

/**
 * Single value of StatLevel1Value is possible. It is the average value, but casted to unsigned. Might be wrong, if average value is negative..
 */
uint32_t
StatLevel1Value::getUnsignedInt()
{
    return ( uint32_t )getDouble();
}

/**
 * Single value of StatLevel1Value is possible. It is the average value, but casted to unsigned.
 */
int32_t
StatLevel1Value::getSignedInt()
{
    return ( int32_t )getDouble();
}


/**
 * Single value of StatLevel1Value is possible. It is the average value, but casted to unsigned. Might be wrong, if average value is negative..
 */
uint64_t
StatLevel1Value::getUnsignedLong()
{
    return ( uint64_t )getDouble();
}

/**
 * Single value of StatLevel1Value is possible. It is the average value, but casted to unsigned.
 */
int64_t
StatLevel1Value::getSignedLong()
{
    return ( int64_t )getDouble();
}

/**
 * Char is meaningless representation of StatLevel1Value. Therefore an exception is thrown.
 */
char
StatLevel1Value::getChar()
{
    return ' ';
}



/**
 * Creates the string representation of the value.
 */
string
StatLevel1Value::getString()
{
// #warning " STRING representation of TAV Value should be developed"
    calcAvg();
    stringstream sstr;
    string       str;
    sstr << Average  << endl;
    sstr >> str;
    return str;
}

// overloaded new operator
void*
StatLevel1Value::operator new( size_t size )
{
    return ( void* )stat1_preallocator.Get();
}
// delete operator overloaded
void
StatLevel1Value::operator delete( void* p )
{
    stat1_preallocator.Put( ( StatLevel1Value* )p );
}


/**
 * Creates the copy and sets the value to 0.
 */
Value*
StatLevel1Value::clone()
{
    return new StatLevel1Value( 1, 0. );
}


/**
 * Creates the copy.
 */
Value*
StatLevel1Value::copy()
{
// #warning "Missing interface for unsigned long long"
    return new StatLevel1Value( N.getUnsignedInt(), Sum.getDouble() );
}


/**
 * Sets the value from stream and returns the position in stream right after the value.
 */
char*
StatLevel1Value::fromStream( char* cv )
{
    return Sum.fromStream( N.fromStream( cv ) );
}

/**
 * Saves the value in the stream and returns the position in stream right after the value.
 */
char*
StatLevel1Value::toStream( char* cv )
{
    return Sum.toStream( N.toStream( cv ) );
}

/**
 * Transforms the endianness in the stream according its layout
 */
char*
StatLevel1Value::transformStream( char* cv, SingleValueTrafo* trafo )
{
    return Sum.transformStream( N.transformStream( cv, trafo ), trafo );
}



/*

   StatLevel1Value
   StatLevel1Value::operator+( const StatLevel1Value& ch )
   {
   //         cout << " START PLUS " << endl;
    StatLevel1Value tmp = *this;
    tmp.N   = tmp.N + ch.N;
    tmp.Sum = tmp.Sum + ch.Sum;
   //         cout << " END PLUS " << endl;
    return tmp;
   }

   StatLevel1Value
   StatLevel1Value::operator-( const StatLevel1Value& ch )
   {
    StatLevel1Value tmp = *this;
    tmp.N   = tmp.N - ch.N;
    tmp.Sum = tmp.Sum - ch.Sum;
    return tmp;
   }
 */

void
StatLevel1Value::operator+=( Value* chval )
{
    if ( chval == NULL )
    {
        return;
    }
    N   += ( ( Value* )( &( ( ( StatLevel1Value* )chval )->N ) ) );
    Sum += ( ( Value* )( &( ( ( StatLevel1Value* )chval )->Sum ) ) );
}

void
StatLevel1Value::operator-=( Value* chval )
{
    if ( chval == NULL )
    {
        return;
    }
    N   -= ( ( Value* )( &( ( ( StatLevel1Value* )chval )->N ) ) );
    Sum -= ( ( Value* )( &( ( ( StatLevel1Value* )chval )->Sum ) ) );
}


void
StatLevel1Value::operator*=( double dval )
{
//     N *= dval; // Average gets multiplied, not the both values.
    Sum *= dval;
}

void
StatLevel1Value::operator/=( double dval )
{
    if ( dval == 0. )
    {
        cerr << "ERROR: DEVISION BY ZERO!" << endl;
    }
    else
    {
        Sum /= dval;     //Avarege gets devided, not both (then no action )
    }
}


void
StatLevel1Value::operator=( double d )
{
    throw RuntimeError( "Impossible to assign a  single double to StatLevel1Value" );
}
/*
   void
   StatLevel1Value::operator=( char c )
   {
    throw RuntimeError( "Impossible to assign a  single char to StatLevel1Value" );
   }


   void
   StatLevel1Value::operator=( uint16_t ui )
   {
    throw RuntimeError( "Impossible to assign a single unsigned  short int to StatLevel1Value" );
   }

   void
   StatLevel1Value::operator=( uint32_t i )
   {
    throw RuntimeError( "Impossible to assign a single unsigned  int to StatLevel1Value" );
   }

   void
   StatLevel1Value::operator=( uint64_t ul )
   {
    throw RuntimeError( "Impossible to assign a  single unswigned long long  int to StatLevel1Value" );
   }

   void
   StatLevel1Value::operator=( int16_t si )
   {
    throw RuntimeError( "Impossible to assign a  single signed  short int to StatLevel1Value" );
   }

   void
   StatLevel1Value::operator=( int32_t i )
   {
    throw RuntimeError( "Impossible to assign a single  int to StatLevel1Value" );
   }

   void
   StatLevel1Value::operator=( int64_t sl )
   {
    throw RuntimeError( "Impossible to assign a single signed long long  short int to StatLevel1Value" );
   }

   void
   StatLevel1Value::operator=( string v )
   {
   // #warning " StatLevel1Value method operator=(string) is not implemented yet"
    cerr << " StatLevel1Value method operator=(string) is not implemented yet" << endl;
   }



   StatLevel1Value
   StatLevel1Value::operator=( StatLevel1Value v )
   {
    if ( &v == this )
    {
        return *this;
    }
    N   = v.getN();
    Sum = v.getSum();
    return *this;
   }

 */

void
StatLevel1Value::operator=( Value* v )
{
// #warning "Error handling has to be done"
    throw RuntimeError( "Impossible to assign a singlegeneral Value to StatLevel1Value" );
}

// -------------------- PRIVATE METHODS- ------------------------

void
StatLevel1Value::calcAvg()
{
    uint32_t n  = N.getUnsignedInt();
    double   dn = N.getDouble();
    double   s  = Sum.getDouble();

    Average =  ( n == 0 ) ? s / ( dn + 1e-256 )  : s / dn;
}


void
StatLevel1Value::normalizeWithClusterCount( uint64_t _N )
{
    N.normalizeWithClusterCount( _N );
    Sum.normalizeWithClusterCount( _N );
}



#endif
