/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeHistogramValue.cpp
 * \brief   Defines the methods of the "HistogramValue".
 ************************************************/

#ifndef __HISTOGRAM_VALUE_CPP
#define __HISTOGRAM_VALUE_CPP

#include <sstream>
#include <cstring>
#include <string>
#include <iostream>
#include "CubeValues.h"

using namespace std;
using namespace cube;


HistogramValue::HistogramValue() : NDoublesValue( 0 )
{
    isSingleValue = false;
}

HistogramValue::HistogramValue( uint64_t n ) : NDoublesValue( n )
{
    isSingleValue = false;
}
HistogramValue::HistogramValue( uint64_t n,
                                double*  vals ) : NDoublesValue( n, vals )
{
    isSingleValue = false;
}


Value*
HistogramValue::clone()
{
    return new HistogramValue( N.getUnsignedLong() );
}

Value*
HistogramValue::copy()
{
    double*         tmp_d = new double[ N.getUnsignedLong() ];
    toStream( ( char* )tmp_d );
    HistogramValue* _return = new HistogramValue( N.getUnsignedLong(), tmp_d );
    delete[] tmp_d;
    return _return;
}


// overloaded new operato
void*
HistogramValue::operator new( size_t size )
{
    return ( void* )histogram_preallocator.Get();
}
// delete operator overloaded
void
HistogramValue::operator delete( void* p )
{
    histogram_preallocator.Put( ( HistogramValue* )p );
}

/*
   HistogramValue
   HistogramValue::operator+( const HistogramValue& ch )
   {
   //     HistogramValue tmp = *this; // ?????????? why this doesn't work???
    double*        tmp_d = new double[ N.getUnsignedLong() ];
    toStream( ( char* )tmp_d );
    HistogramValue tmp( N.getUnsignedLong(), tmp_d );

    for ( unsigned i = 0; i < N.getUnsignedLong(); i++ )
    {
        ( tmp.values[ i ] ) = ( tmp.values[ i ] ) + ( ch.values[ i ] );
    }
    delete tmp_d;
    return tmp;
   }

   HistogramValue
   HistogramValue::operator-( const HistogramValue& ch )
   {
   //     HistogramValue tmp = *this;// ?????????? why this doesn't work???
    double*        tmp_d = new double[ N.getUnsignedLong() ];
    toStream( ( char* )tmp_d );
    HistogramValue tmp( N.getUnsignedLong(), tmp_d );

    for ( unsigned i = 0; i < N.getUnsignedLong(); i++ )
    {
        ( ( tmp.values[ i ] ) ) = ( ( tmp.values[ i ] ) ) - ( ( ch.values[ i ] ) );
    }
    delete tmp_d;
    return tmp;
   }


   HistogramValue
   HistogramValue::operator=( HistogramValue comp )
   {
    if ( values != NULL )
    {
        delete[] values;
    }
    N      = comp.N.getUnsignedLong();
    values = new DoubleValue[ N.getUnsignedLong() ];

    double* tmp_d = new double[ N.getUnsignedLong() ];
    comp.toStream( ( char* )tmp_d );
    fromStream( ( char* )tmp_d );
    delete[] tmp_d;
    return *this;
   }
 */

void
HistogramValue::normalizeWithClusterCount( uint64_t _N )
{
    for ( unsigned i = 0; i < N.getUnsignedLong(); i++ )
    {
        values[ i ]->normalizeWithClusterCount( _N );
    }
}

#endif
