/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeNDoublesValue.cpp
 * \brief   Defines the methods of the "NDoublesValue".
 ************************************************/

#ifndef __NDOUBLES_VALUE_CPP
#define __NDOUBLES_VALUE_CPP

#include <sstream>
#include <cstring>
#include <string>
#include <iostream>
#include "CubeValues.h"

using namespace std;
using namespace cube;


NDoublesValue::NDoublesValue() : N( 0 )
{
    isSingleValue = false;

    values = NULL;
}

NDoublesValue::NDoublesValue( uint64_t n ) : N( n )
{
    isSingleValue = false;
    values        = NULL;

    if ( n == 0 )
    {
        return;
    }

    values = new DoubleValue *[ n ];
    for ( unsigned i = 0; i < n; i++ )
    {
        values[ i ] = new DoubleValue( 0 );
    }
}

NDoublesValue::NDoublesValue( uint64_t n,
                              double*  vals ) : N( n )
{
    isSingleValue = false;

    if ( n == 0 )
    {
        return;
    }

    values = new DoubleValue *[ n ];
    for ( unsigned i = 0; i < n; i++ )
    {
        values[ i ] = new DoubleValue( 0 );
    }
    this->fromStream( ( char* )vals );
}

/**
 * Create NDoublesValue from the stream assuming that real part is first, imaginary part next.
 */
/*
   NDoublesValue::NDoublesValue(char * cv)
   {
    DoubleValue re(cv);
    DoubleValue im(cv+re.getSize());

    r_value = re;
    i_value = im;

   }*/

// NDoublesValue::~NDoublesValue()


/*
   unsigned
   NDoublesValue::NDoublesValue::getSize()
   {
    return ( N.getUnsignedLong() == 0 ) ? 0 : N.getUnsignedLong() * ( values[ 0 ].getSize() );
   }
   double
   NDoublesValue::getDouble()
   {
   //     throw RuntimeError( "Impossible to return single double value from NDoublesValue" );
    return 0.;
   }*/

uint16_t
NDoublesValue::getUnsignedShort()
{
    return ( uint16_t )getDouble();
}
int16_t
NDoublesValue::getSignedShort()
{
    return ( int16_t )getDouble();
}
uint32_t
NDoublesValue::getUnsignedInt()
{
    return ( uint32_t )getDouble();
}
int32_t
NDoublesValue::getSignedInt()
{
    return ( int32_t )getDouble();
}

uint64_t
NDoublesValue::getUnsignedLong()
{
    return ( uint64_t )getDouble();
}
int64_t
NDoublesValue::getSignedLong()
{
    return ( int64_t )getDouble();
}



char
NDoublesValue::getChar()
{
    return ' ';
}

string
NDoublesValue::getString()
{
    string tmp = "(";
    for ( unsigned i = 0; i < N.getUnsignedLong(); i++ )
    {
        tmp += values[ i ]->getString();
        if ( i < ( N.getUnsignedLong() ) - 1 )
        {
            tmp += ", ";
        }
    }
    tmp += ")";
    return tmp;
}


DoubleValue
NDoublesValue::getValue( unsigned idx )
{
    if ( idx < N.getUnsignedLong() )
    {
        return *( values[ idx ] );
    }
    stringstream sstr;
    string       str1, str2;

    sstr <<  idx  << endl;
    sstr >> str1;
    sstr << N.getString() << endl;
    sstr >> str2;
    string str = "Index in NDoubleValue is out of boundary: ";
    throw RuntimeError( str + str1 + " of " + str2 );
}



/*
   Value*
   NDoublesValue::clone()
   {
    return new NDoublesValue( N.getUnsignedLong() );
   }*/

Value*
NDoublesValue::copy()
{
    double*        tmp_d = new double[ N.getUnsignedLong() ];
    toStream( ( char* )tmp_d );
    NDoublesValue* _return =  new NDoublesValue( N.getUnsignedLong(), tmp_d );
    delete[] tmp_d;
    return _return;
}


char*
NDoublesValue::fromStream( char* cv )
{
    char* stream = cv;
    for ( unsigned i = 0; i < N.getUnsignedLong(); i++ )
    {
        stream = values[ i ]->fromStream( stream );
    }
    return stream;
}
char*
NDoublesValue::toStream( char* cv )
{
    char* stream = cv;
    for ( unsigned i = 0; i < N.getUnsignedLong(); i++ )
    {
        stream = values[ i ]->toStream( stream );
    }
    return stream;
}

char*
NDoublesValue::transformStream( char* cv, SingleValueTrafo* trafo )
{
    char* stream = cv;
    for ( unsigned i = 0; i < N.getUnsignedLong(); i++ )
    {
        stream = values[ i ]->transformStream( stream, trafo );
    }
    return stream;
}


void*
NDoublesValue::operator new( size_t size )
{
    return ( void* )ndoubles_preallocator.Get();
}
// delete operator overloaded
void
NDoublesValue::operator delete( void* p )
{
    ndoubles_preallocator.Put( ( NDoublesValue* )p );
}

/*
   NDoublesValue
   NDoublesValue::operator+( const NDoublesValue& ch )
   {
   //     NDoublesValue tmp = *this; // ?????????? why this doesn't work???
    double*       tmp_d = new double[ N.getUnsignedLong() ];
    toStream( ( char* )tmp_d );
    NDoublesValue tmp( N.getUnsignedLong(), tmp_d );

    for ( unsigned i = 0; i < N.getUnsignedLong(); i++ )
    {
        ( ( tmp.values[ i ] ) ) = ( ( tmp.values[ i ] ) ) + ( ( ch.values[ i ] ) );
    }
    delete[] tmp_d;
    return tmp;
   }

   NDoublesValue
   NDoublesValue::operator-( const NDoublesValue& ch )
   {
   //     NDoublesValue tmp = *this; // ?????????? why this doesn't work???
    double*       tmp_d = new double[ N.getUnsignedLong() ];
    toStream( ( char* )tmp_d );
    NDoublesValue tmp( N.getUnsignedLong(), tmp_d );

    for ( unsigned i = 0; i < N.getUnsignedLong(); i++ )
    {
        ( ( tmp.values[ i ] ) ) = ( ( tmp.values[ i ] ) ) - ( ( ch.values[ i ] ) );
    }
    delete[] tmp_d;
    return tmp;
   }

 */
void
NDoublesValue::operator+=( Value* chval )
{
    if ( chval == NULL )
    {
        return;
    }
    for ( unsigned i = 0; i < N.getUnsignedLong(); i++ )
    {
        ( *( values[ i ] ) ) += ( ( Value* )( ( ( ( NDoublesValue* )chval )->values[ i ] ) ) );
    }
}

void
NDoublesValue::operator-=( Value* chval )
{
    if ( chval == NULL )
    {
        return;
    }
    for ( unsigned i = 0; i < N.getUnsignedLong(); i++ )
    {
        ( *( values[ i ] ) ) -= ( ( Value* )( ( ( ( NDoublesValue* )chval )->values[ i ] ) ) );
    }
}


void
NDoublesValue::operator*=( double dval )
{
    for ( unsigned i = 0; i < N.getUnsignedLong(); i++ )
    {
        ( *( values[ i ] ) ) *= dval;
    }
}

void
NDoublesValue::operator/=( double dval )
{
    if ( dval == 0. )
    {
        cerr << "ERROR: DEVISION BY ZERO!" << endl;
    }
    else
    {
        for ( unsigned i = 0; i < N.getUnsignedLong(); i++ )
        {
            ( *( values[ i ] ) ) /= dval;
        }
    }
}




void
NDoublesValue::operator=( double d )
{
    throw RuntimeError( "Impossible to assign a  single double value to NDoublesValue" );
}
/*
   void
   NDoublesValue::operator=( char c )
   {
    throw RuntimeError( "Impossible to assign a  single char value to NDoublesValue" );
   }


   void
   NDoublesValue::operator=( uint16_t us )
   {
    throw RuntimeError( "Impossible to assign a  single unsigned short value to NDoublesValue" );
   }


   void
   NDoublesValue::operator=( uint32_t ui )
   {
    throw RuntimeError( "Impossible to assign a  single unsigned integer value to NDoublesValue" );
   }

   void
   NDoublesValue::operator=( uint64_t ul )
   {
    throw RuntimeError( "Impossible to assign a  single unsigned long long value to NDoublesValue" );
   }



   void
   NDoublesValue::operator=( int16_t us )
   {
    throw RuntimeError( "Impossible to assign a  single signed short value to NDoublesValue" );
   }


   void
   NDoublesValue::operator=( int32_t ui )
   {
    throw RuntimeError( "Impossible to assign a  single signed integer value to NDoublesValue" );
   }

   void
   NDoublesValue::operator=( int64_t ul )
   {
    throw RuntimeError( "Impossible to assign a  single signed long long value to NDoublesValue" );
   }

   void
   NDoublesValue::operator=( string v )
   {
   // #warning " NDoublesValue method operator=(string) is implemented in not optimal way. FLEX+BISON would be better approach"

    string   str_values = v.substr( 1, v.size() - 1 );

    size_t   pos = str_values.find( "," ); // position of "live" in str
    unsigned i   = 0;
    while ( pos != string::npos )
    {
        string tmp = str_values.substr( 0, pos - 1 );
        if ( i < N.getUnsignedLong() )
        {
            ( ( values[ i ] ) ) = tmp;
        }
        str_values = str_values.substr( pos );
        i++;
    }
    if ( i < N.getUnsignedLong() )
    {
        ( ( values[ i ] ) ) = str_values;
    }
   }




   NDoublesValue
   NDoublesValue::operator=( NDoublesValue comp )
   {
    if ( values != NULL )
    {
        delete[] values;
    }
    N      = comp.N.getUnsignedLong();
    values = new DoubleValue[ N.getUnsignedLong() ];

    double* tmp_d = new double[ N.getUnsignedLong() ];
    comp.toStream( ( char* )tmp_d );
    fromStream( ( char* )tmp_d );
    delete[] tmp_d;
    return *this;
   }*/

void
NDoublesValue::operator=( Value* val )
{
    throw RuntimeError( "Impossible to assign a  single general value to NDoublesValue" );
}


void
NDoublesValue::normalizeWithClusterCount( uint64_t _N )
{
    for ( unsigned i = 0; i < N.getUnsignedLong(); i++ )
    {
        values[ i ]->normalizeWithClusterCount( _N );
    }
}

bool
NDoublesValue::isZero()
{
    for ( unsigned i = 0; i < N.getUnsignedLong(); i++ )
    {
        if ( !values[ i ]->isZero() )
        {
            return false;
        }
    }
    return true;
}


#endif
