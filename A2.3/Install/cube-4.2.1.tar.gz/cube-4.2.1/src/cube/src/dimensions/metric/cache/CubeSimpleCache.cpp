/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubeSimpleCache.cpp
 * \brief Imlementation of methods of the class SimpleCache
 */

#ifndef __SIMPLE_CACHE_CPP
#define __SIMPLE_CACHE_CPP

#include <iostream>
#include "CubeSimpleCache.h"


using namespace std;
using namespace cube;


SimpleCache::~SimpleCache()
{
    for ( map<simple_cache_key_t, Value*>::iterator iter = stn_container.begin(); iter != stn_container.end(); iter++ )
    {
        if ( ( *iter ).second != NULL )
        {
            ( ( *iter ).second )->Free(); // use Free call from Value to remove it "from memory" -> place it back to pool
        }
    }
    for ( map<simple_cache_key_t, Value*>::iterator iter = lg_container.begin(); iter != lg_container.end(); iter++ )
    {
        if ( ( *iter ).second != NULL )
        {
            ( ( *iter ).second )->Free(); // use Free call from Value to remove it "from memory" -> place it back to pool
        }
    }
    for ( map<simple_cache_key_t, Value*>::iterator iter = loc_container.begin(); iter != loc_container.end(); iter++ )
    {
        if ( ( *iter ).second != NULL )
        {
            ( ( *iter ).second )->Free(); // use Free call from Value to remove it "from memory" -> place it back to pool
        }
    }
    for ( map<simple_cache_key_t, Value*>::iterator iter = sum_container.begin(); iter != sum_container.end(); iter++ )
    {
        if ( ( *iter ).second != NULL )
        {
            ( ( *iter ).second )->Free(); // use Free call from Value to remove it "from memory" -> place it back to pool
        }
    }
}

Value*
SimpleCache::getCachedValue( Cnode* cnode, CalculationFlavour cf, Sysres* sysres, CalculationFlavour sf )
{
    if ( sysres != NULL && !sysres->isSystemTreeNode() )
    {
        return NULL;
    }
    simple_cache_key_t key = get_key( cnode, cf, sysres, sf );
    if ( key < 0 ) // do not cache ...
    {
        return NULL;
    }

    Value* _value = NULL;

    if ( sysres == NULL )
    {
        _value = sum_container[ key ];
    }
    else
    {
        if ( sysres->isSystemTreeNode() )
        {
            _value = stn_container[ key ];
        }
        if ( sysres->isLocationGroup() )
        {
            _value = lg_container[ key ];
        }
        if ( sysres->isLocation() )
        {
            _value = loc_container[ key ];
        }
    }



    return ( _value != NULL ) ? _value->copy() : _value; // pretend we do not
}

void
SimpleCache::setCachedValue( Value* value, Cnode* cnode, CalculationFlavour cf, Sysres* sysres, CalculationFlavour sf )
{
    if ( sysres != NULL && !sysres->isSystemTreeNode() )
    {
        return;
    }
    simple_cache_key_t key = get_key( cnode, cf, sysres, sf );
    if ( key < 0 ) // do not cache ...
    {
        return;
    }
    if ( sysres == NULL )
    {
        if ( sum_container[ key ] != NULL )
        {
            return;
        }
        sum_container[ key ] =  value->copy();
    }
    else
    {
        if ( sysres->isSystemTreeNode() )
        {
            if ( stn_container[ key ] != NULL )
            {
                return;
            }
            stn_container[ key ] = value->copy();
        }
        if ( sysres->isLocationGroup() )
        {
            if ( lg_container[ key ] != NULL )
            {
                return;
            }
            lg_container[ key ] = value->copy();
        }
        if ( sysres->isLocation() )
        {
            if ( loc_container[ key ] != NULL )
            {
                return;
            }
            loc_container[ key ] = value->copy();
        }
    }
}

simple_cache_key_t
SimpleCache::get_key( Cnode* cnode, CalculationFlavour cf, Sysres* sysres, CalculationFlavour sf )
{
    simple_cache_key_t Nc = 0;
    if ( cf == myf )
    {
        return ( simple_cache_key_t )( -1 );
    }

    if ( myf == CUBE_CALCULATE_EXCLUSIVE )
    {
        Nc = cnode->total_num_children();
    }
    else // mf == CUBE_CALCULATE_INCLUSIVE
    {
        Nc = cnode->num_children();
    }
    if ( sysres == NULL )
    {
        return 2 * cnode->get_id() + cf;
    }
    else
    {
        if ( Nc > treashold )
        {
            return 2 * ( 2 * cnode->get_id() + cf ) +  2 * sysres->get_id() + sf;
        }
        else
        {
            return ( simple_cache_key_t )( -1 );
        }
    }
}


#endif
