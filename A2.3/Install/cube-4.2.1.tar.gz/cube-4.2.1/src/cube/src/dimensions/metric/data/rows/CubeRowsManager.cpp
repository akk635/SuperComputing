/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubeRowsManager.cpp
 * \brief  Implements methods of a class RowsManager
 */

#ifndef CUBE_ROWS_MANAGER_CPP
#define CUBE_ROWS_MANAGER_CPP

#include "CubeRowTypes.h"
#include "CubeRowsManager.h"


using namespace cube;


/**
 * this methos is called, when new Cube should be created
 */
RowsManager::RowsManager( fileplace_t    DataPlace,
                          fileplace_t    IndexPlace,
                          IndexFormat,
                          rows_t*        _rows,
                          Row*           _row,
                          BasicStrategy* _strategy,
                          row_t          __no_row_pointer )
{
    row            = _row;
    rows           = _rows;
    no_row_pointer = __no_row_pointer;
    Value* _value = row->getValue();
    row_supplier = selectRowsSupplier( DataPlace, IndexPlace,  row->getRowSize(),  _value->getSize() );
    delete _value; // not needed anymore- after clone...

    strategy = _strategy;
    strategy->initialize( rows );
    row->setEndianess( row_supplier->getEndianess() ); // endianess detected in rowSupplier and passed to the row interface.
}





RowsManager::RowsManager( fileplace_t    DataPlace,
                          fileplace_t    IndexPlace,
                          rows_t*        _rows,
                          Row*           _row,
                          BasicStrategy* _strategy,
                          row_t          __no_row_pointer )
{
    row            = _row;
    rows           = _rows;
    no_row_pointer = __no_row_pointer;
    Value* _value = row->getValue();
    row_supplier = selectRowsSupplier( DataPlace, IndexPlace,  row->getRowSize(), _value->getSize() );
    delete _value;

    strategy = _strategy;
    strategy->initialize( rows );
    row->setEndianess( row_supplier->getEndianess() ); // endianess detected in rowSupplier and passed to the row interface.
}




RowsManager::~RowsManager()
{
    for ( rows_t::iterator iter = rows->begin(); iter != rows->end(); iter++ )
    {
        if ( ( *iter ).second != no_row_pointer )
        {
            delete[]  ( *iter ).second;
        }
    }
    rows->clear();

    delete row_supplier;
    row_supplier = NULL;
}

void
RowsManager::finalize()
{
    row_supplier->finalize();
}


void
RowsManager::dropAllRows()
{
    for ( rows_t::iterator iter = rows->begin(); iter != rows->end(); iter++ )
    {
        if ( ( *iter ).second == no_row_pointer )
        {
            continue;
        }
        row_supplier->dropRow( ( *iter ).second, ( *iter ).first );
        ( *rows )[ ( *iter ).first ] = NULL;
    }
    rows->clear();
}


void
RowsManager::provideRow( cnode_id_t& id, bool for_writing )
{
//     cout << " _1_ " << id << " " << for_writing << " " << false << endl;
    std::vector<cnode_id_t> _rows;
    _rows.push_back( id );
    provideRows( _rows, for_writing  );
}



void
RowsManager::provideRows( std::vector<cnode_id_t>& wanted_rows, bool for_writing )
{
    std::vector<cnode_id_t> _to_remove;
    strategy->needRows( wanted_rows, _to_remove );

    for ( std::vector<cnode_id_t>::iterator iter = _to_remove.begin(); iter < _to_remove.end(); iter++ )
    {
        if ( ( *rows )[ *iter ] != NULL && ( *rows )[ *iter ] != no_row_pointer )
        {
            row_supplier->dropRow( ( *rows )[ *iter ], *iter );
            rows->erase( *iter );
        }
    }
    for ( std::vector<cnode_id_t>::iterator iter = wanted_rows.begin(); iter < wanted_rows.end(); iter++ )
    {
//         cout << " ___ " << rows << endl;
//         cout << ( *rows )[ *iter ] << endl;
//         cout << " ___4_" << (*iter) << "_" << "_" <<(uint64_t)no_row_pointer << "_" << endl;
        if ( ( *rows )[ *iter ] == NULL || ( for_writing == true && ( *rows )[ *iter ] == no_row_pointer ) )
        {
            row_t _tmp = row_supplier->provideRow( *iter, for_writing  );
//             cout << " __ 5 " << (uint64_t)_tmp << endl;
            if ( _tmp == NULL )
            {
                continue;
            }
            row->correctEndianess( _tmp );
            ( *rows )[ *iter ] = _tmp;
        }
    }
}


void
RowsManager::dropRow( cnode_id_t& id )
{
    std::vector<cnode_id_t> _rows;
    _rows.push_back( id );
    dropRows( _rows );
}



void
RowsManager::dropRows( std::vector<cnode_id_t>& cids )
{
    vector<cnode_id_t > _to_remove;
    strategy->removeRows( cids, _to_remove );

    for ( std::vector<cnode_id_t>::iterator iter = _to_remove.begin(); iter < _to_remove.end(); iter++ )
    {
        if ( ( *rows )[ *iter ] != NULL && ( *rows )[ *iter ] != no_row_pointer )
        {
            row_supplier->dropRow( ( *rows )[ *iter ], *iter );
            rows->erase( *iter );
        }
    }
}

// ---------------------------------------------------------------------



RowsSupplier*
RowsManager::selectRowsSupplier( fileplace_t DataPlace,
                                 fileplace_t IndexPlace, uint64_t rowsize, uint64_t es )
{
    if ( RORowsSupplier::probe( DataPlace, IndexPlace ) )
    {
        return new RORowsSupplier( DataPlace, IndexPlace, rowsize, es );
    }
    else
    if ( ROZRowsSupplier::probe( DataPlace, IndexPlace ) )
    {
        return new ROZRowsSupplier( DataPlace, IndexPlace, rowsize, es );
    }
    else
    if ( WOZRowsSupplier::probe( DataPlace, IndexPlace ) )
    {
        return new WOZRowsSupplier( DataPlace, IndexPlace, rowsize, es );
    }
    else
    if ( WORowsSupplier::probe( DataPlace, IndexPlace ) )
    {
        return new WORowsSupplier( DataPlace, IndexPlace, rowsize, es );
    }
    throw CannotSelectRowSupplierError( "Error in selection of a rows supplier. \n"
                                        "This installation of cube doesn't support compressed cube files. \n"
                                        "Please recompile and reinstall CUBE using configure flags:\n"
                                        "      --with-compression=full|ro and --with-frontend-zlib=[path to zlib]" );
//    return NULL;
}

#endif
