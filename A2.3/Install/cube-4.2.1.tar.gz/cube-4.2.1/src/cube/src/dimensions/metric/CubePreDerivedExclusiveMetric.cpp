/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file CubePreDerivedExclusiveMetric.cpp
 * \brief Defines methods to calculate incl/exclusve values if the metric is defined as an expression. Expression gets calculated first, then the value gets aggregated.

 ********************************************/


#include <iostream>

#include "CubePreDerivedExclusiveMetric.h"

using namespace std;
using namespace cube;


PreDerivedExclusiveMetric::~PreDerivedExclusiveMetric()
{
}




// inclusive value and exclusive value in this metric are same
Value*
PreDerivedExclusiveMetric::get_sev_adv( Cnode* cnode, CalculationFlavour cnf, Sysres* sys, CalculationFlavour sf )
{
    if ( cnode == NULL )
    {
        return NULL;
    }
    if ( sys == NULL )
    {
        return NULL;
    }
    pre_calculation_preparation( cnode, sys );
    if ( init_evaluation != NULL )
    {
        init_evaluation->eval();
        delete init_evaluation;
        init_evaluation = NULL;
    }

    Value* cached_value = cache->getCachedValue( cnode, cnf, sys, sf );
    if ( cached_value != NULL )
    {
        return cached_value;
    }

    Value* v =  selectValueOnDataType( own_data_type );

    if ( evaluation != NULL )
    {
        if ( ( sys->isSystemTreeNode() || sys->isLocationGroup() ) && sf == cube::CUBE_CALCULATE_EXCLUSIVE )
        {
            post_calculation_cleanup();
            return v;
        }
        if ( sys->isSystemTreeNode() )
        {
            SystemTreeNode* _sys = ( SystemTreeNode* )sys;
            // first add values of all sub system nodes
            for ( unsigned i = 0; i < _sys->num_children(); i++ )
            {
                Value* _v = get_sev_adv( cnode, cnf, _sys->get_child( i ), cube::CUBE_CALCULATE_INCLUSIVE );
                ( *v ) += _v;
                delete _v;
            }
            // then add all values of all sub local groups
            for ( unsigned i = 0; i < _sys->num_groups(); i++ )
            {
                Value* _v = get_sev_adv( cnode, cnf, _sys->get_location_group( i ), cube::CUBE_CALCULATE_INCLUSIVE );
                ( *v ) += _v;
                delete _v;
            }
        }
        if ( sys->isLocationGroup() )
        {
            LocationGroup* _lg = ( LocationGroup* )sys;
            // first add values of all locations
            for ( unsigned i = 0; i < _lg->num_children(); i++ )
            {
                Value* _v = get_sev_adv( cnode, cnf, _lg->get_child( i ), cube::CUBE_CALCULATE_INCLUSIVE );
                ( *v ) += _v;
                delete _v;
            }
        }
        if ( sys->isLocation() )
        {
            Location* _loc   = ( Location* )sys;
            double    _value = evaluation->eval( cnode, CUBE_CALCULATE_EXCLUSIVE, _loc, sf );
            ( *v ) = _value;
            for ( cnode_id_t cid = 0; cid < cnode->num_children(); cid++ )
            {
                if ( cnode->get_child( cid )->isHidden() ) // ad as well inclusive value of hidden cnodes
                {
                    Value* _v = get_sev_adv(  cnode->get_child( cid ), CUBE_CALCULATE_INCLUSIVE, _loc, cube::CUBE_CALCULATE_INCLUSIVE   );
                    ( *v ) += _v;
                    delete _v;
                }
            }
            if ( cnf == CUBE_CALCULATE_INCLUSIVE )
            {
                for ( cnode_id_t cid = 0; cid < cnode->num_children(); cid++ )
                {
                    if ( cnode->get_child( cid )->isVisible() ) // add only visible children, coz the hidden have been added in excl value
                    {
                        Value* _v = get_sev_adv(  cnode->get_child( cid ), CUBE_CALCULATE_INCLUSIVE, _loc, cube::CUBE_CALCULATE_INCLUSIVE   );
                        ( *v ) += _v;
                        delete _v;
                    }
                }
            }
        }
    }
    cache->setCachedValue( v, cnode, cnf, sys, sf );
    post_calculation_cleanup();
    return v;
}


Value*
PreDerivedExclusiveMetric::get_sev_adv( Cnode* cnode, CalculationFlavour cnf )
{
    if ( cnode == NULL )
    {
        return NULL;
    }
    pre_calculation_preparation( cnode );
    if ( init_evaluation != NULL )
    {
        init_evaluation->eval();
        delete init_evaluation;
        init_evaluation = NULL;
    }
    Value* cached_value = cache->getCachedValue( cnode, cnf );
    if ( cached_value != NULL )
    {
        return cached_value;
    }

    Value* _v  =  selectValueOnDataType( own_data_type  );
    Value* __v = NULL;
    for ( std::vector<Thread*>::iterator iter = sysv.begin(); iter != sysv.end(); iter++ )
    {
        __v      = get_sev_adv( cnode, cnf, *iter, CUBE_CALCULATE_INCLUSIVE );
        ( *_v ) += __v;
        delete __v;
    }
    cache->setCachedValue( _v, cnode, cnf );
    post_calculation_cleanup();
    return _v;
}
