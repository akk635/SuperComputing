/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeStatLevel3Value.cpp
 * \brief Defines the methods of the "StatLevel3Value".
 ************************************************/
#ifndef __STAT_LEVEL3_VALUE_CPP
#define __STAT_LEVEL3_VALUE_CPP

#include <sstream>
#include <cstring>
#include <string>
#include <cmath>
#include <iostream>
#include "CubeValues.h"
#include "CubeError.h"

using namespace std;
using namespace cube;


StatLevel3Value::StatLevel3Value() : N( 1 ), Sum( 0. ), Sum2( 0. ), Sum3( 0. )
{
    isSingleValue = false;
}

StatLevel3Value::StatLevel3Value( uint32_t n,
                                  double   sum,
                                  double   sum2,
                                  double   sum3 ) : N( n ), Sum( sum ), Sum2( sum2 ), Sum3( sum3 )
{
    isSingleValue = false;
}

// StatLevel3Value::StatLevel3Value( char* cv )
// {
//     isSingleValue = false;
//
//     UnsignedValue _n( cv );
//     DoubleValue   _sum( cv + _n.getSize() );
//     DoubleValue   _sum2( cv + _n.getSize() + _sum.getSize() );
//     DoubleValue   _sum3( cv + _n.getSize() + _sum.getSize() + _sum2.getSize() );
//
//     N    = _n;
//     Sum  = _sum;
//     Sum2 = _sum2;
//     Sum3 = _sum3;
// }

unsigned
StatLevel3Value::getSize()
{
    return
        N.getSize() +
        Sum.getSize() +
        Sum2.getSize() +
        Sum3.getSize()

    ;
}

/**
 * Single value of StatLevel3Value is impossible. Therefore an exception is thrown.
 */
double
StatLevel3Value::getDouble()
{
    return 0.;
}

/**
 * Single value of StatLevel3Value is impossible. Therefore an exception is thrown.
 */
uint16_t
StatLevel3Value::getUnsignedShort()
{
    return ( uint16_t )getDouble();
}

/**
 * Single value of StatLevel3Value is impossible. Therefore an exception is thrown.
 */
int16_t
StatLevel3Value::getSignedShort()
{
    return ( int16_t )getDouble();
}



/**
 * Single value of StatLevel3Value is impossible. Therefore an exception is thrown.
 */
uint32_t
StatLevel3Value::getUnsignedInt()
{
    return ( uint32_t )getDouble();
}

/**
 * Single value of StatLevel3Value is impossible. Therefore an exception is thrown.
 */
int32_t
StatLevel3Value::getSignedInt()
{
    return ( int32_t )getDouble();
}





/**
 * Single value of StatLevel3Value is impossible. Therefore an exception is thrown.
 */
uint64_t
StatLevel3Value::getUnsignedLong()
{
    return ( uint64_t )getDouble();
}

/**
 * Single value of StatLevel3Value is impossible. Therefore an exception is thrown.
 */
int64_t
StatLevel3Value::getSignedLong()
{
    return ( int64_t )getDouble();
}





/**
 * Char is meaningless representation of StatLevel3Value. Therefore an exception is thrown.
 */
char
StatLevel3Value::getChar()
{
    return ' ';
}



/**
 * Creates the string representation of the value.
 */
string
StatLevel3Value::getString()
{
// #warning " STRING representation of TAV Value should be developed"
    calcAvgVarSkew();
    stringstream sstr;
    string       str;
    sstr << "(" << Average << "," << Variance << "," << Skewness << ")"  << endl;
    sstr >> str;
    return str;
}


// overloaded new operator
void*
StatLevel3Value::operator new( size_t size )
{
    return ( void* )stat3_preallocator.Get();
}
// delete operator overloaded
void
StatLevel3Value::operator delete( void* p )
{
    stat3_preallocator.Put( ( StatLevel3Value* )p );
}


/**
 * Creates the copy and sets the value to 0.
 */
Value*
StatLevel3Value::clone()
{
    return new StatLevel3Value( 1, 0., 0., 0. );
}


/**
 * Creates the copy.
 */
Value*
StatLevel3Value::copy()
{
// #warning "Missing interface for unsigned long long"
    return new StatLevel3Value( N.getUnsignedInt(), Sum.getDouble(), Sum2.getDouble(), Sum3.getDouble() );
}


/**
 * Sets the value from stream and returns the position in stream right after the value.
 */
char*
StatLevel3Value::fromStream( char* cv )
{
    return Sum3.fromStream(
               Sum2.fromStream(
                   Sum.fromStream(
                       N.fromStream( cv ) ) ) );
}

/**
 * Saves the value in the stream and returns the position in stream right after the value.
 */
char*
StatLevel3Value::toStream( char* cv )
{
    return Sum3.toStream(
               Sum2.toStream(
                   Sum.toStream(
                       N.toStream( cv ) ) ) );
}

/**
 * Transforms the endianness in the stream according its layout
 */
char*
StatLevel3Value::transformStream( char* cv, SingleValueTrafo* trafo )
{
    return Sum3.transformStream(
               Sum2.transformStream(
                   Sum.transformStream(
                       N.transformStream( cv, trafo ), trafo ), trafo ), trafo );
}



/*

   StatLevel3Value
   StatLevel3Value::operator+( const StatLevel3Value& ch )
   {
    StatLevel3Value tmp = *this;
    tmp.N    = tmp.N + ch.N;
    tmp.Sum  = tmp.Sum + ch.Sum;
    tmp.Sum2 = tmp.Sum2 + ch.Sum2;
    tmp.Sum3 = tmp.Sum3 + ch.Sum3;
    return tmp;
   }

   StatLevel3Value
   StatLevel3Value::operator-( const StatLevel3Value& ch )
   {
    StatLevel3Value tmp = *this;
    tmp.N    = tmp.N - ch.N;
    tmp.Sum  = tmp.Sum - ch.Sum;
    tmp.Sum2 = tmp.Sum2 - ch.Sum2;
    tmp.Sum3 = tmp.Sum3 - ch.Sum3;
    return tmp;
   }*/


void
StatLevel3Value::operator+=( Value* chval )
{
    if ( chval == NULL )
    {
        return;
    }
    N    += ( ( Value* )( &( ( ( StatLevel3Value* )chval )->N ) ) );
    Sum  += ( ( Value* )( &( ( ( StatLevel3Value* )chval )->Sum ) ) );
    Sum2 += ( ( Value* )( &( ( ( StatLevel3Value* )chval )->Sum2 ) ) );
    Sum3 += ( ( Value* )( &( ( ( StatLevel3Value* )chval )->Sum3 ) ) );
}

void
StatLevel3Value::operator-=( Value* chval )
{
    if ( chval == NULL )
    {
        return;
    }
    N    -= ( ( Value* )( &( ( ( StatLevel3Value* )chval )->N ) ) );
    Sum  -= ( ( Value* )( &( ( ( StatLevel3Value* )chval )->Sum ) ) );
    Sum2 -= ( ( Value* )( &( ( ( StatLevel3Value* )chval )->Sum2 ) ) );
    Sum3 -= ( ( Value* )( &( ( ( StatLevel3Value* )chval )->Sum3 ) ) );
}


void
StatLevel3Value::operator*=( double dval )
{
// multiplication with an scalas destroys the relation between variance and average.
//     N *= dval;  // only average scales
    Sum  *= dval;               // average scales
    Sum2 *= dval * dval;        // variance scales quadratically
    Sum3 *= dval * dval * dval; // skewness scales like cube
}

void
StatLevel3Value::operator/=( double dval )
{
    if ( dval == 0. )
    {
        cerr << "ERROR: DEVISION BY ZERO!" << endl;
    }
    else
    {
        N    /= dval;
        Sum  /= dval;
        Sum2 /= dval;
        Sum3 /= dval;
    }
}


void
StatLevel3Value::operator=( double d )
{
    throw RuntimeError( "Impossible to assign a  single double to StatLevel3Value" );
}
/*
   void
   StatLevel3Value::operator=( char c )
   {
    throw RuntimeError( "Impossible to assign a  single char to StatLevel3Value" );
   }


   void
   StatLevel3Value::operator=( uint16_t ui )
   {
    throw RuntimeError( "Impossible to assign a single unsigned  short int to StatLevel3Value" );
   }

   void
   StatLevel3Value::operator=( uint32_t i )
   {
    throw RuntimeError( "Impossible to assign a single unsigned  int to StatLevel3Value" );
   }

   void
   StatLevel3Value::operator=( uint64_t ul )
   {
    throw RuntimeError( "Impossible to assign a  single unswigned long long  int to StatLevel3Value" );
   }

   void
   StatLevel3Value::operator=( int16_t si )
   {
    throw RuntimeError( "Impossible to assign a  single signed  short int to StatLevel3Value" );
   }

   void
   StatLevel3Value::operator=( int32_t i )
   {
    throw RuntimeError( "Impossible to assign a single  int to StatLevel3Value" );
   }

   void
   StatLevel3Value::operator=( int64_t sl )
   {
    throw RuntimeError( "Impossible to assign a single signed long long  short int to StatLevel3Value" );
   }

   void
   StatLevel3Value::operator=( string v )
   {
   // #warning " StatLevel3Value method operator=(string) is not implemented yet"
    cerr << " StatLevel3Value method operator=(string) is not implemented yet" << endl;
   }



   StatLevel3Value
   StatLevel3Value::operator=( StatLevel3Value v )
   {
    if ( &v == this )
    {
        return *this;
    }
    N    = v.getN();
    Sum  = v.getSum();
    Sum2 = v.getSum2();
    Sum3 = v.getSum3();
    return *this;
   }
 */


void
StatLevel3Value::operator=( Value* v )
{
// #warning "Error handling has to be done"
    throw RuntimeError( "Impossible to assign a singlegeneral Value to StatLevel3Value" );
}

// -------------------- PRIVATE METHODS- ------------------------

void
StatLevel3Value::calcAvgVarSkew()
{
    uint32_t n  = N.getUnsignedInt();
    double   dn = N.getDouble();
    double   s  = Sum.getDouble();
    double   s2 = Sum2.getDouble();
    double   s3 = Sum3.getDouble();

    Average  =  ( n == 0 ) ? s / ( dn + 1e-256 )  : s / dn;
    Variance = ( n == 1 ) ? 0.             : 1. / ( dn - 1. ) * sqrt( s2 - 1. / dn * s * s );
    Skewness = ( n == 1 ) ? 0.             : ( 1. / dn *  ( s3 - 3. / dn * s2 * s + 2. / ( dn * dn ) * s * s * s ) ) / ( Variance * Variance * Variance );
}


void
StatLevel3Value::normalizeWithClusterCount( uint64_t _N )
{
    N.normalizeWithClusterCount( _N );
    Sum.normalizeWithClusterCount( _N );
    Sum2.normalizeWithClusterCount( _N );
    Sum3.normalizeWithClusterCount( _N );
}



#endif
