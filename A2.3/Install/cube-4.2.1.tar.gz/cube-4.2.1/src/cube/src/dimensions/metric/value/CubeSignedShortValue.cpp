/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeSignedShortValue.cpp
 * \brief   Defines the methods of the "SignedShortValue".
 ************************************************/

#ifndef __SIGNED_SHORT_VALUE_CPP
#define __SIGNED_SHORT_VALUE_CPP

#include <sstream>
#include <cstring>
#include <string>
#include "CubeValues.h"

using namespace std;
using namespace cube;


SignedShortValue::SignedShortValue()
{
    isSingleValue = true;

    value.isValue = 0;
}

// SignedShortValue::SignedShortValue( uint16_t uv )
// {
//     isSingleValue = true;
//
//     value.isValue = ( int16_t )uv;
// }

SignedShortValue::SignedShortValue( int16_t uv )
{
    isSingleValue = true;

    value.isValue = uv;
}

// SignedShortValue::SignedShortValue( uint32_t uv )
// {
//     isSingleValue = true;
//
//     value.isValue = ( int16_t )uv;
// }
//
// SignedShortValue::SignedShortValue( int32_t uv )
// {
//     isSingleValue = true;
//
//     value.isValue = ( int16_t )uv;
// }
//
// SignedShortValue::SignedShortValue( uint64_t uv )
// {
//     isSingleValue = true;
//
//     value.isValue = ( int16_t )uv;
// }
//
// SignedShortValue::SignedShortValue( int64_t uv )
// {
//     isSingleValue = true;
//
//     value.isValue = ( int16_t )uv;
// }
//
//
//
// SignedShortValue::SignedShortValue( double dv )
// {
//     isSingleValue = true;
//
//     value.isValue = ( int16_t )dv;
// }
// SignedShortValue::SignedShortValue( char* cv )
// {
//     isSingleValue = true;
//
//     memcpy( value.aValue, cv,  sizeof( int16_t ) );
// }
//
// unsigned
// SignedShortValue::getSize()
// {
//     return sizeof( uint16_t );
// }
// double
// SignedShortValue::getDouble()
// {
//     return ( double )value.isValue;
// }
//
//

uint16_t
SignedShortValue::getUnsignedShort()
{
    return ( uint16_t )value.isValue;
}
int16_t
SignedShortValue::getSignedShort()
{
    return value.isValue;
}


uint32_t
SignedShortValue::getUnsignedInt()
{
    return ( uint32_t )value.isValue;
}
int32_t
SignedShortValue::getSignedInt()
{
    return ( int32_t )value.isValue;
}


uint64_t
SignedShortValue::getUnsignedLong()
{
    return ( uint64_t )value.isValue;
}
int64_t
SignedShortValue::getSignedLong()
{
    return ( int64_t )value.isValue;
}

/**
 * As char will be returned just first char of the char representation
 */
char
SignedShortValue::getChar()
{
    return ( char )value.isValue;
}


/**
 * Creates the string representation of the value.
 */
string
SignedShortValue::getString()
{
    stringstream sstr;
    string       str;
    sstr << value.isValue;
    sstr >> str;
    return str;
}

// /*
// /**
//  * Creates the copy and sets the value to 0.
//  */
// Value*
// SignedShortValue::clone()
// {
//     return new SignedShortValue( 0 );
// }
//
//
// /**
//  * Creates the copy.
//  */
// Value*
// SignedShortValue::copy()
// {
//     return new SignedShortValue( value.isValue );
// }
// */

/**
 * Sets the value from stream and returns the position in stream right after the value.
 */
char*
SignedShortValue::fromStream( char* cv )
{
    memcpy( value.aValue, cv, sizeof( int16_t ) );
    return cv + sizeof( int16_t );
}


/**
 * Saves the value in the stream and returns the position in stream right after the value.
 */
char*
SignedShortValue::toStream( char* cv )
{
    memcpy( cv, value.aValue,  sizeof( int16_t ) );
    return cv + sizeof( int16_t );
}

/*
   SignedShortValue
   SignedShortValue::operator+( const SignedShortValue& ch )
   {
    SignedShortValue tmp = *this;
    tmp.value.isValue += ch.value.isValue;
    return tmp;
   }

   SignedShortValue
   SignedShortValue::operator-( const SignedShortValue& ch )
   {
    SignedShortValue tmp = *this;
    tmp.value.isValue -= ch.value.isValue;
    return tmp;
   }


   void
   SignedShortValue::operator+=( Value* chval )
   {
    if ( chval == NULL )
    {
        return;
    }
    value.isValue += ( ( SignedShortValue* )chval )->value.isValue;
   }

   void
   SignedShortValue::operator-=( Value* chval )
   {
    if ( chval == NULL )
    {
        return;
    }
    value.isValue -= ( ( SignedShortValue* )chval )->value.isValue;
   }


   void
   SignedShortValue::operator*=( double dval )
   {
    double _d = ( double )value.isValue;
    _d           *= dval;
    value.isValue = ( int16_t )_d;
   }

   void
   SignedShortValue::operator/=( double dval )
   {
    if ( dval == 0. )
    {
        cerr << "ERROR: DEVISION BY ZERO!" << endl;
    }
    double _d = ( double )value.isValue;
    _d            /= dval;
    value.isValue /= ( int16_t )_d;
   }


 */

// overloaded new operator
void*
SignedShortValue::operator new( size_t size )
{
    return ( void* )int16_preallocator.Get();
}
// delete operator overloaded
void
SignedShortValue::operator delete( void* p )
{
    int16_preallocator.Put( ( SignedShortValue* )p );
}

void
SignedShortValue::operator=( double d )
{
// #warning LOST PRECISION
    value.isValue = ( int16_t )d;
}
/*
   void
   SignedShortValue::operator=( char c )
   {
    value.isValue = ( int16_t )c;
   }


   void
   SignedShortValue::operator=( uint16_t us )
   {
    value.isValue = ( int16_t )us;
   }

   void
   SignedShortValue::operator=( int16_t s )
   {
   // #warning LOST PRECISION
    value.isValue = ( int16_t )s;
   }

   void
   SignedShortValue::operator=( uint32_t ui )
   {
   // #warning LOST PRECISION
    value.isValue = ( int16_t )ui;
   }

   void
   SignedShortValue::operator=( int32_t si )
   {
    value.isValue = ( int16_t )si;
   }

   void
   SignedShortValue::operator=( uint64_t li )
   {
   // #warning LOST PRECISION
    value.isValue = ( int16_t )li;
   }

   void
   SignedShortValue::operator=( int64_t sl )
   {
   // #warning LOST PRECISION
    value.isValue = ( int16_t )sl;
   }

   void
   SignedShortValue::operator=( string v )
   {
    stringstream sstr;
    sstr << v;
    sstr >> value.isValue;
   }



   SignedShortValue
   SignedShortValue::operator=( SignedShortValue v )
   {
   // #warning MISSED INTERFACE FOR SHORT
   // #warning LOST PRECISION
    if ( &v == this )
    {
        return *this;
    }
    value.isValue = v.getSignedShort();
    return *this;
   }*/

void
SignedShortValue::operator=( Value* v )
{
    value.isValue = v->getSignedShort();
}

void
SignedShortValue::normalizeWithClusterCount( uint64_t N )
{
    value.isValue = ( int16_t )( ( double )value.isValue / ( double )N );
}


#endif
