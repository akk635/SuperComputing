/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeMinDoubleValue.cpp
 * \brief   Defines the methods of the "MinDoubleValue".
 ************************************************/

#ifndef __MIN_DOUBLE_VALUE_CPP
#define __MIN_DOUBLE_VALUE_CPP

#include <cstring>
#include <iomanip>
#include <string>
#include <sstream>
#include <iostream>
#include <algorithm>
#include "CubeValues.h"

using namespace std;
using namespace cube;

/*
   MinDoubleValue
   MinDoubleValue::operator+( const MinDoubleValue& ch )
   {
    MinDoubleValue tmp = *this;
    tmp.value.dValue = min( tmp.value.dValue,  ch.value.dValue );
    return tmp;
   }

   MinDoubleValue
   MinDoubleValue::operator-( const MinDoubleValue& ch )
   {
    MinDoubleValue tmp = *this;
    tmp.value.dValue = max( tmp.value.dValue,  ch.value.dValue );
    return tmp;
   }


   void
   MinDoubleValue::operator+=( Value* chval )
   {
    if ( chval == NULL )
    {
        return;
    }
    value.dValue = min( value.dValue, ( ( DoubleValue* )chval )->getDouble() );
   }

   void
   MinDoubleValue::operator-=( Value* chval )
   {
    if ( chval == NULL )
    {
        return;
    }
    value.dValue = max( value.dValue, ( ( DoubleValue* )chval )->getDouble() );
   }*/

/*
   MinDoubleValue
   MinDoubleValue::operator=( MinDoubleValue v )
   {
    if ( &v == this )
    {
        return *this;
    }
    value.dValue = v.getDouble();
    return *this;
   }*/
/*
   Value*
   MinDoubleValue::clone()
   {
    return new MinDoubleValue();
   }*/


string
MinDoubleValue::getString()
{
    stringstream sstr;
    string       str;
    if ( value.dValue != DBL_MAX )
    {
        sstr <<  setprecision( 12 ) << value.dValue;
    }
    else
    {
        sstr <<  "-";
    }

    sstr >> str;
    return str;
}

// overloaded new operator
void*
MinDoubleValue::operator new( size_t size )
{
    return ( void* )min_double_preallocator.Get();
}
// delete operator overloaded
void
MinDoubleValue::operator delete( void* p )
{
    min_double_preallocator.Put( ( MinDoubleValue* )p );
}

/*

   void MinDoubleValue::operator=(string v)
   {
    (DoubleValue)(*this) = v;
   }*/
void
MinDoubleValue::normalizeWithClusterCount( uint64_t N )
{
}


#endif
