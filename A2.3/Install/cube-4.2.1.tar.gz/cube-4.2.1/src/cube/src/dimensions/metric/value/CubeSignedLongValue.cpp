/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeSignedLongValue.cpp
 * \brief   Defines the methods of the "SignedLongValue".
 ************************************************/

#ifndef __SIGNED_LONG_VALUE_CPP
#define __SIGNED_LONG_VALUE_CPP

#include <sstream>
#include <iostream>
#include <cstring>
#include <string>
#include "CubeValues.h"

using namespace std;
using namespace cube;


SignedLongValue::SignedLongValue()
{
    isSingleValue = true;

    value.ilValue = 0;
}
/*
   SignedLongValue::SignedLongValue( uint16_t uv )
   {
    isSingleValue = true;

    value.ilValue = ( int64_t )uv;
   }

   SignedLongValue::SignedLongValue( int16_t uv )
   {
    isSingleValue = true;

    value.ilValue = ( int64_t )uv;
   }

   SignedLongValue::SignedLongValue( uint32_t uv )
   {
    isSingleValue = true;

    value.ilValue = ( int64_t )uv;
   }

   SignedLongValue::SignedLongValue( int32_t uv )
   {
    isSingleValue = true;

    value.ilValue = ( int64_t )uv;
   }


   SignedLongValue::SignedLongValue( uint64_t uv )
   {
    isSingleValue = true;

    value.ilValue = ( int64_t )uv;
   }
 */
SignedLongValue::SignedLongValue( int64_t uv )
{
    isSingleValue = true;

    value.ilValue = ( int64_t )uv;
}

// /*
// SignedLongValue::SignedLongValue( double dv )
// {
//     isSingleValue = true;
//
//     value.ilValue = ( int64_t )dv;
// }
// SignedLongValue::SignedLongValue( char* cv )
// {
//     isSingleValue = true;
//
//     memcpy( value.aValue, cv,  sizeof( int64_t ) );
// }
//
// unsigned
// SignedLongValue::getSize()
// {
//     return sizeof( int64_t );
// }
// double
// SignedLongValue::getDouble()
// {
//     return ( double )value.ilValue;
// }
//
//

uint16_t
SignedLongValue::getUnsignedShort()
{
    return ( uint16_t )value.ilValue;
}

int16_t
SignedLongValue::getSignedShort()
{
    return ( int16_t )value.ilValue;
}

uint32_t
SignedLongValue::getUnsignedInt()
{
    return ( uint32_t )value.ilValue;
}

int32_t
SignedLongValue::getSignedInt()
{
    return ( int32_t )value.ilValue;
}

uint64_t
SignedLongValue::getUnsignedLong()
{
    return ( uint64_t )value.ilValue;
}

int64_t
SignedLongValue::getSignedLong()
{
    return value.ilValue;
}



/**
 * As char will be returned just first char of the char representation
 */
char
SignedLongValue::getChar()
{
    return ( char )value.ilValue;
}

/**
 * Creates the string representation of the value.
 */
string
SignedLongValue::getString()
{
    stringstream sstr;
    string       str;
    sstr << value.ilValue;
    sstr >> str;
    return str;
}


// /*
// /**
//  * Creates the copy and sets the value to 0.
//  */
// Value*
// SignedLongValue::clone()
// {
//     return new SignedLongValue( 0 );
// }
//
// /**
//  * Creates the copy. Missing constructor for signed long. Has to be added.
//  */
// Value*
// SignedLongValue::copy()
// {
// // #warning "lost precision!"
//     return new SignedLongValue( value.ilValue );
// }
// */

/**
 * Sets the value from stream and returns the position in stream right after the value.
 */
char*
SignedLongValue::fromStream( char* cv )
{
    memcpy( value.aValue, cv, sizeof( int64_t ) );
    return cv + sizeof( int64_t );
}

/**
 * Saves the value in the stream and returns the position in stream right after the value.
 */
char*
SignedLongValue::toStream( char* cv )
{
    memcpy( cv, value.aValue, sizeof( int64_t ) );
    return cv + sizeof( int64_t );
}


// overloaded new operator
void*
SignedLongValue::operator new( size_t size )
{
    return ( void* )int64_preallocator.Get();
}
// delete operator overloaded
void
SignedLongValue::operator delete( void* p )
{
    int64_preallocator.Put( ( SignedLongValue* )p );
}

// // /*
// //
// // SignedLongValue
// // SignedLongValue::operator+( const SignedLongValue& ch )
// // {
// //     SignedLongValue tmp = *this;
// //     tmp.value.ilValue += ch.value.ilValue;
// //     return tmp;
// // }
// //
// // SignedLongValue
// // SignedLongValue::operator-( const SignedLongValue& ch )
// // {
// //     SignedLongValue tmp = *this;
// //     tmp.value.ilValue -= ch.value.ilValue;
// //     return tmp;
// // }
// //
// //
// // void
// // SignedLongValue::operator+=( Value* chval )
// // {
// //     if ( chval == NULL )
// //     {
// //         return;
// //     }
// //     value.ilValue += ( ( SignedLongValue* )chval )->value.ilValue;
// // }
// //
// // void
// // SignedLongValue::operator-=( Value* chval )
// // {
// //     if ( chval == NULL )
// //     {
// //         return;
// //     }
// //     value.ilValue -= ( ( SignedLongValue* )chval )->value.ilValue;
// // }
// //
// //
// //
// //
// // void
// // SignedLongValue::operator*=( double dval )
// // {
// //     double _d = ( double )value.ilValue;
// //     _d           *= dval;
// //     value.ilValue = ( int64_t )_d;
// // }
// //
// // void
// // SignedLongValue::operator/=( double dval )
// // {
// //     if ( dval == 0. )
// //     {
// //         cerr << "ERROR: DEVISION BY ZERO!" << endl;
// //     }
// //     double _d = ( double )value.ilValue;
// //     _d           /= dval;
// //     value.ilValue = ( int64_t )dval;
// // }
// //
// //
// //
// //
// //
// //
void
SignedLongValue::operator=( double d )
{
    value.ilValue = ( int64_t )d;
}
// //
// // void
// // SignedLongValue::operator=( char c )
// // {
// //     value.ilValue = ( int64_t )c;
// // }
// //
// //
// // void
// // SignedLongValue::operator=( uint16_t ui )
// // {
// //     value.ilValue = ( int64_t )ui;
// // }
// //
// // void
// // SignedLongValue::operator=( uint32_t i )
// // {
// //     value.ilValue = ( int64_t )i;
// // }
// //
// // void
// // SignedLongValue::operator=( uint64_t ul )
// // {
// //     value.ilValue = ( int64_t )ul;
// // }
// //
// // void
// // SignedLongValue::operator=( int16_t si )
// // {
// //     value.ilValue = ( int16_t )si;
// // }
// //
// // void
// // SignedLongValue::operator=( int32_t i )
// // {
// //     value.ilValue = ( int64_t )i;
// // }
// //
// // void
// // SignedLongValue::operator=( int64_t sl )
// // {
// //     value.ilValue = ( int64_t )sl;
// // }
// //
// // void
// // SignedLongValue::operator=( string v )
// // {
// //     stringstream sstr;
// //     sstr << v;
// //     sstr >> value.ilValue;
// // }
// //
// //
// //
void
SignedLongValue::operator=( Value* v )
{
    value.ilValue = v->getSignedLong();
}
// //
// //
// // SignedLongValue
// // SignedLongValue::operator=( SignedLongValue v )
// // {
// //     if ( &v == this )
// //     {
// //         return *this;
// //     }
// //     value.ilValue = v.getSignedLong();
// //     return *this;
// // }*/


void
SignedLongValue::normalizeWithClusterCount( uint64_t N )
{
    value.ilValue = ( int64_t )( ( double )value.ilValue / ( double )N );
}


#endif
