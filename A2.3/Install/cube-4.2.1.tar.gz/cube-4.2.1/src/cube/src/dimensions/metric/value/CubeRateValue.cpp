/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeRateValue.cpp
 * \brief   Defines the methods of the "RateValue".
 ************************************************/

#ifndef __RATE_VALUE_CPP
#define __RATE_VALUE_CPP

#include <sstream>
#include <cstring>
#include <string>
#include <iostream>
#include <iomanip>
#include "CubeValues.h"

using namespace std;
using namespace cube;


RateValue::RateValue() : main_value( 0. ), duratio_value( 0. )
{
    isSingleValue = true;
}

// RateValue::RateValue( uint64_t main_uv,
//                       uint64_t duratio_uv ) : main_value( main_uv ), duratio_value( duratio_uv )
// {
//     isSingleValue = true;
// }
//
// RateValue::RateValue( int64_t main_uv,
//                       int64_t duratio_uv ) : main_value( main_uv ), duratio_value( duratio_uv )
// {
//     isSingleValue = true;
// }


RateValue::RateValue( double main_dv,
                      double duratio_dv ) : main_value( main_dv ), duratio_value( duratio_dv )
{
    isSingleValue = true;
}
// /*
// /**
//  * Create RateValue from the stream assuming that real part is first, imaginary part next.
//  */
// RateValue::RateValue( char* cv )
// {
//     isSingleValue = true;
//
//     DoubleValue mv( cv );
//     DoubleValue dv( cv + mv.getSize() );
//
//     main_value    = mv;
//     duratio_value = dv;
// }
//
//
// unsigned
// RateValue::RateValue::getSize()
// {
//     return main_value.getSize() + duratio_value.getSize();
// }
// double
// RateValue::getDouble()
// {
//     double m_tmp = main_value.getDouble();
//     double d_tmp = duratio_value.getDouble();
//
//     if ( d_tmp == 0. )
//     {
//         return ( m_tmp < 0 ) ? -DBL_MAX : DBL_MAX;
//     }
//     else
//     {
//         return m_tmp / d_tmp;
//     }
// }
// */


uint16_t
RateValue::getUnsignedShort()
{
    return ( uint16_t )getDouble();
}
int16_t
RateValue::getSignedShort()
{
    return ( int16_t )getDouble();
}

uint32_t
RateValue::getUnsignedInt()
{
    return ( uint32_t )getDouble();
}
int32_t
RateValue::getSignedInt()
{
    return ( int32_t )getDouble();
}

uint64_t
RateValue::getUnsignedLong()
{
    return ( uint64_t )getDouble();
}
int64_t
RateValue::getSignedLong()
{
    return ( int64_t )getDouble();
}

char
RateValue::getChar()
{
    return ' ';
}

string
RateValue::getString()
{
    stringstream sstr;
    string       str;
    sstr <<  setprecision( 12 ) << getDouble();
    sstr >> str;


    string tmp = str + "[(" + main_value.getString() + ")";
    tmp += "/(";
    tmp += duratio_value.getString();
    tmp += ")]";
    return tmp;
}
/*
   Value*
   RateValue::clone()
   {
    return new RateValue( 0., 0. );
   }

   Value*
   RateValue::copy()
   {
    return new RateValue( main_value.getDouble(), duratio_value.getDouble() );
   }*/


char*
RateValue::fromStream( char* cv )
{
    return duratio_value.fromStream( main_value.fromStream( cv ) );
}
char*
RateValue::toStream( char* cv )
{
//     cout << " FRO MSTREAM" << endl;
    return duratio_value.toStream( main_value.toStream( cv ) );
}

char*
RateValue::transformStream( char* stream, SingleValueTrafo* trafo )
{
//     cout << " COMLEX VALUE TRANSFORM STREAM " << (void *)stream << endl;
    return duratio_value.transformStream( main_value.transformStream( stream, trafo ), trafo );
}

// overloaded new operator
void*
RateValue::operator new( size_t size )
{
    return ( void* )rate_preallocator.Get();
}
// delete operator overloaded
void
RateValue::operator delete( void* p )
{
    rate_preallocator.Put( ( RateValue* )p );
}


/*
   RateValue
   RateValue::operator+( const RateValue& ch )
   {
    RateValue tmp = *this;
    tmp.main_value    = tmp.main_value + ch.main_value;
    tmp.duratio_value = tmp.duratio_value + ch.duratio_value;
    return tmp;
   }

   RateValue
   RateValue::operator-( const RateValue& ch )
   {
    RateValue tmp = *this;
    tmp.main_value    = tmp.main_value - ch.main_value;
    tmp.duratio_value = tmp.duratio_value - ch.duratio_value;
    return tmp;
   }


   void
   RateValue::operator+=( Value* chval )
   {
    if ( chval == NULL )
    {
        return;
    }
    main_value    += ( ( Value* )( &( ( ( RateValue* )chval )->main_value ) ) );
    duratio_value += ( ( Value* )( &( ( ( RateValue* )chval )->duratio_value ) ) );
   }

   void
   RateValue::operator-=( Value* chval )
   {
    if ( chval == NULL )
    {
        return;
    }
    main_value    -= ( ( Value* )( &( ( ( RateValue* )chval )->main_value ) ) );
    duratio_value -= ( ( Value* )( &( ( ( RateValue* )chval )->duratio_value ) ) );
   }


   void
   RateValue::operator*=( double dval )
   {
    main_value    *= dval;
    duratio_value *= dval;
   }

   void
   RateValue::operator/=( double dval )
   {
    if ( dval == 0. )
    {
        cerr << "ERROR: DEVISION BY ZERO!" << endl;
        dval = DBL_MIN;
    }
    main_value    /= dval;
    duratio_value /= dval;
   }

 */


void
RateValue::operator=( double d )
{
    throw RuntimeError( "Impossible to assign a single double value to RateValue" );
}
/*
   void
   RateValue::operator=( char c )
   {
    throw RuntimeError( "Impossible to assign a single char value to RateValue" );
   }


   void
   RateValue::operator=( uint16_t us )
   {
    throw RuntimeError( "Impossible to assign a single unsigned short value to RateValue" );
   }


   void
   RateValue::operator=( uint32_t ui )
   {
    throw RuntimeError( "Impossible to assign a single unsigned integer value to RateValue" );
   }

   void
   RateValue::operator=( uint64_t ul )
   {
    throw RuntimeError( "Impossible to assign a single unsigned long long  value to RateValue" );
   }



   void
   RateValue::operator=( int16_t us )
   {
    throw RuntimeError( "Impossible to assign a single signed short  value to RateValue" );
   }


   void
   RateValue::operator=( int32_t ui )
   {
    throw RuntimeError( "Impossible to assign a single signed integer value to RateValue" );
   }

   void
   RateValue::operator=( int64_t ul )
   {
    throw RuntimeError( "Impossible to assign a single signed long long value to RateValue" );
   }

   void
   RateValue::operator=( string v )
   {
   //     cout << " WHAT THE F!" << endl;
   // #warning " RateValue method operator=(string) is implemented in not optimal way. FLEX+BISON would be better approach"
    size_t pos = v.find( ")/(" );    // position of "live" in str
    main_value = v.substr( 1, pos - 1 );

    string istr    = v.substr( pos + 3 );
    size_t end_pos = istr.find( ")" );
    duratio_value = istr.substr( 0, end_pos );
   }


   RateValue
   RateValue::operator=( RateValue comp )
   {
    main_value    = comp.getMainValue();
    duratio_value = comp.getDuratioValue();
    return *this;
   }
 */


void
RateValue::operator=( Value* val )
{
    throw RuntimeError( "Impossible to assign a single general value to RateValue" );
}



void
RateValue::normalizeWithClusterCount( uint64_t N )
{
    main_value.normalizeWithClusterCount( N );
    duratio_value.normalizeWithClusterCount( N );
}


#endif
