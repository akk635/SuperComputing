/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
 *
 * \file CubeUnsignedShortValue.cpp
 * \brief  Defines the methods of the "UnsignedShortValue".
 ************************************************/
#ifndef __UNSIGNED_SHORT_VALUE_CPP
#define __UNSIGNED_SHORT_VALUE_CPP

#include <sstream>
#include <cstring>
#include <string>
#include "CubeValues.h"

using namespace std;
using namespace cube;



UnsignedShortValue::UnsignedShortValue()
{
    isSingleValue = true;
    value.usValue = 0;
}
UnsignedShortValue::UnsignedShortValue( uint16_t uv )
{
    isSingleValue = true;
    value.usValue = ( uint16_t )uv;
}
// UnsignedShortValue::UnsignedShortValue( int16_t uv )
// {
//     isSingleValue = true;
//     value.usValue = ( uint16_t )uv;
// }
//
// UnsignedShortValue::UnsignedShortValue( uint32_t uv )
// {
//     isSingleValue = true;
//     value.usValue = ( uint16_t )uv;
// }
// UnsignedShortValue::UnsignedShortValue( int32_t uv )
// {
//     isSingleValue = true;
//     value.usValue = ( uint16_t )uv;
// }
// UnsignedShortValue::UnsignedShortValue( uint64_t uv )
// {
//     isSingleValue = true;
//     value.usValue = ( uint16_t )uv;
// }
// UnsignedShortValue::UnsignedShortValue( int64_t uv )
// {
//     isSingleValue = true;
//     value.usValue = ( uint16_t )uv;
// }
//
//
//
//
//
// UnsignedShortValue::UnsignedShortValue( double dv )
// {
//     isSingleValue = true;
//     value.usValue = ( uint16_t )dv;
// }
// UnsignedShortValue::UnsignedShortValue( char* cv )
// {
//     isSingleValue = true;
//     memcpy( value.aValue, cv,  sizeof( uint16_t ) );
// }
//
/*unsigned
   UnsignedShortValue::getSize()
   {
    return sizeof( uint16_t );
   }
   double
   UnsignedShortValue::getDouble()
   {
    return ( double )value.usValue;
   }
 */

uint16_t
UnsignedShortValue::getUnsignedShort()
{
    return ( uint16_t )value.usValue;
}

int16_t
UnsignedShortValue::getSignedShort()
{
    return ( int16_t )value.usValue;
}


uint32_t
UnsignedShortValue::getUnsignedInt()
{
    return ( uint32_t )value.usValue;
}

int32_t
UnsignedShortValue::getSignedInt()
{
    return ( int32_t )value.usValue;
}



uint64_t
UnsignedShortValue::getUnsignedLong()
{
    return ( uint64_t )value.usValue;
}

int64_t
UnsignedShortValue::getSignedLong()
{
    return ( int64_t )value.usValue;
}


/**
 * As char will be returned just first char of the char representation
 */
char
UnsignedShortValue::getChar()
{
    return value.aValue[ 0 ];
}

/**
 * Creates the string representation of the value.
 */
string
UnsignedShortValue::getString()
{
    stringstream sstr;
    string       str;
    sstr << value.usValue;
    sstr >> str;
    return str;
}
// /*
// /**
//  * Creates the copy and sets the value to 0.
//  */
// Value*
// UnsignedShortValue::clone()
// {
//     return new UnsignedShortValue( 0 );
// }
//
//
// /**
//  * Creates the copy.
//  */
// Value*
// UnsignedShortValue::copy()
// {
//     return new UnsignedShortValue( value.usValue );
// }*/

/**
 * Sets the value from stream and returns the position in stream right after the value.
 */
char*
UnsignedShortValue::fromStream( char* cv )
{
    memcpy( value.aValue, cv, sizeof( uint16_t ) );
    return cv + sizeof( uint16_t );
}

/**
 * Saves the value in the stream and returns the position in stream right after the value.
 */
char*
UnsignedShortValue::toStream( char* cv )
{
    memcpy( cv, value.aValue, sizeof( uint16_t ) );
    return cv + sizeof( uint16_t );
}

// /*
// UnsignedShortValue
// UnsignedShortValue::operator+( const UnsignedShortValue& ch )
// {
//     UnsignedShortValue tmp = *this;
//     tmp.value.usValue += ch.value.usValue;
//     return tmp;
// }
//
// UnsignedShortValue
// UnsignedShortValue::operator-( const UnsignedShortValue& ch )
// {
//     UnsignedShortValue tmp = *this;
//     tmp.value.usValue -= ch.value.usValue;
//     return tmp;
// }
//
//
// void
// UnsignedShortValue::operator+=( Value* chval )
// {
//     if ( chval == NULL )
//     {
//         return;
//     }
//     value.usValue += ( ( UnsignedShortValue* )chval )->value.usValue;
// }
//
// void
// UnsignedShortValue::operator-=( Value* chval )
// {
//     if ( chval == NULL )
//     {
//         return;
//     }
//     value.usValue -= ( ( UnsignedShortValue* )chval )->value.usValue;
// }
//
//
//
// void
// UnsignedShortValue::operator*=( double dval )
// {
//     double _d = ( double )value.usValue;
//     _d           *= dval;
//     value.usValue = ( uint16_t )_d;
// }
//
// void
// UnsignedShortValue::operator/=( double dval )
// {
//     if ( dval == 0. )
//     {
//         cerr << "ERROR: DEVISION BY ZERO!" << endl;
//     }
//     double _d = ( double )value.usValue;
//     _d           /= dval;
//     value.usValue = ( uint16_t )_d;
// }
//
//
//
//


// overloaded new operator
void*
UnsignedShortValue::operator new( size_t size )
{
    return ( void* )uint16_preallocator.Get();
}
void
UnsignedShortValue::operator delete( void* p )
{
    uint16_preallocator.Put( ( UnsignedShortValue* )p );
}

void
UnsignedShortValue::operator=( double d )
{
// #warning LOST PRECISION
    value.usValue = ( uint16_t )d;
}
//
// void
// UnsignedShortValue::operator=( char c )
// {
//     value.usValue = ( uint16_t )c;
// }
//
//
// void
// UnsignedShortValue::operator=( uint16_t ui )
// {
//     value.usValue = ( uint16_t )ui;
// }
//
// void
// UnsignedShortValue::operator=( uint32_t i )
// {
// // #warning LOST PRECISION
//     value.usValue = ( uint16_t )i;
// }
//
// void
// UnsignedShortValue::operator=( uint64_t ul )
// {
// // #warning LOST PRECISION
//     value.usValue = ( uint16_t )ul;
// }
//
// void
// UnsignedShortValue::operator=( int16_t si )
// {
//     value.usValue = ( uint16_t )si;
// }
//
// void
// UnsignedShortValue::operator=( int32_t i )
// {
// // #warning LOST PRECISION
//     value.usValue = ( uint32_t )i;
// }
//
// void
// UnsignedShortValue::operator=( int64_t sl )
// {
// // #warning LOST PRECISION
//     value.usValue = ( uint16_t )sl;
// }
//
// void
// UnsignedShortValue::operator=( string v )
// {
//     stringstream sstr;
//     sstr << v;
//     sstr >> value.usValue;
// }
//

//
//
// UnsignedShortValue
// UnsignedShortValue::operator=( UnsignedShortValue v )
// {
// // #warning MISSED INTERFACE FOR SHORT
// // #warning LOST PRECISION
//     if ( &v == this )
//     {
//         return *this;
//     }
//     value.usValue = v.getUnsignedShort();
//     return *this;
// }
// */
void
UnsignedShortValue::operator=( Value* v )
{
    value.usValue = v->getUnsignedShort();
}



void
UnsignedShortValue::normalizeWithClusterCount( uint64_t N )
{
    value.usValue = ( uint16_t )( ( double )value.usValue / ( double )N );
}


#endif
