/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __SMALLER_EVALUATION_CPP
#define __SMALLER_EVALUATION_CPP 0

#include "CubeSmallerEvaluation.h"
using namespace cube;

SmallerEvaluation::SmallerEvaluation() : BinaryEvaluation()
{
};

SmallerEvaluation::SmallerEvaluation( GeneralEvaluation* _arg1,
                                      GeneralEvaluation* _arg2 ) : BinaryEvaluation( _arg1, _arg2 )
{
};


SmallerEvaluation::~SmallerEvaluation()
{
}

double
SmallerEvaluation::eval()
{
    return ( ( arguments[ 0 ]->eval() ) < ( arguments[ 1 ]->eval() ) ) ? 1. : 0.;
}

/*

   double
   SmallerEvaluation::eval( cube::Cnode * _cnode, CalculationFlavour _cf, cube::Thread * _thread, CalculationFlavour _tf)
   {
    return  ( (arguments[0]->eval(_cnode, _cf, _thread, _tf)) < ( arguments[1]->eval(_cnode, _cf, _thread, _tf)))?1.:0.;
   }



   double
   SmallerEvaluation::eval( cube::Cnode * _cnode, CalculationFlavour _cf, cube::Thread * _th1, cube::Thread * _th2, CalculationFlavour  _tf )
   {
    return  ( (arguments[0]->eval(_cnode, _cf,_th1, _th2, _tf)) < ( arguments[1]->eval(_cnode, _cf, _th1, _th2, _tf)))?1.:0.;
   }*/

double
SmallerEvaluation::eval( cube::Cnode* _cnode, CalculationFlavour _cf, cube::Sysres* _sf, CalculationFlavour _tf   )
{
    return ( ( arguments[ 0 ]->eval( _cnode, _cf, _sf, _tf ) ) < ( arguments[ 1 ]->eval( _cnode, _cf, _sf, _tf ) ) ) ? 1. : 0.;
}
/*
   double
   SmallerEvaluation::eval( cube::Cnode *  _cnode, CalculationFlavour _cf, cube::Process * _pr, CalculationFlavour  _tf   )
   {
    return  ( (arguments[0]->eval(_cnode, _cf,_pr, _tf)) < ( arguments[1]->eval(_cnode, _cf,_pr, _tf)))?1.:0.;
   }

   double
   SmallerEvaluation::eval( cube::Cnode *  _cnode, CalculationFlavour _cf, cube::Node * _nd, CalculationFlavour    _tf )
   {
    return  ( (arguments[0]->eval(_cnode, _cf,_nd, _tf)) < ( arguments[1]->eval(_cnode, _cf,_nd, _tf)))?1.:0.;
   }

   double
   SmallerEvaluation::eval( cube::Cnode *  _cnode, CalculationFlavour _cf, cube::Machine * _mch, CalculationFlavour   _tf  )
   {
    return  ( (arguments[0]->eval(_cnode, _cf,_mch, _tf)) < ( arguments[1]->eval(_cnode, _cf,_mch, _tf)))?1.:0.;
   }*/

double
SmallerEvaluation::eval( cube::Cnode* _cnode, CalculationFlavour _cf )
{
    return ( ( arguments[ 0 ]->eval( _cnode, _cf ) ) < ( arguments[ 1 ]->eval( _cnode, _cf ) ) ) ? 1. : 0.;
}



#endif
