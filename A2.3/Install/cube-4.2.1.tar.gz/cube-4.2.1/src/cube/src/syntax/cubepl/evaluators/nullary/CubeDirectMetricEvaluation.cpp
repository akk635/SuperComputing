/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __DIRECT_METRIC_EVALUATION_CPP
#define __DIRECT_METRIC_EVALUATION_CPP 0

#include "CubeDirectMetricEvaluation.h"


using namespace cube;

DirectMetricEvaluation::DirectMetricEvaluation( MetricReferenceType    _reference_type,
                                                Cube*                  _cube,
                                                Metric*                _met,
                                                CalcFlavorModificator* cf,
                                                CalcFlavorModificator* sf ) : NullaryEvaluation(), reference_type( _reference_type ), cube( _cube ), metric( _met ), calltree_cf( cf ), systree_sf( sf )
{
    metric_uniq_name = metric->get_uniq_name();
};


DirectMetricEvaluation::~DirectMetricEvaluation()
{
    delete calltree_cf;
    delete systree_sf;
}



double
DirectMetricEvaluation::eval( cube::Cnode* _cnode, CalculationFlavour _cf, cube::Sysres* _sf, CalculationFlavour _tf   )
{
    double _value = 0.;

    switch ( reference_type )
    {
        case FIXED_METRIC_FULL_AGGR:
            _value = cube->get_sev( metric, cube::CUBE_CALCULATE_INCLUSIVE );
            break;
        case FIXED_METRIC_AGGR_SYS:
            _value = cube->get_sev( metric, cube::CUBE_CALCULATE_INCLUSIVE,  _cnode, calltree_cf->flavour( _cf )
                                    );
            break;
        case FIXED_METRIC_NO_AGGR:
        case CONTEXT_METRIC:
        default:
            _value = cube->get_sev( metric, cube::CUBE_CALCULATE_INCLUSIVE,  _cnode, calltree_cf->flavour( _cf ),
                                    _sf, systree_sf->flavour( _tf )
                                    );
            break;
    }

    return _value;
}


double
DirectMetricEvaluation::eval( cube::Cnode* _cnode, CalculationFlavour _cf )
{
    double _value = 0.;

    switch ( reference_type )
    {
        case FIXED_METRIC_FULL_AGGR:
            _value = cube->get_sev( metric, cube::CUBE_CALCULATE_INCLUSIVE );
            break;
        case FIXED_METRIC_AGGR_SYS:
        case FIXED_METRIC_NO_AGGR:
        case CONTEXT_METRIC:
        default:
            _value = cube->get_sev( metric, cube::CUBE_CALCULATE_INCLUSIVE,  _cnode, calltree_cf->flavour( _cf )
                                    );
            break;
    }
    return _value;
}



double
DirectMetricEvaluation::eval()
{
    return 0.; //  return just 0, coz this call is for that evaluator not defined
}


#endif
