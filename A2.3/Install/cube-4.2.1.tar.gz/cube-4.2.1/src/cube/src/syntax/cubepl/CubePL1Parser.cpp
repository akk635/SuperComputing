/* A Bison parser, made by GNU Bison 2.5.  */

/* Skeleton implementation for Bison LALR(1) parsers in C++

      Copyright (C) 2002-2011 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

// Take the name prefix into account.
#define yylex   cubeplparserlex

/* First part of user declarations.  */


/* Line 293 of lalr1.cc  */
#line 41 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.cpp"


#include "CubePL1Parser.h"

/* User implementation prologue.  */

/* Line 299 of lalr1.cc  */
#line 244 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"


#include "CubePL1Scanner.h"
#include <cassert>
#include <cstdlib>
#include <cstring>
#include <stdlib.h>

using namespace std;

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <utility>
#include <string>
#include <vector>
#include "CubePL1ParseContext.h"

/* this "connects" the bison parser in the driver to the flex scanner class
 * object. it defines the yylex() function call to pull the next token from the
 * current lexer object of the driver context. */
#undef yylex
#define yylex Lexer.lex

// Workaround for Sun Studio C++ compilers on Solaris
#if defined( __SVR4 ) &&  defined( __SUNPRO_CC )
  #include <ieeefp.h>

  #define isinf( x )  ( fpclass( x ) == FP_NINF || fpclass( x ) == FP_PINF )
  #define isnan( x )  isnand( x )
#endif



/* Line 299 of lalr1.cc  */
#line 85 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.cpp"

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* FIXME: INFRINGES ON USER NAME SPACE */
#   define YY_( msgid ) dgettext( "bison-runtime", msgid )
#  endif
# endif
# ifndef YY_
#  define YY_( msgid ) msgid
# endif
#endif

/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC( Rhs, K ) ( ( Rhs )[ K ] )
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT( Current, Rhs, N )                               \
    do {                                                                    \
        if ( N )                                                              \
        {                                                                 \
            ( Current ).begin = YYRHSLOC( Rhs, 1 ).begin;                      \
            ( Current ).end   = YYRHSLOC( Rhs, N ).end;                        \
        }                                                                 \
        else                                                                \
        {                                                                 \
            ( Current ).begin = ( Current ).end = YYRHSLOC( Rhs, 0 ).end;        \
        } }                                                                 \
    while ( false )
#endif

/* Suppress unused-variable warnings by "using" E.  */
#define YYUSE( e ) ( ( void )( e ) )

/* Enable debugging if requested.  */
#if YYDEBUG

/* A pseudo ostream that takes yydebug_ into account.  */
# define YYCDEBUG if ( yydebug_ ) ( *yycdebug_ )

# define YY_SYMBOL_PRINT( Title, Type, Value, Location )  \
    do {                                                    \
        if ( yydebug_ )                                         \
        {                                                   \
            *yycdebug_ << Title << ' ';                       \
            yy_symbol_print_( ( Type ), ( Value ), ( Location ) );   \
            *yycdebug_ << std::endl;                          \
        }                                                   \
    } while ( false )

# define YY_REDUCE_PRINT( Rule )          \
    do {                                    \
        if ( yydebug_ ) {                         \
            yy_reduce_print_( Rule ); }            \
    } while ( false )

# define YY_STACK_PRINT()               \
    do {                                    \
        if ( yydebug_ ) {                         \
            yystack_print_(); }                  \
    } while ( false )

#else /* !YYDEBUG */

# define YYCDEBUG if ( false ) std::cerr
# define YY_SYMBOL_PRINT( Title, Type, Value, Location )
# define YY_REDUCE_PRINT( Rule )
# define YY_STACK_PRINT()

#endif /* !YYDEBUG */

#define yyerrok         ( yyerrstatus_ = 0 )
#define yyclearin       ( yychar = yyempty_ )

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  ( !!yyerrstatus_ )


namespace cubeplparser
{
/* Line 382 of lalr1.cc  */
#line 171 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.cpp"

/* Return YYSTR after stripping away unnecessary quotes and
   backslashes, so that it's suitable for yyerror.  The heuristic is
   that double-quoting is unnecessary unless the string contains an
   apostrophe, a comma, or backslash (other than backslash-backslash).
   YYSTR is taken from yytname.  */
std::string
Parser::yytnamerr_( const char* yystr )
{
    if ( *yystr == '"' )
    {
        std::string yyr = "";
        char const* yyp = yystr;

        for (;; )
        {
            switch ( *++yyp )
            {
                case '\'':
                case ',':
                    goto do_not_strip_quotes;

                case '\\':
                    if ( *++yyp != '\\' )
                    {
                        goto do_not_strip_quotes;
                    }
                /* Fall through.  */
                default:
                    yyr += *yyp;
                    break;

                case '"':
                    return yyr;
            }
        }
do_not_strip_quotes:;
    }

    return yystr;
}


/// Build a parser object.
Parser::Parser ( class CubePL1ParseContext& parseContext_yyarg,
                 class Scanner&             Lexer_yyarg )
    :
#if YYDEBUG
      yydebug_( false ),
      yycdebug_( &std::cerr ),
#endif
      parseContext( parseContext_yyarg ),
      Lexer( Lexer_yyarg )
{
}

Parser::~Parser ()
{
}

#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
   `--------------------------------*/

inline void
Parser::yy_symbol_value_print_( int yytype,
                                const semantic_type* yyvaluep, const location_type* yylocationp )
{
    YYUSE( yylocationp );
    YYUSE( yyvaluep );
    switch ( yytype )
    {
        default:
            break;
    }
}


void
Parser::yy_symbol_print_( int yytype,
                          const semantic_type* yyvaluep, const location_type* yylocationp )
{
    *yycdebug_ << ( yytype < yyntokens_ ? "token" : "nterm" )
               << ' ' << yytname_[ yytype ] << " ("
               << *yylocationp << ": ";
    yy_symbol_value_print_( yytype, yyvaluep, yylocationp );
    *yycdebug_ << ')';
}
#endif

void
Parser::yydestruct_( const char* yymsg,
                     int yytype, semantic_type* yyvaluep, location_type* yylocationp )
{
    YYUSE( yylocationp );
    YYUSE( yymsg );
    YYUSE( yyvaluep );

    YY_SYMBOL_PRINT( yymsg, yytype, yyvaluep, yylocationp );

    switch ( yytype )
    {
        default:
            break;
    }
}

void
Parser::yypop_( unsigned int n )
{
    yystate_stack_.pop( n );
    yysemantic_stack_.pop( n );
    yylocation_stack_.pop( n );
}

#if YYDEBUG
std::ostream&
Parser::debug_stream() const
{
    return *yycdebug_;
}

void
Parser::set_debug_stream( std::ostream& o )
{
    yycdebug_ = &o;
}


Parser::debug_level_type
Parser::debug_level() const
{
    return yydebug_;
}

void
Parser::set_debug_level( debug_level_type l )
{
    yydebug_ = l;
}
#endif

inline bool
Parser::yy_pact_value_is_default_( int yyvalue )
{
    return yyvalue == yypact_ninf_;
}

inline bool
Parser::yy_table_value_is_error_( int yyvalue )
{
    return yyvalue == yytable_ninf_;
}

int
Parser::parse()
{
    /// Lookahead and lookahead in internal form.
    int yychar  = yyempty_;
    int yytoken = 0;

    /* State.  */
    int yyn;
    int yylen   = 0;
    int yystate = 0;

    /* Error handling.  */
    int yynerrs_     = 0;
    int yyerrstatus_ = 0;

    /// Semantic value of the lookahead.
    semantic_type yylval;
    /// Location of the lookahead.
    location_type yylloc;
    /// The locations where the error started and ended.
    location_type yyerror_range[ 3 ];

    /// $$.
    semantic_type yyval;
    /// @$.
    location_type yyloc;

    int           yyresult;

    YYCDEBUG << "Starting parse" << std::endl;


    /* User initialization code.  */

/* Line 565 of lalr1.cc  */
#line 130 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
    {
        // initialize the initial location object
    }

/* Line 565 of lalr1.cc  */
#line 365 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.cpp"

    /* Initialize the stacks.  The initial state will be pushed in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystate_stack_    = state_stack_type( 0 );
    yysemantic_stack_ = semantic_stack_type( 0 );
    yylocation_stack_ = location_stack_type( 0 );
    yysemantic_stack_.push( yylval );
    yylocation_stack_.push( yylloc );

    /* New state.  */
yynewstate:
    yystate_stack_.push( yystate );
    YYCDEBUG << "Entering state " << yystate << std::endl;

    /* Accept?  */
    if ( yystate == yyfinal_ )
    {
        goto yyacceptlab;
    }

    goto yybackup;

    /* Backup.  */
yybackup:

    /* Try to take a decision without lookahead.  */
    yyn = yypact_[ yystate ];
    if ( yy_pact_value_is_default_( yyn ) )
    {
        goto yydefault;
    }

    /* Read a lookahead token.  */
    if ( yychar == yyempty_ )
    {
        YYCDEBUG << "Reading a token: ";
        yychar = yylex( &yylval, &yylloc );
    }


    /* Convert token to internal form.  */
    if ( yychar <= yyeof_ )
    {
        yychar = yytoken = yyeof_;
        YYCDEBUG << "Now at end of input." << std::endl;
    }
    else
    {
        yytoken = yytranslate_( yychar );
        YY_SYMBOL_PRINT( "Next token is", yytoken, &yylval, &yylloc );
    }

    /* If the proper action on seeing token YYTOKEN is to reduce or to
       detect an error, take that action.  */
    yyn += yytoken;
    if ( yyn < 0 || yylast_ < yyn || yycheck_[ yyn ] != yytoken )
    {
        goto yydefault;
    }

    /* Reduce or error.  */
    yyn = yytable_[ yyn ];
    if ( yyn <= 0 )
    {
        if ( yy_table_value_is_error_( yyn ) )
        {
            goto yyerrlab;
        }
        yyn = -yyn;
        goto yyreduce;
    }

    /* Shift the lookahead token.  */
    YY_SYMBOL_PRINT( "Shifting", yytoken, &yylval, &yylloc );

    /* Discard the token being shifted.  */
    yychar = yyempty_;

    yysemantic_stack_.push( yylval );
    yylocation_stack_.push( yylloc );

    /* Count tokens shifted since error; after three, turn off error
       status.  */
    if ( yyerrstatus_ )
    {
        --yyerrstatus_;
    }

    yystate = yyn;
    goto yynewstate;

    /*-----------------------------------------------------------.
    | yydefault -- do the default action for the current state.  |
       `-----------------------------------------------------------*/
yydefault:
    yyn = yydefact_[ yystate ];
    if ( yyn == 0 )
    {
        goto yyerrlab;
    }
    goto yyreduce;

    /*-----------------------------.
    | yyreduce -- Do a reduction.  |
       `-----------------------------*/
yyreduce:
    yylen = yyr2_[ yyn ];
    /* If YYLEN is nonzero, implement the default value of the action:
       `$$ = $1'.  Otherwise, use the top of the stack.

       Otherwise, the following line sets YYVAL to garbage.
       This behavior is undocumented and Bison
       users should not rely upon it.  */
    if ( yylen )
    {
        yyval = yysemantic_stack_[ yylen - 1 ];
    }
    else
    {
        yyval = yysemantic_stack_[ 0 ];
    }

    {
        slice<location_type, location_stack_type> slice( yylocation_stack_, yylen );
        YYLLOC_DEFAULT( yyloc, slice, yylen );
    }
    YY_REDUCE_PRINT( yyn );
    switch ( yyn )
    {
        case 2:

/* Line 690 of lalr1.cc  */
#line 288 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.result = parseContext._stack.top();
                    parseContext._stack.pop();
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 3:

/* Line 690 of lalr1.cc  */
#line 297 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                parseContext.syntax_ok &= true;
            }
            break;

        case 19:

/* Line 690 of lalr1.cc  */
#line 322 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new EncapsulationEvaluation( _arg1 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 20:

/* Line 690 of lalr1.cc  */
#line 332 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation* _abs = new AbsEvaluation();
                    _abs->addArgument( _arg1 );
                    parseContext._stack.push( _abs );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 21:

/* Line 690 of lalr1.cc  */
#line 345 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation* _arg2 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new PlusEvaluation( _arg1, _arg2 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 22:

/* Line 690 of lalr1.cc  */
#line 358 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg2 = parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new MinusEvaluation( _arg1, _arg2 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 23:

/* Line 690 of lalr1.cc  */
#line 372 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg2 = parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new DivideEvaluation( _arg1, _arg2 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 24:

/* Line 690 of lalr1.cc  */
#line 385 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation* _arg2 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new MultEvaluation( _arg1, _arg2 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 25:

/* Line 690 of lalr1.cc  */
#line 401 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* power = parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation* base = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new PowerEvaluation( base, power ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 26:

/* Line 690 of lalr1.cc  */
#line 413 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* arg = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new NegativeEvaluation( arg ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 40:

/* Line 690 of lalr1.cc  */
#line 443 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new EncapsulationEvaluation( _arg1 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 41:

/* Line 690 of lalr1.cc  */
#line 453 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new NotEvaluation( _arg1 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 42:

/* Line 690 of lalr1.cc  */
#line 464 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg2 = parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new AndEvaluation( _arg1, _arg2 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 43:

/* Line 690 of lalr1.cc  */
#line 477 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg2 = parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new OrEvaluation( _arg1, _arg2 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 44:

/* Line 690 of lalr1.cc  */
#line 491 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg2 = parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new XorEvaluation( _arg1, _arg2 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 45:

/* Line 690 of lalr1.cc  */
#line 504 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext._stack.push( new ConstantEvaluation( 1 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 46:

/* Line 690 of lalr1.cc  */
#line 512 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext._stack.push( new ConstantEvaluation( 0 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 47:

/* Line 690 of lalr1.cc  */
#line 521 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg2 = parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new EqualEvaluation( _arg1, _arg2 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 48:

/* Line 690 of lalr1.cc  */
#line 535 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg2 = parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new NotEqualEvaluation( _arg1, _arg2 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 49:

/* Line 690 of lalr1.cc  */
#line 549 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg2 = parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new BiggerEvaluation( _arg1, _arg2 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 50:

/* Line 690 of lalr1.cc  */
#line 562 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg2 = parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new SmallerEvaluation( _arg1, _arg2 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 51:

/* Line 690 of lalr1.cc  */
#line 576 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg2 = parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new HalfBiggerEvaluation( _arg1, _arg2 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 52:

/* Line 690 of lalr1.cc  */
#line 590 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg2 = parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new HalfSmallerEvaluation( _arg1, _arg2 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 56:

/* Line 690 of lalr1.cc  */
#line 613 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _value2 =   parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation* _value1 =   parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new StringEqualityEvaluation( _value1, _value2 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 57:

/* Line 690 of lalr1.cc  */
#line 626 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _value2 =   parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation* _value1 =   parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new StringSemiEqualityEvaluation( _value1, _value2 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 58:

/* Line 690 of lalr1.cc  */
#line 638 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    string             _regexp =  parseContext.strings_stack.top();
                    parseContext.strings_stack.pop();
                    GeneralEvaluation* _value =   parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new RegexEvaluation( _value, new StringConstantEvaluation( _regexp ) ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 59:

/* Line 690 of lalr1.cc  */
#line 653 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                string  _tmp = parseContext.str.str();
                regex_t rgT;
                int     _result = regcomp( &rgT, _tmp.c_str(), REG_EXTENDED );
                if ( _result != 0 )
                {
                    parseContext.syntax_ok &= false;
                }
                if ( _result == 0 && !parseContext.test_modus )
                {
                    parseContext.strings_stack.push( _tmp );
                    parseContext.str.str( "" );
                }
                regfree( &rgT );
                parseContext.syntax_ok &= true;
            }
            break;

        case 63:

/* Line 690 of lalr1.cc  */
#line 681 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext._stack.push( new StringConstantEvaluation( parseContext.str.str() ) );
                    parseContext.str.str( "" );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 66:

/* Line 690 of lalr1.cc  */
#line 697 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new LowerCaseEvaluation( _arg1 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 67:

/* Line 690 of lalr1.cc  */
#line 708 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext._stack.push( new UpperCaseEvaluation( _arg1 ) );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 70:

/* Line 690 of lalr1.cc  */
#line 724 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext.function_call.top()->addArgument( _arg1 );
                    parseContext._stack.push( parseContext.function_call.top() );
                    parseContext.function_call.pop();
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 71:

/* Line 690 of lalr1.cc  */
#line 738 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.function_call.push( new SqrtEvaluation() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 72:

/* Line 690 of lalr1.cc  */
#line 746 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.function_call.push( new SinEvaluation() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 73:

/* Line 690 of lalr1.cc  */
#line 754 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.function_call.push( new ASinEvaluation() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 74:

/* Line 690 of lalr1.cc  */
#line 762 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.function_call.push( new CosEvaluation() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 75:

/* Line 690 of lalr1.cc  */
#line 770 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.function_call.push( new ACosEvaluation() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 76:

/* Line 690 of lalr1.cc  */
#line 778 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.function_call.push( new ExpEvaluation() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 77:

/* Line 690 of lalr1.cc  */
#line 786 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.function_call.push( new LnEvaluation() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 78:

/* Line 690 of lalr1.cc  */
#line 794 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.function_call.push( new TanEvaluation() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 79:

/* Line 690 of lalr1.cc  */
#line 802 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.function_call.push( new ATanEvaluation() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 80:

/* Line 690 of lalr1.cc  */
#line 810 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.function_call.push( new RandomEvaluation() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 81:

/* Line 690 of lalr1.cc  */
#line 818 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.function_call.push( new AbsEvaluation() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 82:

/* Line 690 of lalr1.cc  */
#line 826 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.function_call.push( new SgnEvaluation() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 83:

/* Line 690 of lalr1.cc  */
#line 834 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.function_call.push( new PosEvaluation() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 84:

/* Line 690 of lalr1.cc  */
#line 842 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.function_call.push( new NegEvaluation() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 85:

/* Line 690 of lalr1.cc  */
#line 850 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.function_call.push( new FloorEvaluation() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 86:

/* Line 690 of lalr1.cc  */
#line 858 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.function_call.push( new CeilEvaluation() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 87:

/* Line 690 of lalr1.cc  */
#line 869 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation* _arg2 = parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation* _arg1 = parseContext._stack.top();
                    parseContext._stack.pop();
                    parseContext.function_call.top()->addArgument( _arg1 );
                    parseContext.function_call.top()->addArgument( _arg2 );
                    parseContext._stack.push( parseContext.function_call.top() );
                    parseContext.function_call.pop();
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 88:

/* Line 690 of lalr1.cc  */
#line 885 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.function_call.push( new MinEvaluation() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 89:

/* Line 690 of lalr1.cc  */
#line 893 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.function_call.push( new MaxEvaluation() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 90:

/* Line 690 of lalr1.cc  */
#line 904 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    double _value = atof( parseContext.value.c_str() );
                    parseContext._stack.push( new ConstantEvaluation( _value ) );
                    parseContext.value = "";
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 93:

/* Line 690 of lalr1.cc  */
#line 920 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    Metric* _met = parseContext.cube->get_met( parseContext.value );
                    if ( _met != NULL )
                    {
                        parseContext._stack.push( new DirectMetricEvaluation( cube::CONTEXT_METRIC,  parseContext.cube, _met ) );
                    }
                    else
                    {
                        cerr << "Cannot connect to the metric " << parseContext.value << ". Seems that this metric is not created yet. Value of metric::" << parseContext.value << "() will be always 0" << endl;
                        parseContext._stack.push( new ConstantEvaluation( 0 ) );
                    }
                    parseContext.value = "";
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 94:

/* Line 690 of lalr1.cc  */
#line 939 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    Metric* _met = parseContext.cube->get_met( parseContext.value );
                    if ( _met != NULL )
                    {
                        cube::CalcFlavorModificator* mod = parseContext.calcFlavorModificators.top();
                        parseContext.calcFlavorModificators.pop();
                        parseContext._stack.push( new DirectMetricEvaluation( cube::CONTEXT_METRIC,  parseContext.cube, _met, mod ) );
                    }
                    else
                    {
                        cerr << "Cannot connect to the metric " << parseContext.value << ". Seems that this metric is not created yet. Value of metric::" << parseContext.value << "( ?  ) will be always 0" << endl;
                        parseContext._stack.push( new ConstantEvaluation( 0 ) );
                    }
                    parseContext.value = "";
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 95:

/* Line 690 of lalr1.cc  */
#line 960 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    Metric* _met = parseContext.cube->get_met( parseContext.value );
                    if ( _met != NULL )
                    {
                        cube::CalcFlavorModificator* mod2 = parseContext.calcFlavorModificators.top();
                        parseContext.calcFlavorModificators.pop();
                        cube::CalcFlavorModificator* mod1 = parseContext.calcFlavorModificators.top();
                        parseContext.calcFlavorModificators.pop();

                        parseContext._stack.push( new DirectMetricEvaluation( cube::CONTEXT_METRIC,  parseContext.cube, _met, mod1, mod2 ) );
                    }
                    else
                    {
                        cerr << "Cannot connect to the metric " << parseContext.value << ". Seems that this metric is not created yet. Value of metric::" << parseContext.value << "( ?, ? ) will be always 0" << endl;
                        parseContext._stack.push( new ConstantEvaluation( 0 ) );
                    }
                    parseContext.value = "";
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 96:

/* Line 690 of lalr1.cc  */
#line 987 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    Metric* _met = parseContext.cube->get_met( parseContext.value );
                    if ( _met != NULL )
                    {
                        parseContext._stack.push( new DirectMetricEvaluation( cube::FIXED_METRIC_FULL_AGGR,  parseContext.cube, _met ) );
                    }
                    else
                    {
                        cerr << "Cannot connect to the metric " << parseContext.value << ". Seems that this metric is not created yet. Value of metric::" << parseContext.value << "() will be always 0" << endl;
                        parseContext._stack.push( new ConstantEvaluation( 0 ) );
                    }
                    parseContext.value = "";
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 97:

/* Line 690 of lalr1.cc  */
#line 1006 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    Metric* _met = parseContext.cube->get_met( parseContext.value );
                    if ( _met != NULL )
                    {
                        cube::CalcFlavorModificator* mod = parseContext.calcFlavorModificators.top();
                        parseContext.calcFlavorModificators.pop();
                        parseContext._stack.push( new DirectMetricEvaluation( cube::FIXED_METRIC_AGGR_SYS,  parseContext.cube, _met, mod ) );
                    }
                    else
                    {
                        cube::CalcFlavorModificator* mod = parseContext.calcFlavorModificators.top();
                        parseContext.calcFlavorModificators.pop();
                        cerr << "Cannot connect to the metric " << parseContext.value << ". Seems that this metric is not created yet. Value of metric::" << parseContext.value << "( ";
                        mod->print();
                        cout << " ) will be always 0" << endl;


                        delete mod;

                        parseContext._stack.push( new ConstantEvaluation( 0 ) );
                    }
                    parseContext.value = "";
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 98:

/* Line 690 of lalr1.cc  */
#line 1033 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    Metric* _met = parseContext.cube->get_met( parseContext.value );
                    if ( _met != NULL )
                    {
                        cube::CalcFlavorModificator* mod2 = parseContext.calcFlavorModificators.top();
                        parseContext.calcFlavorModificators.pop();
                        cube::CalcFlavorModificator* mod1 = parseContext.calcFlavorModificators.top();
                        parseContext.calcFlavorModificators.pop();

                        parseContext._stack.push( new DirectMetricEvaluation( cube::FIXED_METRIC_NO_AGGR,  parseContext.cube, _met, mod1, mod2 ) );
                    }
                    else
                    {
                        cube::CalcFlavorModificator* mod2 = parseContext.calcFlavorModificators.top();
                        parseContext.calcFlavorModificators.pop();
                        cube::CalcFlavorModificator* mod1 = parseContext.calcFlavorModificators.top();
                        parseContext.calcFlavorModificators.pop();
                        cerr << "Cannot connect to the metric " << parseContext.value << ". Seems that this metric is not created yet. Value of metric::" << parseContext.value << "( ";
                        mod1->print();
                        cout << ",";
                        mod2->print();
                        cout << ") will be always 0" << endl;


                        delete mod2;
                        delete mod1;

                        parseContext._stack.push( new ConstantEvaluation( 0 ) );
                    }
                    parseContext.value = "";
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 99:

/* Line 690 of lalr1.cc  */
#line 1071 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.calcFlavorModificators.push( new CalcFlavorModificatorIncl() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 100:

/* Line 690 of lalr1.cc  */
#line 1079 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.calcFlavorModificators.push( new CalcFlavorModificatorExcl() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 101:

/* Line 690 of lalr1.cc  */
#line 1087 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext.calcFlavorModificators.push( new CalcFlavorModificatorSame() );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 102:

/* Line 690 of lalr1.cc  */
#line 1098 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    LambdaCalculEvaluation* _l_calc = new LambdaCalculEvaluation();

                    GeneralEvaluation*      return_expr = parseContext._stack.top();
                    parseContext._stack.pop();

                    int _num_of_statements = parseContext._number_of_statements.top();
                    parseContext._number_of_statements.pop();

                    vector<GeneralEvaluation*> _tmp_statements;
                    for ( int i = 0; i < _num_of_statements; i++ )
                    {
                        _tmp_statements.push_back( parseContext._statements.top() );
                        parseContext._statements.pop();
                    }
                    for ( int i = _num_of_statements - 1; i >= 0; i-- )
                    {
                        _l_calc->addArgument( _tmp_statements[ i ] );
                    }
                    _l_calc->addArgument( return_expr );
                    parseContext._stack.push( _l_calc );
                    // create lambda calculation using number_of_statements.
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 104:

/* Line 690 of lalr1.cc  */
#line 1130 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext._number_of_statements.push( 0 );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 107:

/* Line 690 of lalr1.cc  */
#line 1147 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    int _tmp = parseContext._number_of_statements.top();
                    parseContext._number_of_statements.pop();
                    _tmp++;
                    parseContext._number_of_statements.push( _tmp );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 108:

/* Line 690 of lalr1.cc  */
#line 1158 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    int _tmp = parseContext._number_of_statements.top();
                    parseContext._number_of_statements.pop();
                    _tmp++;
                    parseContext._number_of_statements.push( _tmp );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 109:

/* Line 690 of lalr1.cc  */
#line 1169 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    int _tmp = parseContext._number_of_statements.top();
                    parseContext._number_of_statements.pop();
                    _tmp++;
                    parseContext._number_of_statements.push( _tmp );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 110:

/* Line 690 of lalr1.cc  */
#line 1180 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                parseContext.syntax_ok &= true;
            }
            break;

        case 111:

/* Line 690 of lalr1.cc  */
#line 1184 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                parseContext.syntax_ok &= true;
            }
            break;

        case 116:

/* Line 690 of lalr1.cc  */
#line 1196 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    int _num_of_statements = parseContext._number_of_statements.top();
                    parseContext._number_of_statements.pop();

                    vector<GeneralEvaluation*> _tmp_statements;
                    for ( int i = 0; i < _num_of_statements; i++ )
                    {
                        _tmp_statements.push_back( parseContext._statements.top() );
                        parseContext._statements.pop();
                    }
                    GeneralEvaluation* _condition = parseContext._stack.top();
                    parseContext._stack.pop();

                    ShortIfEvaluation* _s_if_calc = new ShortIfEvaluation( _condition );

                    for ( int i = _num_of_statements - 1; i >= 0; i-- )
                    {
                        _s_if_calc->addArgument( _tmp_statements[ i ] );
                    }
                    parseContext._statements.push( _s_if_calc );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 117:

/* Line 690 of lalr1.cc  */
#line 1223 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    int _num_of_false_statements = parseContext._number_of_statements.top();
                    parseContext._number_of_statements.pop();
                    int _num_of_true_statements = parseContext._number_of_statements.top();
                    parseContext._number_of_statements.pop();

                    vector<GeneralEvaluation*> _tmp_false_statements;
                    for ( int i = 0; i < _num_of_false_statements; i++ )
                    {
                        _tmp_false_statements.push_back( parseContext._statements.top() );
                        parseContext._statements.pop();
                    }
                    vector<GeneralEvaluation*> _tmp_true_statements;
                    for ( int i = 0; i < _num_of_true_statements; i++ )
                    {
                        _tmp_true_statements.push_back( parseContext._statements.top() );
                        parseContext._statements.pop();
                    }
                    GeneralEvaluation* _condition = parseContext._stack.top();
                    parseContext._stack.pop();

                    FullIfEvaluation* _f_if_calc = new FullIfEvaluation( _condition, _num_of_true_statements, _num_of_false_statements );

                    for ( int i = _num_of_true_statements - 1; i >= 0; i-- )
                    {
                        _f_if_calc->addArgument( _tmp_true_statements[ i ] );
                    }
                    for ( int i = _num_of_false_statements - 1; i >= 0; i-- )
                    {
                        _f_if_calc->addArgument( _tmp_false_statements[ i ] );
                    }
                    parseContext._statements.push( _f_if_calc );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 121:

/* Line 690 of lalr1.cc  */
#line 1271 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext._number_of_statements.push( 0 );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 122:

/* Line 690 of lalr1.cc  */
#line 1281 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    int _num_of_statements = parseContext._number_of_statements.top();
                    parseContext._number_of_statements.pop();

                    vector<GeneralEvaluation*> _tmp_statements;
                    for ( int i = 0; i < _num_of_statements; i++ )
                    {
                        _tmp_statements.push_back( parseContext._statements.top() );
                        parseContext._statements.pop();
                    }
                    GeneralEvaluation* _condition = parseContext._stack.top();
                    parseContext._stack.pop();

                    WhileEvaluation* _while_calc = new WhileEvaluation( _condition );

                    for ( int i = _num_of_statements - 1; i >= 0; i-- )
                    {
                        _while_calc->addArgument( _tmp_statements[ i ] );
                    }
                    parseContext._statements.push( _while_calc );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 123:

/* Line 690 of lalr1.cc  */
#line 1310 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation*    _value = parseContext._stack.top();
                    parseContext._stack.pop();
                    GeneralEvaluation*    _index = parseContext._stack.top();
                    parseContext._stack.pop();
                    std::string           _string = parseContext.string_constants.top();
                    parseContext.string_constants.pop();
                    AssignmentEvaluation* _assign_eval = new AssignmentEvaluation( _string, _index, _value, parseContext.cube->get_cubepl_memory_manager()  );
                    parseContext._statements.push( _assign_eval );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 126:

/* Line 690 of lalr1.cc  */
#line 1329 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext._stack.push( new ConstantEvaluation( 0 ) ); // pushed index 0 if array index is not specified
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 131:

/* Line 690 of lalr1.cc  */
#line 1349 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    std::string expression = parseContext.str.str();
                    parseContext.str.str( "" );
                    std::string uniq_name = parseContext.value;
                    Metric*     _met      = parseContext.cube->get_met( uniq_name );
                    if ( _met == NULL )
                    {
                        _met = parseContext.cube->def_met( "",
                                                           uniq_name,
                                                           "DOUBLE",
                                                           "",
                                                           "",
                                                           "",
                                                           "",
                                                           NULL,
                                                           cube::CUBE_METRIC_POSTDERIVED,
                                                           expression,
                                                           "",
                                                           cube::CUBE_METRIC_GHOST
                                                           );
                    }
                    else
                    {
                        cout << " Metric with uniq name " << uniq_name << " already exists in cube" << endl;
                    }
                }
                else
                {
                    std::string                  expression     = parseContext.str.str();
                    std::string                  cubepl_program = string( "<cubepl>" ) + expression + string( "</cubepl>" );
                    cubeplparser::CubePL1Driver* driver         = new cubeplparser::CubePL1Driver( parseContext.cube );           // create driver for this cube
                    std::string                  nested_error;
                    if ( !driver->test( cubepl_program, nested_error ) )
                    {
                        parseContext.syntax_ok &= false;
                    }
                    delete driver;
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 132:

/* Line 690 of lalr1.cc  */
#line 1392 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    std::string expression = parseContext.str.str();
                    parseContext.str.str( "" );
                    std::string uniq_name = parseContext.value;
                    Metric*     _met      = parseContext.cube->get_met( uniq_name );
                    if ( _met == NULL )
                    {
                        _met = parseContext.cube->def_met( "",
                                                           uniq_name,
                                                           "DOUBLE",
                                                           "",
                                                           "",
                                                           "",
                                                           "",
                                                           NULL,
                                                           cube::CUBE_METRIC_PREDERIVED_INCLUSIVE,
                                                           expression,
                                                           "",
                                                           cube::CUBE_METRIC_GHOST
                                                           );
                    }
                    else
                    {
                        cout << " Metric with uniq name " << uniq_name << " already exists in cube" << endl;
                    }
                }
                else
                {
                    std::string                  expression     = parseContext.str.str();
                    std::string                  cubepl_program = string( "<cubepl>" ) + expression + string( "</cubepl>" );
                    cubeplparser::CubePL1Driver* driver         = new cubeplparser::CubePL1Driver( parseContext.cube );             // create driver for this cube
                    std::string                  nested_error;
                    if ( !driver->test( cubepl_program, nested_error ) )
                    {
                        parseContext.syntax_ok = false;
                    }
                    delete driver;
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 133:

/* Line 690 of lalr1.cc  */
#line 1434 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    std::string expression = parseContext.str.str();
                    parseContext.str.str( "" );
                    std::string uniq_name = parseContext.value;
                    Metric*     _met      = parseContext.cube->get_met( uniq_name );

                    if ( _met == NULL )
                    {
                        _met = parseContext.cube->def_met( "",
                                                           uniq_name,
                                                           "DOUBLE",
                                                           "",
                                                           "",
                                                           "",
                                                           "",
                                                           NULL,
                                                           cube::CUBE_METRIC_PREDERIVED_EXCLUSIVE,
                                                           expression,
                                                           "",
                                                           cube::CUBE_METRIC_GHOST
                                                           );
                    }
                    else
                    {
                        cout << " Metric with uniq name " << uniq_name << " already exists in cube" << endl;
                    }
                }
                else
                {
                    std::string                  expression     = parseContext.str.str();
                    std::string                  cubepl_program = string( "<cubepl>" ) + expression + string( "</cubepl>" );
                    cubeplparser::CubePL1Driver* driver         = new cubeplparser::CubePL1Driver( parseContext.cube );               // create driver for this cube
                    std::string                  nested_error;
                    if ( !driver->test( cubepl_program, nested_error ) )
                    {
                        parseContext.syntax_ok = false;
                    }
                    delete driver;
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 136:

/* Line 690 of lalr1.cc  */
#line 1487 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    std::string expression = parseContext.str.str();
                    parseContext.str.str( "" );
                    std::string uniq_name = parseContext.value;
                    Metric*     _met      = parseContext.cube->get_met( uniq_name );

                    if ( _met == NULL )
                    {
                        cout << " Metric with uniq name " << uniq_name << " doesn't  exists yet. Cannot assign CubePL initialization expression. Skip." << endl;
                    }
                    else
                    {
                        _met->set_init_expression( expression );
                    }
                }
                else
                {
                    std::string                  expression     = parseContext.str.str();
                    std::string                  cubepl_program = string( "<cubepl>" ) + expression + string( "</cubepl>" );
                    cubeplparser::CubePL1Driver* driver         = new cubeplparser::CubePL1Driver( parseContext.cube ); // create driver for this cube
                    std::string                  nested_error;
                    if ( !driver->test( cubepl_program, nested_error ) )
                    {
                        parseContext.syntax_ok = false;
                    }
                    delete driver;
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 137:

/* Line 690 of lalr1.cc  */
#line 1521 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation*  _index = parseContext._stack.top();
                    parseContext._stack.pop();
                    std::string         _string = parseContext.string_constants.top();
                    parseContext.string_constants.pop();
                    VariableEvaluation* _var_eval = new VariableEvaluation(  _string, _index, parseContext.cube->get_cubepl_memory_manager()   );
                    parseContext._stack.push( _var_eval );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 138:

/* Line 690 of lalr1.cc  */
#line 1534 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    GeneralEvaluation*  _index = parseContext._stack.top();
                    parseContext._stack.pop();
                    std::string         _string = parseContext.string_constants.top();
                    parseContext.string_constants.pop();
                    VariableEvaluation* _var_eval = new VariableEvaluation(  _string, _index, parseContext.cube->get_cubepl_memory_manager()  );
                    parseContext._stack.push( _var_eval );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 139:

/* Line 690 of lalr1.cc  */
#line 1549 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    parseContext._stack.push( new ConstantEvaluation( 0 ) ); // pushed index 0 if array index is not specified
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 141:

/* Line 690 of lalr1.cc  */
#line 1562 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    std::string               _string = parseContext.string_constants.top();
                    parseContext.string_constants.pop();
                    SizeOfVariableEvaluation* _sizeof_var_eval = new SizeOfVariableEvaluation(  _string, parseContext.cube->get_cubepl_memory_manager()  );
                    parseContext._stack.push( _sizeof_var_eval );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 142:

/* Line 690 of lalr1.cc  */
#line 1574 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    std::string                _string = parseContext.string_constants.top();
                    parseContext.string_constants.pop();
                    DefinedVariableEvaluation* _sizeof_var_eval = new DefinedVariableEvaluation(  _string, parseContext.cube->get_cubepl_memory_manager()  );
                    parseContext._stack.push( _sizeof_var_eval );
                }
            }
            break;

        case 143:

/* Line 690 of lalr1.cc  */
#line 1584 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    std::string _string = parseContext.string_constants.top();
                    parseContext.cube->get_cubepl_memory_manager()->register_variable( _string, CUBEPL_VARIABLE );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 144:

/* Line 690 of lalr1.cc  */
#line 1593 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                if ( !parseContext.test_modus )
                {
                    std::string _string = parseContext.string_constants.top();
                    parseContext.cube->get_cubepl_memory_manager()->register_variable( _string, CUBEPL_GLOBAL_VARIABLE );
                }
                parseContext.syntax_ok &= true;
            }
            break;

        case 145:

/* Line 690 of lalr1.cc  */
#line 1603 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
            {
                parseContext.string_constants.push( parseContext.value );
                parseContext.value = "";
            }
            break;



/* Line 690 of lalr1.cc  */
#line 2025 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.cpp"
        default:
            break;
    }
    /* User semantic actions sometimes alter yychar, and that requires
       that yytoken be updated with the new translation.  We take the
       approach of translating immediately before every use of yytoken.
       One alternative is translating here after every semantic action,
       but that translation would be missed if the semantic action
       invokes YYABORT, YYACCEPT, or YYERROR immediately after altering
       yychar.  In the case of YYABORT or YYACCEPT, an incorrect
       destructor might then be invoked immediately.  In the case of
       YYERROR, subsequent parser actions might lead to an incorrect
       destructor call or verbose syntax error message before the
       lookahead is translated.  */
    YY_SYMBOL_PRINT( "-> $$ =", yyr1_[ yyn ], &yyval, &yyloc );

    yypop_( yylen );
    yylen = 0;
    YY_STACK_PRINT();

    yysemantic_stack_.push( yyval );
    yylocation_stack_.push( yyloc );

    /* Shift the result of the reduction.  */
    yyn     = yyr1_[ yyn ];
    yystate = yypgoto_[ yyn - yyntokens_ ] + yystate_stack_[ 0 ];
    if ( 0 <= yystate && yystate <= yylast_
         && yycheck_[ yystate ] == yystate_stack_[ 0 ] )
    {
        yystate = yytable_[ yystate ];
    }
    else
    {
        yystate = yydefgoto_[ yyn - yyntokens_ ];
    }
    goto yynewstate;

    /*------------------------------------.
    | yyerrlab -- here on detecting error |
       `------------------------------------*/
yyerrlab:
    /* Make sure we have latest lookahead translation.  See comments at
       user semantic actions for why this is necessary.  */
    yytoken = yytranslate_( yychar );

    /* If not already recovering from an error, report this error.  */
    if ( !yyerrstatus_ )
    {
        ++yynerrs_;
        if ( yychar == yyempty_ )
        {
            yytoken = yyempty_;
        }
        error( yylloc, yysyntax_error_( yystate, yytoken ) );
    }

    yyerror_range[ 1 ] = yylloc;
    if ( yyerrstatus_ == 3 )
    {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        if ( yychar <= yyeof_ )
        {
            /* Return failure if at end of input.  */
            if ( yychar == yyeof_ )
            {
                YYABORT;
            }
        }
        else
        {
            yydestruct_( "Error: discarding", yytoken, &yylval, &yylloc );
            yychar = yyempty_;
        }
    }

    /* Else will try to reuse lookahead token after shifting the error
       token.  */
    goto yyerrlab1;


    /*---------------------------------------------------.
    | yyerrorlab -- error raised explicitly by YYERROR.  |
       `---------------------------------------------------*/
yyerrorlab:

    /* Pacify compilers like GCC when the user code never invokes
       YYERROR and the label yyerrorlab therefore never appears in user
       code.  */
    if ( false )
    {
        goto yyerrorlab;
    }

    yyerror_range[ 1 ] = yylocation_stack_[ yylen - 1 ];
    /* Do not reclaim the symbols of the rule which action triggered
       this YYERROR.  */
    yypop_( yylen );
    yylen   = 0;
    yystate = yystate_stack_[ 0 ];
    goto yyerrlab1;

    /*-------------------------------------------------------------.
    | yyerrlab1 -- common code for both syntax error and YYERROR.  |
       `-------------------------------------------------------------*/
yyerrlab1:
    yyerrstatus_ = 3;   /* Each real token shifted decrements this.  */

    for (;; )
    {
        yyn = yypact_[ yystate ];
        if ( !yy_pact_value_is_default_( yyn ) )
        {
            yyn += yyterror_;
            if ( 0 <= yyn && yyn <= yylast_ && yycheck_[ yyn ] == yyterror_ )
            {
                yyn = yytable_[ yyn ];
                if ( 0 < yyn )
                {
                    break;
                }
            }
        }

        /* Pop the current state because it cannot handle the error token.  */
        if ( yystate_stack_.height() == 1 )
        {
            YYABORT;
        }

        yyerror_range[ 1 ] = yylocation_stack_[ 0 ];
        yydestruct_( "Error: popping",
                     yystos_[ yystate ],
                     &yysemantic_stack_[ 0 ], &yylocation_stack_[ 0 ] );
        yypop_();
        yystate = yystate_stack_[ 0 ];
        YY_STACK_PRINT();
    }

    yyerror_range[ 2 ] = yylloc;
    // Using YYLLOC is tempting, but would change the location of
    // the lookahead.  YYLOC is available though.
    YYLLOC_DEFAULT( yyloc, yyerror_range, 2 );
    yysemantic_stack_.push( yylval );
    yylocation_stack_.push( yyloc );

    /* Shift the error token.  */
    YY_SYMBOL_PRINT( "Shifting", yystos_[ yyn ],
                     &yysemantic_stack_[ 0 ], &yylocation_stack_[ 0 ] );

    yystate = yyn;
    goto yynewstate;

    /* Accept.  */
yyacceptlab:
    yyresult = 0;
    goto yyreturn;

    /* Abort.  */
yyabortlab:
    yyresult = 1;
    goto yyreturn;

yyreturn:
    if ( yychar != yyempty_ )
    {
        /* Make sure we have latest lookahead translation.  See comments
           at user semantic actions for why this is necessary.  */
        yytoken = yytranslate_( yychar );
        yydestruct_( "Cleanup: discarding lookahead", yytoken, &yylval,
                     &yylloc );
    }

    /* Do not reclaim the symbols of the rule which action triggered
       this YYABORT or YYACCEPT.  */
    yypop_( yylen );
    while ( yystate_stack_.height() != 1 )
    {
        yydestruct_( "Cleanup: popping",
                     yystos_[ yystate_stack_[ 0 ] ],
                     &yysemantic_stack_[ 0 ],
                     &yylocation_stack_[ 0 ] );
        yypop_();
    }

    return yyresult;
}

// Generate an error message.
std::string
Parser::yysyntax_error_( int yystate, int yytoken )
{
    std::string yyres;
    // Number of reported tokens (one for the "unexpected", one per
    // "expected").
    size_t yycount = 0;
    // Its maximum.
    enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
    // Arguments of yyformat.
    char const* yyarg[ YYERROR_VERBOSE_ARGS_MAXIMUM ];

    /* There are many possibilities here to consider:
       - If this state is a consistent state with a default action, then
         the only way this function was invoked is if the default action
         is an error action.  In that case, don't check for expected
         tokens because there are none.
       - The only way there can be no lookahead present (in yytoken) is
         if this state is a consistent state with a default action.
         Thus, detecting the absence of a lookahead is sufficient to
         determine that there is no unexpected or expected token to
         report.  In that case, just report a simple "syntax error".
       - Don't assume there isn't a lookahead just because this state is
         a consistent state with a default action.  There might have
         been a previous inconsistent state, consistent state with a
         non-default action, or user semantic action that manipulated
         yychar.
       - Of course, the expected token list depends on states to have
         correct lookahead information, and it depends on the parser not
         to perform extra reductions after fetching a lookahead from the
         scanner and before detecting a syntax error.  Thus, state
         merging (from LALR or IELR) and default reductions corrupt the
         expected token list.  However, the list is correct for
         canonical LR with one exception: it will still contain any
         token that will not be accepted due to an error action in a
         later state.
     */
    if ( yytoken != yyempty_ )
    {
        yyarg[ yycount++ ] = yytname_[ yytoken ];
        int yyn = yypact_[ yystate ];
        if ( !yy_pact_value_is_default_( yyn ) )
        {
            /* Start YYX at -YYN if negative to avoid negative indexes in
               YYCHECK.  In other words, skip the first -YYN actions for
               this state because they are default actions.  */
            int yyxbegin = yyn < 0 ? -yyn : 0;
            /* Stay within bounds of both yycheck and yytname.  */
            int yychecklim = yylast_ - yyn + 1;
            int yyxend     = yychecklim < yyntokens_ ? yychecklim : yyntokens_;
            for ( int yyx = yyxbegin; yyx < yyxend; ++yyx )
            {
                if ( yycheck_[ yyx + yyn ] == yyx && yyx != yyterror_
                     && !yy_table_value_is_error_( yytable_[ yyx + yyn ] ) )
                {
                    if ( yycount == YYERROR_VERBOSE_ARGS_MAXIMUM )
                    {
                        yycount = 1;
                        break;
                    }
                    else
                    {
                        yyarg[ yycount++ ] = yytname_[ yyx ];
                    }
                }
            }
        }
    }

    char const* yyformat = 0;
    switch ( yycount )
    {
#define YYCASE_( N, S )                         \
    case N:                               \
        yyformat = S;                       \
        break
        YYCASE_( 0, YY_( "syntax error" ) );
        YYCASE_( 1, YY_( "syntax error, unexpected %s" ) );
        YYCASE_( 2, YY_( "syntax error, unexpected %s, expecting %s" ) );
        YYCASE_( 3, YY_( "syntax error, unexpected %s, expecting %s or %s" ) );
        YYCASE_( 4, YY_( "syntax error, unexpected %s, expecting %s or %s or %s" ) );
        YYCASE_( 5, YY_( "syntax error, unexpected %s, expecting %s or %s or %s or %s" ) );
#undef YYCASE_
    }

    // Argument number.
    size_t yyi = 0;
    for ( char const* yyp = yyformat; *yyp; ++yyp )
    {
        if ( yyp[ 0 ] == '%' && yyp[ 1 ] == 's' && yyi < yycount )
        {
            yyres += yytnamerr_( yyarg[ yyi++ ] );
            ++yyp;
        }
        else
        {
            yyres += *yyp;
        }
    }
    return yyres;
}


/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
const short int Parser::yypact_ninf_ = -159;
const short int
Parser::                yypact_[] =
{
    6,    13,    11,    -159,  127,   127,   -159,  4,     15,    127,
    -159, -159,  -159,  -159,  -159,  -159,  -159,  -159,  -159,  -159,
    -159, -159,  -159,  -159,  -159,  -159,  -159,  -159,  16,    -44,
    -40,  -159,  294,   -159,  -159,  -159,  -159,  -159,  -159,  -159,
    -159, -159,  -159,  26,    -159,  64,    -159,  -159,  -159,  -159,
    -159, 235,   -159,  -159,  -159,  -159,  -159,  -159,  137,   302,
    8,    8,     166,   8,     73,    81,    -159,  127,   127,   127,
    127,  127,   127,   127,   85,    105,   126,   128,   100,   59,
    67,   75,    152,   120,   -159,  -159,  -159,  162,   -159,  -159,
    139,  -159,  -159,  -159,  -159,  -159,  -159,  -159,  -159,  -159,
    -159, -159,  177,   180,   -159,  179,   46,    52,    137,   137,
    168,  168,   -159,  319,   53,    8,     8,     200,   200,   8,
    195,  202,   195,   127,   198,   235,   -159,  199,   235,   127,
    -159, -159,  231,   -159,  -159,  -159,  -159,  1,     -159,  2,
    -159, 127,   211,   240,   200,   243,   -159,  -159,  244,   245,
    -159, 268,   62,    -159,  -159,  -159,  -159,  -159,  -159,  -159,
    -159, -159,  -159,  -159,  -159,  -159,  -159,  -159,  -159,  -35,
    -159, -159,  -159,  -159,  134,   121,   248,   185,   -159,  -57,
    -159, 99,    -159,  -159,  162,   -159,  249,   279,   127,   -159,
    130,  -159,  130,   326,   -159,  -159,  241,   124,   200,   22,
    22,   127,   127,   127,   127,   127,   127,   -159,  200,   200,
    200,  22,    22,    188,   162,   267,   -159,  -159,  280,   281,
    -159, -159,  -159,  104,   301,   303,   -159,  -159,  138,   304,
    -159, 307,   279,   279,   279,   279,   279,   279,   -159,  -159,
    -159, -159,  -159,  -159,  -159,  -159,  127,   195,   195,   -159,
    -159, -159,  -159,  -159,  -159,  210,   -159,  -159,  -159
};

/* YYDEFACT[S] -- default reduction number in state S.  Performed when
   YYTABLE doesn't specify something else to do.  Zero means the
   default is an error.  */
const unsigned char
Parser::yydefact_[] =
{
    0,   0,     0,     3,     0,     0,     104,   0,     0,     0,
    71,  72,    73,    74,    75,    78,    79,    76,    77,    81,
    80,  82,    83,    84,    85,    86,    88,    89,    0,     0,
    0,   90,    0,     4,     5,     6,     7,     8,     9,     10,
    11,  12,    68,    0,     69,    0,     13,    14,    91,    92,
    15,  105,   16,    137,   138,   17,    18,    1,     26,    0,
    0,   0,     0,     0,     0,     0,     2,     0,     0,     0,
    0,   0,     0,     0,     0,     0,     0,     0,     0,     0,
    0,   0,     0,     0,     107,   114,   115,   0,     108,   109,
    0,   124,   125,   112,   128,   129,   130,   113,   110,   111,
    19,  145,   0,     0,     20,    0,     0,     0,     21,    22,
    24,  23,    25,    0,     0,     0,     0,     0,     0,     0,
    0,   0,     0,     0,     0,     105,   121,   116,   105,   0,
    141, 142,   139,   93,    99,    100,   101,   0,     96,    0,
    70,  0,     0,     0,     0,     0,     45,    46,    0,     0,
    63,  0,     0,     27,    34,    35,    36,    37,    38,    28,
    29,  30,    31,    32,    33,    39,    53,    54,    55,    0,
    61,  62,    64,    65,    16,    0,     0,     0,     131,   0,
    136, 0,     102,   106,   0,     117,   0,     123,   0,     94,
    0,   97,    0,     0,     143,   144,   0,     0,     0,     0,
    0,   0,     0,     0,     0,     0,     0,     118,   0,     0,
    0,   0,     0,     0,     0,     126,   135,   134,   0,     0,
    103, 119,   120,   0,     0,     0,     87,    40,    0,     0,
    60,  0,     49,    47,    51,    52,    48,    50,    42,    43,
    44,  56,    57,    59,    58,    122,   0,     0,     0,     140,
    95,  98,    41,    66,    67,    0,     132,   133,   127
};

/* YYPGOTO[NTERM-NUM].  */
const short int
Parser::yypgoto_[] =
{
    -159, -159,  -1,    -159,  -159,  -159,  -159,  -159,  -159,  -159,
    -159, -116,  -159,  -159,  -159,  -159,  -159,  -159,  -159,  -159,
    -159, -159,  -159,  -159,  -159,  -159,  -159,  -159,  -159,  71,
    -159, -159,  -159,  -159,  -159,  -159,  -159,  -159,  -159,  -159,
    -159, -159,  -159,  -89,   -159,  -159,  -159,  -118,  -159,  -159,
    -159, -159,  -159,  -159,  -158,  -159,  -159,  -159,  -159,  -159,
    -159, -159,  -159,  -159,  -159,  -121,  -159,  -159,  -112,  -159,
    -159, -159,  -159,  -159,  -159,  -39
};

/* YYDEFGOTO[NTERM-NUM].  */
const short int
Parser::yydefgoto_[] =
{
    -1,  2,     151,   33,    34,    35,    36,    37,    38,    39,
    40,  152,   153,   154,   155,   156,   157,   158,   159,   160,
    161, 162,   163,   164,   165,   166,   167,   168,   244,   169,
    170, 171,   172,   173,   41,    42,    43,    44,    45,    46,
    47,  48,    49,    137,   50,    124,   51,    82,    83,    84,
    85,  86,    87,    185,   127,   128,   88,    89,    90,    91,
    92,  93,    94,    95,    96,    178,   217,   97,    52,    53,
    54,  55,    56,    98,    99,    102
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If YYTABLE_NINF_, syntax error.  */
const signed char Parser::yytable_ninf_ = -61;
const short int
Parser::                  yytable_[] =
{
    32,  180,   175,   58,    59,    174,   174,   183,   62,    1,
    186, 57,    189,   191,   60,    211,   212,   3,     139,   4,
    218, 219,   103,   5,     105,   61,    221,   6,     197,   213,
    63,  64,    174,   7,     8,     65,    72,    9,     10,    11,
    12,  13,    14,    15,    16,    17,    18,    19,    20,    21,
    22,  23,    24,    25,    26,    27,    245,   133,   67,    68,
    69,  70,    71,    138,   190,   192,   108,   109,   110,   111,
    112, 113,   114,   207,   73,    28,    142,   143,   29,    30,
    176, 101,   228,   106,   28,    31,    174,   230,   230,   148,
    149, 107,   238,   239,   240,   115,   174,   174,   174,   230,
    230, 224,   150,   225,   67,    68,    69,    70,    71,    67,
    68,  69,    70,    71,    119,   116,   141,   249,   220,   208,
    209, 210,   181,   134,   135,   136,   256,   257,   187,   134,
    135, 136,   214,   4,     120,   227,   117,   5,     118,   125,
    193, 6,     121,   196,   69,    70,    71,    7,     8,     252,
    122, 9,     10,    11,    12,    13,    14,    15,    16,    17,
    18,  19,    20,    21,    22,    23,    24,    25,    26,    27,
    123, 67,    68,    69,    70,    71,    126,   71,    208,   209,
    210, 208,   209,   210,   -60,   -60,   129,   223,   130,   28,
    104, 131,   29,    30,    132,   208,   209,   210,   -60,   31,
    232, 233,   234,   235,   236,   237,   4,     134,   135,   136,
    144, 177,   179,   182,   6,     67,    68,    69,    70,    71,
    7,   8,     194,   258,   9,     10,    11,    12,    13,    14,
    15,  16,    17,    18,    19,    20,    21,    22,    23,    24,
    25,  26,    27,    188,   184,   255,   67,    68,    69,    70,
    71,  195,   100,   198,   199,   200,   145,   74,    75,    216,
    146, 147,   28,    215,   222,   29,    30,    148,   149,   243,
    229, 231,   31,    67,    68,    69,    70,    71,    76,    246,
    150, 77,    241,   242,   67,    68,    69,    70,    71,    201,
    202, 247,   248,   203,   204,   205,   206,   78,    66,    67,
    68,  69,    70,    71,    79,    80,    81,    67,    68,    69,
    70,  71,    250,   100,   251,   253,   201,   202,   254,   0,
    203, 204,   205,   206,   67,    68,    69,    70,    71,    0,
    140, 67,    68,    69,    70,    71,    0,     226
};

/* YYCHECK.  */
const short int
Parser::yycheck_[] =
{
    1,   122,   118,   4,     5,     117,   118,   125,   9,     3,
    128, 0,     11,    11,    10,    50,    51,    4,     107,   6,
    77,  78,    61,    10,    63,    10,    184,   14,    144,   64,
    14,  75,    144,   20,    21,    75,    10,    24,    25,    26,
    27,  28,    29,    30,    31,    32,    33,    34,    35,    36,
    37,  38,    39,    40,    41,    42,    214,   11,    5,     6,
    7,   8,     9,     11,    63,    63,    67,    68,    69,    70,
    71,  72,    73,    11,    10,    62,    115,   116,   65,    66,
    119, 73,    198,   10,    62,    72,    198,   199,   200,   67,
    68,  10,    208,   209,   210,   10,    208,   209,   210,   211,
    212, 190,   80,    192,   5,     6,     7,     8,     9,     5,
    6,   7,     8,     9,     14,    10,    63,    13,    19,    57,
    58,  59,    123,   77,    78,    79,    247,   248,   129,   77,
    78,  79,    11,    6,     75,    11,    10,    10,    10,    19,
    141, 14,    75,    144,   7,     8,     9,     20,    21,    11,
    75,  24,    25,    26,    27,    28,    29,    30,    31,    32,
    33,  34,    35,    36,    37,    38,    39,    40,    41,    42,
    18,  5,     6,     7,     8,     9,     14,    9,     57,    58,
    59,  57,    58,    59,    50,    51,    47,    188,   11,    62,
    24,  11,    65,    66,    15,    57,    58,    59,    64,    72,
    201, 202,   203,   204,   205,   206,   6,     77,    78,    79,
    10,  16,    10,    15,    14,    5,     6,     7,     8,     9,
    20,  21,    11,    13,    24,    25,    26,    27,    28,    29,
    30,  31,    32,    33,    34,    35,    36,    37,    38,    39,
    40,  41,    42,    12,    45,    246,   5,     6,     7,     8,
    9,   11,    11,    10,    10,    10,    56,    22,    23,    74,
    60,  61,    62,    15,    15,    65,    66,    67,    68,    81,
    199, 200,   72,    5,     6,     7,     8,     9,     43,    12,
    80,  46,    211,   212,   5,     6,     7,     8,     9,     48,
    49,  11,    11,    52,    53,    54,    55,    62,    4,     5,
    6,   7,     8,     9,     69,    70,    71,    5,     6,     7,
    8,   9,     11,    11,    11,    11,    48,    49,    11,    -1,
    52,  53,    54,    55,    5,     6,     7,     8,     9,     -1,
    11,  5,     6,     7,     8,     9,     -1,    11
};

/* STOS_[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
const unsigned char
Parser::yystos_[] =
{
    0,   3,     85,    4,     6,     10,    14,    20,    21,    24,
    25,  26,    27,    28,    29,    30,    31,    32,    33,    34,
    35,  36,    37,    38,    39,    40,    41,    42,    62,    65,
    66,  72,    86,    87,    88,    89,    90,    91,    92,    93,
    94,  118,   119,   120,   121,   122,   123,   124,   125,   126,
    128, 130,   152,   153,   154,   155,   156,   0,     86,    86,
    10,  10,    86,    14,    75,    75,    4,     5,     6,     7,
    8,   9,     10,    10,    22,    23,    43,    46,    62,    69,
    70,  71,    131,   132,   133,   134,   135,   136,   140,   141,
    142, 143,   144,   145,   146,   147,   148,   151,   157,   158,
    11,  73,    159,   159,   24,    159,   10,    10,    86,    86,
    86,  86,    86,    86,    86,    10,    10,    10,    10,    14,
    75,  75,    75,    18,    129,   19,    14,    138,   139,   47,
    11,  11,    15,    11,    77,    78,    79,    127,   11,    127,
    11,  63,    159,   159,   10,    56,    60,    61,    67,    68,
    80,  86,    95,    96,    97,    98,    99,    100,   101,   102,
    103, 104,   105,   106,   107,   108,   109,   110,   111,   113,
    114, 115,   116,   117,   152,   95,    159,   16,    149,   10,
    149, 86,    15,    131,   45,    137,   131,   86,    12,    11,
    63,  11,    63,    86,    11,    11,    86,    95,    10,    10,
    10,  48,    49,    52,    53,    54,    55,    11,    57,    58,
    59,  50,    51,    64,    11,    15,    74,    150,   77,    78,
    19,  138,   15,    86,    127,   127,   11,    11,    95,    113,
    152, 113,   86,    86,    86,    86,    86,    86,    95,    95,
    95,  113,   113,   81,    112,   138,   12,    11,    11,    13,
    11,  11,    11,    11,    11,    86,    149,   149,   13
};

#if YYDEBUG
/* TOKEN_NUMBER_[YYLEX-NUM] -- Internal symbol number corresponding
   to YYLEX-NUM.  */
const unsigned short int
Parser::yytoken_number_[] =
{
    0,   256,   601,   602,   603,   604,   605,   606,   607,   608,
    609, 610,   611,   612,   613,   614,   615,   616,   617,   618,
    619, 620,   621,   622,   623,   624,   625,   626,   627,   628,
    629, 630,   631,   632,   633,   634,   635,   636,   637,   638,
    639, 640,   641,   642,   643,   644,   645,   646,   647,   648,
    649, 650,   651,   652,   653,   654,   655,   656,   657,   658,
    659, 660,   661,   662,   663,   664,   665,   666,   667,   668,
    669, 670,   100,   200,   210,   300,   301,   671,   672,   600,
    400, 500,   673,   674
};
#endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
const unsigned char
Parser::yyr1_[] =
{
    0,   84,    85,    85,    86,    86,    86,    86,    86,    86,
    86,  86,    86,    86,    86,    86,    86,    86,    86,    87,
    88,  89,    90,    91,    92,    93,    94,    95,    95,    95,
    95,  95,    95,    95,    95,    95,    95,    95,    95,    95,
    96,  96,    97,    98,    99,    100,   101,   102,   103,   104,
    105, 106,   107,   108,   108,   108,   109,   110,   111,   112,
    113, 113,   113,   114,   115,   115,   116,   117,   118,   118,
    119, 120,   120,   120,   120,   120,   120,   120,   120,   120,
    120, 120,   120,   120,   120,   120,   120,   121,   122,   122,
    123, 124,   124,   125,   125,   125,   126,   126,   126,   127,
    127, 127,   128,   129,   130,   131,   131,   132,   132,   132,
    132, 132,   132,   132,   133,   133,   134,   135,   136,   137,
    138, 139,   140,   141,   142,   142,   143,   144,   145,   145,
    145, 146,   147,   148,   149,   150,   151,   152,   152,   153,
    154, 155,   156,   157,   158,   159
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
const unsigned char
Parser::yyr2_[] =
{
    0, 2,     3,     2,     1,     1,     1,     1,     1,     1,
    1, 1,     1,     1,     1,     1,     1,     1,     1,     3,
    3, 3,     3,     3,     3,     3,     2,     1,     1,     1,
    1, 1,     1,     1,     1,     1,     1,     1,     1,     1,
    3, 4,     3,     3,     3,     1,     1,     3,     3,     3,
    3, 3,     3,     1,     1,     1,     3,     3,     3,     1,
    1, 1,     1,     1,     1,     1,     4,     4,     1,     1,
    4, 1,     1,     1,     1,     1,     1,     1,     1,     1,
    1, 1,     1,     1,     1,     1,     1,     6,     1,     1,
    1, 1,     1,     4,     5,     7,     4,     5,     7,     1,
    1, 1,     4,     3,     1,     0,     3,     1,     1,     1,
    1, 1,     1,     1,     1,     1,     2,     3,     4,     2,
    3, 1,     5,     3,     1,     1,     4,     7,     1,     1,
    1, 3,     6,     6,     2,     1,     3,     1,     1,     4,
    7, 4,     4,     4,     4,     1
};

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at \a yyntokens_, nonterminals.  */
const char*
const Parser::yytname_[] =
{
    "\"end of file\"",                          "error",                             "$undefined",                       "\"<cubepl>\"",
    "\"</cubepl>\"",                            "\"+\"",                             "\"-\"",                            "\"*\"",              "\"/\"",             "\"^\"",     "\"(\"",
    "\")\"",                                    "\"[\"",                             "\"]\"",                            "\"{\"",              "\"}\"",             "\"<<\"",    "\">>\"",
    "\"return\"",                               "\";\"",                             "\"sizeof\"",                       "\"defined\"",        "\"local\"",
    "\"global\"",                               "\"|\"",                             "\"sqrt\"",                         "\"sin\"",            "\"asin\"",          "\"cos\"",
    "\"acos\"",                                 "\"tan\"",                           "\"atan\"",                         "\"exp\"",            "\"log\"",           "\"abs\"",
    "\"random\"",                               "\"sgn\"",                           "\"pos\"",                          "\"neg\"",            "\"floor\"",         "\"ceil\"",
    "\"min\"",                                  "\"max\"",                           "\"if\"",                           "\"elseif\"",         "\"else\"",          "\"while\"",
    "\"=\"",                                    "\">\"",                             "\"==\"",                           "\"eq\"",             "\"seq\"",           "\">=\"",    "\"<=\"",
    "\"!=\"",                                   "\"<\"",                             "\"not\"",                          "\"and\"",            "\"or\"",            "\"xor\"",   "\"true\"",
    "\"false\"",                                "\"$\"",                             "\",\"",                            "\"=~\"",             "\"metric::\"",
    "\"metric::fixed::\"",                      "\"lowercase\"",                     "\"uppercase\"",
    "\"cube::metric::postderived::\"",          "\"cube::metric::prederived::\"",
    "\"cube::init::metric::\"",                 "CONSTANT",                          "STRING_CONSTANT",                  "STRING_TEXT",
    "METRIC_NAME",                              "INIT_METRIC_NAME",                  "\"i\"",                            "\"e\"",              "SAME_MODIFICATOR",
    "QUOTED_STRING",                            "REGEXP_STRING",                     "FUNC2",                            "SIGN",               "$accept",           "document",
    "expression",                               "enclosed_expression",               "absolute_value",                   "sum",
    "substract",                                "division",                          "multiplication",                   "power",              "negation",
    "boolean_expression",                       "enclosed_boolean_expression",       "and_expression",
    "or_expression",                            "xor_expression",                    "true_expression",                  "false_expression",
    "equality",                                 "not_equality",                      "bigger",                           "smaller",            "halfbigger",
    "halfsmaller",                              "string_operation",                  "string_equality",
    "string_semi_equality",                     "regexp",                            "regexp_expression",
    "string_expression",                        "quoted_string",                     "string_function",                  "lowercase",
    "uppercase",                                "function_call",                     "one_variable_function",            "function_name",
    "two_variables_function",                   "function2_name",                    "constant",                         "metric_refs",
    "context_metric",                           "fixed_metric",                      "calculationFlavourModificator",
    "lambda_calcul",                            "return_expression",                 "lambda_start",
    "list_of_statements",                       "statement",                         "if_statement",                     "simple_if_statement",
    "full_if_statement",                        "if_condition",                      "else_enclosed_list_of_statements",
    "enclosed_list_of_statements",              "enclosed_list_of_statements_start",
    "while_statement",                          "assignment",                        "assignment_target",                "put_variable",
    "put_variable_indexed",                     "create_ghost_metric",
    "create_postderived_ghost_metric",
    "create_prederived_inclusive_ghost_metric",
    "create_prederived_exclusive_ghost_metric", "GhostMetricDefinition",
    "CubePLGhostText",                          "init_metric",                       "get_variable",                     "get_variable_simple",
    "get_variable_indexed",                     "sizeof_variable",                   "defined_variable",
    "local_variable",                           "global_variable",                   "string_constant",                  0
};
#endif

#if YYDEBUG
/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
const Parser::rhs_number_type
Parser::yyrhs_[] =
{
    85,  0,     -1,    3,     86,    4,     -1,    3,     4,     -1,
    87,  -1,    88,    -1,    89,    -1,    90,    -1,    91,    -1,
    92,  -1,    93,    -1,    94,    -1,    118,   -1,    123,   -1,
    124, -1,    128,   -1,    152,   -1,    155,   -1,    156,   -1,
    10,  86,    11,    -1,    24,    86,    24,    -1,    86,    5,
    86,  -1,    86,    6,     86,    -1,    86,    8,     86,    -1,
    86,  7,     86,    -1,    86,    9,     86,    -1,    6,     86,
    -1,  96,    -1,    102,   -1,    103,   -1,    104,   -1,    105,
    -1,  106,   -1,    107,   -1,    97,    -1,    98,    -1,    99,
    -1,  100,   -1,    101,   -1,    108,   -1,    10,    95,    11,
    -1,  56,    10,    95,    11,    -1,    95,    57,    95,    -1,
    95,  58,    95,    -1,    95,    59,    95,    -1,    60,    -1,
    61,  -1,    86,    49,    86,    -1,    86,    54,    86,    -1,
    86,  48,    86,    -1,    86,    55,    86,    -1,    86,    52,
    86,  -1,    86,    53,    86,    -1,    109,   -1,    110,   -1,
    111, -1,    113,   50,    113,   -1,    113,   51,    113,   -1,
    113, 64,    112,   -1,    81,    -1,    152,   -1,    114,   -1,
    115, -1,    80,    -1,    116,   -1,    117,   -1,    67,    10,
    113, 11,    -1,    68,    10,    113,   11,    -1,    119,   -1,
    121, -1,    120,   10,    86,    11,    -1,    25,    -1,    26,
    -1,  27,    -1,    28,    -1,    29,    -1,    32,    -1,    33,
    -1,  30,    -1,    31,    -1,    35,    -1,    34,    -1,    36,
    -1,  37,    -1,    38,    -1,    39,    -1,    40,    -1,    122,
    10,  86,    63,    86,    11,    -1,    41,    -1,    42,    -1,
    72,  -1,    125,   -1,    126,   -1,    65,    75,    10,    11,
    -1,  65,    75,    10,    127,   11,    -1,    65,    75,    10,
    127, 63,    127,   11,    -1,    66,    75,    10,    11,    -1,
    66,  75,    10,    127,   11,    -1,    66,    75,    10,    127,
    63,  127,   11,    -1,    77,    -1,    78,    -1,    79,    -1,
    130, 131,   129,   15,    -1,    18,    86,    19,    -1,    14,
    -1,  -1,    132,   19,    131,   -1,    133,   -1,    140,   -1,
    141, -1,    157,   -1,    158,   -1,    145,   -1,    151,   -1,
    134, -1,    135,   -1,    136,   138,   -1,    136,   138,   137,
    -1,  43,    10,    95,    11,    -1,    45,    138,   -1,    139,
    131, 15,    -1,    14,    -1,    46,    10,    95,    11,    138,
    -1,  142,   47,    86,    -1,    143,   -1,    144,   -1,    62,
    14,  159,   15,    -1,    62,    14,    159,   15,    12,    86,
    13,  -1,    146,   -1,    147,   -1,    148,   -1,    69,    75,
    149, -1,    70,    75,    10,    77,    11,    149,   -1,    70,
    75,  10,    78,    11,    149,   -1,    16,    150,   -1,    74,
    -1,  71,    75,    149,   -1,    153,   -1,    154,   -1,    62,
    14,  159,   15,    -1,    62,    14,    159,   15,    12,    86,
    13,  -1,    20,    10,    159,   11,    -1,    21,    10,    159,
    11,  -1,    22,    10,    159,   11,    -1,    23,    10,    159,
    11,  -1,    73,    -1
};

/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
const unsigned short int
Parser::yyprhs_[] =
{
    0,   0,     3,     7,     10,    12,    14,    16,    18,    20,
    22,  24,    26,    28,    30,    32,    34,    36,    38,    40,
    44,  48,    52,    56,    60,    64,    68,    71,    73,    75,
    77,  79,    81,    83,    85,    87,    89,    91,    93,    95,
    97,  101,   106,   110,   114,   118,   120,   122,   126,   130,
    134, 138,   142,   146,   148,   150,   152,   156,   160,   164,
    166, 168,   170,   172,   174,   176,   178,   183,   188,   190,
    192, 197,   199,   201,   203,   205,   207,   209,   211,   213,
    215, 217,   219,   221,   223,   225,   227,   229,   236,   238,
    240, 242,   244,   246,   251,   257,   265,   270,   276,   284,
    286, 288,   290,   295,   299,   301,   302,   306,   308,   310,
    312, 314,   316,   318,   320,   322,   324,   327,   331,   336,
    339, 343,   345,   351,   355,   357,   359,   364,   372,   374,
    376, 378,   382,   389,   396,   399,   401,   405,   407,   409,
    414, 422,   427,   432,   437,   442
};

/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
const unsigned short int
Parser::yyrline_[] =
{
    0,    287,   287,   296,   303,   304,   305,   306,   307,   308,
    309,  310,   311,   312,   313,   314,   315,   316,   317,   321,
    331,  344,   357,   371,   384,   400,   412,   426,   427,   428,
    429,  430,   431,   432,   433,   434,   435,   436,   437,   438,
    442,  452,   463,   476,   490,   503,   511,   520,   534,   548,
    561,  575,   589,   605,   606,   607,   612,   625,   637,   652,
    672,  673,   674,   680,   691,   691,   696,   707,   721,   721,
    723,  737,   745,   753,   761,   769,   777,   785,   793,   801,
    809,  817,   825,   833,   841,   849,   857,   868,   884,   892,
    903,  914,   914,   919,   938,   959,   986,   1005,  1032,  1070,
    1078, 1086,  1097,  1127,  1129,  1138,  1140,  1146,  1157,  1168,
    1179, 1183,  1187,  1188,  1191,  1192,  1195,  1222,  1261,  1264,
    1267, 1270,  1280,  1309,  1325,  1325,  1328,  1338,  1342,  1343,
    1344, 1348,  1391,  1433,  1477,  1480,  1486,  1520,  1533,  1548,
    1557, 1561,  1573,  1583,  1592,  1602
};

// Print the state stack on the debug stream.
void
Parser::yystack_print_()
{
    *yycdebug_ << "Stack now";
    for ( state_stack_type::const_iterator i = yystate_stack_.begin();
          i != yystate_stack_.end(); ++i )
    {
        *yycdebug_ << ' ' << *i;
    }
    *yycdebug_ << std::endl;
}

// Report on the debug stream that the rule \a yyrule is going to be reduced.
void
Parser::yy_reduce_print_( int yyrule )
{
    unsigned int yylno  = yyrline_[ yyrule ];
    int          yynrhs = yyr2_[ yyrule ];
    /* Print the symbols being reduced, and their result.  */
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):" << std::endl;
    /* The symbols being reduced.  */
    for ( int yyi = 0; yyi < yynrhs; yyi++ )
    {
        YY_SYMBOL_PRINT( "   $" << yyi + 1 << " =",
                         yyrhs_[ yyprhs_[ yyrule ] + yyi ],
                         &( yysemantic_stack_[ ( yynrhs ) - ( yyi + 1 ) ] ),
                         &( yylocation_stack_[ ( yynrhs ) - ( yyi + 1 ) ] ) );
    }
}
#endif // YYDEBUG

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
Parser::token_number_type
Parser::yytranslate_( int t )
{
    static
    const token_number_type
        translate_table[] =
    {
        0,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        72, 2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        73, 2,     2,     2,     2,     2,     2,     2,     2,     2,
        74, 2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     1,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        75, 76,    2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        80, 2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        81, 2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,  2,     2,     2,     2,     2,     2,     2,     2,     2,
        79, 2,     3,     4,     5,     6,     7,     8,     9,     10,
        11, 12,    13,    14,    15,    16,    17,    18,    19,    20,
        21, 22,    23,    24,    25,    26,    27,    28,    29,    30,
        31, 32,    33,    34,    35,    36,    37,    38,    39,    40,
        41, 42,    43,    44,    45,    46,    47,    48,    49,    50,
        51, 52,    53,    54,    55,    56,    57,    58,    59,    60,
        61, 62,    63,    64,    65,    66,    67,    68,    69,    70,
        71, 77,    78,    82,    83
    };
    if ( ( unsigned int )t <= yyuser_token_number_max_ )
    {
        return translate_table[ t ];
    }
    else
    {
        return yyundef_token_;
    }
}

const int Parser::                      yyeof_     = 0;
const int Parser::                      yylast_    = 337;
const int Parser::                      yynnts_    = 76;
const int Parser::                      yyempty_   = -2;
const int Parser::                      yyfinal_   = 57;
const int Parser::                      yyterror_  = 1;
const int Parser::                      yyerrcode_ = 256;
const int Parser::                      yyntokens_ = 84;

const unsigned int Parser::             yyuser_token_number_max_ = 674;
const Parser::token_number_type Parser::yyundef_token_           = 2;
} // cubeplparser

/* Line 1136 of lalr1.cc  */
#line 2840 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.cpp"


/* Line 1138 of lalr1.cc  */
#line 1608 "../../build-backend/../src/cube/src/syntax/cubepl/CubePL1Parser.yy"
/*** Additional Code ***/


void
cubeplparser::Parser::error( const Parser::location_type& l,
                             const std::string&           m )
{
    Parser::location_type _l = l;


    _l.end.column   = ( _l.end.column < 9 ) ? 1 : _l.end.column - 8;
    _l.begin.column = _l.end.column - 1;

    parseContext.syntax_ok = false;
    stringstream sstr;
    string str;
    sstr << _l;
    sstr >> str;
    parseContext.error_message = str + ":" + m;
    parseContext.error_place   = _l;

/*   if (strstr(m.c_str(),"expecting <?xml")!=NULL) {
     driver.error_just_message("The cube file is probably empty or filled with wrong content. The file has ended before the header of cube started. \n");
    }
   if (strstr(m.c_str()," expecting </row>")!=NULL) {
     driver.error_just_message("One of the possible reasons is \n    1) that the severity value is malformed. CUBE expects the \"double\" value in C_LOCALE with dot instead of comma;. \n    2) that the CUBE file is not properly ended. Probably the writing of CUBE file was interrupted.");
    }
   if (strstr(m.c_str()," expecting <matrix")!=NULL ||
        (strstr(m.c_str()," expecting <severity>")!=NULL) ) {
     driver.error_just_message("The cube file has probably a proper structure, but doesn't contain any severity values.");
    }
   if (strstr(m.c_str()," expecting <metric")!=NULL) {
     driver.error_just_message("The cube file doesn't contain any information about metric dimension.");
    }
   if (strstr(m.c_str()," expecting <region")!=NULL) {
     driver.error_just_message("The cube file doesn't contain any information about program dimension.");
    }
   if (strstr(m.c_str()," expecting <machine")!=NULL) {
     driver.error_just_message("The cube file doesn't contain any information about system dimension.");
    }
   if (strstr(m.c_str()," expecting <thread")!=NULL) {
     driver.error_just_message("The system dimension of the cube file is malformed. It contains a process without any threads.");
    }
   if (strstr(m.c_str()," expecting <process")!=NULL) {
     driver.error_just_message("The system dimension of the cube file is malformed. It contains a node without any processes.");
    }
   if (strstr(m.c_str()," expecting <node")!=NULL) {
     driver.error_just_message("The system dimension of the cube file is malformed. It contains a machine without any computing nodes.");
    }
      driver.error(l, m);
 */
}
