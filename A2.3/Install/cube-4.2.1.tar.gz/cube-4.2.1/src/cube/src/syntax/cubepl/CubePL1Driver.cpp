/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __CUBEPL1_DRIVER_CPP
#define __CUBEPL1_DRIVER_CPP 0

#include <vector>
#include <iostream>
#include <sstream>
#include <float.h>
#include <cmath>

#include "CubePL1Driver.h"
#include "CubePL1Parser.h"
#include "CubePL1Scanner.h"
#include "CubePL1ParseContext.h"
#include "CubePL1MemoryManager.h"




using namespace std;
using namespace cubeplparser;




CubePL1Driver::CubePL1Driver( Cube* _cube ) : cube( _cube )
{
};

CubePL1Driver::~CubePL1Driver()
{
};

GeneralEvaluation*
CubePL1Driver::compile( istream* strin, ostream* errs )
{
//  stringstream strin(cubepl_program);

    CubePL1ParseContext*   parseContext = new CubePL1ParseContext( cube );

    cubeplparser::Scanner* lexer  = new cubeplparser::Scanner( strin, errs, parseContext );
    cubeplparser::Parser*  parser = new cubeplparser::Parser( *parseContext, *lexer );
    parser->parse();
    GeneralEvaluation*     formula = parseContext->result;

    delete lexer;
    delete parser;
    delete parseContext;

    return formula;
};

bool
CubePL1Driver::test( std::string& cubepl_program, std::string & error_message )
{
    stringstream           strin( cubepl_program );
    stringstream           ssout;

    CubePL1ParseContext*   parseContext = new CubePL1ParseContext( NULL, true );
    cubeplparser::Scanner* lexer        = new cubeplparser::Scanner( &strin, &ssout, parseContext );
    cubeplparser::Parser*  parser       = new cubeplparser::Parser( *parseContext, *lexer );
    parser->parse();

    string error_output;
    ssout >> error_output;
    bool   _ok = parseContext->syntax_ok;

    if ( error_output.length() != 0 )
    {
        _ok                         = false;
        parseContext->error_message = "Scanner cannot recognize token: " + error_output;
    }

    if ( !_ok  )
    {
        error_message = parseContext->error_message;
    }

    delete parseContext->result;
    delete lexer;
    delete parser;
    delete parseContext;

    return _ok;
}

std::string
CubePL1Driver::printStatus()
{
    return "OK";
};



#endif
