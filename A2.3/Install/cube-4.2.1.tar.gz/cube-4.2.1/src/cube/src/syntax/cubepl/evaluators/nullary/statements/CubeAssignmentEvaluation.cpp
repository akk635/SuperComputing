/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __ASSIGNMENT_EVALUATION_CPP
#define __ASSIGNMENT_EVALUATION_CPP 0

#include "CubeAssignmentEvaluation.h"
// #include "CubePL1MemoryManager.h"

using namespace cube;

AssignmentEvaluation::~AssignmentEvaluation()
{
    delete value;
    delete index;
}

double
AssignmentEvaluation::eval()
{
    memory->put( variable, index->eval(), value->eval(), kind );
    return 0.;
}

/*
   double
   AssignmentEvaluation::eval( Cnode* cnode, CalculationFlavour cf, Thread* th, CalculationFlavour tf )
   {
    memory->put( variable, index->eval( cnode, cf, th, tf ), value->eval( cnode, cf, th, tf ), kind  );
    return 0.;
   };


   double
   AssignmentEvaluation::eval( Cnode* cnode, CalculationFlavour cf, Thread* th1, Thread* th2, CalculationFlavour tf  )
   {
    memory->put( variable, index->eval( cnode, cf, th1, th2, tf ), value->eval( cnode, cf, th1, th2, tf ), kind  );
    return 0.;
   };
 */

double
AssignmentEvaluation::eval( Cnode* cnode, CalculationFlavour cf, Sysres* sr, CalculationFlavour tf  )
{
    memory->put( variable, index->eval( cnode, cf, sr, tf ), value->eval( cnode, cf, sr, tf ), kind  );
    return 0.;
};

/*
   double
   AssignmentEvaluation::eval( Cnode* cnode, CalculationFlavour cf, Process* pr, CalculationFlavour tf  )
   {
    memory->put( variable, index->eval( cnode, cf, pr, tf ), value->eval( cnode, cf, pr, tf ), kind  );
    return 0.;
   };


   double
   AssignmentEvaluation::eval( Cnode* cnode, CalculationFlavour cf, Node* nd, CalculationFlavour tf )
   {
    memory->put( variable, index->eval( cnode, cf, nd, tf ), value->eval( cnode, cf, nd, tf ), kind  );
    return 0.;
   };


   double
   AssignmentEvaluation::eval( Cnode* cnode, CalculationFlavour cf, Machine* mch, CalculationFlavour tf  )
   {
    memory->put( variable, index->eval( cnode, cf, mch, tf ), value->eval( cnode, cf, mch, tf ), kind  );
    return 0.;
   };
 */

double
AssignmentEvaluation::eval( Cnode* cnode, CalculationFlavour cf )
{
    memory->put( variable, index->eval( cnode, cf ), value->eval( cnode, cf ), kind  );
    return 0.;
};

#endif
