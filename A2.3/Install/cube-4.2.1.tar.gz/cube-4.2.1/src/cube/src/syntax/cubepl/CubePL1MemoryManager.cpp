/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __CUBEPL1_MEMORY_MANAGER_CPP
#define __CUBEPL1_MEMORY_MANAGER_CPP 0

#include <vector>
#include <iostream>
#include <sstream>
#include <float.h>
#include <cmath>
#include <cstring>
#include <iomanip>
#include <string>

#include "CubePL1MemoryManager.h"
#include "CubeError.h"


using namespace std;
using namespace cube;


CubePL1MemoryManager::CubePL1MemoryManager()
{
    max_reserved_memory_size = 100;
    init();
    reserved_variables[ "cube::#mirrors" ]         = CUBE_NUM_MIRRORS;
    reserved_variables[ "cube::#metrics" ]         = CUBE_NUM_METRICS;
    reserved_variables[ "cube::#root::metrics" ]   = CUBE_NUM_ROOT_METRICS;
    reserved_variables[ "cube::#regions" ]         = CUBE_NUM_REGIONS;
    reserved_variables[ "cube::#callpaths" ]       = CUBE_NUM_CALLPATHS;
    reserved_variables[ "cube::#root::callpaths" ] = CUBE_NUM_ROOT_CALLPATHS;
    reserved_variables[ "cube::#locations" ]       = CUBE_NUM_LOCATIONS;
    reserved_variables[ "cube::#locationgroups" ]  = CUBE_NUM_LOCATION_GROUPS;
    reserved_variables[ "cube::#stns" ]            = CUBE_NUM_STNS;
    reserved_variables[ "cube::#rootstns" ]        = CUBE_NUM_ROOT_STNS;
    reserved_variables[ "cube::filename" ]         = CUBE_FILENAME;

    reserved_variables[ "cube::metric::uniq::name" ]     = CUBE_METRIC_UNIQ_NAME;
    reserved_variables[ "cube::metric::disp::name" ]     = CUBE_METRIC_DISP_NAME;
    reserved_variables[ "cube::metric::url" ]            = CUBE_METRIC_URL;
    reserved_variables[ "cube::metric::description" ]    = CUBE_METRIC_DESCRIPTION;
    reserved_variables[ "cube::metric::dtype" ]          = CUBE_METRIC_DTYPE;
    reserved_variables[ "cube::metric::uom" ]            = CUBE_METRIC_UOM;
    reserved_variables[ "cube::metric::expression" ]     = CUBE_METRIC_EXPRESSION;
    reserved_variables[ "cube::metric::initexpression" ] = CUBE_METRIC_INIT_EXPRESSION;
    reserved_variables[ "cube::metric::#children" ]      = CUBE_METRIC_NUM_CHILDREN;
    reserved_variables[ "cube::metric::parent::id" ]     = CUBE_METRIC_PARENT_ID;
    reserved_variables[ "cube::metric::children" ]       = CUBE_METRIC_CHILDREN;
    reserved_variables[ "cube::metric::enumeration" ]    = CUBE_METRIC_ENUMERATION;

    reserved_variables[ "cube::callpath::mod" ]         = CUBE_CALLPATH_MOD;
    reserved_variables[ "cube::callpath::line" ]        = CUBE_CALLPATH_LINE;
    reserved_variables[ "cube::callpath::#children" ]   = CUBE_CALLPATH_NUM_CHILDREN;
    reserved_variables[ "cube::callpath::children" ]    = CUBE_CALLPATH_CHILDREN;
    reserved_variables[ "cube::callpath::calleeid" ]    = CUBE_CALLPATH_CALLEE_ID;
    reserved_variables[ "cube::callpath::parent::id" ]  = CUBE_CALLPATH_PARENT_ID;
    reserved_variables[ "cube::callpath::enumeration" ] = CUBE_CALLPATH_ENUMERATION;


    reserved_variables[ "cube::region::name" ]        = CUBE_REGION_NAME;
    reserved_variables[ "cube::region::url" ]         = CUBE_REGION_URL;
    reserved_variables[ "cube::region::description" ] = CUBE_REGION_DESCRIPTION;
    reserved_variables[ "cube::region::mod" ]         = CUBE_REGION_MOD;
    reserved_variables[ "cube::region::begin::line" ] = CUBE_REGION_BEGIN_LINE;
    reserved_variables[ "cube::region::end::line" ]   = CUBE_REGION_END_LINE;

    reserved_variables[ "cube::stn::name" ]            = CUBE_STN_NAME;
    reserved_variables[ "cube::stn::description" ]     = CUBE_STN_DESCRIPTION;
    reserved_variables[ "cube::stn::class" ]           = CUBE_STN_CLASS;
    reserved_variables[ "cube::stn::#children" ]       = CUBE_STN_NUM_CHILDREN;
    reserved_variables[ "cube::stn::children" ]        = CUBE_STN_ENUMERATION;
    reserved_variables[ "cube::stn::#locationgroups" ] = CUBE_STN_NUM_LOCATION_GROUPS;
    reserved_variables[ "cube::stn::locationgroups" ]  = CUBE_STN_LOCATION_GROUPS;
    reserved_variables[ "cube::stn::parent::id" ]      = CUBE_STN_PARENT_ID;

    reserved_variables[ "cube::locationgroup::name" ]       = CUBE_LOCATION_GROUP_NAME;
    reserved_variables[ "cube::locationgroup::parent::id" ] = CUBE_LOCATION_GROUP_PARENT_ID;
    reserved_variables[ "cube::locationgroup::rank" ]       = CUBE_LOCATION_GROUP_RANK;
    reserved_variables[ "cube::locationgroup::type" ]       = CUBE_LOCATION_GROUP_TYPE;
    reserved_variables[ "cube::locationgroup::void" ]       = CUBE_LOCATION_GROUP_VOID;
    reserved_variables[ "cube::locationgroup::#locations" ] = CUBE_LOCATION_GROUP_NUM_LOCATIONS;
    reserved_variables[ "cube::locationgroup::locations" ]  = CUBE_LOCATION_GROUP_LOCATIONS;

    reserved_variables[ "cube::location::name" ]       = CUBE_LOCATION_NAME;
    reserved_variables[ "cube::location::type" ]       = CUBE_LOCATION_TYPE;
    reserved_variables[ "cube::location::parent::id" ] = CUBE_LOCATION_PARENT_ID;
    reserved_variables[ "cube::location::rank" ]       = CUBE_LOCATION_RANK;
    reserved_variables[ "cube::location::void" ]       = CUBE_LOCATION_VOID;


    reserved_variables[ "cube::#locations::void" ]         = CUBE_NUM_VOID_LOCS;
    reserved_variables[ "cube::#locations::nonvoid" ]      = CUBE_NUM_NONVOID_LOCS;
    reserved_variables[ "cube::#locationgroups::void" ]    = CUBE_NUM_VOID_LGS;
    reserved_variables[ "cube::#locationgroups::nonvoid" ] = CUBE_NUM_NONVOID_LGS;
};

CubePL1MemoryManager::~CubePL1MemoryManager()
{
//     cout << " Statistic on CubePL:" << endl;
//     cout << " Max size of used memory : " << memory.size() << endl;
//     cout << " Max size of used global memory : " << global_memory.size() << endl;
};


MemoryAdress
CubePL1MemoryManager::register_variable( std::string    name,
                                         KindOfVariable var )
{
    size_t                                        _addr = 0;
    std::map<std::string, MemoryAdress>::iterator it;
    it = reserved_variables.find( name );
    if ( it  != reserved_variables.end() )
    {
        return ( *it ).second;
    }
    it = registered_variables.find( name );
    if ( it  != registered_variables.end() )
    {
        return ( *it ).second;
    }

    it = registered_global_variables.find( name );
    if ( it  != registered_global_variables.end() )
    {
        return ( *it ).second;
    }

    switch ( var )
    {
        case  CUBEPL_RESERVED_VARIABLE:
        {
            _addr = reserved_memory.size();
            reserved_memory.resize( _addr + 1 );
            reserved_variables[ name ] = _addr;
            break;
        }
        case  CUBEPL_VARIABLE:
        {
            _addr                        = page_size;
            registered_variables[ name ] = _addr;
            page_size++;
            memory.resize( memory_stack.top() + page_size );
            break;
        }
        case  CUBEPL_GLOBAL_VARIABLE:
        {
            _addr = global_memory.size();
            global_memory.resize( _addr + 1 );
            registered_global_variables[ name ] = _addr;
            break;
        }
        default:
            throw CubePL1Error( "Unknown type of CubePL variable." );
            break;
    }
    return _addr;
}


KindOfVariable
CubePL1MemoryManager::kind_of_variable( std::string name )
{
    std::map<std::string, MemoryAdress>::iterator it;
    it = reserved_variables.find( name );
    if ( it  != reserved_variables.end() )
    {
        return CUBEPL_RESERVED_VARIABLE;
    }
    it = registered_global_variables.find( name );
    if ( it  != registered_global_variables.end() )
    {
        return CUBEPL_GLOBAL_VARIABLE;
    }
    it = registered_variables.find( name );
    if ( it  != registered_variables.end() )
    {
        return CUBEPL_VARIABLE;
    }
    throw CubePL1Error( "Variable " + name + " is not registered yet" );
    return CUBEPL_GLOBAL_VARIABLE;
}



void
CubePL1MemoryManager::init()
{
    global_memory.clear();
    memory.clear();
    while ( memory_stack.size() > 0 )
    {
        memory_stack.pop();
    }
    memory_stack.push( 0 );
    reserved_memory.resize( max_reserved_memory_size );
    registered_variables.clear();
    registered_variables[ "calculation::metric::id" ]   = CALCULATION_METRIC_ID;
    registered_variables[ "calculation::callpath::id" ] = CALCULATION_CALLPATH_ID;
    registered_variables[ "calculation::region::id" ]   = CALCULATION_REGION_ID;
    registered_variables[ "calculation::sysres::id" ]   = CALCULATION_SYSRES_ID;
    registered_variables[ "calculation::sysres::kind" ] = CALCULATION_SYSRES_KIND;
    page_size                                           = 5;
};

void
CubePL1MemoryManager::new_page()
{
    if ( page_size == 0 )
    {
        return;
    }
    if ( memory_stack.top() > memory.size() )
    {
        throw CubePL1MemoryLayoutError( "Memory stack point out of memory range" );
    }
    if ( memory.size() - memory_stack.top() < 2 * page_size )
    {
        memory.resize( 10 * page_size + memory_stack.top() ); // Extend the memory for double page. Complete current and allocate new one
    }
    memory_stack.push( memory_stack.top() + page_size );      // move page pointer to another page;
};

void
CubePL1MemoryManager::throw_page()
{
    if ( memory_stack.size() > 1 )
    {
        memory_stack.pop();
    }
}



bool
CubePL1MemoryManager::defined( std::string name )
{
    std::map<std::string, MemoryAdress>::iterator it;
    it = reserved_variables.find( name );
    if ( it  != reserved_variables.end() )
    {
        return true;
    }
    it = registered_global_variables.find( name );
    if ( it  != registered_global_variables.end() )
    {
        return true;
    }
    it = registered_variables.find( name );
    if ( it  != registered_variables.end() )
    {
        return true;
    }
    return false;
}



void
CubePL1MemoryManager::clear_variable( MemoryAdress   adress,
                                      KindOfVariable var  )
{
    if ( var == CUBEPL_VARIABLE )
    {
        memory[ memory_stack.top() +  adress ].clear();
    }
    if ( var == CUBEPL_RESERVED_VARIABLE )
    {
        reserved_memory[ adress ].clear();
    }
    if ( var == CUBEPL_GLOBAL_VARIABLE )
    {
        global_memory[ adress ].clear();
    }
}

void
CubePL1MemoryManager::put( MemoryAdress   adress,
                           double         index,
                           double         value,
                           KindOfVariable var   )
{
    size_t _index = ( size_t )index;
    switch ( var )
    {
        case CUBEPL_VARIABLE:
        {
            if ( memory_stack.top() +  adress <= memory.size() )
            {
                if (  memory[ memory_stack.top() +  adress ].size() <= _index )
                {
                    memory[ memory_stack.top() +  adress ].resize( _index + 1 );
                }
            }
            memory[ memory_stack.top() +  adress ][ _index ].double_value = value;
            memory[ memory_stack.top() +  adress ][ _index ].state        = CUBEPL_VALUE_DOUBLE;
            break;
        }
        case CUBEPL_RESERVED_VARIABLE:
        {
            if (  reserved_memory[ adress ].size() <= _index )
            {
                reserved_memory[  adress ].resize( _index + 1 );
            }
            reserved_memory[ adress ][ _index ].double_value = value;
            reserved_memory[ adress ][ _index ].state        = CUBEPL_VALUE_DOUBLE;
            break;
        }
        case  CUBEPL_GLOBAL_VARIABLE:
        {
            if (  global_memory[ adress ].size() <= _index )
            {
                global_memory[  adress ].resize( _index + 1 );
            }
            global_memory[ adress ][ _index ].double_value = value;
            global_memory[ adress ][ _index ].state        = CUBEPL_VALUE_DOUBLE;
            break;
        }
        default:
            throw CubePL1Error( "Unknown type of CubePL variable." );
            break;
    }
    ;
};


void
CubePL1MemoryManager::put( MemoryAdress   adress,
                           double         index,
                           string         value,
                           KindOfVariable var  )
{
    size_t _index = ( size_t )index;
    switch ( var )
    {
        case CUBEPL_VARIABLE:
        {
            if (  memory[ memory_stack.top() +  adress ].size() <= _index )
            {
                memory[ memory_stack.top() +  adress ].resize( _index + 1 );
            }
            memory[ memory_stack.top() +  adress ][ _index ].state        = CUBEPL_VALUE_STRING;
            memory[ memory_stack.top() +  adress ][ _index ].string_value = value;
            break;
        }
        case CUBEPL_RESERVED_VARIABLE:
        {
            if (  reserved_memory[  adress ].size() <= _index )
            {
                reserved_memory[  adress ].resize( _index + 1 );
            }
            reserved_memory[  adress ][ _index ].state        = CUBEPL_VALUE_STRING;
            reserved_memory[  adress ][ _index ].string_value = value;
            break;
        }
        case  CUBEPL_GLOBAL_VARIABLE:
        {
            if (  global_memory[  adress ].size() <= _index )
            {
                global_memory[  adress ].resize( _index + 1 );
            }
            global_memory[  adress ][ _index ].state        = CUBEPL_VALUE_STRING;
            global_memory[  adress ][ _index ].string_value = value;
            break;
        }
        default:
            throw CubePL1Error( "Unknown type of CubePL variable." );
            break;
    }
    ;
};


void
CubePL1MemoryManager::push_back( MemoryAdress   adress,
                                 double         value,
                                 KindOfVariable var )
{
    switch ( var )
    {
        case CUBEPL_VARIABLE:
        {
            CubePLMemoryDuplet _t;
            _t.double_value = value;
            _t.state        = CUBEPL_VALUE_DOUBLE;

            memory[ memory_stack.top() +  adress ].push_back( _t );
            break;
        }
        case CUBEPL_RESERVED_VARIABLE:
        {
            CubePLMemoryDuplet _t;
            _t.double_value = value;
            _t.state        = CUBEPL_VALUE_DOUBLE;

            reserved_memory[ adress ].push_back( _t );
            break;
        }
        case  CUBEPL_GLOBAL_VARIABLE:
        {
            CubePLMemoryDuplet _t;
            _t.double_value = value;
            _t.state        = CUBEPL_VALUE_DOUBLE;

            global_memory[ adress ].push_back( _t );
            break;
        }
        default:
            throw CubePL1Error( "Unknown type of CubePL variable." );
            break;
    }
    ;
}

void
CubePL1MemoryManager::push_back( MemoryAdress   adress,
                                 string         value,
                                 KindOfVariable var )
{
    switch ( var )
    {
        case CUBEPL_VARIABLE:
        {
            CubePLMemoryDuplet _t;
            _t.string_value = value;
            _t.state        = CUBEPL_VALUE_STRING;
            memory[ memory_stack.top() +  adress ].push_back( _t );
            break;
        }
        case CUBEPL_RESERVED_VARIABLE:
        {
            CubePLMemoryDuplet _t;
            _t.string_value = value;
            _t.state        = CUBEPL_VALUE_STRING;
            reserved_memory[ adress ].push_back( _t );
            break;
        }
        case  CUBEPL_GLOBAL_VARIABLE:
        {
            CubePLMemoryDuplet _t;
            _t.string_value = value;
            _t.state        = CUBEPL_VALUE_STRING;
            global_memory[ adress ].push_back( _t );
            break;
        }
        default:
            throw CubePL1Error( "Unknown type of CubePL variable." );
            break;
    }
}

double
CubePL1MemoryManager::get( MemoryAdress   adress,
                           double         index,
                           KindOfVariable var   )
{
    size_t _index = ( size_t )index;
    switch ( var )
    {
        case CUBEPL_VARIABLE:
        {
            if ( memory[ memory_stack.top() +  adress ].size() <= _index )
            {
                return 0.;
            }
            else
            {
                CubePLMemoryDuplet & _t =  memory[ memory_stack.top() +  adress ][ _index ];
                if ( _t.state == CUBEPL_VALUE_STRING ) // convert to double if possible
                {
                    std::istringstream stream( _t.string_value );
                    double             t;
                    stream >> t;
                    _t.double_value = t;
                    _t.state        = CUBEPL_VALUE_EQUAL;
                }
                return _t.double_value;
            }
            break;
        }
        case CUBEPL_RESERVED_VARIABLE:
        {
            if ( reserved_memory[ adress ].size() <= _index )
            {
                return 0.;
            }
            else
            {
                CubePLMemoryDuplet & _t =  reserved_memory[ adress ][ _index ];
                if ( _t.state == CUBEPL_VALUE_STRING ) // convert to double if possible
                {
                    std::istringstream stream( _t.string_value );
                    double             t;
                    stream >> t;
                    _t.double_value = t;
                    _t.state        = CUBEPL_VALUE_EQUAL;
                }
                return _t.double_value;
            }
            break;
        }
        case  CUBEPL_GLOBAL_VARIABLE:
        {
            if ( global_memory[ adress ].size() <= _index )
            {
                return 0.;
            }
            else
            {
                CubePLMemoryDuplet & _t =  global_memory[ adress ][ _index ];
                if ( _t.state == CUBEPL_VALUE_STRING ) // convert to double if possible
                {
                    std::istringstream stream( _t.string_value );
                    double             t;
                    stream >> t;
                    _t.double_value = t;
                    _t.state        = CUBEPL_VALUE_EQUAL;
                }
                return _t.double_value;
            }
            break;
        }
        default:
            throw CubePL1Error( "Unknown type of CubePL variable." );
            break;
    }
    return 0.;
}

string
CubePL1MemoryManager::get_as_string( MemoryAdress   adress,
                                     double         index,
                                     KindOfVariable var  )
{
    size_t _index = ( size_t )index;

    switch ( var )
    {
        case CUBEPL_VARIABLE:
        {
            if ( memory[ memory_stack.top() +  adress ].size() <= _index )
            {
                return "";
            }
            else
            {
                CubePLMemoryDuplet & _t =  memory[ memory_stack.top() +  adress ][ _index ];
                if ( _t.state == CUBEPL_VALUE_DOUBLE ) // convert to string if possible
                {
                    stringstream sstr;
                    string       str;
                    sstr <<  setprecision( 14 ) <<  _t.double_value;
                    sstr >> _t.string_value;
                    _t.state = CUBEPL_VALUE_EQUAL;
                }
                return _t.string_value;
            }
            break;
        }
        case CUBEPL_RESERVED_VARIABLE:
        {
            if ( reserved_memory[ adress ].size() <= _index )
            {
                return "";
            }
            else
            {
                CubePLMemoryDuplet & _t =  reserved_memory[ adress ][ _index ];
                if ( _t.state == CUBEPL_VALUE_DOUBLE )   // convert to string if possible
                {
                    stringstream sstr;
                    string       str;
                    sstr <<  setprecision( 14 ) <<  _t.double_value;
                    sstr >> _t.string_value;
                    _t.state = CUBEPL_VALUE_EQUAL;
                }
                return _t.string_value;
            }
            break;
        }
        case  CUBEPL_GLOBAL_VARIABLE:
        {
            if ( global_memory[ adress ].size() <= _index )
            {
                return "";
            }
            else
            {
                CubePLMemoryDuplet & _t =  global_memory[ adress ][ _index ];
                if ( _t.state == CUBEPL_VALUE_DOUBLE )   // convert to string if possible
                {
                    stringstream sstr;
                    string       str;
                    sstr <<  setprecision( 14 ) <<  _t.double_value;
                    sstr >> _t.string_value;
                    _t.state = CUBEPL_VALUE_EQUAL;
                }
                return _t.string_value;
            }
            break;
        }
        default:
            throw CubePL1Error( "Unknown type of CubePL variable." );
            break;
    }
    return "";
}


size_t
CubePL1MemoryManager::size_of( MemoryAdress   adress,
                               KindOfVariable var )
{
    if ( var == CUBEPL_VARIABLE )
    {
        return memory[ memory_stack.top() +  adress ].size();
    }
    if ( var == CUBEPL_RESERVED_VARIABLE )
    {
        return reserved_memory[ adress ].size();
    }
    if ( var == CUBEPL_GLOBAL_VARIABLE )
    {
        return global_memory[ adress ].size();
    }
    throw CubePL1Error( "Unknown type of CubePL variable." );
    return 0;
}



#endif
