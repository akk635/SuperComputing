/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __AND_EVALUATION_CPP
#define __AND_EVALUATION_CPP 0

#include "CubeAndEvaluation.h"
using namespace cube;

AndEvaluation::AndEvaluation() : BinaryEvaluation()
{
};

AndEvaluation::AndEvaluation( GeneralEvaluation* _arg1,
                              GeneralEvaluation* _arg2 ) : BinaryEvaluation( _arg1, _arg2 )
{
};


AndEvaluation::~AndEvaluation()
{
}

double
AndEvaluation::eval()
{
    double result = 0;
    for ( vector<GeneralEvaluation*>::iterator iter = arguments.begin(); iter != arguments.end(); iter++ )
    {
        result = ( *iter )->eval();
        if ( result == 0. )
        {
            return 0.;
        }
    }
    return 1.;
}

/*

   double
   AndEvaluation::eval( cube::Cnode * _cnode, CalculationFlavour _cf, cube::Thread * _thread, CalculationFlavour _tf)
   {
    double result = 0;
    for ( vector<GeneralEvaluation*>::iterator iter = arguments.begin(); iter != arguments.end(); iter++ )
    {
        result = (*iter)->eval(_cnode, _cf, _thread, _tf);
        if (result == 0.)
            return 0.;
    }
    return 1.;
   }



   double AndEvaluation::eval( cube::Cnode * _cnode, CalculationFlavour _cf, cube::Thread * _th1, cube::Thread * _th2, CalculationFlavour  _tf )
   {
    double result = 0;
    for ( vector<GeneralEvaluation*>::iterator iter = arguments.begin(); iter != arguments.end(); iter++ )
    {
        result = (*iter)->eval(_cnode, _cf,
                                            _th1, _th2, _tf);
        if (result == 0.)
            return 0.;

    }
    return 1;
   }
 */

double
AndEvaluation::eval( cube::Cnode* _cnode, CalculationFlavour _cf, cube::Sysres* _sf, CalculationFlavour _tf   )
{
    double result = 0;
    for ( vector<GeneralEvaluation*>::iterator iter = arguments.begin(); iter != arguments.end(); iter++ )
    {
        result = ( *iter )->eval( _cnode, _cf,
                                  _sf, _tf );
        if ( result == 0. )
        {
            return 0.;
        }
    }
    return result;
}

// double
// AndEvaluation::eval( cube::Cnode *  _cnode, CalculationFlavour _cf, cube::Process * _pr, CalculationFlavour  _tf   )
// {
//     double result = 0;
//     for (vector<GeneralEvaluation *>::iterator iter = arguments.begin(); iter!= arguments.end(); iter++ )
//     {
//      result = (*iter)->eval(_cnode, _cf,
//                                      _pr, _tf);
//      if (result == 0.)
//          return 0.;
//
//     }
//     return 1.;
// }
//
// double
// AndEvaluation::eval( cube::Cnode *  _cnode, CalculationFlavour _cf, cube::Node * _nd, CalculationFlavour    _tf )
// {
//     double result = 0;
//     for (vector<GeneralEvaluation *>::iterator iter = arguments.begin(); iter!= arguments.end(); iter++ )
//     {
//      result = (*iter)->eval(_cnode, _cf,
//                                          _nd, _tf);
//      if (result == 0.)
//          return 0.;
//
//     }
//     return 1.;
//
// }
//
// double
// AndEvaluation::eval( cube::Cnode *  _cnode, CalculationFlavour _cf, cube::Machine * _mch, CalculationFlavour   _tf  )
// {
//      double result = 0;
//     for (vector<GeneralEvaluation *>::iterator iter = arguments.begin(); iter!= arguments.end(); iter++ )
//     {
//      result = (*iter)->eval(_cnode, _cf,
//                                          _mch, _tf);
//      if (result == 0.)
//          return 0.;
//
//     }
//     return 1.;
// }

double
AndEvaluation::eval( cube::Cnode* _cnode, CalculationFlavour _cf )
{
    double result = 0;
    for ( vector<GeneralEvaluation*>::iterator iter = arguments.begin(); iter != arguments.end(); iter++ )
    {
        result = ( *iter )->eval( _cnode, _cf );
        if ( result == 0. )
        {
            return 0.;
        }
    }
    return 1.;
}



#endif
