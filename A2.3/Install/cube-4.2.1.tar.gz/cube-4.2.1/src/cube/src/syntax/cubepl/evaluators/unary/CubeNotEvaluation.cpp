/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __NOT_EVALUATION_CPP
#define __NOT_EVALUATION_CPP 0

#include "CubeNotEvaluation.h"
using namespace cube;
NotEvaluation::NotEvaluation() : UnaryEvaluation()
{
}

NotEvaluation::NotEvaluation( GeneralEvaluation* _arg ) : UnaryEvaluation( _arg )
{
}


NotEvaluation::~NotEvaluation()
{
}

double
NotEvaluation::eval()
{
    if ( getNumOfParameters() == 0 )
    {
        return 0;
    }
    if ( getNumOfParameters() == 1 )
    {
        return ( arguments[ 0 ]->eval() != 0. ) ? 0. : 1.;
    }
    cerr << " Negation of more than 1 parameters is not defined" << endl;
    return 0;
}
/*

   double
   NotEvaluation::eval( Cnode * _cnode, CalculationFlavour _cf , Thread * _th, CalculationFlavour _tf)
   {
    if (getNumOfParameters() == 0 )
        return 0;
    if ( getNumOfParameters() == 1)
    {
        return (arguments[0]->eval(_cnode, _cf, _th, _tf)!=0.)?0.:1.;
    }
    cerr << " Negation of more than 1 parameters is not defined" << endl;
    return 0;
   }

   double
   NotEvaluation::eval( Cnode *  _cnode, CalculationFlavour _cf , Thread * _th1, Thread * _th2, CalculationFlavour   _tf )
   {
    if (getNumOfParameters() == 0 )
        return 0;
    if ( getNumOfParameters() == 1)
    {
        return (arguments[0]->eval( _cnode, _cf, _th1, _th2, _tf)!=0.)?0.:1.;
    }
    cerr << " Negation of more than 1 parameters is not defined" << endl;
    return 0;

   }
 */
double
NotEvaluation::eval( Cnode* _cnode, CalculationFlavour _cf, Sysres* _sys, CalculationFlavour _sf  )
{
    if ( getNumOfParameters() == 0 )
    {
        return 0;
    }
    if ( getNumOfParameters() == 1 )
    {
        return ( arguments[ 0 ]->eval( _cnode, _cf, _sys, _sf ) != 0. ) ? 0. : 1.;
    }
    cerr << " Negation of more than 1 parameters is not defined" << endl;
    return 0;
}
/*
   double
   NotEvaluation::eval( Cnode *  _cnode, CalculationFlavour _cf , Process * _pc, CalculationFlavour _pf  )
   {
    if (getNumOfParameters() == 0 )
        return 0;
    if ( getNumOfParameters() == 1)
    {
        return (arguments[0]->eval( _cnode, _cf, _pc, _pf) != 0.)?0.:1.;
    }
    cerr << " Negation of more than 1 parameters is not defined" << endl;
    return 0;

   }

   double
   NotEvaluation::eval( Cnode *  _cnode, CalculationFlavour _cf , Node * _nd, CalculationFlavour  _nf)
   {
    if (getNumOfParameters() == 0 )
        return 0;
    if ( getNumOfParameters() == 1)
    {
        return (arguments[0]->eval( _cnode, _cf, _nd, _nf)!= 0.)?0.:1.;
    }
    cerr << " Negation of more than 1 parameters is not defined" << endl;
    return 0;

   }

   double
   NotEvaluation::eval( Cnode *  _cnode, CalculationFlavour _cf , Machine * _mach, CalculationFlavour _mf  )
   {
    if (getNumOfParameters() == 0 )
        return 0;
    if ( getNumOfParameters() == 1)
    {
        return (arguments[0]->eval( _cnode, _cf, _mach, _mf)!=0.)?0.:1.;
    }
    cerr << " Negation of more than 1 parameters is not defined" << endl;
    return 0;

   }
 */
double
NotEvaluation::eval( Cnode* _cnode, CalculationFlavour _cf )
{
    if ( getNumOfParameters() == 0 )
    {
        return 0;
    }
    if ( getNumOfParameters() == 1 )
    {
        return ( arguments[ 0 ]->eval( _cnode, _cf ) != 0. ) ? 0. : 1.;
    }
    cerr << " Negation of more than 1 parameters is not defined" << endl;
    return 0;
}



#endif
