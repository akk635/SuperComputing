/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __MULT_EVALUATION_CPP
#define __MULT_EVALUATION_CPP 0

#include "CubeMultEvaluation.h"
using namespace cube;

MultEvaluation::MultEvaluation() : BinaryEvaluation()
{
};

MultEvaluation::MultEvaluation( GeneralEvaluation* _arg1,
                                GeneralEvaluation* _arg2 ) : BinaryEvaluation( _arg1, _arg2 )
{
};


MultEvaluation::~MultEvaluation()
{
}

double
MultEvaluation::eval()
{
    if ( getNumOfParameters() == 2 )
    {
        double _value = ( arguments[ 0 ]->eval() ) * ( arguments[ 1 ]->eval() );
        if ( fabs( _value ) == std::numeric_limits<double>::infinity() )
        {
            if ( _value < 0 )
            {
                return -DBL_MAX;
            }
            else
            {
                return DBL_MAX;
            }
        }
        else
        {
            return _value;
        }
    }
    cerr << " Multiplication is not defined for else  than two paraments." << endl;
    return 0.;
}



double
MultEvaluation::eval( cube::Cnode* _cnode, CalculationFlavour _cf, cube::Sysres* _sf, CalculationFlavour _tf   )
{
    if ( getNumOfParameters() == 2 )
    {
        double _value =  ( arguments[ 0 ]->eval( _cnode, _cf,
                                                 _sf, _tf ) ) * ( arguments[ 1 ]->eval( _cnode, _cf,
                                                                                        _sf, _tf ) );
        if ( fabs( _value ) == std::numeric_limits<double>::infinity() )
        {
            if ( _value < 0 )
            {
                return -DBL_MAX;
            }
            else
            {
                return DBL_MAX;
            }
        }
        else
        {
            return _value;
        }
    }
    cerr << " Multiplication is not defined for else  than two paraments." << endl;
    return 0.;
}

double
MultEvaluation::eval( cube::Cnode* _cnode, CalculationFlavour _cf )
{
    if ( getNumOfParameters() == 2 )
    {
        double _value =   ( arguments[ 0 ]->eval( _cnode, _cf ) ) * ( arguments[ 1 ]->eval( _cnode, _cf ) );
        if ( fabs( _value ) == std::numeric_limits<double>::infinity() )
        {
            if ( _value < 0 )
            {
                return -DBL_MAX;
            }
            else
            {
                return DBL_MAX;
            }
        }
        else
        {
            return _value;
        }
    }
    cerr << " Multiplication is not defined for else  than two paraments." << endl;
    return 0.;
}



#endif
