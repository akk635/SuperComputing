/* A Bison parser, made by GNU Bison 2.5.  */

/* Skeleton implementation for Bison LALR(1) parsers in C++

      Copyright (C) 2002-2011 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

// Take the name prefix into account.
#define yylex   cubeparserlex

/* First part of user declarations.  */


/* Line 293 of lalr1.cc  */
#line 41 "../../build-backend/../src/cube/src/syntax/Cube4Parser.cpp"


#include "Cube4Parser.h"

/* User implementation prologue.  */

/* Line 299 of lalr1.cc  */
#line 211 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"


#include "CubeDriver.h"
#include "Cube4Scanner.h"
#include <cassert>
#include <cstdlib>
#include <cstring>
#include <stdlib.h>

using namespace std;

#include "CubeMetric.h"
#include "CubeCnode.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <utility>
#include <string>
#include <vector>
#include "CubeServices.h"
#include "CubeParseContext.h"
#include "CubeMetric.h"
#include "Cube.h"
#include "CubeCartesian.h"

/* this "connects" the bison parser in the driver to the flex scanner class
 * object. it defines the yylex() function call to pull the next token from the
 * current lexer object of the driver context. */
#undef yylex
#define yylex Cube4Lexer.lex

// Workaround for Sun Studio C++ compilers on Solaris
#if defined( __SVR4 ) &&  defined( __SUNPRO_CC )
  #include <ieeefp.h>

  #define isinf( x )  ( fpclass( x ) == FP_NINF || fpclass( x ) == FP_PINF )
  #define isnan( x )  isnand( x )
#endif



/* Line 299 of lalr1.cc  */
#line 92 "../../build-backend/../src/cube/src/syntax/Cube4Parser.cpp"

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* FIXME: INFRINGES ON USER NAME SPACE */
#   define YY_( msgid ) dgettext( "bison-runtime", msgid )
#  endif
# endif
# ifndef YY_
#  define YY_( msgid ) msgid
# endif
#endif

/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC( Rhs, K ) ( ( Rhs )[ K ] )
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT( Current, Rhs, N )                               \
    do {                                                                    \
        if ( N )                                                              \
        {                                                                 \
            ( Current ).begin = YYRHSLOC( Rhs, 1 ).begin;                      \
            ( Current ).end   = YYRHSLOC( Rhs, N ).end;                        \
        }                                                                 \
        else                                                                \
        {                                                                 \
            ( Current ).begin = ( Current ).end = YYRHSLOC( Rhs, 0 ).end;        \
        } }                                                                 \
    while ( false )
#endif

/* Suppress unused-variable warnings by "using" E.  */
#define YYUSE( e ) ( ( void )( e ) )

/* Enable debugging if requested.  */
#if YYDEBUG

/* A pseudo ostream that takes yydebug_ into account.  */
# define YYCDEBUG if ( yydebug_ ) ( *yycdebug_ )

# define YY_SYMBOL_PRINT( Title, Type, Value, Location )  \
    do {                                                    \
        if ( yydebug_ )                                         \
        {                                                   \
            *yycdebug_ << Title << ' ';                       \
            yy_symbol_print_( ( Type ), ( Value ), ( Location ) );   \
            *yycdebug_ << std::endl;                          \
        }                                                   \
    } while ( false )

# define YY_REDUCE_PRINT( Rule )          \
    do {                                    \
        if ( yydebug_ ) {                         \
            yy_reduce_print_( Rule ); }            \
    } while ( false )

# define YY_STACK_PRINT()               \
    do {                                    \
        if ( yydebug_ ) {                         \
            yystack_print_(); }                  \
    } while ( false )

#else /* !YYDEBUG */

# define YYCDEBUG if ( false ) std::cerr
# define YY_SYMBOL_PRINT( Title, Type, Value, Location )
# define YY_REDUCE_PRINT( Rule )
# define YY_STACK_PRINT()

#endif /* !YYDEBUG */

#define yyerrok         ( yyerrstatus_ = 0 )
#define yyclearin       ( yychar = yyempty_ )

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  ( !!yyerrstatus_ )


namespace cubeparser
{
/* Line 382 of lalr1.cc  */
#line 178 "../../build-backend/../src/cube/src/syntax/Cube4Parser.cpp"

/* Return YYSTR after stripping away unnecessary quotes and
   backslashes, so that it's suitable for yyerror.  The heuristic is
   that double-quoting is unnecessary unless the string contains an
   apostrophe, a comma, or backslash (other than backslash-backslash).
   YYSTR is taken from yytname.  */
std::string
Cube4Parser::yytnamerr_( const char* yystr )
{
    if ( *yystr == '"' )
    {
        std::string yyr = "";
        char const* yyp = yystr;

        for (;; )
        {
            switch ( *++yyp )
            {
                case '\'':
                case ',':
                    goto do_not_strip_quotes;

                case '\\':
                    if ( *++yyp != '\\' )
                    {
                        goto do_not_strip_quotes;
                    }
                /* Fall through.  */
                default:
                    yyr += *yyp;
                    break;

                case '"':
                    return yyr;
            }
        }
do_not_strip_quotes:;
    }

    return yystr;
}


/// Build a parser object.
Cube4Parser::Cube4Parser ( class Driver&       driver_yyarg,
                           class ParseContext& parseContext_yyarg,
                           class Cube4Scanner& Cube4Lexer_yyarg,
                           class cube::Cube&   cube_yyarg,
                           bool&               clustering_on_yyarg )
    :
#if YYDEBUG
      yydebug_( false ),
      yycdebug_( &std::cerr ),
#endif
      driver( driver_yyarg ),
      parseContext( parseContext_yyarg ),
      Cube4Lexer( Cube4Lexer_yyarg ),
      cube( cube_yyarg ),
      clustering_on( clustering_on_yyarg )
{
}

Cube4Parser::~Cube4Parser ()
{
}

#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
   `--------------------------------*/

inline void
Cube4Parser::yy_symbol_value_print_( int yytype,
                                     const semantic_type* yyvaluep, const location_type* yylocationp )
{
    YYUSE( yylocationp );
    YYUSE( yyvaluep );
    switch ( yytype )
    {
        default:
            break;
    }
}


void
Cube4Parser::yy_symbol_print_( int yytype,
                               const semantic_type* yyvaluep, const location_type* yylocationp )
{
    *yycdebug_ << ( yytype < yyntokens_ ? "token" : "nterm" )
               << ' ' << yytname_[ yytype ] << " ("
               << *yylocationp << ": ";
    yy_symbol_value_print_( yytype, yyvaluep, yylocationp );
    *yycdebug_ << ')';
}
#endif

void
Cube4Parser::yydestruct_( const char* yymsg,
                          int yytype, semantic_type* yyvaluep, location_type* yylocationp )
{
    YYUSE( yylocationp );
    YYUSE( yymsg );
    YYUSE( yyvaluep );

    YY_SYMBOL_PRINT( yymsg, yytype, yyvaluep, yylocationp );

    switch ( yytype )
    {
        default:
            break;
    }
}

void
Cube4Parser::yypop_( unsigned int n )
{
    yystate_stack_.pop( n );
    yysemantic_stack_.pop( n );
    yylocation_stack_.pop( n );
}

#if YYDEBUG
std::ostream&
Cube4Parser::debug_stream() const
{
    return *yycdebug_;
}

void
Cube4Parser::set_debug_stream( std::ostream& o )
{
    yycdebug_ = &o;
}


Cube4Parser::debug_level_type
Cube4Parser::debug_level() const
{
    return yydebug_;
}

void
Cube4Parser::set_debug_level( debug_level_type l )
{
    yydebug_ = l;
}
#endif

inline bool
Cube4Parser::yy_pact_value_is_default_( int yyvalue )
{
    return yyvalue == yypact_ninf_;
}

inline bool
Cube4Parser::yy_table_value_is_error_( int yyvalue )
{
    return yyvalue == yytable_ninf_;
}

int
Cube4Parser::parse()
{
    /// Lookahead and lookahead in internal form.
    int yychar  = yyempty_;
    int yytoken = 0;

    /* State.  */
    int yyn;
    int yylen   = 0;
    int yystate = 0;

    /* Error handling.  */
    int yynerrs_     = 0;
    int yyerrstatus_ = 0;

    /// Semantic value of the lookahead.
    semantic_type yylval;
    /// Location of the lookahead.
    location_type yylloc;
    /// The locations where the error started and ended.
    location_type yyerror_range[ 3 ];

    /// $$.
    semantic_type yyval;
    /// @$.
    location_type yyloc;

    int           yyresult;

    YYCDEBUG << "Starting parse" << std::endl;


    /* User initialization code.  */

/* Line 565 of lalr1.cc  */
#line 62 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
    {
        // initialize the initial location object
        yylloc.begin.filename = yylloc.end.filename = &driver.streamname;
        clustering_on         = false;
    }

/* Line 565 of lalr1.cc  */
#line 377 "../../build-backend/../src/cube/src/syntax/Cube4Parser.cpp"

    /* Initialize the stacks.  The initial state will be pushed in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystate_stack_    = state_stack_type( 0 );
    yysemantic_stack_ = semantic_stack_type( 0 );
    yylocation_stack_ = location_stack_type( 0 );
    yysemantic_stack_.push( yylval );
    yylocation_stack_.push( yylloc );

    /* New state.  */
yynewstate:
    yystate_stack_.push( yystate );
    YYCDEBUG << "Entering state " << yystate << std::endl;

    /* Accept?  */
    if ( yystate == yyfinal_ )
    {
        goto yyacceptlab;
    }

    goto yybackup;

    /* Backup.  */
yybackup:

    /* Try to take a decision without lookahead.  */
    yyn = yypact_[ yystate ];
    if ( yy_pact_value_is_default_( yyn ) )
    {
        goto yydefault;
    }

    /* Read a lookahead token.  */
    if ( yychar == yyempty_ )
    {
        YYCDEBUG << "Reading a token: ";
        yychar = yylex( &yylval, &yylloc );
    }


    /* Convert token to internal form.  */
    if ( yychar <= yyeof_ )
    {
        yychar = yytoken = yyeof_;
        YYCDEBUG << "Now at end of input." << std::endl;
    }
    else
    {
        yytoken = yytranslate_( yychar );
        YY_SYMBOL_PRINT( "Next token is", yytoken, &yylval, &yylloc );
    }

    /* If the proper action on seeing token YYTOKEN is to reduce or to
       detect an error, take that action.  */
    yyn += yytoken;
    if ( yyn < 0 || yylast_ < yyn || yycheck_[ yyn ] != yytoken )
    {
        goto yydefault;
    }

    /* Reduce or error.  */
    yyn = yytable_[ yyn ];
    if ( yyn <= 0 )
    {
        if ( yy_table_value_is_error_( yyn ) )
        {
            goto yyerrlab;
        }
        yyn = -yyn;
        goto yyreduce;
    }

    /* Shift the lookahead token.  */
    YY_SYMBOL_PRINT( "Shifting", yytoken, &yylval, &yylloc );

    /* Discard the token being shifted.  */
    yychar = yyempty_;

    yysemantic_stack_.push( yylval );
    yylocation_stack_.push( yylloc );

    /* Count tokens shifted since error; after three, turn off error
       status.  */
    if ( yyerrstatus_ )
    {
        --yyerrstatus_;
    }

    yystate = yyn;
    goto yynewstate;

    /*-----------------------------------------------------------.
    | yydefault -- do the default action for the current state.  |
       `-----------------------------------------------------------*/
yydefault:
    yyn = yydefact_[ yystate ];
    if ( yyn == 0 )
    {
        goto yyerrlab;
    }
    goto yyreduce;

    /*-----------------------------.
    | yyreduce -- Do a reduction.  |
       `-----------------------------*/
yyreduce:
    yylen = yyr2_[ yyn ];
    /* If YYLEN is nonzero, implement the default value of the action:
       `$$ = $1'.  Otherwise, use the top of the stack.

       Otherwise, the following line sets YYVAL to garbage.
       This behavior is undocumented and Bison
       users should not rely upon it.  */
    if ( yylen )
    {
        yyval = yysemantic_stack_[ yylen - 1 ];
    }
    else
    {
        yyval = yysemantic_stack_[ 0 ];
    }

    {
        slice<location_type, location_stack_type> slice( yylocation_stack_, yylen );
        YYLLOC_DEFAULT( yyloc, slice, yylen );
    }
    YY_REDUCE_PRINT( yyn );
    switch ( yyn )
    {
        case 2:

/* Line 690 of lalr1.cc  */
#line 261 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.versionSeen )
                {
                    error( yylloc, "Multiple version attributes defines!" );
                }
                else
                {
                    parseContext.versionSeen = true;
                }
                parseContext.version = parseContext.str.str();
            }
            break;

        case 3:

/* Line 690 of lalr1.cc  */
#line 268 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.encodingSeen )
                {
                    error( yylloc, "Multiple encoding attributes defines!" );
                }
                else
                {
                    parseContext.encodingSeen = true;
                }
                parseContext.encoding = parseContext.str.str();
            }
            break;

        case 4:

/* Line 690 of lalr1.cc  */
#line 275 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.keySeen )
                {
                    error( yylloc, "Multiple key attributes defines!" );
                }
                else
                {
                    parseContext.keySeen = true;
                }
                parseContext.key = parseContext.str.str();
            }
            break;

        case 5:

/* Line 690 of lalr1.cc  */
#line 282 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.valueSeen )
                {
                    error( yylloc, "Multiple value attributes defines!" );
                }
                else
                {
                    parseContext.valueSeen = true;
                }
                parseContext.value = parseContext.str.str();
            }
            break;

        case 6:

/* Line 690 of lalr1.cc  */
#line 289 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.modSeen )
                {
                    error( yylloc, "Multiple module attributes defines!" );
                }
                else
                {
                    parseContext.modSeen = true;
                }
                parseContext.mod = parseContext.str.str();
            }
            break;

        case 7:

/* Line 690 of lalr1.cc  */
#line 296 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.metricTypeSeen )
                {
                    error( yylloc, "Multiple metric type attributes defines!" );
                }
                else
                {
                    parseContext.metricTypeSeen = true;
                }
                parseContext.metricType = parseContext.str.str();
            }
            break;

        case 8:

/* Line 690 of lalr1.cc  */
#line 304 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.cnodeParTypeSeen )
                {
                    error( yylloc, "Multiple cnode parameter type attributes defines!" );
                }
                else
                {
                    parseContext.cnodeParTypeSeen = true;
                }
                parseContext.cnode_parameter_type = parseContext.str.str();
            }
            break;

        case 9:

/* Line 690 of lalr1.cc  */
#line 313 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.cnodeParKeySeen )
                {
                    error( yylloc, "Multiple cnode parameter keys defines!" );
                }
                else
                {
                    parseContext.cnodeParKeySeen = true;
                }
                parseContext.cnode_parameter_key = parseContext.str.str();
            }
            break;

        case 10:

/* Line 690 of lalr1.cc  */
#line 322 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.cnodeParValueSeen )
                {
                    error( yylloc, "Multiple cnode parameter values defines!" );
                }
                else
                {
                    parseContext.cnodeParValueSeen = true;
                }
                parseContext.cnode_parameter_value = parseContext.str.str();
            }
            break;

        case 11:

/* Line 690 of lalr1.cc  */
#line 331 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.cartNameSeen )
                {
                    error( yylloc, "Multiple topology names  defines!" );
                }
                else
                {
                    parseContext.cartNameSeen = true;
                }
                parseContext.cartName = parseContext.str.str();
            }
            break;

        case 12:

/* Line 690 of lalr1.cc  */
#line 341 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.dimNameSeen )
                {
                    error( yylloc, "Multiple names for dimension attributes defines!" );
                }
                else
                {
                    parseContext.dimNameSeen = true;
                }
                parseContext.dimNamesCount++;
                parseContext.dimName = services::escapeFromXML( parseContext.str.str() );
            }
            break;

        case 14:

/* Line 690 of lalr1.cc  */
#line 351 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.metricsTitleSeen )
                {
                    error( yylloc, "Multiple metrics titles defined!" );
                }
                else
                {
                    parseContext.metricsTitleSeen = true;
                }
                parseContext.metricsTitle = parseContext.str.str();
            }
            break;

        case 16:

/* Line 690 of lalr1.cc  */
#line 360 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.calltreeTitleSeen )
                {
                    error( yylloc, "Multiple calltree titles defined!" );
                }
                else
                {
                    parseContext.calltreeTitleSeen = true;
                }
                parseContext.calltreeTitle = parseContext.str.str();
            }
            break;

        case 18:

/* Line 690 of lalr1.cc  */
#line 370 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.systemtreeTitleSeen )
                {
                    error( yylloc, "Multiple system tree titles defined!" );
                }
                else
                {
                    parseContext.systemtreeTitleSeen = true;
                }
                parseContext.systemtreeTitle = parseContext.str.str();
            }
            break;

        case 19:

/* Line 690 of lalr1.cc  */
#line 382 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.idSeen )
                {
                    error( yylloc, "Multiple id attributes defines!" );
                }
                else
                {
                    parseContext.idSeen = true;
                }
                if ( parseContext.longAttribute < 0 )
                {
                    error( yylloc, "Ids must be non-negative!" );
                }
                parseContext.id = ( int )parseContext.longAttribute;
            }
            break;

        case 20:

/* Line 690 of lalr1.cc  */
#line 391 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.calleeidSeen )
                {
                    error( yylloc, "Multiple callee id attributes defines!" );
                }
                else
                {
                    parseContext.calleeidSeen = true;
                }
                if ( parseContext.longAttribute < 0 )
                {
                    error( yylloc, "Callee ids of regions must be non-negative!" );
                }
                parseContext.calleeid = ( int )parseContext.longAttribute;
            }
            break;

        case 21:

/* Line 690 of lalr1.cc  */
#line 403 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.thrdidSeen )
                {
                    error( yylloc, "Multiple location id attributes defines!" );
                }
                else
                {
                    parseContext.thrdidSeen = true;
                }
                if ( parseContext.longAttribute < 0 )
                {
                    error( yylloc, "Location ids must be non-negative!" );
                }
                parseContext.locid = ( int )parseContext.longAttribute;
            }
            break;

        case 22:

/* Line 690 of lalr1.cc  */
#line 412 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.procidSeen )
                {
                    error( yylloc, "Multiple location group id attributes defines!" );
                }
                else
                {
                    parseContext.procidSeen = true;
                }
                if ( parseContext.longAttribute < 0 )
                {
                    error( yylloc, "Location group ids must be non-negative!" );
                }
                parseContext.lgid = ( int )parseContext.longAttribute;
            }
            break;

        case 23:

/* Line 690 of lalr1.cc  */
#line 421 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.nodeidSeen )
                {
                    error( yylloc, "Multiple system tree node id attributes defines!" );
                }
                else
                {
                    parseContext.nodeidSeen = true;
                }
                if ( parseContext.longAttribute < 0 )
                {
                    error( yylloc, "System tree node ids must be non-negative!" );
                }
                parseContext.stnid = ( int )parseContext.longAttribute;
            }
            break;

        case 24:

/* Line 690 of lalr1.cc  */
#line 431 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.thrdidSeen )
                {
                    error( yylloc, "Multiple thread id attributes defines!" );
                }
                else
                {
                    parseContext.thrdidSeen = true;
                }
                if ( parseContext.longAttribute < 0 )
                {
                    error( yylloc, "Thread ids must be non-negative!" );
                }
                parseContext.thrdid = ( int )parseContext.longAttribute;
            }
            break;

        case 25:

/* Line 690 of lalr1.cc  */
#line 440 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.procidSeen )
                {
                    error( yylloc, "Multiple process id attributes defines!" );
                }
                else
                {
                    parseContext.procidSeen = true;
                }
                if ( parseContext.longAttribute < 0 )
                {
                    error( yylloc, "Process ids must be non-negative!" );
                }
                parseContext.procid = ( int )parseContext.longAttribute;
            }
            break;

        case 26:

/* Line 690 of lalr1.cc  */
#line 449 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.nodeidSeen )
                {
                    error( yylloc, "Multiple node id attributes defines!" );
                }
                else
                {
                    parseContext.nodeidSeen = true;
                }
                if ( parseContext.longAttribute < 0 )
                {
                    error( yylloc, "Node ids must be non-negative!" );
                }
                parseContext.nodeid = ( int )parseContext.longAttribute;
            }
            break;

        case 27:

/* Line 690 of lalr1.cc  */
#line 458 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.machidSeen )
                {
                    error( yylloc, "Multiple machine id attributes defines!" );
                }
                else
                {
                    parseContext.machidSeen = true;
                }
                if ( parseContext.longAttribute < 0 )
                {
                    error( yylloc, "Machine ids must be non-negative!" );
                }
                parseContext.machid = ( int )parseContext.longAttribute;
            }
            break;

        case 28:

/* Line 690 of lalr1.cc  */
#line 467 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.metricidSeen )
                {
                    error( yylloc, "Multiple metric id attributes defines!" );
                }
                else
                {
                    parseContext.metricidSeen = true;
                }
                if ( parseContext.longAttribute < 0 )
                {
                    error( yylloc, "Metric ids must be non-negative!" );
                }
                parseContext.metricid = parseContext.longAttribute;
            }
            break;

        case 29:

/* Line 690 of lalr1.cc  */
#line 476 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.cnodeidSeen )
                {
                    error( yylloc, "Multiple cnode id attributes defines!" );
                }
                else
                {
                    parseContext.cnodeidSeen = true;
                }
                if ( parseContext.longAttribute < 0 )
                {
                    error( yylloc, "Cnode ids must be non-negative!" );
                }
                parseContext.cnodeid = ( int )parseContext.longAttribute;
            }
            break;

        case 30:

/* Line 690 of lalr1.cc  */
#line 487 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.beginSeen )
                {
                    error( yylloc, "Multiple begin attributes defines!" );
                }
                else
                {
                    parseContext.beginSeen = true;
                }
                parseContext.beginln = parseContext.longAttribute;
            }
            break;

        case 31:

/* Line 690 of lalr1.cc  */
#line 495 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.endSeen )
                {
                    error( yylloc, "Multiple end attributes defines!" );
                }
                else
                {
                    parseContext.endSeen = true;
                }
                parseContext.endln = parseContext.longAttribute;
            }
            break;

        case 32:

/* Line 690 of lalr1.cc  */
#line 503 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.lineSeen )
                {
                    error( yylloc, "Multiple line attributes defines!" );
                }
                else
                {
                    parseContext.lineSeen = true;
                }
                parseContext.line = parseContext.longAttribute;
            }
            break;

        case 33:

/* Line 690 of lalr1.cc  */
#line 511 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.ndimsSeen )
                {
                    error( yylloc, "Multiple ndims attributes defines!" );
                }
                else
                {
                    parseContext.ndimsSeen = true;
                }
                if ( parseContext.longAttribute <= 0 )
                {
                    error( yylloc, "Topology dimensions must be positive numbers!" );
                }
                parseContext.ndims = parseContext.longAttribute;
            }
            break;

        case 34:

/* Line 690 of lalr1.cc  */
#line 521 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.sizeSeen )
                {
                    error( yylloc, "Multiple size attributes defines!" );
                }
                else
                {
                    parseContext.sizeSeen = true;
                }
                if ( parseContext.longAttribute <= 0 )
                {
                    error( yylloc, "Dimension sizes must be positive numbers!" );
                }
                parseContext.dimVec.push_back( parseContext.longAttribute );
            }
            break;

        case 35:

/* Line 690 of lalr1.cc  */
#line 533 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.periodicSeen )
                {
                    error( yylloc, "Multiple periodic attributes defines!" );
                }
                else
                {
                    parseContext.periodicSeen = true;
                }
                parseContext.periodicVec.push_back( false );
            }
            break;

        case 36:

/* Line 690 of lalr1.cc  */
#line 539 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.periodicSeen )
                {
                    error( yylloc, "Multiple periodic attributes defined!" );
                }
                else
                {
                    parseContext.periodicSeen = true;
                }
                parseContext.periodicVec.push_back( true );
            }
            break;

        case 37:

/* Line 690 of lalr1.cc  */
#line 550 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.murlSeen )
                {
                    error( yylloc, "Multiple murl tags defined!" );
                }
                else
                {
                    parseContext.murlSeen = true;
                }
                parseContext.murl = parseContext.str.str();
            }
            break;

        case 38:

/* Line 690 of lalr1.cc  */
#line 560 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.dispnameSeen )
                {
                    error( yylloc, "Multiple disp_name tags defined!" );
                }
                else
                {
                    parseContext.dispnameSeen = true;
                }
                parseContext.disp_name = parseContext.str.str();
            }
            break;

        case 39:

/* Line 690 of lalr1.cc  */
#line 567 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.uniqnameSeen )
                {
                    error( yylloc, "Multiple uniq_name tags defined!" );
                }
                else
                {
                    parseContext.uniqnameSeen = true;
                }
                parseContext.uniq_name = parseContext.str.str();
            }
            break;

        case 40:

/* Line 690 of lalr1.cc  */
#line 573 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.dtypeSeen )
                {
                    error( yylloc, "Multiple dtype tags defined!" );
                }
                else
                {
                    parseContext.dtypeSeen = true;
                }
                parseContext.dtype = parseContext.str.str();
            }
            break;

        case 41:

/* Line 690 of lalr1.cc  */
#line 580 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.uomSeen )
                {
                    error( yylloc, "Multiple uom tags defined!" );
                }
                else
                {
                    parseContext.uomSeen = true;
                }
                parseContext.uom = parseContext.str.str();
            }
            break;

        case 42:

/* Line 690 of lalr1.cc  */
#line 587 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.valSeen )
                {
                    error( yylloc, "Multiple val tags defined!" );
                }
                else
                {
                    parseContext.valSeen = true;
                }
                parseContext.val = parseContext.str.str();
            }
            break;

        case 43:

/* Line 690 of lalr1.cc  */
#line 594 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.urlSeen )
                {
                    error( yylloc, "Multiple url tags defined!" );
                }
                else
                {
                    parseContext.urlSeen = true;
                }
                parseContext.url = parseContext.str.str();
            }
            break;

        case 46:

/* Line 690 of lalr1.cc  */
#line 606 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.expressionSeen )
                {
                    error( yylloc, "Multiple expressions defined!" );
                }
                else
                {
                    parseContext.expressionSeen = true;
                }
                parseContext.expression = services::escapeFromXML( parseContext.str.str() );
            }
            break;

        case 47:

/* Line 690 of lalr1.cc  */
#line 614 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.expressionInitSeen )
                {
                    error( yylloc, "Multiple expression initializations defined!" );
                }
                else
                {
                    parseContext.expressionInitSeen = true;
                }
                parseContext.expressionInit = services::escapeFromXML( parseContext.str.str() );
            }
            break;

        case 48:

/* Line 690 of lalr1.cc  */
#line 622 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.descrSeen )
                {
                    error( yylloc, "Multiple descr tags defined!" );
                }
                else
                {
                    parseContext.descrSeen = true;
                }
                parseContext.descr = parseContext.str.str();
            }
            break;

        case 49:

/* Line 690 of lalr1.cc  */
#line 629 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.nameSeen )
                {
                    error( yylloc, "Multiple name tags defined!" );
                }
                else
                {
                    parseContext.nameSeen = true;
                }
                parseContext.name = parseContext.str.str();
            }
            break;

        case 50:

/* Line 690 of lalr1.cc  */
#line 638 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.classSeen )
                {
                    error( yylloc, "Multiple class tags defined!" );
                }
                else
                {
                    parseContext.classSeen = true;
                }
                parseContext.stn_class = parseContext.str.str();
            }
            break;

        case 51:

/* Line 690 of lalr1.cc  */
#line 647 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.typeSeen )
                {
                    error( yylloc, "Multiple type tags defined!" );
                }
                else
                {
                    parseContext.typeSeen = true;
                }
                parseContext.type = parseContext.str.str();
            }
            break;

        case 52:

/* Line 690 of lalr1.cc  */
#line 654 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.rankSeen )
                {
                    error( yylloc, "Multiple rank tags defined!" );
                }
                else
                {
                    parseContext.rankSeen = true;
                }
                if ( parseContext.longValues.size() == 0 )
                {
                    error( yylloc, "No rank is given in a rank tag!" );
                }
                if ( parseContext.longValues.size() > 1 )
                {
                    error( yylloc, "Multiple ranks are given in a rank tag!" );
                }
                int rank = ( int )parseContext.longValues[ 0 ];
                if ( rank < 0 )
                {
                    error( yylloc, "Ranks must be non-negative!" );
                }
                parseContext.rank = rank;
            }
            break;

        case 53:

/* Line 690 of lalr1.cc  */
#line 671 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                unsigned nparameters = 0;
                if ( parseContext.cnode_parameter_type == "numeric" )
                {
                    if ( parseContext.n_cnode_num_parameters.size() != 0 || true )
                    {
                        nparameters = parseContext.n_cnode_num_parameters.top();
                        parseContext.n_cnode_num_parameters.pop();
                    }
                    nparameters++;
                    parseContext.n_cnode_num_parameters.push( nparameters );
                    std::pair<std::string, std::string > _key;
                    _key.first  =  services::escapeFromXML( parseContext.cnode_parameter_key );
                    _key.second =  services::escapeFromXML( parseContext.cnode_parameter_value );
                    parseContext.cnode_num_parameters.push( _key );
                }
                if ( parseContext.cnode_parameter_type == "string" )
                {
                    if ( parseContext.n_cnode_str_parameters.size() != 0 ||  true )
                    {
                        nparameters = parseContext.n_cnode_str_parameters.top();
                        parseContext.n_cnode_str_parameters.pop();
                    }
                    nparameters++;
                    parseContext.n_cnode_str_parameters.push( nparameters );

                    std::pair<std::string, std::string > _key;
                    _key.first  =  services::escapeFromXML( parseContext.cnode_parameter_key );
                    _key.second =  services::escapeFromXML( parseContext.cnode_parameter_value );
                    parseContext.cnode_str_parameters.push( _key );
                }
                parseContext.stringContent     = false;
                parseContext.cnodeParTypeSeen  = false;
                parseContext.cnodeParKeySeen   = false;
                parseContext.cnodeParValueSeen = false;
            }
            break;

        case 55:

/* Line 690 of lalr1.cc  */
#line 722 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                if ( !parseContext.versionSeen )
                {
                    error( yylloc, "Missing version attribute!" );
                }
                else
                {
                    parseContext.versionSeen = false;
                }
                if ( !parseContext.encodingSeen )
                {
                    error( yylloc, "Missing encoding attribute!" );
                }
                else
                {
                    parseContext.encodingSeen = false;
                }
                int valid = strcmp( parseContext.version.c_str(), "1.0" );
                if ( valid != 0 )
                {
                    error( yylloc, "XML version is expected to be 1.0!" );
                }
                valid = strcmp( parseContext.encoding.c_str(), "UTF-8" );
                if ( valid != 0 )
                {
                    error( yylloc, "XML encoding is expected to be UTF-8!" );
                }
            }
            break;

        case 61:

/* Line 690 of lalr1.cc  */
#line 754 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                parseContext.cubeVersion = 4;
            }
            break;

        case 62:

/* Line 690 of lalr1.cc  */
#line 757 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                parseContext.cubeVersion = 4.1;
            }
            break;

        case 63:

/* Line 690 of lalr1.cc  */
#line 760 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                parseContext.cubeVersion = 4.2;
            }
            break;

        case 64:

/* Line 690 of lalr1.cc  */
#line 763 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                parseContext.cubeVersion = 4.3;
            }
            break;

        case 65:

/* Line 690 of lalr1.cc  */
#line 766 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                parseContext.cubeVersion = 3;
            }
            break;

        case 66:

/* Line 690 of lalr1.cc  */
#line 769 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                throw cube::NotSupportedVersionError( parseContext.str.str() );
            }
            break;

        case 73:

/* Line 690 of lalr1.cc  */
#line 789 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                if ( !parseContext.keySeen )
                {
                    error( yylloc, "Missing key attribute!" );
                }
                else
                {
                    parseContext.keySeen = false;
                }
                if ( !parseContext.valueSeen )
                {
                    error( yylloc, "Missing value attribute!" );
                }
                else
                {
                    parseContext.valueSeen = false;
                }
                cube.def_attr( services::escapeFromXML( parseContext.key ), services::escapeFromXML( parseContext.value ) );
            }
            break;

        case 84:

/* Line 690 of lalr1.cc  */
#line 829 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            { parseContext.murlSeen = false;
              cube.def_mirror( services::escapeFromXML( parseContext.murl ) );
            }
            break;

        case 85:

/* Line 690 of lalr1.cc  */
#line 830 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            { parseContext.murlSeen = false;
              cube.def_mirror( services::escapeFromXML( parseContext.murl ) );
            }
            break;

        case 86:

/* Line 690 of lalr1.cc  */
#line 839 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                clustering_on = false;
                if ( cube.is_clustering_on() )
                {
                    clustering_on = true;
                    std::map<uint64_t, std::map<uint64_t, uint64_t> >  clusters_counter;

                    const std::map<std::string, std::string> &         attrs = cube.get_attrs();
                    std::map<std::string, std::string>::const_iterator _iter = attrs.find( "CLUSTERING" );
                    if ( _iter  != attrs.end() && ( *_iter ).second.compare( "ON" ) == 0 )
                    {
                        std::map<std::string, std::string>::const_iterator _iter = attrs.find( "CLUSTER ITERATION COUNT" );
                        if ( _iter != attrs.end() )
                        {
                            parseContext.number_of_iterations = services::string2int( ( *_iter ).second );
                            std::map<std::string, std::string>::const_iterator _iter = attrs.find( "CLUSTER ROOT CNODE ID" );
                            if ( _iter != attrs.end() )
                            {
                                parseContext.clustering_root_cnode_id = services::string2int( ( *_iter ).second );
                                for ( uint64_t iteration = 0; iteration < parseContext.number_of_iterations; iteration++ )
                                {
                                    std::string                                        iteration_number = services::numeric2string( iteration );
                                    std::string                                        key              = "CLUSTER MAPPING " + iteration_number;
                                    std::map<std::string, std::string>::const_iterator _iter            = attrs.find( key );
                                    if ( _iter != attrs.end() )
                                    {
                                        std::string           value                 = ( *_iter ).second;
                                        uint64_t              iteration_key         = iteration;
                                        std::vector<uint64_t> _cluster_id           = services::parse_clustering_value( value );
                                        std::vector<uint64_t> _collapsed_cluster_id = services::sort_and_collapse_clusters( _cluster_id );
                                        parseContext.cluster_mapping[ iteration_key ]           = _cluster_id;
                                        parseContext.cluster_positions[ iteration_key ]         = services::get_cluster_positions( _cluster_id );
                                        parseContext.collapsed_cluster_mapping[ iteration_key ] = _collapsed_cluster_id;
                                        uint64_t process_rank = 0;
                                        for ( std::vector<uint64_t>::iterator iter = _cluster_id.begin(); iter != _cluster_id.end(); iter++, process_rank++ )
                                        {
                                            uint64_t _id = *iter;
                                            clusters_counter[ _id ][ process_rank ]++;
                                        }
                                    }
                                    else
                                    {
                                        cerr << "Clustering mapping is not continuous." << endl;
                                        clustering_on = false;
                                        cube.enable_clustering( false );
                                        break;
                                    }
                                }
                                cube.set_clusters_count( clusters_counter );
                            }
                            else
                            {
                                cerr << "Cannot find cluster root cnode" << endl;
                                clustering_on = false;
                                cube.enable_clustering( false );
                            }
                        }
                        else
                        {
                            cerr << "Cannot find number of clustered iterations" << endl;
                            clustering_on = false;
                            cube.enable_clustering( false );
                        }
                    }
                    else
                    {
                        clustering_on = false;
                        cube.enable_clustering( false );
                    }
                }
            }
            break;

        case 87:

/* Line 690 of lalr1.cc  */
#line 912 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.metricsTitle != "" )
                {
                    cube.set_metrics_title( services::escapeFromXML( parseContext.metricsTitle ) );
                }
            }
            break;

        case 91:

/* Line 690 of lalr1.cc  */
#line 928 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                parseContext.idSeen = false;
                //check for tags
                if ( parseContext.metricTypeSeen )
                {
                    parseContext.metricTypeSeen = false;
                }
                else
                {
                    parseContext.metricType = "";
                }
                if ( parseContext.dispnameSeen )
                {
                    parseContext.dispnameSeen = false;
                }
                else
                {
                    parseContext.disp_name = "";
                }
                if ( parseContext.uniqnameSeen )
                {
                    parseContext.uniqnameSeen = false;
                }
                else
                {
                    parseContext.uniq_name = "";
                }
                if ( parseContext.dtypeSeen )
                {
                    parseContext.dtypeSeen = false;
                }
                else
                {
                    parseContext.dtype = "";
                }
                if ( parseContext.uomSeen )
                {
                    parseContext.uomSeen = false;
                }
                else
                {
                    parseContext.uom = "";
                }
                if ( parseContext.valSeen )
                {
                    parseContext.valSeen = false;
                }
                else
                {
                    parseContext.val = "";
                }
                if ( parseContext.urlSeen )
                {
                    parseContext.urlSeen = false;
                }
                else
                {
                    parseContext.url = "";
                }
                if ( parseContext.descrSeen )
                {
                    parseContext.descrSeen = false;
                }
                else
                {
                    parseContext.descr = "";
                }
                if ( parseContext.expressionSeen )
                {
                    parseContext.expressionSeen = false;
                }
                else
                {
                    parseContext.expression = "";
                }
                if ( parseContext.expressionInitSeen )
                {
                    parseContext.expressionInitSeen = false;
                }
                else
                {
                    parseContext.expressionInit = "";
                }

                while ( ( int )parseContext.metricVec.size() <= parseContext.id )
                {
                    parseContext.metricVec.push_back( NULL );
                }
                if ( parseContext.metricVec[ parseContext.id ] != NULL )
                {
                    error( yylloc, "Re-declared metric!" );
                }
                parseContext.currentMetric =
                    cube.def_met(
                        services::escapeFromXML( parseContext.disp_name ),
                        services::escapeFromXML( parseContext.uniq_name ),
                        services::escapeFromXML( parseContext.dtype ),
                        services::escapeFromXML( parseContext.uom ),
                        services::escapeFromXML( parseContext.val ),
                        services::escapeFromXML( parseContext.url ),
                        services::escapeFromXML( parseContext.descr ),
                        parseContext.currentMetric,
                        parseContext.id,
                        cube::Metric::get_type_of_metric( parseContext.metricType ),
                        services::escapeFromXML( parseContext.expression ),
                        services::escapeFromXML( parseContext.expressionInit ) );
                if ( parseContext.currentMetric != NULL )
                {
                    if ( parseContext.n_attributes.size() > 0 )
                    {
                        unsigned nattributes = parseContext.n_attributes.top();
                        parseContext.n_attributes.pop();

                        if ( nattributes > parseContext.attributes.size() )
                        {
                            error( yyloc, "Number of saved attributes for metric " + parseContext.uniq_name + " is more, than number of actual saved parameters." );
                        }
                        for ( unsigned i = 0; i < nattributes; i++ )
                        {
                            std::pair< std::string, std::string> attr = parseContext.attributes.top();
                            parseContext.attributes.pop();
                            parseContext.currentMetric->def_attr( attr.first, attr.second );
                        }
                    }
                    parseContext.metricVec[ parseContext.id ] = parseContext.currentMetric;
                }
                else
                {
                    std::string _error = "Cannot create metric  " + parseContext.uniq_name + ". Ignore it.";
                    cerr << _error << endl;
/*             error(yylloc,_error.c_str()); */
                }
            }
            break;

        case 108:

/* Line 690 of lalr1.cc  */
#line 1027 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                if ( !parseContext.keySeen )
                {
                    error( yylloc, "Missing key attribute!" );
                }
                else
                {
                    parseContext.keySeen = false;
                }
                if ( !parseContext.valueSeen )
                {
                    error( yylloc, "Missing value attribute!" );
                }
                else
                {
                    parseContext.valueSeen = false;
                }

                unsigned nattributes = 0;
                if ( parseContext.n_attributes.size() != 0  )
                {
                    nattributes = parseContext.n_attributes.top();
                    parseContext.n_attributes.pop();
                }
                nattributes++;
                parseContext.n_attributes.push( nattributes );
                std::pair<std::string, std::string > _key;
                _key.first  =  services::escapeFromXML( parseContext.key );
                _key.second =  services::escapeFromXML( parseContext.value );
                parseContext.attributes.push( _key );
            }
            break;

        case 109:

/* Line 690 of lalr1.cc  */
#line 1055 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.currentMetric != NULL )
                {
                    parseContext.currentMetric =
                        ( parseContext.currentMetric )->get_parent();
                }
            }
            break;

        case 110:

/* Line 690 of lalr1.cc  */
#line 1067 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.calltreeTitle != "" )
                {
                    cube.set_calltree_title( services::escapeFromXML( parseContext.calltreeTitle ) );
                }


                if ( clustering_on ) // here look for region template  and create subtrees for iterations
                {
                    // after parsing, whole stored calltree is stored not within cube, but separatelly, in parseContext.oroginal_tree_roots.
                    // here we create first a copy of the original tree without clustering subtrees
                    cube::Cnode* clusters_root = NULL;
                    cube.set_original_root_cnodev( parseContext.original_tree_roots );
                    for ( std::vector<cube::Cnode*>::iterator citer = parseContext.original_tree_roots.begin(); citer != parseContext.original_tree_roots.end(); citer++ )
                    {
                        cube::Cnode* cnode          = *citer;
                        cube::Cnode* _clusters_root = NULL;
                        services::copy_tree( cnode, _clusters_root, parseContext.clustering_root_cnode_id,  NULL, &cube );
                        if ( _clusters_root != NULL )
                        {
                            clusters_root = _clusters_root;
                        }
                    }
                    parseContext.clustering_root_cnode = clusters_root;

                    if ( services::get_children( parseContext.original_tree_roots,
                                                 parseContext.clustering_root_cnode_id,
                                                 parseContext.clusters_trees ) )
                    {
                        int i = 0;
                        for ( std::vector<cube::Cnode*>::iterator citer = parseContext.clusters_trees.begin(); citer != parseContext.clusters_trees.end(); citer++, i++ )
                        {
                            parseContext.id2cluster[ ( *citer )->get_id() ] = i;
                        }
                    }
                    else
                    {
                        clustering_on = false;
                        break;
                    }



                    // here we are going througs registered sofar regions and look for first cluster to take its region as a template for iterations
                    for ( std::vector<cube::Region*>::const_iterator riter = cube.get_regv().begin(); riter != cube.get_regv().end(); riter++ )
                    {
                        cube::Region* region = *riter;
                        if ( region->get_name().compare( "instance=1" ) == 0 )
                        {
                            parseContext.iterationRegionTemplate = region;
                            break;
                        }
                    }
                    // if we didn't found any regions, but clustering was "on" -> fatal error appeared.
                    if ( parseContext.iterationRegionTemplate == NULL ) // we didnt find any template for iteration subtree, bad cube layout
                    {
                        throw cube::CubeClusteringLayoutError( "Cannot find a template for iteration calltree." );
                    }

                    // here we merge different combinations of clusters.
                    // one can reduce amount of merges if one finds ont set of different collapsed rows - improvements for future.

                    // here we create regions for iterations
                    std::map<uint64_t,   std::map<uint64_t, uint64_t> > cluster_counter = cube.get_clusters_counter();
                    for ( unsigned i = 0; i < parseContext.number_of_iterations; i++ )
                    {
                        std::stringstream sstr;
                        std::string       iteration_name;
                        sstr << i;
                        sstr >> iteration_name;
                        // we create a regions
                        cube::Region* region =  cube.def_region(
                            "iteration=" + iteration_name,
                            parseContext.iterationRegionTemplate->get_begn_ln(),
                            parseContext.iterationRegionTemplate->get_end_ln(),
                            parseContext.iterationRegionTemplate->get_url(),
                            parseContext.iterationRegionTemplate->get_descr(),
                            parseContext.iterationRegionTemplate->get_mod()
                            );
                        parseContext.iteration_regions.push_back( region );
                        // create its cnode
                        cube::Cnode* iteration_cnode = cube.def_cnode(
                            region,
                            region->get_mod(),
                            region->get_begn_ln(),
                            parseContext.clustering_root_cnode
                            );

                        // here we merge all subtrees of all clusters to this callpath.
                        std::vector<cube::Cnode*> subtrees;
                        for ( std::vector< uint64_t>::iterator iter = parseContext.collapsed_cluster_mapping[ i ].begin(); iter != parseContext.collapsed_cluster_mapping[ i ].end(); iter++  )
                        {
                            uint64_t                     _cluster_id            = *iter;
                            std::map<uint64_t, uint64_t> _cluster_normalization = cluster_counter[ _cluster_id ];
                            uint64_t                     _cluster_position      = parseContext.id2cluster[ _cluster_id ];
                            cube::Cnode*                 cluster_root           = parseContext.clusters_trees[ _cluster_position ];
                            cube.store_ghost_cnode( cluster_root );
                            for ( size_t j = 0; j <  parseContext.cluster_positions[ i ][ _cluster_id ].size(); j++ )
                            {
                                iteration_cnode->set_remapping_cnode( parseContext.cluster_positions[ i ][ _cluster_id ][ j ], cluster_root,  _cluster_normalization[ parseContext.cluster_positions[ i ][ _cluster_id ][ j ] ] );
                            }
                            services::gather_children( subtrees, cluster_root );
                            services::merge_trees( subtrees, iteration_cnode, &cube, &_cluster_normalization, &( parseContext.cluster_positions[ i ][ _cluster_id ] ) );
                        }
                    }
                }
            }
            break;

        case 113:

/* Line 690 of lalr1.cc  */
#line 1177 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for the attributes
                if ( !parseContext.idSeen )
                {
                    error( yylloc, "Missing id attribute!" );
                }
                else
                {
                    parseContext.idSeen = false;
                }
                if ( !parseContext.modSeen )
                {
                    parseContext.mod = "";
                }
                else
                {
                    parseContext.modSeen = false;
                }
                if ( !parseContext.beginSeen )
                {
                    parseContext.beginln = -1;
                }
                else
                {
                    parseContext.beginSeen = false;
                }
                if ( !parseContext.endSeen )
                {
                    parseContext.endln = -1;
                }
                else
                {
                    parseContext.endSeen = false;
                }

                //check for tags
                if ( parseContext.nameSeen )
                {
                    parseContext.nameSeen = false;
                }
                else
                {
                    parseContext.name = "";
                }
                if ( parseContext.urlSeen )
                {
                    parseContext.urlSeen = false;
                }
                else
                {
                    parseContext.url = "";
                }
                if ( parseContext.descrSeen )
                {
                    parseContext.descrSeen = false;
                }
                else
                {
                    parseContext.descr = "";
                }

                while ( ( int )parseContext.regionVec.size() <= parseContext.id )
                {
                    parseContext.regionVec.push_back( NULL );
                }
                if ( parseContext.regionVec[ parseContext.id ] != NULL )
                {
                    error( yylloc, "Re-declared region!" );
                }

                cube::Region* _region =
                    cube.def_region(
                        services::escapeFromXML( parseContext.name ),
                        parseContext.beginln,
                        parseContext.endln,
                        parseContext.url,
                        services::escapeFromXML( parseContext.descr ),
                        services::escapeFromXML( parseContext.mod ),
                        parseContext.id );
                if ( parseContext.n_attributes.size() > 0 )
                {
                    unsigned nattributes = parseContext.n_attributes.top();
                    parseContext.n_attributes.pop();

                    if ( nattributes > parseContext.attributes.size() )
                    {
                        error( yyloc, "Number of saved attributes for region " + parseContext.name + " is more, than number of actual saved parameters." );
                    }
                    for ( unsigned i = 0; i < nattributes; i++ )
                    {
                        std::pair< std::string, std::string> attr = parseContext.attributes.top();
                        parseContext.attributes.pop();
                        _region->def_attr( attr.first, attr.second );
                    }
                }
                parseContext.regionVec[ parseContext.id ] = _region;
            }
            break;

        case 130:

/* Line 690 of lalr1.cc  */
#line 1268 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.n_attributes.size() > 0 )
                {
                    unsigned nattributes = parseContext.n_attributes.top();
                    parseContext.n_attributes.pop();

                    if ( nattributes > parseContext.attributes.size() )
                    {
                        error( yyloc, "Number of saved attributes for cnode is more, than number of actual saved parameters." );
                    }
                    for ( unsigned i = 0; i < nattributes; i++ )
                    {
                        std::pair< std::string, std::string> attr = parseContext.attributes.top();
                        parseContext.attributes.pop();
                        parseContext.currentCnode->def_attr( attr.first, attr.second );
                    }
                }


                if ( !clustering_on )
                {
                    if ( parseContext.currentCnode == NULL )
                    {
                        error( yylloc, "Cnode definitions are not correctly nested!" );
                    }


                    if ( !parseContext.n_cnode_num_parameters.empty()  )
                    {
                        unsigned nparameters = parseContext.n_cnode_num_parameters.top();
                        parseContext.n_cnode_num_parameters.pop();

                        if ( nparameters > parseContext.cnode_num_parameters.size() )
                        {
                            error( yyloc, "Number of saved numeric parameters for current cnode is more, than number of actual saved parameters." );
                        }
                        for ( unsigned i = 0; i < nparameters; i++ )
                        {
                            std::pair< std::string, std::string> param = parseContext.cnode_num_parameters.top();

                            parseContext.cnode_num_parameters.pop();

                            double d_value = atof( param.second.data() );
                            parseContext.currentCnode->add_num_parameter( param.first, d_value );
                        }
                    }
                    if ( !parseContext.n_cnode_str_parameters.empty()  )
                    {
                        unsigned nparameters = parseContext.n_cnode_str_parameters.top();
                        parseContext.n_cnode_str_parameters.pop();

                        if ( nparameters > parseContext.cnode_str_parameters.size() )
                        {
                            error( yyloc, "Number of saved string parameters for current cnode is more, than number of actual saved parameters." );
                        }
                        for ( unsigned i = 0; i < nparameters; i++ )
                        {
                            std::pair< std::string, std::string> param = parseContext.cnode_str_parameters.top();
                            parseContext.cnode_str_parameters.pop();
                            parseContext.currentCnode->add_str_parameter( param.first, param.second );
                        }
                    }

                    parseContext.currentCnode =
                        parseContext.currentCnode->get_parent();
                    parseContext.start_parse_clusters = false;
                }
                else
                {
                    if ( parseContext.clusterCurrentCnode == NULL )
                    {
                        error( yylloc, "Cluster cnode definitions are not correctly nested!" );
                    }


                    if ( !parseContext.n_cnode_num_parameters.empty()  )
                    {
                        unsigned nparameters = parseContext.n_cnode_num_parameters.top();
                        parseContext.n_cnode_num_parameters.pop();

                        if ( nparameters > parseContext.cnode_num_parameters.size() )
                        {
                            error( yyloc, "Number of saved numeric parameters for current cnode is more, than number of actual saved parameters." );
                        }
                        for ( unsigned i = 0; i < nparameters; i++ )
                        {
                            std::pair< std::string, std::string> param = parseContext.cnode_num_parameters.top();

                            parseContext.cnode_num_parameters.pop();

                            double d_value = atof( param.second.data() );
                            parseContext.clusterCurrentCnode->add_num_parameter( param.first, d_value );
                        }
                    }
                    if ( !parseContext.n_cnode_str_parameters.empty()  )
                    {
                        unsigned nparameters = parseContext.n_cnode_str_parameters.top();
                        parseContext.n_cnode_str_parameters.pop();

                        if ( nparameters > parseContext.cnode_str_parameters.size() )
                        {
                            error( yyloc, "Number of saved string parameters for current cnode is more, than number of actual saved parameters." );
                        }
                        for ( unsigned i = 0; i < nparameters; i++ )
                        {
                            std::pair< std::string, std::string> param = parseContext.cnode_str_parameters.top();
                            parseContext.cnode_str_parameters.pop();
                            parseContext.clusterCurrentCnode->add_str_parameter( param.first, param.second );
                        }
                    }

                    parseContext.clusterCurrentCnode =
                        parseContext.clusterCurrentCnode->get_parent();
                    if ( parseContext.clusterCurrentCnode == NULL )
                    {
                        parseContext.parse_clusters = false;
                    }
                }
            }
            break;

        case 131:

/* Line 690 of lalr1.cc  */
#line 1390 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for the attributes
                if ( !parseContext.idSeen )
                {
                    error( yylloc, "Missing id attribute in cnode definition!" );
                }
                else
                {
                    parseContext.idSeen = false;
                }
                if ( !parseContext.calleeidSeen )
                {
                    error( yylloc, "Missing callee id attribute in cnode definition!" );
                }
                else
                {
                    parseContext.calleeidSeen = false;
                }
                if ( !parseContext.lineSeen )
                {
                    parseContext.line = -1;
                }
                else
                {
                    parseContext.lineSeen = false;
                }
                if ( !parseContext.modSeen )
                {
                    parseContext.mod = "";
                }
                else
                {
                    parseContext.modSeen = false;
                }
                //check if the region is defined
                if ( ( int )parseContext.regionVec.size() <= parseContext.calleeid )
                {
                    error( yylloc, "Undefined region in cnode definition!" );
                }
                if ( parseContext.regionVec[ parseContext.calleeid ] == NULL )
                {
                    error( yylloc, "Undefined region in cnode definition!" );
                }
                //extend the cnode vector if necessary
                while ( ( int )parseContext.cnodeVec.size() <= parseContext.id )
                {
                    parseContext.cnodeVec.push_back( NULL );
                }
                if ( parseContext.cnodeVec[ parseContext.id ] != NULL )
                {
                    error( yylloc, "Re-declared cnode!" );
                }
                //define the cnode

                parseContext.cnodeParTypeSeen  = false;
                parseContext.cnodeParKeySeen   = false;
                parseContext.cnodeParValueSeen = false;

                if ( clustering_on )
                {
                    parseContext.clusterCurrentCnode = new cube::Cnode( parseContext.regionVec[ parseContext.calleeid ],
                                                                        services::escapeFromXML( parseContext.mod ),
                                                                        parseContext.line,
                                                                        parseContext.clusterCurrentCnode,
                                                                        parseContext.id );
                    if ( parseContext.clusterCurrentCnode->get_parent() == NULL ) // store root call path for cluster in a vector.
                    {
                        parseContext.original_tree_roots.push_back( parseContext.clusterCurrentCnode );
                    }
                }
                else
                {
                    parseContext.currentCnode = cube.def_cnode(
                        parseContext.regionVec[ parseContext.calleeid ],
                        services::escapeFromXML( parseContext.mod ),
                        parseContext.line,
                        parseContext.currentCnode,
                        parseContext.id );

                    parseContext.cnodeVec[ parseContext.id ] =
                        parseContext.currentCnode;
                }
            }
            break;

        case 142:

/* Line 690 of lalr1.cc  */
#line 1475 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( parseContext.systemtreeTitle != "" )
                {
                    cube.set_systemtree_title( services::escapeFromXML( parseContext.systemtreeTitle ) );
                }
            }
            break;

        case 147:

/* Line 690 of lalr1.cc  */
#line 1493 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                parseContext.idSeen = false;
                //check for tags
                parseContext.nameSeen = false;
                if ( !parseContext.classSeen )
                {
                    error( yylloc, "No class of system tree node declared." );
                }
                parseContext.classSeen = false;
                if ( parseContext.descrSeen )
                {
                    parseContext.descrSeen = false;
                }
                else
                {
                    parseContext.descr = "";
                }

                cube::SystemTreeNode* _stn = cube.def_system_tree_node(
                    services::escapeFromXML( parseContext.name ),
                    services::escapeFromXML( parseContext.descr ),
                    services::escapeFromXML( parseContext.stn_class ),
                    ( parseContext.currentSystemTreeNode.size() == 0 ) ? NULL : parseContext.currentSystemTreeNode.top() );
                if ( parseContext.n_attributes.size() > 0 )
                {
                    unsigned nattributes = parseContext.n_attributes.top();
                    parseContext.n_attributes.pop();

                    if ( nattributes > parseContext.attributes.size() )
                    {
                        error( yyloc, "Number of saved attributes for metric " + parseContext.uniq_name + " is more, than number of actual saved parameters." );
                    }
                    for ( unsigned i = 0; i < nattributes; i++ )
                    {
                        std::pair< std::string, std::string> attr = parseContext.attributes.top();
                        parseContext.attributes.pop();
                        _stn->def_attr( attr.first, attr.second );
                    }
                }


                parseContext.currentSystemTreeNode.push( _stn );
                while ( ( unsigned int )parseContext.stnVec.size() <= _stn->get_id() )
                {
                    parseContext.stnVec.push_back( NULL );
                }
                if ( parseContext.stnVec[ _stn->get_id() ] != NULL )
                {
                    error( yylloc, "Re-declared system tree node!" );
                }
                parseContext.stnVec[ _stn->get_id() ] = _stn;
            }
            break;

        case 148:

/* Line 690 of lalr1.cc  */
#line 1537 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                parseContext.currentSystemTreeNode.pop();
                //check for attributes
                parseContext.idSeen = false;
                //check for tags
                parseContext.nameSeen = false;
                if ( parseContext.descrSeen )
                {
                    parseContext.descrSeen = false;
                }
                else
                {
                    parseContext.descr = "";
                }
            }
            break;

        case 155:

/* Line 690 of lalr1.cc  */
#line 1572 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                parseContext.idSeen = false;
                //check for tags
                parseContext.nameSeen = false;
                parseContext.rankSeen = false;
                if ( !parseContext.typeSeen )
                {
                    error( yylloc, "No type of location group declared." );
                }
                parseContext.typeSeen = false;

                if ( parseContext.descrSeen )
                {
                    parseContext.descrSeen = false;
                }
                else
                {
                    parseContext.descr = "";
                }

                parseContext.currentLocationGroup = cube.def_location_group(
                    services::escapeFromXML( parseContext.name ),
                    parseContext.rank,
                    cube::LocationGroup::getLocationGroupType( services::escapeFromXML( parseContext.type ) ),
                    parseContext.currentSystemTreeNode.top() );

                if ( parseContext.n_attributes.size() > 0 )
                {
                    unsigned nattributes = parseContext.n_attributes.top();
                    parseContext.n_attributes.pop();

                    if ( nattributes > parseContext.attributes.size() )
                    {
                        error( yyloc, "Number of saved attributes for location group " + parseContext.name + " is more, than number of actual saved parameters." );
                    }
                    for ( unsigned i = 0; i < nattributes; i++ )
                    {
                        std::pair< std::string, std::string> attr = parseContext.attributes.top();
                        parseContext.attributes.pop();
                        parseContext.currentLocationGroup->def_attr( attr.first, attr.second );
                    }
                }


                while ( ( unsigned int )parseContext.locGroup.size() <= parseContext.currentLocationGroup->get_id() )
                {
                    parseContext.locGroup.push_back( NULL );
                }
                if ( parseContext.locGroup[ parseContext.currentLocationGroup->get_id() ] != NULL )
                {
                    error( yylloc, "Re-declared location group!" );
                }
                parseContext.locGroup[ parseContext.currentLocationGroup->get_id() ] = parseContext.currentLocationGroup;
            }
            break;

        case 163:

/* Line 690 of lalr1.cc  */
#line 1637 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                parseContext.idSeen = false;
                //check for tags
                parseContext.nameSeen = false;
                parseContext.rankSeen = false;

                if ( !parseContext.typeSeen )
                {
                    error( yylloc, "No type of location group declared." );
                }
                parseContext.typeSeen        = false;
                parseContext.currentLocation = cube.def_location(
                    services::escapeFromXML( parseContext.name ),
                    parseContext.rank,
                    cube::Location::getLocationType( services::escapeFromXML( parseContext.type ) ),
                    parseContext.currentLocationGroup,
                    parseContext.id );
                if ( parseContext.n_attributes.size() > 0 )
                {
                    unsigned nattributes = parseContext.n_attributes.top();
                    parseContext.n_attributes.pop();

                    if ( nattributes > parseContext.attributes.size() )
                    {
                        error( yyloc, "Number of saved attributes for location " + parseContext.name + " is more, than number of actual saved parameters." );
                    }
                    for ( unsigned i = 0; i < nattributes; i++ )
                    {
                        std::pair< std::string, std::string> attr = parseContext.attributes.top();
                        parseContext.attributes.pop();
                        parseContext.currentLocation->def_attr( attr.first, attr.second );
                    }
                }

                while ( ( unsigned int )parseContext.locVec.size() <= parseContext.currentLocation->get_id() )
                {
                    parseContext.locVec.push_back( NULL );
                }
                if ( parseContext.locVec[ parseContext.currentLocation->get_id() ] != NULL )
                {
                    error( yylloc, "Re-declared location!" );
                }
                parseContext.locVec[ parseContext.currentLocation->get_id() ] = parseContext.currentLocation;
            }
            break;

        case 166:

/* Line 690 of lalr1.cc  */
#line 1687 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                parseContext.idSeen = false;
                //check for tags
                parseContext.nameSeen = false;
                if ( parseContext.descrSeen )
                {
                    parseContext.descrSeen = false;
                }
                else
                {
                    parseContext.descr = "";
                }

                parseContext.currentMachine = cube.def_mach(
                    services::escapeFromXML( parseContext.name ),
                    services::escapeFromXML( parseContext.descr ) );
                while ( ( unsigned int )parseContext.machVec.size() <= parseContext.currentMachine->get_id() )
                {
                    parseContext.machVec.push_back( NULL );
                }
                if ( parseContext.machVec[ parseContext.currentMachine->get_id() ] != NULL )
                {
                    error( yylloc, "Re-declared machine!" );
                }
                parseContext.machVec[ parseContext.currentMachine->get_id() ] = parseContext.currentMachine;
            }
            break;

        case 170:

/* Line 690 of lalr1.cc  */
#line 1712 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                parseContext.idSeen = false;
                //check for tags
                parseContext.nameSeen = false;
                if ( parseContext.descrSeen )
                {
                    parseContext.descrSeen = false;
                }
                else
                {
                    parseContext.descr = "";
                }

                parseContext.currentNode = cube.def_node(
                    services::escapeFromXML( parseContext.name ),
                    parseContext.currentMachine );
                while ( ( unsigned int )parseContext.nodeVec.size() <= parseContext.currentNode->get_id() )
                {
                    parseContext.nodeVec.push_back( NULL );
                }
                if ( parseContext.nodeVec[ parseContext.currentNode->get_id() ] != NULL )
                {
                    error( yylloc, "Re-declared node!" );
                }
                parseContext.nodeVec[ parseContext.currentNode->get_id() ] = parseContext.currentNode;
            }
            break;

        case 174:

/* Line 690 of lalr1.cc  */
#line 1737 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                parseContext.idSeen = false;
                //check for tags
                if ( parseContext.nameSeen )
                {
                    parseContext.nameSeen = false;
                }
                else
                {
                    parseContext.name = "";
                }
                if ( parseContext.rankSeen )
                {
                    parseContext.rankSeen = false;
                }
                else
                {
                    parseContext.rank = 0;
                }

                std::ostringstream name;
                if ( parseContext.name.empty() )
                {
                    name << "Process " << parseContext.rank;
                }
                else
                {
                    name << parseContext.name;
                }
                parseContext.currentProc = cube.def_proc(
                    services::escapeFromXML( name.str() ),
                    parseContext.rank,
                    parseContext.currentNode );
                while ( ( unsigned int )parseContext.procVec.size() <= parseContext.currentProc->get_id() )
                {
                    parseContext.procVec.push_back( NULL );
                }
                if ( parseContext.procVec[ parseContext.currentProc->get_id() ] != NULL )
                {
                    error( yylloc, "Re-declared process!" );
                }
                parseContext.procVec[ parseContext.currentProc->get_id() ] = parseContext.currentProc;
            }
            break;

        case 182:

/* Line 690 of lalr1.cc  */
#line 1779 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                parseContext.idSeen = false;
                //check for tags
                if ( parseContext.nameSeen )
                {
                    parseContext.nameSeen = false;
                }
                else
                {
                    parseContext.name = "";
                }
                if ( parseContext.rankSeen )
                {
                    parseContext.rankSeen = false;
                }
                else
                {
                    parseContext.rank = 0;
                }

                std::ostringstream name;
                if ( parseContext.name.empty() )
                {
                    name << "Thread " << parseContext.rank;
                }
                else
                {
                    name << parseContext.name;
                }
                parseContext.currentThread = cube.def_thrd(
                    services::escapeFromXML( name.str() ),
                    parseContext.rank,
                    parseContext.currentProc,
                    parseContext.id );
                while ( ( unsigned int )parseContext.threadVec.size() <= parseContext.currentThread->get_id() )
                {
                    parseContext.threadVec.push_back( NULL );
                }
                if ( parseContext.threadVec[ parseContext.currentThread->get_id() ] != NULL )
                {
                    error( yylloc, "Re-declared thread!" );
                }
                parseContext.threadVec[ parseContext.currentThread->get_id() ] = parseContext.currentThread;
            }
            break;

        case 185:

/* Line 690 of lalr1.cc  */
#line 1812 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( !parseContext.checkThreadIds() )
                {
                    error( yylloc, "Thread ids must cover an interval [0,n] without gap!" );
                }
            }
            break;

        case 193:

/* Line 690 of lalr1.cc  */
#line 1833 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                parseContext.ndimsSeen = false;

                if ( parseContext.ndims != ( int )parseContext.dimVec.size() )
                {
                    error( yylloc, "Too few or too many topology dimensions are declared!" );
                }
                parseContext.currentCart = cube.def_cart(
                    parseContext.ndims,
                    parseContext.dimVec,
                    parseContext.periodicVec );

                if ( parseContext.cartNameSeen )
                {
                    ( parseContext.currentCart )->set_name( services::escapeFromXML( parseContext.cartName ) );
                    parseContext.cartNameSeen = false;
                }
                if ( parseContext.dimNamesCount > 0 )
                {
                    parseContext.dimNamesCount = 0;
                    ( parseContext.currentCart )->set_namedims( parseContext.dimNameVec );
                }
                parseContext.dimNameVec.clear();
            }
            break;

        case 195:

/* Line 690 of lalr1.cc  */
#line 1860 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            { parseContext.dimVec.clear();
              parseContext.periodicVec.clear();
              parseContext.cartNameSeen = false;
            }
            break;

        case 198:

/* Line 690 of lalr1.cc  */
#line 1872 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                if ( !parseContext.sizeSeen )
                {
                    error( yylloc, "Missing size attribute!" );
                }
                else
                {
                    parseContext.sizeSeen = false;
                }
                if ( !parseContext.periodicSeen )
                {
                    error( yylloc, "Missing periodic attribute!" );
                }
                else
                {
                    parseContext.periodicSeen = false;
                }
                if ( parseContext.dimNameSeen )
                {
                    parseContext.dimNameVec.push_back( parseContext.dimName );
                }
                else
                {
                    parseContext.dimNameVec.push_back( "" );
                }
                parseContext.dimNameSeen = false;
            }
            break;

        case 213:

/* Line 690 of lalr1.cc  */
#line 1921 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                parseContext.thrdidSeen = false;

                if ( parseContext.dimVec.size() != parseContext.longValues.size() )
                {
                    error( yylloc, "Too few or too many dimension coordinates in coord tag!" );
                }
                for ( unsigned i = 0; i < parseContext.dimVec.size(); i++ )
                {
                    if ( parseContext.longValues[ i ] >= parseContext.dimVec[ i ] )
                    {
                        error( yylloc, "Topology coordinate is out of range!" );
                    }
                }
                if ( parseContext.locid >= ( int )parseContext.locVec.size() )
                {
                    error( yylloc, "Location of the topology coordinates wasn't declared!" );
                }
                if ( parseContext.locVec[ parseContext.locid ] == NULL )
                {
                    error( yylloc, "Location of the topology coordinates wasn't declared!" );
                }
                cube.def_coords( parseContext.currentCart,
                                 ( cube::Sysres* )( parseContext.locVec[ parseContext.locid ] ),
                                 parseContext.longValues );
            }
            break;

        case 214:

/* Line 690 of lalr1.cc  */
#line 1942 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                parseContext.procidSeen = false;

                if ( parseContext.dimVec.size() != parseContext.longValues.size() )
                {
                    error( yylloc, "Too few or too many dimension coordinates in coord tag!" );
                }
                for ( unsigned i = 0; i < parseContext.dimVec.size(); i++ )
                {
                    if ( parseContext.longValues[ i ] >= parseContext.dimVec[ i ] )
                    {
                        error( yylloc, "Topology coordinate is out of range!" );
                    }
                }
                if ( parseContext.lgid >= ( int )parseContext.locGroup.size() )
                {
                    error( yylloc, "Location group of the topology coordinates wasn't declared!" );
                }
                if ( parseContext.locGroup[ parseContext.lgid ] == NULL )
                {
                    error( yylloc, "Location group of the topology coordinates wasn't declared!" );
                }
                cube.def_coords( parseContext.currentCart,
                                 ( cube::Sysres* )( parseContext.locGroup[ parseContext.lgid ] ),
                                 parseContext.longValues );
            }
            break;

        case 215:

/* Line 690 of lalr1.cc  */
#line 1963 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                parseContext.nodeidSeen = false;

                if ( parseContext.dimVec.size() != parseContext.longValues.size() )
                {
                    error( yylloc, "Too few or too many dimension coordinates in coord tag!" );
                }
                for ( unsigned i = 0; i < parseContext.dimVec.size(); i++ )
                {
                    if ( parseContext.longValues[ i ] >= parseContext.dimVec[ i ] )
                    {
                        error( yylloc, "Topology coordinate is out of range!" );
                    }
                }
                if ( parseContext.stnid >= ( int )parseContext.stnVec.size() )
                {
                    error( yylloc, "System tree node of the topology coordinates wasn't declared!" );
                }
                if ( parseContext.nodeVec[ parseContext.stnid ] == NULL )
                {
                    error( yylloc, "System tree node of the topology coordinates wasn't declared!" );
                }
                cube.def_coords( parseContext.currentCart,
                                 ( cube::Sysres* )( parseContext.nodeVec[ parseContext.stnid ] ),
                                 parseContext.longValues );
            }
            break;

        case 216:

/* Line 690 of lalr1.cc  */
#line 1985 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                parseContext.thrdidSeen = false;

                if ( parseContext.dimVec.size() != parseContext.longValues.size() )
                {
                    error( yylloc, "Too few or too many dimension coordinates in coord tag!" );
                }
                for ( unsigned i = 0; i < parseContext.dimVec.size(); i++ )
                {
                    if ( parseContext.longValues[ i ] >= parseContext.dimVec[ i ] )
                    {
                        error( yylloc, "Topology coordinate is out of range!" );
                    }
                }
                if ( parseContext.thrdid >= ( int )parseContext.threadVec.size() )
                {
                    error( yylloc, "Thread of the topology coordinates wasn't declared!" );
                }
                if ( parseContext.threadVec[ parseContext.thrdid ] == NULL )
                {
                    error( yylloc, "Thread of the topology coordinates wasn't declared!" );
                }
                cube.def_coords( parseContext.currentCart,
                                 ( cube::Sysres* )( parseContext.threadVec[ parseContext.thrdid ] ),
                                 parseContext.longValues );
            }
            break;

        case 217:

/* Line 690 of lalr1.cc  */
#line 2006 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                parseContext.procidSeen = false;

                if ( parseContext.dimVec.size() != parseContext.longValues.size() )
                {
                    error( yylloc, "Too few or too many dimension coordinates in coord tag!" );
                }
                for ( unsigned i = 0; i < parseContext.dimVec.size(); i++ )
                {
                    if ( parseContext.longValues[ i ] >= parseContext.dimVec[ i ] )
                    {
                        error( yylloc, "Topology coordinate is out of range!" );
                    }
                }
                if ( parseContext.procid >= ( int )parseContext.locGroup.size() )
                {
                    error( yylloc, "Process of the topology coordinates wasn't declared!" );
                }
                if ( parseContext.locGroup[ parseContext.procid ] == NULL )
                {
                    error( yylloc, "Process of the topology coordinates wasn't declared!" );
                }
                cube.def_coords( parseContext.currentCart,
                                 ( cube::Sysres* )( parseContext.locGroup[ parseContext.procid ] ),
                                 parseContext.longValues );
            }
            break;

        case 218:

/* Line 690 of lalr1.cc  */
#line 2027 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                parseContext.nodeidSeen = false;

                if ( parseContext.dimVec.size() != parseContext.longValues.size() )
                {
                    error( yylloc, "Too few or too many dimension coordinates in coord tag!" );
                }
                for ( unsigned i = 0; i < parseContext.dimVec.size(); i++ )
                {
                    if ( parseContext.longValues[ i ] >= parseContext.dimVec[ i ] )
                    {
                        error( yylloc, "Topology coordinate is out of range!" );
                    }
                }

                if ( parseContext.nodeid >= ( int )cube.get_non_root_stnv().size() )
                {
                    error( yylloc, "Node of the topology coordinates wasn't declared!" );
                }
                if ( cube.get_non_root_stnv().at( parseContext.nodeid ) == NULL )
                {
                    error( yylloc, "Node of the topology coordinates wasn't declared!" );
                }
                cube.def_coords( parseContext.currentCart,
                                 ( cube::Sysres* )( cube.get_non_root_stnv().at( parseContext.nodeid ) ),
                                 parseContext.longValues );
            }
            break;

        case 219:

/* Line 690 of lalr1.cc  */
#line 2049 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                parseContext.machidSeen = false;

                if ( parseContext.dimVec.size() != parseContext.longValues.size() )
                {
                    error( yylloc, "Too few or too many dimension coordinates in coord tag!" );
                }
                for ( unsigned i = 0; i < parseContext.dimVec.size(); i++ )
                {
                    if ( parseContext.longValues[ i ] >= parseContext.dimVec[ i ] )
                    {
                        error( yylloc, "Topology coordinate is out of range!" );
                    }
                }
                if ( parseContext.machid >= ( int )cube.get_root_stnv().size() )
                {
                    error( yylloc, "Machine of the topology coordinates wasn't declared!" );
                }
                if ( cube.get_root_stnv().at( parseContext.nodeid ) == NULL )
                {
                    error( yylloc, "Machine of the topology coordinates wasn't declared!" );
                }
                cube.def_coords( parseContext.currentCart,
                                 ( cube::Sysres* )( cube.get_root_stnv().at( parseContext.machid ) ),
                                 parseContext.longValues );
            }
            break;

        case 222:

/* Line 690 of lalr1.cc  */
#line 2076 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            { if ( parseContext.dynamicMetricLoading )
              {
                  return 0;
              }
            }
            break;

        case 226:

/* Line 690 of lalr1.cc  */
#line 2086 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                parseContext.metricidSeen = false;

                if ( ( int )parseContext.metricVec.size() <= parseContext.metricid )
                {
                    error( yylloc, "Metric of the severity matrix wasn't declared!" );
                }
                if ( parseContext.metricVec[ parseContext.metricid ] == NULL )
                {
                    error( yylloc, "Metric of the severity matrix wasn't declared!" );
                }
                parseContext.currentMetric =
                    parseContext.metricVec[ parseContext.metricid ];

                parseContext.ignoreMetric = false;
                cube::Metric* metric = parseContext.currentMetric;
                while ( metric != NULL )
                {
                    if ( metric->get_val() == "VOID" )
                    {
                        parseContext.ignoreMetric = true;
                        break;
                    }
                    metric = metric->get_parent();
                }
            }
            break;

        case 232:

/* Line 690 of lalr1.cc  */
#line 2119 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                //check for attributes
                parseContext.cnodeidSeen = false;

                if ( !parseContext.ignoreMetric )
                {
                    if ( ( int )parseContext.cnodeVec.size() <= parseContext.cnodeid )
                    {
                        error( yylloc, "Cnode of the severity row wasn't declared!" );
                    }
                    if ( parseContext.cnodeVec[ parseContext.cnodeid ] == NULL )
                    {
                        error( yylloc, "Cnode of the severity row wasn't declared!" );
                    }
                    parseContext.currentCnode =
                        parseContext.cnodeVec[ parseContext.cnodeid ];
                }
            }
            break;

        case 233:

/* Line 690 of lalr1.cc  */
#line 2131 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
            {
                if ( !parseContext.ignoreMetric )
                {
                    std::vector<double> &        v = parseContext.realValues;
                    std::vector<cube::Thread*> & t = parseContext.threadVec;
                    if ( v.size() > t.size() )
                    {
                        error( yylloc, "Too many values in severity row!" );
                    }
                    cube::Metric* metric = parseContext.currentMetric;
                    cube::Cnode*  cnode  = parseContext.currentCnode;
                    for ( unsigned i = 0; i < v.size(); i++ )
                    {
                        cube.set_sev( metric,
                                      cnode,
                                      t[ i ],
                                      v[ i ] );
                    }
                }
            }
            break;



/* Line 690 of lalr1.cc  */
#line 2352 "../../build-backend/../src/cube/src/syntax/Cube4Parser.cpp"
        default:
            break;
    }
    /* User semantic actions sometimes alter yychar, and that requires
       that yytoken be updated with the new translation.  We take the
       approach of translating immediately before every use of yytoken.
       One alternative is translating here after every semantic action,
       but that translation would be missed if the semantic action
       invokes YYABORT, YYACCEPT, or YYERROR immediately after altering
       yychar.  In the case of YYABORT or YYACCEPT, an incorrect
       destructor might then be invoked immediately.  In the case of
       YYERROR, subsequent parser actions might lead to an incorrect
       destructor call or verbose syntax error message before the
       lookahead is translated.  */
    YY_SYMBOL_PRINT( "-> $$ =", yyr1_[ yyn ], &yyval, &yyloc );

    yypop_( yylen );
    yylen = 0;
    YY_STACK_PRINT();

    yysemantic_stack_.push( yyval );
    yylocation_stack_.push( yyloc );

    /* Shift the result of the reduction.  */
    yyn     = yyr1_[ yyn ];
    yystate = yypgoto_[ yyn - yyntokens_ ] + yystate_stack_[ 0 ];
    if ( 0 <= yystate && yystate <= yylast_
         && yycheck_[ yystate ] == yystate_stack_[ 0 ] )
    {
        yystate = yytable_[ yystate ];
    }
    else
    {
        yystate = yydefgoto_[ yyn - yyntokens_ ];
    }
    goto yynewstate;

    /*------------------------------------.
    | yyerrlab -- here on detecting error |
       `------------------------------------*/
yyerrlab:
    /* Make sure we have latest lookahead translation.  See comments at
       user semantic actions for why this is necessary.  */
    yytoken = yytranslate_( yychar );

    /* If not already recovering from an error, report this error.  */
    if ( !yyerrstatus_ )
    {
        ++yynerrs_;
        if ( yychar == yyempty_ )
        {
            yytoken = yyempty_;
        }
        error( yylloc, yysyntax_error_( yystate, yytoken ) );
    }

    yyerror_range[ 1 ] = yylloc;
    if ( yyerrstatus_ == 3 )
    {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        if ( yychar <= yyeof_ )
        {
            /* Return failure if at end of input.  */
            if ( yychar == yyeof_ )
            {
                YYABORT;
            }
        }
        else
        {
            yydestruct_( "Error: discarding", yytoken, &yylval, &yylloc );
            yychar = yyempty_;
        }
    }

    /* Else will try to reuse lookahead token after shifting the error
       token.  */
    goto yyerrlab1;


    /*---------------------------------------------------.
    | yyerrorlab -- error raised explicitly by YYERROR.  |
       `---------------------------------------------------*/
yyerrorlab:

    /* Pacify compilers like GCC when the user code never invokes
       YYERROR and the label yyerrorlab therefore never appears in user
       code.  */
    if ( false )
    {
        goto yyerrorlab;
    }

    yyerror_range[ 1 ] = yylocation_stack_[ yylen - 1 ];
    /* Do not reclaim the symbols of the rule which action triggered
       this YYERROR.  */
    yypop_( yylen );
    yylen   = 0;
    yystate = yystate_stack_[ 0 ];
    goto yyerrlab1;

    /*-------------------------------------------------------------.
    | yyerrlab1 -- common code for both syntax error and YYERROR.  |
       `-------------------------------------------------------------*/
yyerrlab1:
    yyerrstatus_ = 3;   /* Each real token shifted decrements this.  */

    for (;; )
    {
        yyn = yypact_[ yystate ];
        if ( !yy_pact_value_is_default_( yyn ) )
        {
            yyn += yyterror_;
            if ( 0 <= yyn && yyn <= yylast_ && yycheck_[ yyn ] == yyterror_ )
            {
                yyn = yytable_[ yyn ];
                if ( 0 < yyn )
                {
                    break;
                }
            }
        }

        /* Pop the current state because it cannot handle the error token.  */
        if ( yystate_stack_.height() == 1 )
        {
            YYABORT;
        }

        yyerror_range[ 1 ] = yylocation_stack_[ 0 ];
        yydestruct_( "Error: popping",
                     yystos_[ yystate ],
                     &yysemantic_stack_[ 0 ], &yylocation_stack_[ 0 ] );
        yypop_();
        yystate = yystate_stack_[ 0 ];
        YY_STACK_PRINT();
    }

    yyerror_range[ 2 ] = yylloc;
    // Using YYLLOC is tempting, but would change the location of
    // the lookahead.  YYLOC is available though.
    YYLLOC_DEFAULT( yyloc, yyerror_range, 2 );
    yysemantic_stack_.push( yylval );
    yylocation_stack_.push( yyloc );

    /* Shift the error token.  */
    YY_SYMBOL_PRINT( "Shifting", yystos_[ yyn ],
                     &yysemantic_stack_[ 0 ], &yylocation_stack_[ 0 ] );

    yystate = yyn;
    goto yynewstate;

    /* Accept.  */
yyacceptlab:
    yyresult = 0;
    goto yyreturn;

    /* Abort.  */
yyabortlab:
    yyresult = 1;
    goto yyreturn;

yyreturn:
    if ( yychar != yyempty_ )
    {
        /* Make sure we have latest lookahead translation.  See comments
           at user semantic actions for why this is necessary.  */
        yytoken = yytranslate_( yychar );
        yydestruct_( "Cleanup: discarding lookahead", yytoken, &yylval,
                     &yylloc );
    }

    /* Do not reclaim the symbols of the rule which action triggered
       this YYABORT or YYACCEPT.  */
    yypop_( yylen );
    while ( yystate_stack_.height() != 1 )
    {
        yydestruct_( "Cleanup: popping",
                     yystos_[ yystate_stack_[ 0 ] ],
                     &yysemantic_stack_[ 0 ],
                     &yylocation_stack_[ 0 ] );
        yypop_();
    }

    return yyresult;
}

// Generate an error message.
std::string
Cube4Parser::yysyntax_error_( int yystate, int yytoken )
{
    std::string yyres;
    // Number of reported tokens (one for the "unexpected", one per
    // "expected").
    size_t yycount = 0;
    // Its maximum.
    enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
    // Arguments of yyformat.
    char const* yyarg[ YYERROR_VERBOSE_ARGS_MAXIMUM ];

    /* There are many possibilities here to consider:
       - If this state is a consistent state with a default action, then
         the only way this function was invoked is if the default action
         is an error action.  In that case, don't check for expected
         tokens because there are none.
       - The only way there can be no lookahead present (in yytoken) is
         if this state is a consistent state with a default action.
         Thus, detecting the absence of a lookahead is sufficient to
         determine that there is no unexpected or expected token to
         report.  In that case, just report a simple "syntax error".
       - Don't assume there isn't a lookahead just because this state is
         a consistent state with a default action.  There might have
         been a previous inconsistent state, consistent state with a
         non-default action, or user semantic action that manipulated
         yychar.
       - Of course, the expected token list depends on states to have
         correct lookahead information, and it depends on the parser not
         to perform extra reductions after fetching a lookahead from the
         scanner and before detecting a syntax error.  Thus, state
         merging (from LALR or IELR) and default reductions corrupt the
         expected token list.  However, the list is correct for
         canonical LR with one exception: it will still contain any
         token that will not be accepted due to an error action in a
         later state.
     */
    if ( yytoken != yyempty_ )
    {
        yyarg[ yycount++ ] = yytname_[ yytoken ];
        int yyn = yypact_[ yystate ];
        if ( !yy_pact_value_is_default_( yyn ) )
        {
            /* Start YYX at -YYN if negative to avoid negative indexes in
               YYCHECK.  In other words, skip the first -YYN actions for
               this state because they are default actions.  */
            int yyxbegin = yyn < 0 ? -yyn : 0;
            /* Stay within bounds of both yycheck and yytname.  */
            int yychecklim = yylast_ - yyn + 1;
            int yyxend     = yychecklim < yyntokens_ ? yychecklim : yyntokens_;
            for ( int yyx = yyxbegin; yyx < yyxend; ++yyx )
            {
                if ( yycheck_[ yyx + yyn ] == yyx && yyx != yyterror_
                     && !yy_table_value_is_error_( yytable_[ yyx + yyn ] ) )
                {
                    if ( yycount == YYERROR_VERBOSE_ARGS_MAXIMUM )
                    {
                        yycount = 1;
                        break;
                    }
                    else
                    {
                        yyarg[ yycount++ ] = yytname_[ yyx ];
                    }
                }
            }
        }
    }

    char const* yyformat = 0;
    switch ( yycount )
    {
#define YYCASE_( N, S )                         \
    case N:                               \
        yyformat = S;                       \
        break
        YYCASE_( 0, YY_( "syntax error" ) );
        YYCASE_( 1, YY_( "syntax error, unexpected %s" ) );
        YYCASE_( 2, YY_( "syntax error, unexpected %s, expecting %s" ) );
        YYCASE_( 3, YY_( "syntax error, unexpected %s, expecting %s or %s" ) );
        YYCASE_( 4, YY_( "syntax error, unexpected %s, expecting %s or %s or %s" ) );
        YYCASE_( 5, YY_( "syntax error, unexpected %s, expecting %s or %s or %s or %s" ) );
#undef YYCASE_
    }

    // Argument number.
    size_t yyi = 0;
    for ( char const* yyp = yyformat; *yyp; ++yyp )
    {
        if ( yyp[ 0 ] == '%' && yyp[ 1 ] == 's' && yyi < yycount )
        {
            yyres += yytnamerr_( yyarg[ yyi++ ] );
            ++yyp;
        }
        else
        {
            yyres += *yyp;
        }
    }
    return yyres;
}


/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
const short int Cube4Parser::yypact_ninf_ = -364;
const short int
Cube4Parser::                yypact_[] =
{
    29,   2,      25,       125,        17,           63,           -364,         -364,        -6,          -364,
    -364, -364,   -364,     -364,       -364,         -364,         45,           -364,        3,           -364,
    -364, -364,   -364,     -364,       -27,          16,           -364,         55,          3,           -364,
    23,   41,     87,       91,         -364,         -364,         -4,           -364,        43,          66,
    -364, 24,     -364,     -364,       23,           41,           41,           26,          35,          -364,
    -364, -364,   -364,     68,         -364,         72,           43,           -364,        151,         152,
    41,   35,     35,       156,        155,          65,           73,           -364,        -364,        -364,
    -364, 144,    35,       73,         73,           -364,         139,          162,         161,         -364,
    -364, -364,   67,       5,          -364,         73,           -364,         -364,        48,          22,
    -364, -364,   53,       -364,       165,          52,           -364,         -364,        -364,        -364,
    -364, 167,    168,      169,        -364,         -364,         -364,         -364,        9,           -364,
    42,   -364,   -18,      -364,       67,           67,           88,           143,         -364,        141,
    -364, -31,    -364,     172,        -364,         173,          -364,         -364,        -364,        -1,
    -364, 176,    177,      -364,       -364,         -364,         -364,         -364,        0,           89,
    -364, 154,    -364,     179,        180,          -364,         103,          -364,        -364,        -364,
    71,   -364,   -364,     -364,       56,           96,           118,          117,         115,         -364,
    -364, -364,   -364,     170,        -1,           -364,         -364,         -364,        -364,        -364,
    188,  99,     -364,     14,         119,          119,          146,          -364,        194,         193,
    178,  175,    140,      142,        137,          136,          135,          -364,        -364,        -364,
    -364, -364,   -364,     -364,       -364,         -364,         -364,         56,          -364,        -364,
    107,  -364,   -364,     -364,       -364,         -364,         -364,         204,         116,         -364,
    -364, -364,   130,      138,        -364,         122,          146,          -364,        -77,         -364,
    -364, -364,   -364,     -364,       -364,         -364,         -364,         -364,        -364,        206,
    -364, 211,    210,      147,        138,          -364,         -364,         -364,        -364,        214,
    216,  121,    -364,     215,        182,          -364,         -364,         -364,        -364,        -364,
    183,  -364,   -364,     -364,       217,          104,          184,          182,         -364,        223,
    67,   59,     -364,     -80,        10,           -364,         220,          226,         -364,        -364,
    -364, -364,   227,      -364,       -364,         230,          231,          105,         -364,        -364,
    -364, -5,     -364,     -364,       -364,         -364,         -364,         50,          119,         -364,
    -364, -364,   -364,     -364,       -364,         20,           189,          67,          143,         207,
    -364, 138,    232,      234,        236,          237,          238,          239,         240,         241,
    242,  243,    244,      245,        246,          247,          64,           -364,        -364,        -364,
    -364, -364,   -364,     -364,       -364,         -364,         248,          -364,        -364,        -364,
    -364, -364,   -364,     -364,       -364,         -364,         203,          205,         208,         209,
    212,  213,    218,      -364,       20,           119,          221,          -364,        -364,        -364,
    -364, -364,   -364,     -364,       -364,         160,          -364,         -364,        67,          113,
    -364, 181,    185,      224,        252,          -364,         -364,         -364,        164,         223,
    67,   111,    -364,     -25,        -364,         223,          -364,         257,         -364,        -364,
    -364, -364,   -25,      -364,       -364,         119,          225,          -364,        233,         67,
    114,  -364,   -364,     265,        -364,         -364,         -25,          -28,         -364
};

/* YYDEFACT[S] -- default reduction number in state S.  Performed when
   YYTABLE doesn't specify something else to do.  Zero means the
   default is an error.  */
const unsigned char
Cube4Parser::yydefact_[] =
{
    0,   0,     0,       0,         0,           0,           58,          59,          0,           56,
    1,   61,    62,      63,        64,          65,          0,           54,          0,           2,
    3,   55,    57,      66,        0,           79,          86,          0,           0,           71,
    0,   0,     0,       0,         76,          77,          0,           74,          82,          0,
    80,  13,    60,      72,        0,           0,           0,           15,          0,           4,
    5,   73,    75,      0,         84,          0,           83,          78,          0,           0,
    0,   0,     0,       0,         0,           17,          220,         37,          81,          85,
    14,  0,     0,       220,       220,         16,          0,           0,           0,           222,
    70,  221,   0,       0,         88,          220,         68,          69,          0,           0,
    111, 18,    0,       224,       0,           92,          109,         87,          89,          90,
    67,  0,     0,       0,         125,         124,         126,         127,         0,           122,
    0,   112,   132,     128,       0,           0,           183,         144,         145,         143,
    164, 0,     19,      0,         93,          0,           6,           30,          31,          114,
    123, 0,     0,       138,       136,         139,         137,         140,         0,           0,
    110, 132,   134,     0,         0,           185,         0,           184,         146,         165,
    0,   223,   225,     7,         94,          0,           0,           0,           0,           119,
    120, 118,   121,     0,         115,         116,         32,          20,          131,         141,
    0,   0,     133,     0,         0,           0,           187,         142,         0,           0,
    0,   0,     0,       0,         0,           0,           0,           98,          99,          100,
    101, 102,   103,     105,       106,         104,         91,          95,          96,          107,
    0,   43,    48,      49,        113,         117,         8,           0,           0,           130,
    135, 129,   0,       44,        195,         0,           188,         189,         0,           28,
    226, 46,    47,      38,        39,          40,          41,          42,          97,          0,
    9,   0,     0,       0,         44,          166,         45,          186,         190,         0,
    0,   0,     191,     0,         228,         108,         10,          53,          50,          149,
    0,   11,    33,      192,       0,           0,           0,           229,         230,         147,
    0,   0,     168,     0,         0,           196,         0,           0,           227,         231,
    150, 153,   0,       167,       169,         0,           0,           0,           201,         202,
    203, 0,     199,     193,       197,         29,          232,         151,         0,           12,
    34,  35,    36,      198,       200,         0,           0,           0,           152,         0,
    154, 44,    0,       0,         0,           0,           0,           0,           0,           0,
    0,   0,     0,       0,         0,           0,           0,           204,         210,         211,
    212, 206,   207,     208,       209,         233,         0,           148,         170,         21,
    22,  23,    24,      25,        26,          27,          0,           0,           0,           0,
    0,   0,     0,       194,       0,           0,           0,           213,         214,         215,
    216, 217,   218,     219,       205,         0,           155,         157,         0,           0,
    172, 0,     0,       0,         0,           171,         173,         52,          0,           159,
    0,   0,     161,     0,         51,          159,         158,         0,           156,         162,
    178, 179,   174,     176,       160,         0,           0,           177,         0,           0,
    0,   180,   163,     0,         175,         181,         0,           0,           182
};

/* YYPGOTO[NTERM-NUM].  */
const short int
Cube4Parser::yypgoto_[] =
{
    -364, -364,    -364,      120,         74,        -96,       -364,     -364,       -364,       -364,
    -364, -364,    -364,      -364,        -364,      -82,       -364,     -364,       -364,       -364,
    -364, -364,    -364,      -364,        -364,      -364,      -364,     -364,       -364,       32,
    -364, -364,    222,       -364,        -364,      -364,      -364,     -364,       -143,       -225,
    -364, -364,    -119,      -128,        -364,      -364,      -78,      -364,       -364,       -364,
    -364, 271,     -364,      -364,        -364,      -364,      253,      -364,       249,        254,
    -364, -364,    -364,      -364,        11,        -364,      -364,     197,        -364,       -364,
    -364, 86,      -149,      -364,        -8,        -364,      195,      -364,       -364,       123,
    -364, 186,     -364,      124,         145,       -364,      153,      -364,       8,          -364,
    6,    -115,    -364,      -364,        -364,      -364,      -364,     -364,       -95,        -364,
    -86,  -364,    -79,       -364,        187,       -364,      -364,     34,         -364,       -364,
    -63,  -364,    -98,       -363,        -364,      -91,       -364,     -364,       -364,       -364,
    -364, -364,    84,        -364,        -364,      -364,      37,       -364,       21,         -364,
    -41,  -364,    -364,      -364,        -364,      -364,      -364,     -364,       15,         -364,
    -364, -364,    -364,      -364,        -364,      -364,      47,       -364
};

/* YYDEFGOTO[NTERM-NUM].  */
const short int
Cube4Parser::yydefgoto_[] =
{
    -1,  6,    7,     34,     35,      104,     124,    171,     208,     232,
    241, 278,  59,    64,     78,      105,     135,    309,     310,     311,
    312, 313,  314,   315,    179,     267,     106,    107,     136,     242,
    279, 280,  54,    187,    188,     189,     190,    191,     159,     235,
    193, 194,  236,   380,    234,     369,     381,    141,     2,       3,
    8,   9,    17,    18,     27,      28,      29,     36,      37,      30,
    39,  40,   55,    56,     31,      41,      83,     84,      125,     196,
    197, 198,  162,   99,     48,      89,      90,     163,     164,     165,
    108, 109,  112,   113,    142,     173,     137,    138,     66,      116,
    117, 118,  271,   259,    299,     287,     300,    363,     356,     357,
    376, 371,  372,   119,    120,     250,     261,    262,     346,     359,
    360, 386,  382,   383,    390,     391,     146,    147,     176,     215,
    216, 243,  217,   295,    218,     264,     265,    281,     282,     316,
    317, 318,  319,   320,    321,     322,     323,    324,     80,      81,
    93,  121,  152,   244,    256,     257,     258,    296
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If YYTABLE_NINF_, syntax error.  */
const signed char Cube4Parser::yytable_ninf_ = -1;
const unsigned short int
Cube4Parser::                  yytable_[] =
{
    95,  161,  148,   293,    51,       199,      21,        168,       155,       249,
    160, 192,  24,    139,    133,      150,      129,       398,       275,       387,
    263, 239,  19,    155,    210,      10,       82,        96,        134,       276,
    277, 240,  143,   144,    387,      195,      161,       61,        62,        45,
    1,   46,   133,   110,    209,      160,      212,       213,       199,       88,
    158, 110,  72,    158,    192,      60,       134,       25,        361,       140,
    151, 361,  283,   26,     23,       155,      97,        32,        20,        73,
    74,  156,  38,    157,    33,       42,       328,       158,       195,       180,
    85,  181,  114,   26,     297,      114,      4,         5,         86,        87,
    32,  115,  49,    275,    4,        5,        50,        33,        273,       260,
    100, 53,   94,    101,    276,      277,      131,       132,       291,       292,
    270, 94,   101,   102,    103,      343,      344,       47,        182,       65,
    183, 57,   184,   58,     185,      63,       186,       67,        156,       68,
    157, 302,  303,   304,    305,      306,      307,       308,       11,        12,
    13,  14,   15,    16,     94,       101,      378,       370,       131,       132,
    94,  101,  102,   103,    365,      358,      70,        394,       389,       71,
    301, 75,   76,    79,     77,       82,       88,        91,        92,        94,
    122, 123,  126,   127,    128,      114,      145,       153,       272,       115,
    154, 166,  167,   148,    170,      139,      174,       175,       177,       178,
    32,  201,  202,   206,    203,      207,      214,       158,       204,       219,
    220, 222,  221,   223,    225,      226,      227,       224,       33,        230,
    233, 237,  157,   231,    245,      326,      246,       355,       247,       251,
    375, 252,  254,   260,    266,      285,      375,       263,       248,       240,
    255, 268,  155,   286,    288,      289,      290,       329,       325,       330,
    327, 331,  332,   333,    334,      335,      361,       374,       336,       337,
    338, 339,  340,   341,    342,      345,      347,       355,       348,       373,
    370, 349,  350,   358,    385,      351,      352,       368,       367,       389,
    392, 353,  396,   253,    229,      200,      364,       362,       69,        22,
    98,  43,   44,    228,    111,      52,       172,       205,       377,       384,
    388, 169,  379,   298,    130,      274,      366,       211,       397,       395,
    238, 284,  294,   354,    269,      0,        149,       393
};

/* YYCHECK.  */
const short int
Cube4Parser::yycheck_[] =
{
    82,  129,   117,    8,        8,          154,         12,          7,           9,           234,
    129, 154,   9,      31,       110,        46,          7,           45,          98,          382,
    10,  98,    5,      9,        173,        0,           21,          22,          110,         109,
    110, 108,   114,    115,      397,        154,         164,         45,          46,          28,
    11,  30,    138,    29,       30,         164,         174,         175,         197,         27,
    78,  29,    60,     78,       197,        44,          138,         54,          86,          77,
    91,  86,    52,     60,       19,         9,           61,          94,          5,           61,
    62,  72,    56,     74,       101,        20,          301,         78,          197,         23,
    72,  25,    32,     60,       34,         32,          92,          93,          73,          74,
    94,  38,    5,      98,       92,         93,          5,           101,         39,          40,
    85,  58,    102,    103,      109,        110,         106,         107,         3,           4,
    259, 102,   103,    104,      105,        51,          52,          76,          62,          84,
    64,  55,    66,     99,       68,         99,          70,          59,          72,          57,
    74,  111,   112,    113,      114,        115,         116,         117,         13,          14,
    15,  16,    17,     18,       102,        103,         35,          36,          106,         107,
    102, 103,   104,    105,      41,         42,          5,           43,          44,          7,
    288, 5,     7,      90,       99,         21,          27,          5,           7,           102,
    5,   119,   5,      5,        5,          32,          88,          5,           260,         38,
    7,   5,     5,      298,      95,         31,          7,           7,           85,          118,
    94,  73,    75,     5,        79,         96,          50,          78,          28,          5,
    7,   26,    24,     63,       67,         69,          71,          65,          101,         5,
    80,  89,    74,     97,       8,          297,         5,           345,         8,           5,
    369, 5,     7,      40,       120,        5,           375,         10,          81,          108,
    48,  47,    9,      7,        7,          5,           5,           5,           49,          5,
    33,  5,     5,      5,        5,          5,           86,          83,          7,           7,
    7,   7,     7,      7,        7,          7,           53,          385,         53,          7,
    36,  53,    53,     42,       7,          53,          53,          82,          87,          44,
    37,  53,    7,      241,      200,        155,         358,         355,         56,          8,
    83,  28,    28,     197,      89,         36,          141,         164,         370,         375,
    385, 138,   371,    287,      108,        261,         359,         173,         396,         390,
    216, 264,   281,    344,      257,        -1,          119,         389
};

/* STOS_[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
const unsigned short int
Cube4Parser::yystos_[] =
{
    0,   11,   169,    170,      92,          93,         122,        123,        171,        172,
    0,   13,   14,     15,       16,          17,         18,         173,        174,        5,
    5,   12,   172,    19,       9,           54,         60,         175,        176,        177,
    180, 185,  94,     101,      124,         125,        178,        179,        56,         181,
    182, 186,  20,     177,      180,         185,        185,        76,         195,        5,
    5,   8,    179,    58,       153,         183,        184,        55,         99,         133,
    185, 195,  195,    99,       134,         84,         209,        59,         57,         153,
    5,   7,    195,    209,      209,         5,          7,          99,         135,        90,
    259, 260,  21,     187,      188,         209,        259,        259,        27,         196,
    197, 5,    7,      261,      102,         136,        22,         61,         188,        194,
    259, 103,  104,    105,      126,         136,        147,        148,        201,        202,
    29,  197,  203,    204,      32,          38,         210,        211,        212,        224,
    225, 262,  5,      119,      127,         189,        5,          5,          5,          7,
    202, 106,  107,    126,      136,         137,        149,        207,        208,        31,
    77,  168,  205,    136,      136,         88,         237,        238,        212,        225,
    46,  91,   263,    5,        7,           9,          72,         74,         78,         159,
    163, 164,  193,    198,      199,         200,        5,          5,          7,          207,
    95,  128,  205,    206,      7,           7,          239,        85,         118,        145,
    23,  25,   62,     64,       66,          68,         70,         154,        155,        156,
    157, 158,  159,    161,      162,         163,        190,        191,        192,        193,
    124, 73,   75,     79,       28,          200,        5,          96,         129,        30,
    193, 204,  164,    164,      50,          240,        241,        243,        245,        5,
    7,   24,   26,     63,       65,          67,         69,         71,         192,        125,
    5,   97,   130,    80,       165,         160,        163,        89,         243,        98,
    108, 131,  150,    242,      264,         8,          5,          8,          81,         160,
    226, 5,    5,      150,      7,           48,         265,        266,        267,        214,
    40,  227,  228,    10,       246,         247,        120,        146,        47,         267,
    193, 213,  136,    39,       228,         98,         109,        110,        132,        151,
    152, 248,  249,    52,       247,         5,          7,          216,        7,          5,
    5,   3,    4,      8,        249,         244,        268,        34,         211,        215,
    217, 164,  111,    112,      113,         114,        115,        116,        117,        138,
    139, 140,  141,    142,      143,         144,        250,        251,        252,        253,
    254, 255,  256,    257,      258,         49,         136,        33,         160,        5,
    5,   5,    5,      5,        5,           5,          7,          7,          7,          7,
    7,   7,    7,      51,       52,          7,          229,        53,         53,         53,
    53,  53,   53,     53,       251,         164,        219,        220,        42,         230,
    231, 86,   167,    218,      136,         41,         231,        87,         82,         166,
    36,  222,  223,    7,        83,          193,        221,        136,        35,         223,
    164, 167,  233,    234,      221,         7,          232,        234,        219,        44,
    235, 236,  37,     136,      43,          236,        7,          233,        45
};

#if YYDEBUG
/* TOKEN_NUMBER_[YYLEX-NUM] -- Internal symbol number corresponding
   to YYLEX-NUM.  */
const unsigned short int
Cube4Parser::yytoken_number_[] =
{
    0,    256,    1001,    1002,    1003,   1004,  1005,  1006,  1007,  1008,
    1009, 1010,   1011,    1012,    1013,   1014,  1015,  1016,  1017,  1000,
    1018, 1019,   1020,    1021,    1022,   1023,  1024,  1025,  1026,  1027,
    1028, 1029,   1030,    1031,    1032,   1033,  1034,  1035,  1036,  1037,
    1038, 1039,   1040,    1041,    1042,   1043,  1044,  1045,  1046,  1047,
    1048, 1049,   1050,    1051,    1052,   1053,  1054,  1055,  1056,  1057,
    1058, 1059,   1060,    1061,    1062,   1063,  1064,  1065,  1066,  1067,
    1068, 1069,   1070,    1071,    1072,   1073,  1074,  1075,  1076,  1077,
    1078, 1079,   1080,    1081,    1082,   1083,  1084,  1085,  1086,  1087,
    1088, 1089,   1090,    1091,    1092,   1093,  1094,  1095,  1096,  1097,
    1098, 1099,   1100,    1101,    1102,   1103,  1104,  1105,  1106,  1107,
    1108, 1109,   1110,    1111,    1112,   1113,  1114,  1115,  1116,  1117,
    1118
};
#endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
const unsigned short int
Cube4Parser::yyr1_[] =
{
    0,   121,   122,   123,   124,   125,   126,   127,   128,   129,
    130, 131,   132,   133,   133,   134,   134,   135,   135,   136,
    137, 138,   139,   140,   141,   142,   143,   144,   145,   146,
    147, 148,   149,   150,   151,   152,   152,   153,   154,   155,
    156, 157,   158,   159,   160,   160,   161,   162,   163,   164,
    165, 166,   167,   168,   169,   170,   171,   171,   172,   172,
    173, 174,   174,   174,   174,   174,   174,   175,   175,   175,
    175, 176,   176,   177,   178,   178,   179,   179,   180,   181,
    181, 182,   183,   183,   184,   184,   186,   185,   187,   187,
    187, 188,   189,   189,   190,   190,   191,   191,   192,   192,
    192, 192,   192,   192,   192,   192,   192,   192,   193,   194,
    195, 196,   196,   197,   198,   198,   199,   199,   200,   200,
    200, 200,   201,   201,   202,   202,   202,   202,   203,   203,
    203, 204,   205,   205,   206,   206,   207,   207,   207,   207,
    208, 208,   209,   210,   210,   211,   211,   213,   212,   214,
    214, 215,   215,   216,   216,   218,   217,   219,   220,   221,
    221, 222,   222,   223,   224,   224,   226,   225,   227,   227,
    229, 228,   230,   230,   232,   231,   233,   233,   234,   234,
    235, 235,   236,   237,   237,   239,   238,   240,   240,   241,
    241, 242,   242,   244,   243,   245,   246,   246,   247,   248,
    248, 249,   249,   249,   250,   250,   251,   251,   251,   251,
    251, 251,   251,   252,   253,   254,   255,   256,   257,   258,
    259, 259,   261,   260,   262,   262,   264,   263,   265,   265,
    266, 266,   268,   267
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
const unsigned char
Cube4Parser::yyr2_[] =
{
    0, 2, 2, 2, 2,     2,     2,     2,     2,      2,
    2, 2, 2, 0, 2,     0,     2,     0,     2,      2,
    2, 2, 2, 2, 2,     2,     2,     2,     2,      2,
    2, 2, 2, 2, 2,     2,     2,     2,     2,      2,
    2, 2, 2, 2, 0,     1,     2,     2,     2,      2,
    2, 2, 2, 5, 2,     3,     1,     2,     1,      1,
    3, 1, 1, 1, 1,     1,     2,     6,     5,      5,
    4, 1, 2, 3, 1,     2,     1,     1,     3,      0,
    1, 3, 0, 1, 1,     2,     0,     6,     1,      2,
    2, 5, 0, 1, 0,     1,     1,     2,     1,      1,
    1, 1, 1, 1, 1,     1,     1,     1,     4,      1,
    6, 1, 2, 5, 0,     1,     1,     2,     1,      1,
    1, 1, 1, 2, 1,     1,     1,     1,     1,      4,
    4, 3, 0, 2, 0,     2,     1,     1,     1,      1,
    1, 2, 6, 1, 1,     1,     2,     0,     11,     0,
    2, 0, 1, 0, 2,     0,     7,     1,     4,      0,
    2, 1, 2, 5, 1,     2,     0,     8,     1,      2,
    0, 8, 1, 2, 0,     7,     1,     2,     1,      1,
    1, 2, 5, 0, 1,     0,     4,     0,     1,      1,
    2, 1, 2, 0, 8,     1,     1,     2,     3,      1,
    2, 1, 1, 1, 1,     3,     1,     1,     1,      1,
    1, 1, 1, 3, 3,     3,     3,     3,     3,      3,
    0, 1, 0, 4, 0,     2,     0,     6,     0,      1,
    1, 2, 0, 5
};

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at \a yyntokens_, nonterminals.  */
const char*
const Cube4Parser::yytname_[] =
{
    "\"end of file\"",               "error",                                "$undefined",                                    "\"false\"",                                                            "\"true\"",
    "\"attribute value\"",           "\"error\"",                            "\">\"",                                         "\"/>\"",                                                               "\"<attr\"",
    "\"<dim\"",                      "\"<?xml\"",                            "\"?>\"",                                        "\"<cube version=\\\"4.0\\\"\"",
    "\"<cube version=\\\"4.1\\\"\"", "\"<cube version=\\\"4.2\\\"\"",
    "\"<cube version=\\\"4.3\\\"\"", "\"<cube version=\\\"3.0\\\"\"",
    "\"<cube version=\\\"\"",        "CUBE_OPEN_NOT_SUPPORTED",              "\"</cube>\"",
    "\"<metric\"",                   "\"</metric>\"",                        "\"<cubepl>\"",                                  "\"</cubepl>\"",
    "\"<cubeplinit>\"",              "\"</cubeplinit>\"",                    "\"<region\"",                                   "\"</region>\"",
    "\"<cnode\"",                    "\"</cnode>\"",                         "\"<parameter\"",                                "\"<systemtreenode\"",
    "\"</systemtreenode>\"",         "\"<locationgroup\"",                   "\"</locationgroup>\"",
    "\"<location\"",                 "\"</location>\"",                      "\"<machine\"",                                  "\"</machine>\"",
    "\"<node\"",                     "\"</node>\"",                          "\"<process\"",                                  "\"</process>\"",
    "\"<thread\"",                   "\"</thread>\"",                        "\"<matrix\"",                                   "\"</matrix>\"",
    "\"<row\"",                      "\"</row>\"",                           "\"<cart\"",                                     "\"</cart>\"",                                                          "\"<coord\"",
    "\"</coord>\"",                  "\"<doc>\"",                            "\"</doc>\"",                                    "\"<mirrors>\"",
    "\"</mirrors>\"",                "\"<murl>\"",                           "\"</murl>\"",                                   "\"<metrics\"",
    "\"</metrics>\"",                "\"<disp_name>\"",                      "\"</disp_name>\"",
    "\"<uniq_name>\"",               "\"</uniq_name>\"",                     "\"<dtype>\"",                                   "\"</dtype>\"",
    "\"<uom>\"",                     "\"</uom>\"",                           "\"<val>\"",                                     "\"</val>\"",                                                           "\"<url>\"",
    "\"</url>\"",                    "\"<descr>\"",                          "\"</descr>\"",                                  "\"<program\"",
    "\"</program>\"",                "\"<name>\"",                           "\"</name>\"",                                   "\"<class>\"",
    "\"</class>\"",                  "\"<type>\"",                           "\"</type>\"",                                   "\"<system\"",
    "\"</system>\"",                 "\"<rank>\"",                           "\"</rank>\"",                                   "\"<topologies>\"",
    "\"</topologies>\"",             "\"<severity>\"",                       "\"</severity>\"",
    "\"attribute name version\"",    "\"attribute name encoding\"",
    "\"attribute name key\"",        "\"attribute name partype\"",
    "\"attribute name parkey\"",     "\"attribute name parvalue\"",
    "\"attribute name name\"",       "\"attribute name title\"",
    "\"attribute name file\"",       "\"attribute name value\"",
    "\"attribute name id\"",         "\"attribute name mod\"",
    "\"attribute name begin\"",      "\"attribute name end\"",
    "\"attribute name line\"",       "\"attribute name calleeid\"",
    "\"attribute name ndims\"",      "\"attribute name size\"",
    "\"attribute name periodic\"",   "\"attribute name locId\"",
    "\"attribute name lgId\"",       "\"attribute name stnId\"",
    "\"attribute name thrdId\"",     "\"attribute name procId\"",
    "\"attribute name nodeId\"",     "\"attribute name machId\"",
    "\"attribute name metricId\"",   "\"attribute name type\"",
    "\"attribute name cnodeId\"",    "$accept",                              "version_attr",                                  "encoding_attr",
    "key_attr",                      "value_attr",                           "mod_attr",                                      "metric_type_attr",
    "cnode_par_type_attr",           "cnode_par_key_attr",                   "cnode_par_value_attr",
    "cart_name_attr",                "dim_name_attr",                        "metrics_title_attr",
    "calltree_title_attr",           "systemtree_title_attr",                "id_attr",
    "calleeid_attr",                 "locid_attr",                           "lgid_attr",                                     "stnid_attr",                                                           "thrdid_attr",
    "procid_attr",                   "nodeid_attr",                          "machid_attr",                                   "metricid_attr",
    "cnodeid_attr",                  "begin_attr",                           "end_attr",                                      "line_attr",                                                            "ndims_attr",
    "size_attr",                     "periodic_attr",                        "murl_tag",                                      "disp_name_tag",
    "uniq_name_tag",                 "dtype_tag",                            "uom_tag",                                       "val_tag",                                                              "url_tag",
    "descr_tag_opt",                 "expression_tag",                       "expression_init_tag",                           "descr_tag",
    "name_tag",                      "class_tag",                            "type_tag",                                      "rank_tag",                                                             "parameter_tag",
    "document",                      "xml_tag",                              "xml_attributes",                                "xml_attribute",                                                        "cube_tag",
    "cube_begin",                    "cube_content",                         "attr_tags",                                     "attr_tag",                                                             "attr_attributes",
    "attr_attribute",                "doc_tag",                              "mirrors_tag_attr",                              "mirrors_tag",
    "murl_tags_attr",                "murl_tags",                            "metrics_tag",                                   "$@1",                                                                  "metric_tag",
    "metric_begin",                  "metric_type_attrs",                    "tags_of_metric_attr",
    "tags_of_metric",                "tag_of_metric",                        "generic_attr_tag",                              "metric_end",
    "program_tag",                   "region_tags",                          "region_tag",                                    "tags_of_region_attr",
    "tags_of_region",                "tag_of_region",                        "region_attributes",
    "region_attribute",              "cnode_tag",                            "cnode_begin",                                   "cnode_parameters",
    "cnode_attr_tags",               "cnode_attribute",                      "cnode_attributes",                              "system_tag",
    "systemtree_tags",               "flexsystemtree_tags",                  "systemtree_tag",                                "$@2",
    "systree_attr_tags",             "systemtree_sub_tags",                  "location_group_tags",
    "location_group_tag",            "$@3",                                  "loc_tags",                                      "loc_tag",                                                              "lg_attr_tags",
    "location_tags",                 "location_tag",                         "machine_tags",                                  "machine_tag",                                                          "$@4",
    "node_tags",                     "node_tag",                             "$@5",                                           "process_tags",                                                         "process_tag",                                                         "$@6",
    "tags_of_process",               "tag_of_process",                       "thread_tags",                                   "thread_tag",
    "topologies_tag_attr",           "topologies_tag",                       "$@7",                                           "cart_tags_attr",
    "cart_tags",                     "cart_attrs",                           "cart_tag",                                      "$@8",                                                                  "cart_open",                                                           "dim_tags",
    "dim_tag",                       "dim_attributes",                       "dim_attribute",                                 "coord_tags",                                                           "coord_tag",
    "coord_tag_loc",                 "coord_tag_lg",                         "coord_tag_stn",                                 "coord_tag_thrd",
    "coord_tag_proc",                "coord_tag_node",                       "coord_tag_mach",                                "severity_tag",
    "severity_part",                 "$@9",                                  "matrix_tags",                                   "matrix_tag",                                                           "$@10",
    "row_tags_attr",                 "row_tags",                             "row_tag",                                       "$@11",                                                                 0
};
#endif

#if YYDEBUG
/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
const Cube4Parser::rhs_number_type
Cube4Parser::yyrhs_[] =
{
    169, 0,     -1,      92,        5,           -1,          93,          5,           -1,         94,
    5,   -1,    101,     5,         -1,          103,         5,           -1,          119,        5,
    -1,  95,    5,       -1,        96,          5,           -1,          97,          5,          -1,
    98,  5,     -1,      98,        5,           -1,          -1,          99,          5,          -1,
    -1,  99,    5,       -1,        -1,          99,          5,           -1,          102,        5,
    -1,  107,   5,       -1,        111,         5,           -1,          112,         5,          -1,
    113, 5,     -1,      114,       5,           -1,          115,         5,           -1,         116,
    5,   -1,    117,     5,         -1,          118,         5,           -1,          120,        5,
    -1,  104,   5,       -1,        105,         5,           -1,          106,         5,          -1,
    108, 5,     -1,      109,       5,           -1,          110,         3,           -1,         110,
    4,   -1,    58,      59,        -1,          62,          63,          -1,          64,         65,
    -1,  66,    67,      -1,        68,          69,          -1,          70,          71,         -1,
    72,  73,    -1,      -1,        163,         -1,          23,          24,          -1,         25,
    26,  -1,    74,      75,        -1,          78,          79,          -1,          80,         81,
    -1,  82,    83,      -1,        86,          87,          -1,          31,          128,        129,
    130, 8,     -1,      170,       173,         -1,          11,          171,         12,         -1,
    172, -1,    171,     172,       -1,          122,         -1,          123,         -1,         174,
    175, 20,    -1,      13,        -1,          14,          -1,          15,          -1,         16,
    -1,  17,    -1,      18,        19,          -1,          176,         180,         185,        195,
    209, 259,   -1,      176,       185,         195,         209,         259,         -1,         180,
    185, 195,   209,     259,       -1,          185,         195,         209,         259,        -1,
    177, -1,    176,     177,       -1,          9,           178,         8,           -1,         179,
    -1,  178,   179,     -1,        124,         -1,          125,         -1,          54,         181,
    55,  -1,    -1,      182,       -1,          56,          183,         57,          -1,         -1,
    184, -1,    153,     -1,        184,         153,         -1,          -1,          60,         186,
    133, 7,     187,     61,        -1,          188,         -1,          187,         188,        -1,
    187, 194,   -1,      21,        136,         189,         7,           190,         -1,         -1,
    127, -1,    -1,      191,       -1,          192,         -1,          191,         192,        -1,
    154, -1,    155,     -1,        156,         -1,          157,         -1,          158,        -1,
    159, -1,    163,     -1,        161,         -1,          162,         -1,          193,        -1,
    9,   124,   125,     8,         -1,          22,          -1,          76,          134,        7,
    196, 203,   77,      -1,        197,         -1,          196,         197,         -1,         27,
    201, 7,     198,     28,        -1,          -1,          199,         -1,          200,        -1,
    199, 200,   -1,      164,       -1,          159,         -1,          163,         -1,         193,
    -1,  202,   -1,      201,       202,         -1,          136,         -1,          126,        -1,
    147, -1,    148,     -1,        204,         -1,          203,         205,         206,        204,
    -1,  203,   205,     206,       30,          -1,          29,          208,         7,          -1,
    -1,  168,   205,     -1,        -1,          206,         193,         -1,          136,        -1,
    149, -1,    126,     -1,        137,         -1,          207,         -1,          208,        207,
    -1,  84,    135,     7,         210,         237,         85,          -1,          224,        -1,
    211, -1,    212,     -1,        211,         212,         -1,          -1,          32,         136,
    7,   164,   165,     160,       214,         213,         216,         215,         33,         -1,
    -1,  214,   193,     -1,        -1,          211,         -1,          -1,          216,        217,
    -1,  -1,    34,      136,       7,           219,         218,         222,         35,         -1,
    220, -1,    164,     167,       166,         221,         -1,          -1,          193,        221,
    -1,  223,   -1,      222,       223,         -1,          36,          136,         7,          219,
    37,  -1,    225,     -1,        224,         225,         -1,          -1,          38,         136,
    7,   164,   160,     226,       227,         39,          -1,          228,         -1,         227,
    228, -1,    -1,      40,        136,         7,           164,         160,         229,        230,
    41,  -1,    231,     -1,        230,         231,         -1,          -1,          42,         136,
    7,   233,   232,     235,       43,          -1,          234,         -1,          233,        234,
    -1,  164,   -1,      167,       -1,          236,         -1,          235,         236,        -1,
    44,  136,   7,       233,       45,          -1,          -1,          238,         -1,         -1,
    88,  239,   240,     89,        -1,          -1,          241,         -1,          243,        -1,
    241, 243,   -1,      150,       -1,          131,         150,         -1,          -1,         245,
    242, 7,     246,     52,        244,         250,         51,          -1,          50,         -1,
    247, -1,    246,     247,       -1,          10,          248,         8,           -1,         249,
    -1,  248,   249,     -1,        132,         -1,          151,         -1,          152,        -1,
    251, -1,    250,     52,        251,         -1,          255,         -1,          256,        -1,
    257, -1,    258,     -1,        252,         -1,          253,         -1,          254,        -1,
    138, 7,     53,      -1,        139,         7,           53,          -1,          140,        7,
    53,  -1,    141,     7,         53,          -1,          142,         7,           53,         -1,
    143, 7,     53,      -1,        144,         7,           53,          -1,          -1,         260,
    -1,  -1,    90,      261,       262,         91,          -1,          -1,          262,        263,
    -1,  -1,    46,      145,       7,           264,         265,         47,          -1,         -1,
    266, -1,    267,     -1,        266,         267,         -1,          -1,          48,         146,
    7,   268,   49,      -1
};

/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
const unsigned short int
Cube4Parser::yyprhs_[] =
{
    0,   0,   3,   6,   9,     12,     15,     18,      21,     24,
    27,  30,  33,  36,  37,    40,     41,     44,      45,     48,
    51,  54,  57,  60,  63,    66,     69,     72,      75,     78,
    81,  84,  87,  90,  93,    96,     99,     102,     105,    108,
    111, 114, 117, 120, 123,   124,    126,    129,     132,    135,
    138, 141, 144, 147, 153,   156,    160,    162,     165,    167,
    169, 173, 175, 177, 179,   181,    183,    186,     193,    199,
    205, 210, 212, 215, 219,   221,    224,    226,     228,    232,
    233, 235, 239, 240, 242,   244,    247,    248,     255,    257,
    260, 263, 269, 270, 272,   273,    275,    277,     280,    282,
    284, 286, 288, 290, 292,   294,    296,    298,     300,    305,
    307, 314, 316, 319, 325,   326,    328,    330,     333,    335,
    337, 339, 341, 343, 346,   348,    350,    352,     354,    356,
    361, 366, 370, 371, 374,   375,    378,    380,     382,    384,
    386, 388, 391, 398, 400,   402,    404,    407,     408,    420,
    421, 424, 425, 427, 428,   431,    432,    440,     442,    447,
    448, 451, 453, 456, 462,   464,    467,    468,     477,    479,
    482, 483, 492, 494, 497,   498,    506,    508,     511,    513,
    515, 517, 520, 526, 527,   529,    530,    535,     536,    538,
    540, 543, 545, 548, 549,   558,    560,    562,     565,    569,
    571, 574, 576, 578, 580,   582,    586,    588,     590,    592,
    594, 596, 598, 600, 604,   608,    612,    616,     620,    624,
    628, 629, 631, 632, 637,   638,    641,    642,     649,    650,
    652, 654, 657, 658
};

/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
const unsigned short int
Cube4Parser::yyrline_[] =
{
    0,    261,    261,     268,     275,    282,   289,   296,   304,   313,
    322,  331,    341,     349,     351,    358,   360,   368,   370,   382,
    391,  403,    412,     421,     431,    440,   449,   458,   467,   476,
    487,  495,    503,     511,     521,    533,   539,   550,   560,   567,
    573,  580,    587,     594,     600,    601,   606,   614,   622,   629,
    638,  647,    654,     671,     716,    722,   738,   739,   743,   744,
    750,  754,    757,     760,     763,    766,   769,   775,   776,   777,
    778,  784,    785,     789,     802,    803,   807,   808,   814,   816,
    817,  821,    824,     825,     829,    830,   839,   838,   920,   921,
    922,  928,    1000,    1001,    1003,   1004,  1008,  1009,  1013,  1014,
    1015, 1016,   1017,    1018,    1019,   1020,  1021,  1022,  1027,  1055,
    1066, 1172,   1173,    1177,    1234,   1235,  1239,  1240,  1244,  1245,
    1246, 1247,   1253,    1254,    1258,   1259,  1260,  1261,  1265,  1266,
    1267, 1390,   1447,    1448,    1453,   1455,  1460,  1461,  1462,  1463,
    1467, 1468,   1474,    1482,    1484,   1488,  1489,  1493,  1493,  1549,
    1551, 1560,   1562,    1565,    1567,   1572,  1572,  1618,  1622,  1625,
    1627, 1633,   1634,    1637,    1682,   1683,  1687,  1687,  1707,  1708,
    1712, 1712,   1732,    1733,    1737,   1737,  1765,  1766,  1769,  1770,
    1774, 1775,   1779,    1807,    1808,   1812,  1812,  1818,  1819,  1823,
    1824, 1828,   1829,    1833,    1833,   1860,  1867,  1868,  1872,  1889,
    1890, 1894,   1895,    1896,    1900,   1901,  1908,  1909,  1910,  1911,
    1912, 1913,   1914,    1921,    1942,   1963,  1985,  2006,  2027,  2049,
    2072, 2073,   2076,    2076,    2079,   2081,  2086,  2086,  2109,  2110,
    2114, 2115,   2119,    2119
};

// Print the state stack on the debug stream.
void
Cube4Parser::yystack_print_()
{
    *yycdebug_ << "Stack now";
    for ( state_stack_type::const_iterator i = yystate_stack_.begin();
          i != yystate_stack_.end(); ++i )
    {
        *yycdebug_ << ' ' << *i;
    }
    *yycdebug_ << std::endl;
}

// Report on the debug stream that the rule \a yyrule is going to be reduced.
void
Cube4Parser::yy_reduce_print_( int yyrule )
{
    unsigned int yylno  = yyrline_[ yyrule ];
    int          yynrhs = yyr2_[ yyrule ];
    /* Print the symbols being reduced, and their result.  */
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):" << std::endl;
    /* The symbols being reduced.  */
    for ( int yyi = 0; yyi < yynrhs; yyi++ )
    {
        YY_SYMBOL_PRINT( "   $" << yyi + 1 << " =",
                         yyrhs_[ yyprhs_[ yyrule ] + yyi ],
                         &( yysemantic_stack_[ ( yynrhs ) - ( yyi + 1 ) ] ),
                         &( yylocation_stack_[ ( yynrhs ) - ( yyi + 1 ) ] ) );
    }
}
#endif // YYDEBUG

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
Cube4Parser::token_number_type
Cube4Parser::yytranslate_( int t )
{
    static
    const token_number_type
        translate_table[] =
    {
        0,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     1,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        2,   2,   2,   2,   2,     2,     2,     2,     2,      2,
        19,  2,   3,   4,   5,     6,     7,     8,     9,      10,
        11,  12,  13,  14,  15,    16,    17,    18,    20,     21,
        22,  23,  24,  25,  26,    27,    28,    29,    30,     31,
        32,  33,  34,  35,  36,    37,    38,    39,    40,     41,
        42,  43,  44,  45,  46,    47,    48,    49,    50,     51,
        52,  53,  54,  55,  56,    57,    58,    59,    60,     61,
        62,  63,  64,  65,  66,    67,    68,    69,    70,     71,
        72,  73,  74,  75,  76,    77,    78,    79,    80,     81,
        82,  83,  84,  85,  86,    87,    88,    89,    90,     91,
        92,  93,  94,  95,  96,    97,    98,    99,    100,    101,
        102, 103, 104, 105, 106,   107,   108,   109,   110,    111,
        112, 113, 114, 115, 116,   117,   118,   119,   120
    };
    if ( ( unsigned int )t <= yyuser_token_number_max_ )
    {
        return translate_table[ t ];
    }
    else
    {
        return yyundef_token_;
    }
}

const int Cube4Parser::                           yyeof_     = 0;
const int Cube4Parser::                           yylast_    = 307;
const int Cube4Parser::                           yynnts_    = 148;
const int Cube4Parser::                           yyempty_   = -2;
const int Cube4Parser::                           yyfinal_   = 10;
const int Cube4Parser::                           yyterror_  = 1;
const int Cube4Parser::                           yyerrcode_ = 256;
const int Cube4Parser::                           yyntokens_ = 121;

const unsigned int Cube4Parser::                  yyuser_token_number_max_ = 1118;
const Cube4Parser::token_number_type Cube4Parser::yyundef_token_           = 2;
} // cubeparser

/* Line 1136 of lalr1.cc  */
#line 3357 "../../build-backend/../src/cube/src/syntax/Cube4Parser.cpp"


/* Line 1138 of lalr1.cc  */
#line 2153 "../../build-backend/../src/cube/src/syntax/Cube4Parser.yy"
/*** Additional Code ***/


void
cubeparser::Cube4Parser::error( const Cube4Parser::location_type& l,
                                const std::string&                m )
{
    if ( strstr( m.c_str(), "expecting <?xml" ) != NULL )
    {
        driver.error_just_message( "The cube file is probably empty or filled with wrong content. The file has ended before the header of cube started. \n" );
    }
    if ( strstr( m.c_str(), " expecting </row>" ) != NULL )
    {
        driver.error_just_message( "One of the possible reasons is \n    1) that the severity value is malformed. CUBE expects the \"double\" value in C_LOCALE with dot instead of comma;. \n    2) that the CUBE file is not properly ended. Probably the writing of CUBE file was interrupted." );
    }
    if ( strstr( m.c_str(), " expecting <matrix" ) != NULL ||
         ( strstr( m.c_str(), " expecting <severity>" ) != NULL ) )
    {
        driver.error_just_message( "The cube file has probably a proper structure, but doesn't contain any severity values." );
    }
    if ( strstr( m.c_str(), " expecting <metric" ) != NULL )
    {
        driver.error_just_message( "The cube file doesn't contain any information about metric dimension." );
    }
    if ( strstr( m.c_str(), " expecting <region" ) != NULL )
    {
        driver.error_just_message( "The cube file doesn't contain any information about program dimension." );
    }
    if ( strstr( m.c_str(), " expecting <machine" ) != NULL )
    {
        driver.error_just_message( "The cube file doesn't contain any information about system dimension." );
    }
    if ( strstr( m.c_str(), " expecting <thread" ) != NULL )
    {
        driver.error_just_message( "The system dimension of the cube file is malformed. It contains a process without any threads." );
    }
    if ( strstr( m.c_str(), " expecting <process" ) != NULL )
    {
        driver.error_just_message( "The system dimension of the cube file is malformed. It contains a node without any processes." );
    }
    if ( strstr( m.c_str(), " expecting <node" ) != NULL )
    {
        driver.error_just_message( "The system dimension of the cube file is malformed. It contains a machine without any computing nodes." );
    }
    driver.error( l, m );
}
