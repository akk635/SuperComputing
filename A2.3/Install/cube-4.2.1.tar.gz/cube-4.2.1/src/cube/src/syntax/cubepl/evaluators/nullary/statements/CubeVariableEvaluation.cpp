/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __VARIABLE_EVALUATION_CPP
#define __VARIABLE_EVALUATION_CPP 0

#include "CubeVariableEvaluation.h"

using namespace cube;


VariableEvaluation::~VariableEvaluation()
{
    delete index;
}


double
VariableEvaluation::eval()
{
    return memory->get( variable, index->eval(), kind  );
}

/*
   double
   VariableEvaluation::eval( Cnode* cnode, CalculationFlavour cf, Thread* th, CalculationFlavour tf )
   {
    return memory->get( variable, index->eval( cnode, cf, th, tf ), kind );
   };


   double
   VariableEvaluation::eval( Cnode* cnode, CalculationFlavour cf, Thread* th1, Thread* th2, CalculationFlavour tf  )
   {
    return memory->get( variable, index->eval( cnode, cf, th1, th2, tf ), kind  );
   };
 */

double
VariableEvaluation::eval( Cnode* cnode, CalculationFlavour cf, Sysres* sr, CalculationFlavour tf  )
{
    return memory->get( variable, index->eval( cnode, cf, sr, tf ), kind  );
};

/*
   double
   VariableEvaluation::eval( Cnode* cnode, CalculationFlavour cf, Process* pr, CalculationFlavour tf  )
   {
    return memory->get( variable, index->eval( cnode, cf, pr, tf ), kind  );
   };


   double
   VariableEvaluation::eval( Cnode* cnode, CalculationFlavour cf, Node* nd, CalculationFlavour tf )
   {
    return memory->get( variable, index->eval( cnode, cf, nd, tf ), kind  );
   };


   double
   VariableEvaluation::eval( Cnode* cnode, CalculationFlavour cf, Machine* mch, CalculationFlavour tf  )
   {
    return memory->get( variable, index->eval( cnode, cf, mch, tf ), kind  );
   };
 */

double
VariableEvaluation::eval( Cnode* cnode, CalculationFlavour cf )
{
    return memory->get( variable, index->eval( cnode, cf ), kind  );
};




string
VariableEvaluation::strEval()
{
    return memory->get_as_string( variable, index->eval(), kind  );
}


#endif
