/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
#ifndef __MINUS_EVALUATION_CPP
#define __MINUS_EVALUATION_CPP 0

#include "CubeMinusEvaluation.h"
using namespace cube;

MinusEvaluation::MinusEvaluation() : BinaryEvaluation()
{
};

MinusEvaluation::MinusEvaluation( GeneralEvaluation* _arg1,
                                  GeneralEvaluation* _arg2 ) : BinaryEvaluation( _arg1, _arg2 )
{
};


MinusEvaluation::~MinusEvaluation()
{
}

double
MinusEvaluation::eval()
{
    if ( getNumOfParameters() == 2 )
    {
        return ( arguments[ 0 ]->eval() ) - ( arguments[ 1 ]->eval() );
    }
    cerr << " Substraction is not defined for else  than two paraments." << endl;
    return 0.;
}


/*
   double
   MinusEvaluation::eval( cube::Cnode * _cnode, CalculationFlavour _cf, cube::Thread * _thread, CalculationFlavour _tf)
   {
    if (getNumOfParameters() == 2)
        return (
                ( arguments[0]->eval(_cnode, _cf, _thread, _tf)) -
                (arguments[1]->eval(_cnode, _cf,_thread, _tf))
                );
    cerr << " Substraction is not defined for else  than two paraments." << endl;
    return 0.;
   }



   double MinusEvaluation::eval( cube::Cnode * _cnode, CalculationFlavour _cf, cube::Thread * _th1, cube::Thread * _th2, CalculationFlavour  _tf )
   {
    if (getNumOfParameters() == 2)
        return (arguments[0]->eval(_cnode, _cf,
                                            _th1, _th2, _tf)) - (arguments[1]->eval(_cnode, _cf,
                                            _th1, _th2, _tf));
    cerr << " Substraction is not defined for else  than two paraments." << endl;
    return 0.;
   }
 */

double
MinusEvaluation::eval( cube::Cnode* _cnode, CalculationFlavour _cf, cube::Sysres* _sf, CalculationFlavour _tf   )
{
    if ( getNumOfParameters() == 2 )
    {
        return ( arguments[ 0 ]->eval( _cnode, _cf,
                                       _sf, _tf ) ) - ( arguments[ 1 ]->eval( _cnode, _cf,
                                                                              _sf, _tf ) );
    }
    cerr << " Substraction is not defined for else  than two paraments." << endl;
    return 0.;
}
/*
   double
   MinusEvaluation::eval( cube::Cnode *  _cnode, CalculationFlavour _cf, cube::Process * _pr, CalculationFlavour  _tf   )
   {
    if (getNumOfParameters() == 2)
        return (arguments[0]->eval(_cnode, _cf,
                                        _pr, _tf)) - (arguments[1]->eval(_cnode, _cf,
                                        _pr, _tf));
    cerr << " Substraction is not defined for else  than two paraments." << endl;
    return 0.;
   }

   double
   MinusEvaluation::eval( cube::Cnode *  _cnode, CalculationFlavour _cf, cube::Node * _nd, CalculationFlavour    _tf )
   {
    if (getNumOfParameters() == 2)
        return (arguments[0]->eval(_cnode, _cf,
                                            _nd, _tf)) - (arguments[1]->eval(_cnode, _cf,
                                            _nd, _tf));
    cerr << " Substraction is not defined for else  than two paraments." << endl;
    return 0.;
   }

   double
   MinusEvaluation::eval( cube::Cnode *  _cnode, CalculationFlavour _cf, cube::Machine * _mch, CalculationFlavour   _tf  )
   {
    if (getNumOfParameters() == 2)
        return (arguments[0]->eval(_cnode, _cf,
                                            _mch, _tf)) - (arguments[1]->eval(_cnode, _cf,
                                            _mch, _tf));
    cerr << " Substraction is not defined for else  than two paraments." << endl;
    return 0.;
   }*/

double
MinusEvaluation::eval( cube::Cnode* _cnode, CalculationFlavour _cf )
{
    if ( getNumOfParameters() == 2 )
    {
        return ( arguments[ 0 ]->eval( _cnode, _cf ) ) - ( arguments[ 1 ]->eval( _cnode, _cf ) );
    }
    cerr << " Substraction is not defined for else  than two paraments." << endl;
    return 0.;
}



#endif
