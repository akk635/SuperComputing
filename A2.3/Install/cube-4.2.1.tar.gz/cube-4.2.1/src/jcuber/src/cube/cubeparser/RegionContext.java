/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.cubeparser;
import scalasca.cubex.cube.*;
import java.util.HashMap;
import java.util.Map;

public class RegionContext
{
	public int id= -1;
	public String mod= "";
	public int beginln= -1;
	public int endln= -1;
	public String name= "";
	public String url= "";
	public String descr= "";
    public Map<String, String> attributes = new HashMap<String, String> ();

	RegionContext() {};

	public String toString()
	{

		return
			"ID:" + id + "\t" +
			"Name:" + name + "\t" +
			"Mod:" + mod + "\t" +
			"Begin Line:" + beginln + "\t" +
			"End Line :" + endln + "\t" +
			"url:" + url + "\t" +
			"description:" + descr + "\t" 
			;
	}
}