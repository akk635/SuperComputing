/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.datalayout.data.value;
import scalasca.cubex.cube.errors.*;
import scalasca.cubex.cube.services.transformation.*;

import java.lang.*;
import java.util.*;
import java.io.*;
import java.lang.Math;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public class CubeTauAtomicMetric extends Value
{

	protected CubeUint32 		N;
	protected CubeMinDouble 	Min;
	protected CubeMaxDouble 	Max;
	protected CubeDouble		Sum;
	protected CubeDouble		Sum2;

	private double avg;
	private double var;

	public CubeTauAtomicMetric()
		{
			N = new CubeUint32();
			Min = new CubeMinDouble();
			Max = new CubeMaxDouble();
			Sum = new CubeDouble();
			Sum2 = new CubeDouble();

			calculateValues();

		};


	public CubeTauAtomicMetric(int _n, double _min, double _max, double _sum, double _sum2)
		{
			N = new CubeUint32(_n);
			Min = new CubeMinDouble(_min);
			Max = new CubeMaxDouble(_max);
			Sum = new CubeDouble(_sum);
			Sum2 = new CubeDouble(_sum2);
			calculateValues();
		};




	public String getName()
		{
			return "TAU_ATOMIC";
		}
	public String toString()
		{
			return "("+N.toString() + ", " + Min.toString() + ", "+ Max.toString() +"):" + Double.valueOf(avg).toString() + ", " + Double.valueOf(var).toString();
		}

	public int size() 
		{
			return N.size() + Min.size() + Max.size() + Sum.size() + Sum2.size();
		} ;

	public void correctEndianess(Endianess _end, DataInputStream in, DataOutputStream out)  throws IOException
		{
			N.correctEndianess(_end, in, out);
			Min.correctEndianess(_end, in, out);
			Max.correctEndianess(_end, in, out);
			Sum.correctEndianess(_end, in, out);
			Sum2.correctEndianess(_end, in, out);
			calculateValues();
		}

	public Value clone()
	{
		return new CubeTauAtomicMetric();
	}
	public Value copy()
	{
		return new CubeTauAtomicMetric(
					(int)(N.getDouble()),
					Min.getDouble(),
					Max.getDouble(),
					Sum.getDouble(),
					Sum2.getDouble()
					);
	}
	public Value clone(DataInputStream in)  throws IOException
	{
		int _n = in.readInt();
		double _min = in.readDouble();
		double _max = in.readDouble();
		double _sum = in.readDouble();
		double _sum2 = in.readDouble();
		return new CubeTauAtomicMetric(_n, _min , _max, _sum, _sum2);
	}


 // ------------------- setXXX methods ------------------
	public  void setValue(String str) // initialization from String
	{
// 		value = 0; // here is parsing needed
	}
	public  void setValue(byte v) // initialization from byte
	{
// 		value = 0;
	}

	public  void setValue(short v) // initialization from short
	{
// 		value = Short(value).byteValue();
	}
	public  void setValue(int v) // initialization from integer
	{
// 		value = Integer(value).byteValue();
	}
	public  void setValue(long v) // initialization from long
	{
// 		value = Long(value).byteValue();
	}
	public  void setValue(double v) // initialization from double
	{
// 		value = Double(value).byteValue();
	}


 // ------------------- getXXX methods ------------------
	public double getDouble()
	{
		return avg; // as many-values value it should be configurable
	}

	public double getN()
	{
		return N.getDouble(); 
	}

	public double getMin()
	{
		return Min.getDouble();
	}
	public double getMax()
	{
		return Max.getDouble();
	}

	public double getSum()
	{
		return Sum.getDouble();
	}
	public double getSum2()
	{
		return Sum2.getDouble();
	}

	public double getAvg()
	{
		return avg;
	}
	public double getVar()
	{
		return var;
	}



 // -------------------- lagebra -------------------------
	public void addValue(Value v)  // performs operation "+"
	{
		CubeTauAtomicMetric _v = (CubeTauAtomicMetric)v;
		N.addValue(_v.N);
		Min.addValue(_v.Min);
		Max.addValue(_v.Max);
		Sum.addValue(_v.Sum);
		Sum2.addValue(_v.Sum2);
		calculateValues();

	}

	public void subtractValue(Value v)  // performs operation "-", if defined
	{
		CubeTauAtomicMetric _v = (CubeTauAtomicMetric)v;
		N.subtractValue(_v.N);
		Min.subtractValue(_v.Min);
		Max.subtractValue(_v.Max);
		Sum.subtractValue(_v.Sum);
		Sum2.subtractValue(_v.Sum2);
		calculateValues();

	}



 // -------------------- CALCULATION ---------------------
	
	private void calculateValues()
	{
		double dn 	= N.getDouble();
		double s 	= Sum.getDouble();
		double s2 	= Sum2.getDouble();
		if (dn != 0.)
		{
			avg = s / dn;
			var = Math.sqrt(1./(dn)* (s2 - s*s/dn));
		}
	}


}
