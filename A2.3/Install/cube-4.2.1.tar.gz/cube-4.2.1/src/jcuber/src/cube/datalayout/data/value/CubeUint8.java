/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.datalayout.data.value;
import scalasca.cubex.cube.errors.*;
import scalasca.cubex.cube.services.transformation.*;

import java.lang.*;
import java.util.*;
import java.io.*;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public class CubeUint8 extends Value
{

	protected short value; // altough we store in stream always lowest byte of that short.

	public CubeUint8() {  value = 0; };

	@SuppressWarnings("unchecked")
	public CubeUint8(byte _v) {  value = (short)_v; };

	public String getName()
		{
			return "UINT8";
		}

	public String toString()
	{
		return Short.valueOf(value).toString();
	}


	public int size() { return 1; } ;

	public void correctEndianess(Endianess _end, DataInputStream in, DataOutputStream out)   throws IOException
		{
			byte _in  = in.readByte();
			byte __in = _end.applyOn(_in);
			out.writeByte(__in);
		}

	public Value clone()
	{
		return new CubeUint8();
	}
	public Value copy()
	{
		return new CubeUint8((byte)value);
	}

	public Value clone(DataInputStream in)  throws IOException
	{
		return new CubeUint8(in.readByte());
	}
 // ------------------- setXXX methods ------------------
	public  void setValue(String v) // initialization from String
	{
		value = Short.parseShort(v);
	}
	public  void setValue(byte v) // initialization from byte
	{
		value = (short)v;
	}

	public  void setValue(short v) // initialization from short
	{
		value = (short)v;
	}
	public  void setValue(int v) // initialization from integer
	{
		value = (short)v;
	}
	public  void setValue(long v) // initialization from long
	{
		value = (short)v;
	}
	public  void setValue(double v) // initialization from double
	{
		value = (short)v;
	}




 // ------------------- getXXX methods ------------------
	public double getDouble()
	{
		return Short.valueOf(value).doubleValue(); 
	}

 // -------------------- lagebra -------------------------
	public void addValue(Value v)  // performs operation "+"
	{
		CubeUint8 _v = (CubeUint8)v;
		value += _v.value;
	}

	public void subtractValue(Value v)  // performs operation "-", if defined
	{
		CubeUint8 _v = (CubeUint8)v;
		value -= _v.value;
	}

}
