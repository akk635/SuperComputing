/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.datalayout.data.value;
import scalasca.cubex.cube.errors.*;
import scalasca.cubex.cube.services.transformation.*;
import java.lang.*;
import java.util.*;
import java.io.*;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public class CubeMaxDouble extends CubeDouble
{

	public CubeMaxDouble() { value = -Double.MAX_VALUE; };
	public CubeMaxDouble(double _v ) { value = _v; };

	public String getName()
	{
		return "MAXDOUBLE";
	}

	public Value clone()
	{
		return new CubeMaxDouble();
	}
	public Value copy()
	{
		return new CubeMaxDouble(value);
	}

	public Value clone(DataInputStream in)  throws IOException
	{
		return new CubeMaxDouble(in.readDouble());
	}

 // -------------------- lagebra -------------------------
	public void addValue(Value v)  // performs operation "+"
	{
		CubeMaxDouble _v = (CubeMaxDouble)v;
		value = Math.max(value, _v.value);
	}

	public void subtractValue(Value v)  // performs operation "-", if defined
	{
		CubeMaxDouble _v = (CubeMaxDouble)v;

		value = Math.min(value, _v.value);
	}

}
