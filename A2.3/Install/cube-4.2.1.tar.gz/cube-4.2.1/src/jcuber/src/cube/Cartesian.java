/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube;
import java.lang.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/*
 * Class , delivers file structure of CubeX
 * 
 */
public class Cartesian 
{
    private String name  = "";
    private int ndim = -1;
    private ArrayList<Integer> dimv = new ArrayList<Integer>();
    private ArrayList<String>  dim_names = new ArrayList<String>();

    private ArrayList<Boolean> periodv = new ArrayList<Boolean>();
    private Map<Location, ArrayList<Integer> > sys2coord = new HashMap<Location, ArrayList<Integer> >();

	
    //     @SuppressWarnings("unchecked")
    public Cartesian( int _ndim, ArrayList<Integer> _dimv, ArrayList<Boolean> _periodv)
    {
	ndim = _ndim;
	dimv = _dimv;
	periodv = _periodv;
    }


    public void def_coords(Location _loc, ArrayList<Integer> _coords )
    {
	sys2coord.put(_loc, _coords);
    }

    public int get_ndim () { return ndim; }
    public ArrayList<Integer> get_dimv () { return dimv; }
    public ArrayList<Boolean> get_periodv () { return periodv; }
    public ArrayList<Integer> get_coordv ( Location _thread)
    {
	ArrayList<Integer> _return = sys2coord.get(_thread);
	if (_return == null)
	    _return = new ArrayList<Integer>();

	return _return;
    }

    public void set_name(String _name ) { name = _name; }
    public String get_name() { return name; }

    public boolean set_namedims(ArrayList<String> names)
    {
	if (names.size() == ndim)
	{
	    dim_names = names;
	    return true;
	}
	return false;
    }
    ArrayList<String> get_namedims() { return dim_names; };

    public boolean set_dim_name(int dim, String name)
    {
	if (dim <0 || dim>=ndim)
	    return false;
	if (dim_names.size() < ndim)
	    dim_names.ensureCapacity(ndim);
	dim_names.set(dim, name);
	return true;
    }
    public String get_dim_name(int dim)
    {
	if (dim <0 || dim>=ndim)
	{
	    System.err.println("Dimension index " + dim + " is out of range of dimension number " + ndim);
	    return "";
	}
	return dim_names.get(dim);
    }




}
