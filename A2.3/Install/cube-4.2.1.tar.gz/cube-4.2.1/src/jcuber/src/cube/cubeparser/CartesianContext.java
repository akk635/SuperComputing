/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.cubeparser;
import scalasca.cubex.cube.*;
import java.util.*;

public class CartesianContext
{
	public String name= new String("");
	public int ndims= -1;
	public ArrayList<Integer> dim_sizes = new ArrayList<Integer>();
	public ArrayList<String> dim_names = new ArrayList<String>();
	public ArrayList<Boolean> dim_periodicity = new ArrayList<Boolean>();

	public ArrayList< ArrayList <Integer> >  coordinates = new ArrayList< ArrayList<Integer> >();
	public int actualThreadId = -1;
	CartesianContext() {};

	public String toString()
	{

		String _str = 
			"Name:" + name + "\t" +
			"Ndim:" + ndims + "\n"
			;
		
		for (int dim_index = 0; dim_index < dim_sizes.size(); dim_index++)
		{
			Integer size = dim_sizes.get(dim_index);
			Boolean periodic = dim_periodicity.get(dim_index);
			_str +=
			"Dim " + dim_index + " has " + size + " and periodic is " + periodic.toString() + "\n";
		}
		for (int coords_index = 0; coords_index < coordinates.size(); coords_index++)
		{
			ArrayList < Integer > _coordinates = coordinates.get(coords_index);
			String _joined_coords = "";
			if (_coordinates != null)
			{
				for(Integer s : _coordinates)
					_joined_coords += new Integer(s)+ " ";
			}
			_str +=
			"Thread  " + coords_index + "  ( " + _joined_coords + ") \n";
		}
		return _str;

	}			
}