 /****************************************************************************
 **  CUBE        http://www.scalasca.org/                                   **
 **  SCALASCA    http://www.scalasca.org/                                   **
 *****************************************************************************
 **  Copyright (c) 2011-2011                                                **
 **  Forschungszentrum Juelich, Juelich Supercomputing Centre               **
 **                                                                         **
 **  See the file COPYRIGHT in the package base directory for details       **
 ****************************************************************************/

package scalasca.cubex.cube.cubeparser;
import scalasca.cubex.cube.*;
import java.util.HashMap;
import java.util.Map;

public class LocationContext
{
	public int id= -1;
	public String name = "";
	public long rank = -1;
	public LocationType type = LocationType.CPU_THREAD;
    public Map<String, String> attributes = new HashMap<String, String> ();

	LocationContext() {};

	public String toString()
	{

		return
			"ID:" + id + "\t" +
			"Name :" + name  + "\t" +
			"Rank:" + rank + "\t" + 
			"Type:" + type + "\t" 
			;
	}
}