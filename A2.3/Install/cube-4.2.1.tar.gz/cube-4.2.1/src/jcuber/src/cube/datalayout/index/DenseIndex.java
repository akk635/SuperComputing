/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.datalayout.index;
import scalasca.cubex.cube.errors.*;
import scalasca.cubex.cube.services.transformation.*;

import java.lang.*;
import java.util.*;
import java.io.*;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public class DenseIndex extends Index
{
	
	//     @SuppressWarnings("unchecked")
	public DenseIndex(int number_of_cnodes, int number_of_threads, Endianess _end) 
	{
		super(number_of_cnodes, number_of_threads, _end );
		indexType = IndexType.DENSE;
	}

	public int getPosition(int cid, int tid) throws IDOutOfBoundsException, MissingRowException
	{
		if (cid <0 || cid>=number_of_cnodes)
			throw new CIDPairOutOfBoundsException(cid, number_of_cnodes);
		if (tid <0 || tid>=number_of_cnodes)
			throw new TIDPairOutOfBoundsException(tid, number_of_threads);

		return cid*number_of_threads + tid;
	}


}
