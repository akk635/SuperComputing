/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.datalayout.data;
import scalasca.cubex.cube.datalayout.data.value.*;
import scalasca.cubex.cube.errors.*;
import scalasca.cubex.cube.services.transformation.*;
import java.lang.*;
import java.util.*;
import java.io.*;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public class DataChooser
{
	static private String Marker =  "CUBEX.DATA";
	static private String ZMarker = "ZCUBEX.DATA";

	static public DataRows getDataRows(byte[] _metric_data, Value _metric_value, Endianess _endianess) throws BadCubeReportLayoutException
		{
			String _marker = new String(_metric_data,0, ZMarker.length());

			if 	(  _marker.substring(0, Marker.length()).equalsIgnoreCase(Marker))
			{
				return new DataRows(removeMarker(Marker.length(), _metric_data), _metric_value, _endianess);
			}
			if 	(  _marker.substring(0, ZMarker.length()).equalsIgnoreCase(ZMarker))
			{
				return new CompressedDataRows(removeMarker(ZMarker.length(), _metric_data), _metric_value, _endianess);
			}
			throw new BadCubeReportLayoutException("Data doesn't start with correct marker. Expect " + Marker + " or " + ZMarker + " but it starts with "+ _marker);
		} ;




	static private byte[] removeMarker(int skip, byte[] data)
	{
		byte[] new_data = new byte[ data.length - skip  ];
		System.arraycopy(data, skip, new_data, 0, data.length - skip);
		return new_data;
	}

}
