 /****************************************************************************
 **  CUBE        http://www.scalasca.org/                                   **
 **  SCALASCA    http://www.scalasca.org/                                   **
 *****************************************************************************
 **  Copyright (c) 2011-2011                                                **
 **  Forschungszentrum Juelich, Juelich Supercomputing Centre               **
 **                                                                         **
 **  See the file COPYRIGHT in the package base directory for details       **
 ****************************************************************************/

package scalasca.cubex.cube;
import java.lang.String;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public class LocationGroup extends NamedVertex
{

    protected long rank = -1;
    LocationGroupType type =  LocationGroupType.PROCESS;

//     @SuppressWarnings("unchecked")	
    public LocationGroup() { super("Process"); }
    public LocationGroup(int _id,SystemTreeNode _parent) 
    { 
      super(_id, "Process", null); 
      parent = _parent;
      ((SystemTreeNode)parent).addLocationGroup(this);
	
    }
    public LocationGroup(int _id, long _rank, LocationGroupType _type, SystemTreeNode _parent) 
    { 
      super(_id, "Process", null);  
      parent = _parent;
      type = _type;
      ((SystemTreeNode)parent).addLocationGroup(this);
      rank = _rank; 
    }
    public LocationGroup(int _id, long _rank, String _name, LocationGroupType _type, SystemTreeNode _parent) 
    { 
      super(_id, _name, null);  
      parent = _parent;
      type = _type;
      ((SystemTreeNode)parent).addLocationGroup(this);
      rank = _rank; 
    }

    public void init(long _rank, String  _name, LocationGroupType _type) 
    { 
      setName(_name); 
      rank = _rank; 
      type = _type; 
    }

    public long getRank()
    {
	return rank;
    }


    public String getName()
    {
	return super.getName() + " " + String.valueOf(rank);
    }

    public LocationGroupType getType()
    {
	return type;
    }
     public String getTypeAsString()
    {
      if (type == LocationGroupType.PROCESS )
	  return "process";
      if (type == LocationGroupType.METRICS )
	  return "metrics";
      return "not supported";
    }   
    
    
    public static 
    LocationGroupType 
    getLocationGroupType(String _type) throws scalasca.cubex.cube.errors.BadSyntaxException
    {
      if (_type.equals("process") )
	  return LocationGroupType.PROCESS;
      if (_type.equals("metrics") )
	  return LocationGroupType.METRICS;
      throw new scalasca.cubex.cube.errors.BadSyntaxException("Do not support location group type " + _type);
    }
    
    
}
