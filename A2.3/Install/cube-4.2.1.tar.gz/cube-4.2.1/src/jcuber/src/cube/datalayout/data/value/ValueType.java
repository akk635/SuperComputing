/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.datalayout.data.value;

public enum ValueType
{
	UNKNOWN    (-1 ) { public String toString() { return "UNKNOWN";   };  public boolean isMultiValued() { return false;   };	},
	UINT8      ( 0 ) { public String toString() { return "UINT8"; };  public boolean isMultiValued() { return false;   }; 	},
	INT8       ( 1 ) { public String toString() { return "INT8"; };  public boolean isMultiValued() { return false;   };	},
	UINT16      ( 2 ) { public String toString() { return "UINT16"; };  public boolean isMultiValued() { return false;   }; 	},
	INT16       ( 3 ) { public String toString() { return "INT16"; };  public boolean isMultiValued() { return false;   };	},
	UINT32      ( 4 ) { public String toString() { return "UINT32"; };  public boolean isMultiValued() { return false;   }; 	},
	INT32       ( 5 ) { public String toString() { return "INT32"; };  public boolean isMultiValued() { return false;   };	},
	UINT64      ( 6 ) { public String toString() { return "UINT64"; };  public boolean isMultiValued() { return false;   }; 	},
	INT64       ( 7 ) { public String toString() { return "INT64"; };  public boolean isMultiValued() { return false;   };	},
	DOUBLE      ( 8 ) { public String toString() { return "DOUBLE"; };  public boolean isMultiValued() { return false;   }; 	},
	MINDOUBLE      ( 9 ) { public String toString() { return "MINDOUBLE"; };  public boolean isMultiValued() { return false;   }; 	},
	MAXDOUBLE      ( 10 ) { public String toString() { return "MAXDOUBLE"; };  public boolean isMultiValued() { return false;   }; 	},
	TAU_ATOMIC_METRIC  ( 11 ) { public String toString() { return "TAU_ATOMIC"; };  public boolean isMultiValued() { return true;   };	},
	COMPLEX  ( 12 ) { public String toString() { return "COMPLEX"; };  public boolean isMultiValued() { return true;   };	};

	private final int value;
	ValueType(int value) { this.value = value; }

	abstract public String toString();
	abstract public boolean isMultiValued();

	static public ValueType getValueType(String value)
	{
		if (value.equalsIgnoreCase("UNKNOWN"))   return ValueType.UNKNOWN;
		if (value.equalsIgnoreCase("UINT8")) return ValueType.UINT8;
		if (value.equalsIgnoreCase("INT8")) return ValueType.INT8;
		if (value.equalsIgnoreCase("UINT16")) return ValueType.UINT16;
		if (value.equalsIgnoreCase("INT16")) return ValueType.INT16;
		if (value.equalsIgnoreCase("UINT32")) return ValueType.UINT32;
		if (value.equalsIgnoreCase("INT32")) return ValueType.INT32;
		if (value.equalsIgnoreCase("UINT64") || value.equalsIgnoreCase("INTEGER")) return ValueType.UINT64;
		if (value.equalsIgnoreCase("INT64")) return ValueType.INT64;
		if (value.equalsIgnoreCase("DOUBLE") || value.equalsIgnoreCase("FLOAT")) return ValueType.DOUBLE;
		if (value.equalsIgnoreCase("MINDOUBLE")) return ValueType.MINDOUBLE;
		if (value.equalsIgnoreCase("MAXDOUBLE")) return ValueType.MAXDOUBLE;
		if (value.equalsIgnoreCase("TAU_ATOMIC")) return ValueType.TAU_ATOMIC_METRIC;
		if (value.equalsIgnoreCase("COMPLEX")) return ValueType.COMPLEX;
		return ValueType.UNKNOWN;
	}




}


