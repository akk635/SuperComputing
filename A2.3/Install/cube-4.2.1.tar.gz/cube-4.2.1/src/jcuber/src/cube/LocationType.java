 /****************************************************************************
 **  CUBE        http://www.scalasca.org/                                   **
 **  SCALASCA    http://www.scalasca.org/                                   **
 *****************************************************************************
 **  Copyright (c) 2011-2011                                                **
 **  Forschungszentrum Juelich, Juelich Supercomputing Centre               **
 **                                                                         **
 **  See the file COPYRIGHT in the package base directory for details       **
 ****************************************************************************/

package scalasca.cubex.cube;
public enum LocationType
{
UNKNOWN,
CPU_THREAD,
GPU,
METRIC
}

