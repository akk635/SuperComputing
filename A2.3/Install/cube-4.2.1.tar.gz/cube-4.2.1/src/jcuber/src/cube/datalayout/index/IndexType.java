/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.datalayout.index;
import java.lang.*;
import java.util.*;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public enum IndexType
{

 	UNKNOWN    ( 0xFF ) 	{ public String toString() { return "UNKNOWN";  }	},
	NONE  ( 0 ) 		{ public String toString() { return "NONE"; 	}	},
	SPARSE   ( 1 )		{ public String toString() { return "SPARSE"; 	}	},
	BITVECTOR ( 2 )		{ public String toString() { return "BITVECTOR";}	},
	DENSE   ( 3 )		{ public String toString() { return "DENSE"; 	}	};

	private final byte type;
	IndexType(int type) { this.type = (byte)type; }
	abstract public String toString();


	static public IndexType getIndexType(byte value)
	{
		if (value == 0xFF)   return IndexType.UNKNOWN;
		if (value == 0x01)   return IndexType.SPARSE;
		if (value == 0x02)   return IndexType.BITVECTOR;
		if (value == 0x03)   return IndexType.DENSE;
		return IndexType.UNKNOWN;
	}



}
