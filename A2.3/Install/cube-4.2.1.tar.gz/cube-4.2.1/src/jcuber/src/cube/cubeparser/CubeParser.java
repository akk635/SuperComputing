/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.cubeparser;
import java.lang.Integer;
import java.lang.Long;
import java.lang.String;
import java.util.StringTokenizer;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Stack;
import java.util.EmptyStackException;

import java.io.File;
import java.io.FileInputStream;
import java.io.ByteArrayInputStream;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.FileNotFoundException;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

import scalasca.cubex.cubexlayout.*;
import scalasca.cubex.cube.*;
import scalasca.cubex.cube.services.*;

import scalasca.cubex.cube.errors.*;
import scalasca.cubex.cube.cubeparser.*;




/*
 * Class , delivers file structure of CubeX
 * 
 */
public class CubeParser extends DefaultHandler implements ProgressReportInterface
{
	private ProgressReportContext progressContext = new ProgressReportContext();

	private Cube cube;
	private CubeContext actualCubeContext = CubeContext.UNKNOWN;

	private StringBuffer tagContent = new StringBuffer();

//  ------------  metric stacks --------------
	private Metric actualMetric = null;
	private Metric parentMetric = null;
	private MetricContext metricContext = new MetricContext();
	private Stack<MetricContext> metricContextes  = new Stack<MetricContext>();
// -------------- region stacks --------------
	private RegionContext regionContext = null;

// -------------- cnode stacks --------------
	private Cnode actualCnode = null;
	private CnodeContext cnodeContext = new CnodeContext();
	private Stack<CnodeContext> cnodeContextes  = new Stack<CnodeContext>();
// --------------- machine contexts --------- 
	private SystemTreeNode actualStn  = null;
	private SystemTreeNodeContext stnContext = null;
	private Stack<SystemTreeNodeContext> stnContextes  = new Stack<SystemTreeNodeContext>();

// --------------- machine contexts ---------
	private LocationGroup actualLocationGroup  = null;
	private LocationGroupContext lgContext = null;
// --------------- machine contexts ---------
	private Location actualLocation  = null;
	private LocationContext locationContext = null;
// --------------- topologies context ----------
// 	private cube.Cartesian actualCartesian  = null;
	private CartesianContext cartesianContext = null;





public CubeParser (Cube _cube) { cube = _cube ; } 

@SuppressWarnings("unchecked")
public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException
{

	String _id = "";
	String _title = "";
	switch (getTag(localName, actualCubeContext ))
	{
		case CUBE:
			progressContext.setAchievedStep();
			progressContext.setNextStep(0.1);
			progressContext.setProgressMessage("Read metadata about cube report...");
			cube.set_version(attributes.getValue("", "version"));
			actualCubeContext = CubeContext.CUBE;
			break;
		case ATTR:
			cube.def_attr(attributes.getValue("","key"), attributes.getValue("", "value"));
			break;
		case MURL:
			cube.def_mirror(tagContent.toString());
			tagContent.setLength(0);
			break;

		case METRICS:
			progressContext.setAchievedStep();
			progressContext.setNextStep(0.2);
			progressContext.setProgressMessage("Read metadata about metrics...");
			_title = attributes.getValue("","title");
			if (_title != null)
				cube.set_metricstree_title(_title);
			break;
		case METRIC:
			try{
				actualCubeContext = CubeContext.METRIC;
				if (metricContext != null)
				{
					metricContextes.push(metricContext);
				}
				parentMetric = actualMetric; // saving parent
				metricContext = new MetricContext();
				metricContext.id = Integer.parseInt(attributes.getValue("","id"));
				metricContext.metricType = MetricType.getMetricType(attributes.getValue("","type"));
				metricContext.parent = parentMetric;
				actualMetric = cube.def_met(
								metricContext.id,
								metricContext.metricType,
								metricContext.parent
								); 
				metricContext.metric = actualMetric;
			    }catch (UnknownMetricTypeException e)
			    {
				    System.out.println("Ignore metric becuase of error:" + e.toString());
			    }
			break;
        case METRATTR:
                metricContext.attributes.put(attributes.getValue("","key"), attributes.getValue("", "value"));
            break;

		case PROGRAM:
			progressContext.setAchievedStep();
			progressContext.setNextStep(0.2);
			progressContext.setProgressMessage("Read metadata about program...");
			_title = attributes.getValue("","title");
			if (_title != null)
				cube.set_calltree_title(_title);
			break;

		case REGION:
			actualCubeContext = CubeContext.REGION;
			regionContext = new RegionContext();
			regionContext.id = Integer.parseInt(attributes.getValue("","id"));
			regionContext.mod = attributes.getValue("","mod");
			regionContext.beginln = Integer.parseInt(attributes.getValue("","begin"));
			regionContext.endln = Integer.parseInt(attributes.getValue("","end"));
			break;
        case RATTR:
            regionContext.attributes.put(attributes.getValue("","key"), attributes.getValue("", "value"));
            break;
			
		case CNODE:
			actualCubeContext = CubeContext.CNODE;
			if (cnodeContext != null)
			{
				cnodeContextes.push(cnodeContext);
			}
			Cnode parent_cnode = actualCnode; // saving parent

			cnodeContext = new CnodeContext();
			cnodeContext.id = Integer.parseInt(attributes.getValue("","id"));
			cnodeContext.region_id = Integer.parseInt(attributes.getValue("","calleeId"));
			cnodeContext.parent = parent_cnode;
			actualCnode=cube.def_cnode(
							cnodeContext.id,
							cnodeContext.region_id,
							cnodeContext.parent
							);
			cnodeContext.cnode = actualCnode;
			break;
		case CNODE_PARAMETER:
			if (actualCubeContext != CubeContext.CNODE)
				throw new SAXException("Found cnode parameter outside of <cnode ...> </cnode>.");
			String _partype = attributes.getValue("","partype");
			String _parkey = attributes.getValue("","parkey");
			String _parvalue = attributes.getValue("","parvalue");
			if (_partype.equalsIgnoreCase("numeric"))
			{
				try
				{
					cnodeContext.num_parameters.put(_parkey, new Long(_parvalue));
				}catch (NumberFormatException e )
				{
					throw new SAXException ("Cannot read numerical parameter \"" + _parkey + " of cnode id=" + cnodeContext.id);
				}
			}
			if (_partype.equalsIgnoreCase("string"))
			{
				cnodeContext.str_parameters.put(_parkey, _parvalue);
			}
			break;
        case CNODE_ATTR:
            cnodeContext.attributes.put(attributes.getValue("","key"), attributes.getValue("", "value"));
            break;          

		case SYSTEM:
			progressContext.setAchievedStep();
			progressContext.setNextStep(0.2);
			progressContext.setProgressMessage("Read metadata about system...");
			_title = attributes.getValue("","title");
			if (_title != null)
				cube.set_systemtree_title(_title);
			break;
		case SYSTEMTREENODE:
			actualCubeContext = CubeContext.SYSTEMTREENODE;
			if (stnContext != null)
			  {
				  stnContextes.push(stnContext);
			  }
			stnContext = new SystemTreeNodeContext();
			_id = attributes.getValue("","id");
			if (_id == null)
				_id = attributes.getValue("","Id");
			stnContext.id = Integer.parseInt(_id);
			actualStn = cube.def_system_tree_node(stnContext.id, actualStn);
			stnContext.stn = actualStn;
			break;
        case STNATTR:
            stnContext.attributes.put(attributes.getValue("","key"), attributes.getValue("", "value"));
            break;
			
		case LOCATIONGROUP:
			actualCubeContext = CubeContext.LOCATIONGROUP;
			lgContext = new LocationGroupContext();
			_id = attributes.getValue("","id");
			if (_id == null)
				_id = attributes.getValue("","Id");
			lgContext.id = Integer.parseInt(_id);
			actualLocationGroup = cube.def_location_group(lgContext.id, actualStn);
			break;
        case LGATTR:
            lgContext.attributes.put(attributes.getValue("","key"), attributes.getValue("", "value"));
            break;
		case LOCATION:
			actualCubeContext = CubeContext.LOCATION;
			locationContext = new LocationContext();
			_id = attributes.getValue("","id");
			if (_id == null)
				_id = attributes.getValue("","Id");
			locationContext.id = Integer.parseInt(_id);
			actualLocation = cube.def_location(locationContext.id, actualLocationGroup);
			break;
        case LATTR:
            locationContext.attributes.put(attributes.getValue("","key"), attributes.getValue("", "value"));
            break;			
		case TOPOLOGIES:
			actualCubeContext = CubeContext.TOPOLOGIES;
			break;
		case CART:
			if (actualCubeContext != CubeContext.TOPOLOGIES )
				throw new SAXException ( "Found <cart ...> outside of <topologies> ..</topologies>" );
			actualCubeContext = CubeContext.CARTESIAN;
			cartesianContext = new CartesianContext();
			cartesianContext.ndims = Integer.parseInt(attributes.getValue("","ndims"));
			cartesianContext.name = attributes.getValue("","name");
			break;
		case DIM:
			if (actualCubeContext != CubeContext.CARTESIAN )
				throw new SAXException( "Found <dim ...> outside of <cart> ..</cart>" );
			cartesianContext.dim_sizes.add(new Integer(attributes.getValue("","size")));
			cartesianContext.dim_names.add(attributes.getValue("","name"));
			cartesianContext.dim_periodicity.add(new Boolean(attributes.getValue("","periodic")));
			break;
		case COORD:
			if (actualCubeContext != CubeContext.CARTESIAN )
				throw new SAXException( "Found <coord ...> outside of <cart> ..</cart>" );
			actualCubeContext = CubeContext.COORDINATES;
			if ( attributes.getValue("","thrdId") != null )
			  cartesianContext.actualThreadId =  Integer.parseInt(attributes.getValue("","thrdId"));
			if ( attributes.getValue("","locId") != null )
			  cartesianContext.actualThreadId =  Integer.parseInt(attributes.getValue("","locId"));
			tagContent.setLength(0);
			break;


		// cube3 copatibility cases
		case SEVERITY:
			progressContext.setAchievedStep();
			progressContext.setNextStep(0.4);
			progressContext.setProgressMessage("Read severity data ...");
			if (actualCubeContext != CubeContext.CUBE)
				throw new SAXException( "Found <severity ...> before </system>" );
			actualCubeContext = CubeContext.SEVERITY;
			cube.prepareForCube3();
			break;
		case MATRIX:
			if (actualCubeContext != CubeContext.SEVERITY)
				throw new SAXException( "Found <matrix ...> outside of  <severity>...</severity>" );
			actualCubeContext = CubeContext.MATRIX;
			actualMetric = cube.get_metv().get(new Integer(attributes.getValue("","metricId")).intValue());
			break;
		case ROW:
			if (actualCubeContext != CubeContext.MATRIX)
				throw new SAXException( "Found <row ...> outside of  <matrix>...</matrix>" );
			actualCubeContext = CubeContext.ROW;
			actualCnode = cube.get_cnodev().get(new Integer(attributes.getValue("","cnodeId")).intValue());
			break;
		default:
//    			System.out.println("Skip start TAG: <" + localName + ">");
			tagContent.setLength(0);
			break;
	}

}

// @SuppressWarnings("unchecked")
public void endElement(String uri, String localName, String qName) throws  SAXException
{
	switch (getTag(localName, actualCubeContext ))
	{
		case CUBE:
// 			System.out.println("we are sdone");
			break;
		case METRIC:
			try{
				if (actualMetric != null)  // we ignore DERIVED or other metrics
				{
				    actualMetric.init(
						    metricContext.uniq_name,
						    metricContext.disp_name,
						    metricContext.dtype,
						    metricContext.uom,
						    metricContext.url,
						    metricContext.descr
						    );
                    actualMetric.set_attrs( metricContext.attributes);

				}
				metricContext = metricContextes.pop();
				actualMetric  = metricContext.metric;
				parentMetric  = metricContext.parent; // saving parent
			}
			catch (EmptyStackException e){}
			catch (UnknownValueTypeException e)
			{
				System.out.println("Do not initialize metric becuase of error:" + e.toString());
			}
			break;
		case UNIQ_NAME:
				metricContext.uniq_name=tagContent.toString();
				tagContent.setLength(0);
			break;
		case DISP_NAME:
				metricContext.disp_name=tagContent.toString();
				tagContent.setLength(0);
			break;
		case DTYPE:
				metricContext.dtype=tagContent.toString();
				tagContent.setLength(0);
			break;
		case UOM:
				metricContext.uom=tagContent.toString();
				tagContent.setLength(0);
			break;
		case METURL:
				metricContext.url=tagContent.toString();
				tagContent.setLength(0);
			break;
		case METDESCR:
				metricContext.descr=tagContent.toString();
				tagContent.setLength(0);
			break;
		case REGION:
		     Region _region =
		     cube.def_region(
					regionContext.id,
					regionContext.name,
					regionContext.beginln,
					regionContext.endln,
					regionContext.url,
					regionContext.descr,
					regionContext.mod
					);
            _region.set_attrs( regionContext.attributes);
			break;
		case RURL:
			regionContext.url=tagContent.toString();
			tagContent.setLength(0);
			break;
		case RNAME:
			regionContext.name=tagContent.toString();
			tagContent.setLength(0);
			break;
		case RDESCR:
			regionContext.descr=tagContent.toString();
			tagContent.setLength(0);
			break;
		case CNODE:
			actualCnode.add_str_parameters( cnodeContext.str_parameters);
			actualCnode.add_num_parameters( cnodeContext.num_parameters);
            actualCnode.set_attrs( cnodeContext.attributes);
 			try{
				cnodeContext = cnodeContextes.pop();
				actualCnode =  cnodeContext.cnode;
			}catch (EmptyStackException e) {}
			break;
		case SYSTEMTREENODE:
			try
			{
			  actualStn.init(
					  stnContext.name,
					  stnContext.description,
					  stnContext.stn_class
					  );
              actualStn.set_attrs( stnContext.attributes);			
			  stnContext = stnContextes.pop();
			  actualStn = stnContext.stn;
			}catch (EmptyStackException e){}
				
			break;
		case STNNAME:
			stnContext.name=tagContent.toString();
			tagContent.setLength(0);
			break;
		case STNDESCR:
			stnContext.description=tagContent.toString();
			tagContent.setLength(0);
			break;
		case STNCLASS:
			stnContext.stn_class=tagContent.toString();
			tagContent.setLength(0);
			break;
		case LOCATIONGROUP:
			actualLocationGroup.init(
					lgContext.rank,
					lgContext.name,
					lgContext.type
					);
            actualLocationGroup.set_attrs( lgContext.attributes);            
			actualCubeContext = CubeContext.SYSTEMTREENODE;
			break;
		case LGNAME:
			lgContext.name=tagContent.toString();
			tagContent.setLength(0);
			break;
		case LGRANK:
			lgContext.rank=Long.parseLong(tagContent.toString());
			tagContent.setLength(0);
			break;
		case LGTYPE:
			try
			{
			  lgContext.type=scalasca.cubex.cube.LocationGroup.getLocationGroupType(tagContent.toString());
			}
			catch (scalasca.cubex.cube.errors.BadSyntaxException e)
			{
				System.out.println("Error in CUBE syntax:" + e.toString());	
				System.out.println("Set PROCESS as a location group type.");	
				lgContext.type = LocationGroupType.PROCESS;
			}
			tagContent.setLength(0);
			break;
		case LOCATION:
			actualLocation.init(
					locationContext.rank,
					locationContext.name,
					locationContext.type
					);
            actualLocation.set_attrs( locationContext.attributes);  
			actualCubeContext = CubeContext.LOCATIONGROUP;			
			break;
		case LNAME:
			locationContext.name=tagContent.toString();
			tagContent.setLength(0);
			break;
		case LRANK:
			locationContext.rank=Long.parseLong(tagContent.toString());
			tagContent.setLength(0);
			break;
		case LTYPE:
			try
			{
			  locationContext.type=scalasca.cubex.cube.Location.getLocationType(tagContent.toString());
			}
			catch (scalasca.cubex.cube.errors.BadSyntaxException e)
			{
				System.out.println("Error in CUBE syntax:" + e.toString());	
				System.out.println("Set THREAD as location type.");	
				locationContext.type = LocationType.CPU_THREAD;
			}
			  tagContent.setLength(0);
			  break;			
        case CART:
			if (actualCubeContext != CubeContext.CARTESIAN)
				throw new SAXException("Found </cart> outside without corresponding <cart ...>");
			Cartesian cart = cube.def_cart( cartesianContext.ndims, cartesianContext.dim_sizes, cartesianContext.dim_periodicity);
			cart.set_namedims(cartesianContext.dim_names);
			ArrayList< ArrayList<Integer> > context_coords = cartesianContext.coordinates;
			ArrayList< scalasca.cubex.cube.Location> _threadv = cube.get_locationv();
			for (scalasca.cubex.cube.Location thread: _threadv)
			{
				if (thread.getId() < context_coords.size() ) // not all threads might have coordinates (should be all, but might be not all)
					cart.def_coords(thread, context_coords.get(thread.getId()));
			}
			if (cartesianContext.name != null)
				cart.set_name( cartesianContext.name);
			actualCubeContext = CubeContext.TOPOLOGIES;
			break;
		case COORD:
			if (actualCubeContext != CubeContext.COORDINATES)
				throw new SAXException("Found <coord ...> </coord> outside of <cart ...> </cart>");
			String coordinates = tagContent.toString();
			ArrayList <Integer > _coord_list = new ArrayList<Integer>();
			StringTokenizer _coords = new StringTokenizer(coordinates, " \t");
			int index = 0;
			while (_coords.hasMoreTokens())
			{
				try
				{
					_coord_list.add(new Integer(_coords.nextToken()));
				}
				catch (NumberFormatException e)
				{ throw new SAXException("Cannot read thread coordinate coordinate: " + e.getMessage()); }
			}

			if (_coord_list.size() != cartesianContext.ndims)
			{
				throw new SAXException("Number of coordinates for thread id= "+ cartesianContext.actualThreadId + " ( "+_coord_list.size()+") is different than number of dimensions in that topology ("+cartesianContext.ndims +")");
			}
			if (cartesianContext.coordinates.size()<=cartesianContext.actualThreadId)
			{
				cartesianContext.coordinates.ensureCapacity(cartesianContext.actualThreadId+1);
				for (int i= cartesianContext.coordinates.size(); i< (cartesianContext.actualThreadId+1); i++)
					cartesianContext.coordinates.add(null);
			}
			cartesianContext.coordinates.set(cartesianContext.actualThreadId, _coord_list);


			tagContent.setLength(0);
			actualCubeContext = CubeContext.CARTESIAN;

			break;
		case SYSTEM:
			actualCubeContext = CubeContext.CUBE;
			break;
		case MATRIX:
			actualCubeContext = CubeContext.SEVERITY;
//  			System.out.println("Load Data for  for metric " + actualMetric.getDisplayName());
// 			
// 		) and for cnode (" + actualCnode.getName()+")");
			break;
		case ROW:
			StringTokenizer values = new StringTokenizer(tagContent.toString(), "\n");
			int threadId = 0;
			while (values.hasMoreTokens())
			{
				String value = values.nextToken().trim();
				if (value.equalsIgnoreCase("")) continue;
				scalasca.cubex.cube.Location _thread = cube.get_locationv().get(threadId);
				try
				{
					cube.set_sev(actualMetric, actualCnode, _thread, value);
				}
				catch (NotEnumeratedCnodeException e)
				{
					throw new SAXException("Internal cube error: " + e.getMessage());
				}
				threadId++;
			}

			tagContent.setLength(0);
			actualCubeContext = CubeContext.MATRIX;
			break;
		default:
//    			System.out.println("Skip end  TAG: </" + localName + ">");
			break;
	}
}

@SuppressWarnings("unchecked")
public void endDocument() throws SAXException
{
// 	System.out.println("End DOCUMENT");
	tagContent.setLength(0);
}

@SuppressWarnings("unchecked")
public void startDocument() throws SAXException
{
// 	System.out.println("Start DOCUMENT");
}

@SuppressWarnings("unchecked")
@Override
public void characters(char[] ch, int start, int length) throws  SAXException
{
	tagContent.append(ch, start, length);
}


// -------- Service functions ---------------

public CubeRawTag getRawTag(String tagName)
{
	if (tagName.equalsIgnoreCase("cube")) return CubeRawTag.CUBE;

	if (tagName.equalsIgnoreCase("attr")) return CubeRawTag.ATTR;
	if (tagName.equalsIgnoreCase("doc")) return CubeRawTag.DOC;
	if (tagName.equalsIgnoreCase("mirrors")) return CubeRawTag.MIRRORS;
	if (tagName.equalsIgnoreCase("murl")) return CubeRawTag.MURL;

	if (tagName.equalsIgnoreCase("metrics")) return CubeRawTag.METRICS;
	if (tagName.equalsIgnoreCase("metric")) return CubeRawTag.METRIC;
	if (tagName.equalsIgnoreCase("uniq_name")) return CubeRawTag.UNIQ_NAME;
	if (tagName.equalsIgnoreCase("disp_name")) return CubeRawTag.DISP_NAME;
	if (tagName.equalsIgnoreCase("dtype")) return CubeRawTag.DTYPE;
	if (tagName.equalsIgnoreCase("uom")) return CubeRawTag.UOM;
	if (tagName.equalsIgnoreCase("url")) return CubeRawTag.URL;
	if (tagName.equalsIgnoreCase("descr")) return CubeRawTag.DESCR;

	if (tagName.equalsIgnoreCase("program")) return CubeRawTag.PROGRAM;
	if (tagName.equalsIgnoreCase("region")) return CubeRawTag.REGION;
	if (tagName.equalsIgnoreCase("name")) return CubeRawTag.NAME;
	if (tagName.equalsIgnoreCase("cnode")) return CubeRawTag.CNODE;
	if (tagName.equalsIgnoreCase("parameter")) return CubeRawTag.CNODE_PARAMETER;
	if (tagName.equalsIgnoreCase("class")) return CubeRawTag.CLASS;
	if (tagName.equalsIgnoreCase("type")) return CubeRawTag.TYPE;

	if (tagName.equalsIgnoreCase("system")) return CubeRawTag.SYSTEM;
	if (tagName.equalsIgnoreCase("systemtreenode")) return CubeRawTag.SYSTEMTREENODE;
	if (tagName.equalsIgnoreCase("locationgroup")) return CubeRawTag.LOCATIONGROUP;
	if (tagName.equalsIgnoreCase("location")) return CubeRawTag.LOCATION;
	if (tagName.equalsIgnoreCase("machine")) return CubeRawTag.SYSTEMTREENODE;
	if (tagName.equalsIgnoreCase("node")) return CubeRawTag.SYSTEMTREENODE;
	if (tagName.equalsIgnoreCase("process")) return CubeRawTag.LOCATIONGROUP;
	if (tagName.equalsIgnoreCase("thread")) return CubeRawTag.LOCATION;
	if (tagName.equalsIgnoreCase("rank")) return CubeRawTag.RANK;
	if (tagName.equalsIgnoreCase("topologies")) return CubeRawTag.TOPOLOGIES;
	if (tagName.equalsIgnoreCase("cart")) return CubeRawTag.CART;
	if (tagName.equalsIgnoreCase("dim")) return CubeRawTag.DIM;
	if (tagName.equalsIgnoreCase("coord")) return CubeRawTag.COORD;

	// cube3 compatibility tags
	if (tagName.equalsIgnoreCase("severity")) return CubeRawTag.SEVERITY;
	if (tagName.equalsIgnoreCase("matrix")) return CubeRawTag.MATRIX;
	if (tagName.equalsIgnoreCase("row")) return CubeRawTag.ROW;

	return CubeRawTag.UNKNOWN;
}



public CubeTag getTag(String tagName, CubeContext context)
{

	CubeRawTag raw_tag = getRawTag(tagName);

	switch (context)
	{
		case METRIC:
				return getTagInMetricContext(raw_tag);
		case REGION:
				return getTagInRegionContext(raw_tag);
        case CNODE:
                return getTagInCnodeContext(raw_tag);
		case SYSTEMTREENODE:
				return getTagInSystemTreeNodeContext(raw_tag);
		case LOCATIONGROUP:
				return getTagInLocationGroupContext(raw_tag);
		case LOCATION:
				return getTagInLocationContext(raw_tag);
		default:
				return getEqualTag(raw_tag);
	}


}



public CubeTag getTagInMetricContext(CubeRawTag raw_tag)
{
	switch (raw_tag)
	{
		case URL:
			return CubeTag.METURL;
		case DESCR:
			return CubeTag.METDESCR;
		case ATTR:
            return CubeTag.METRATTR;
		default:
			return getEqualTag(raw_tag);
	}
}


public CubeTag getTagInRegionContext(CubeRawTag raw_tag)
{
	switch (raw_tag)
	{
		case NAME:
			return CubeTag.RNAME;
		case URL:
			return CubeTag.RURL;
        case ATTR:
            return CubeTag.RATTR;
		case DESCR:
			return CubeTag.RDESCR;
		default:
			return getEqualTag(raw_tag);
	}
}


public CubeTag getTagInCnodeContext(CubeRawTag raw_tag)
{
    switch (raw_tag)
    {
        case ATTR:
            return CubeTag.CNODE_ATTR;
        default:
            return getEqualTag(raw_tag);
    }
}

public CubeTag getTagInSystemTreeNodeContext(CubeRawTag raw_tag)
{
	switch (raw_tag)
	{
		case NAME:
			return CubeTag.STNNAME;
		case DESCR:
			return CubeTag.STNDESCR;
		case CLASS:
			return CubeTag.STNCLASS;	
        case ATTR:
            return CubeTag.STNATTR;
		default:
			return getEqualTag(raw_tag);
	}
}


public CubeTag getTagInLocationGroupContext(CubeRawTag raw_tag)
{
	switch (raw_tag)
	{
		case NAME:
			return CubeTag.LGNAME;
		case TYPE:
			return CubeTag.LGTYPE;			
		case RANK:
			return CubeTag.LGRANK;	
        case ATTR:
            return CubeTag.LGATTR;			
		default:
			return getEqualTag(raw_tag);
	}
}




public CubeTag getTagInLocationContext(CubeRawTag raw_tag)
{
	switch (raw_tag)
	{
		case NAME:
			return CubeTag.LNAME;
		case RANK:
			return CubeTag.LRANK;
		case TYPE:
			return CubeTag.LTYPE;	
        case ATTR:
            return CubeTag.LATTR;  
		default:
			return getEqualTag(raw_tag);
	}
}


public CubeTag getEqualTag(CubeRawTag rawTag)
{
	switch (rawTag)
	{
		case CUBE:
			return CubeTag.CUBE;
		case ATTR:
			return CubeTag.ATTR;
		case DOC:
			return CubeTag.DOC;
		case MIRRORS:
			return CubeTag.MIRRORS;
		case MURL:
			return CubeTag.MURL;

		case METRICS:
			return CubeTag.METRICS;
		case METRIC:
			return CubeTag.METRIC;
		case UNIQ_NAME:
			return CubeTag.UNIQ_NAME;
		case DISP_NAME:
			return CubeTag.DISP_NAME;
		case DTYPE:
			return CubeTag.DTYPE;
		case UOM:
			return CubeTag.UOM;


		case PROGRAM:
			return CubeTag.PROGRAM;
		case REGION:
			return CubeTag.REGION;
		case CNODE:
			return CubeTag.CNODE;
		case CNODE_PARAMETER:
			return CubeTag.CNODE_PARAMETER;

		case SYSTEM:
			return CubeTag.SYSTEM;
			
		case SYSTEMTREENODE:
			return CubeTag.SYSTEMTREENODE;
		case LOCATIONGROUP:
			return CubeTag.LOCATIONGROUP;
		case LOCATION:
			return CubeTag.LOCATION;

		case TOPOLOGIES:
			return CubeTag.TOPOLOGIES;
		case CART:
			return CubeTag.CART;
		case DIM:
			return CubeTag.DIM;
		case COORD:
			return CubeTag.COORD;


		case SEVERITY:
			return CubeTag.SEVERITY;
		case MATRIX:
			return CubeTag.MATRIX;
		case ROW:
			return CubeTag.ROW;




		default:
			return CubeTag.UNKNOWN;
	}
}






	public double getProgress()
	{
		return progressContext.getProgress();
	}

	public String getProgressMessage()
	{
		return progressContext.getProgressMessage();
	}

	public void setActiveProgressReportContext(ProgressReportContext _prc)
	{
		progressContext = _prc;
	}




}
