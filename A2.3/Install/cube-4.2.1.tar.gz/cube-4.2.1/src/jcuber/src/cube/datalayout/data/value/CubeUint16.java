/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.datalayout.data.value;
import scalasca.cubex.cube.errors.*;
import scalasca.cubex.cube.services.transformation.*;

import java.lang.*;
import java.util.*;
import java.io.*;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public class CubeUint16 extends Value
{

	protected int value;

	public CubeUint16() { value = 0; };

	@SuppressWarnings("unchecked")
	public CubeUint16(short _v) { value = (int)_v; };

	public String getName()
	{
		return "UINT16";
	}

	public String toString()
	{
		return Integer.valueOf(value).toString();
	}

	public int size() { return 2; } ;

	public void correctEndianess(Endianess _end, DataInputStream in, DataOutputStream out)  throws IOException
		{
			short _in  =  in.readShort();
			short __in = _end.applyOn(_in);
			out.writeShort(__in);
		}

	public Value clone()
	{
		return new CubeUint16();
	}
	public Value copy()
	{
		return new CubeUint16((short)value);
	}

	public Value clone(DataInputStream in)  throws IOException
	{
		return new CubeUint16(in.readShort());
	}
 // ------------------- setXXX methods ------------------
	public  void setValue(String v) // initialization from String
	{
		value = Integer.parseInt(v);
	}
	public  void setValue(byte v) // initialization from byte
	{
		value = (int)v;
	}

	public  void setValue(short v) // initialization from short
	{
		value = (int)v;
	}
	public  void setValue(int v) // initialization from integer
	{
		value = (int)v;
	}
	public  void setValue(long v) // initialization from long
	{
		value = (int)v;
	}
	public  void setValue(double v) // initialization from double
	{
		value = (int)v;
	}

 // ------------------- getXXX methods ------------------
	public double getDouble()
	{
		return Integer.valueOf(value).doubleValue();
	}

 // -------------------- lagebra -------------------------
	public void addValue(Value v)  // performs operation "+"
	{
		CubeUint16 _v = (CubeUint16)v;
		value += _v.value;
	}

	public void subtractValue(Value v)  // performs operation "-", if defined
	{
		CubeUint16 _v = (CubeUint16)v;
		value -= _v.value;
	}

}
