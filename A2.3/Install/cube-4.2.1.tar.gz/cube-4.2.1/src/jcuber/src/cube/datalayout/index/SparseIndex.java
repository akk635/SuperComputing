/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.datalayout.index;
import scalasca.cubex.cube.errors.*;
import java.lang.*;
import scalasca.cubex.cube.services.transformation.*;
import java.util.*;
import java.io.*;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public class SparseIndex extends Index
{

	protected int[] index = null;
	protected int index_size;
	//     @SuppressWarnings("unchecked")
	public SparseIndex(int number_of_cnodes, int number_of_threads, byte[] _index, Endianess _endianess) throws BadCubeReportLayoutException
	{
		super(number_of_cnodes, number_of_threads, _endianess );
		
 		indexType = IndexType.SPARSE;

 		try
 		{
 			if (_index == null)
				throw new BadCubeReportLayoutException("Got empty sparse index");

			if (_index.length > 0)
			{

				DataInputStream _data = new DataInputStream( new ByteArrayInputStream(_index));
				if (_data == null)
					throw new IOException("Cannot create DataInputStream");
				index_size = endianess.applyOn(_data.readInt());
				this.index = new int[index_size];

				for (int i=0; i<index_size; i++)
				{
					this.index[i] = endianess.applyOn(_data.readInt());
				}
			}else
			{
				index_size = 0;
				index = new int[0];
			}
 		}catch (IOException e)
 		{
 			throw new BadCubeReportLayoutException("Cannot create sparse index: " + e.getMessage());
 		}
	}





	protected void printOwnIndex()
	{

		System.out.println(" Index size    : " + index_size);
		System.out.print  (" Index content : ");
		for (int id : index)
		{
			System.out.print(id+" ");
		}
		System.out.println();
	}



	public int getPosition(int cid, int tid) throws IDOutOfBoundsException, MissingRowException
	{
		if (cid <0 || cid>=number_of_cnodes)
			throw new CIDPairOutOfBoundsException(cid, number_of_cnodes);
		if (tid <0 || tid>=number_of_cnodes)
			throw new TIDPairOutOfBoundsException(tid, number_of_threads);

		int place = Arrays.binarySearch(index, cid);
		if (place <0)
			throw new MissingRowException(cid);


		return place*number_of_threads + tid;
	}




}
