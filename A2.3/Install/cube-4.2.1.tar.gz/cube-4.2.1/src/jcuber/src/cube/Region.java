/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube;
import java.lang.*;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public class Region extends NamedVertex
{
    protected int startln;
    protected int endln;
    protected String mod;
    protected String source;
    protected String description;


//     @SuppressWarnings("unchecked")	
    public Region() { super("Region"); }
    public Region(int _id, String _name, int _startln, int _endln, String _mod, String _source, String descr) { super(_id, _name);  source=_source; startln = _startln; endln = _endln; descr = description; }


    public String getSource()
    {
	return source;
    }

    public String getMod()
    {
	return mod;
    }

    public int  getStartln()
    {
	return startln;
    }

    public int getEndln()
    {
	return endln;
    }
    public String getDescription()
    {
	return description;
    }

}
