/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.datalayout.index;
import scalasca.cubex.cube.errors.*;
import java.lang.*;
import scalasca.cubex.cube.services.transformation.*;
import java.util.*;
import java.io.*;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public abstract class Index
{
	//     @SuppressWarnings("unchecked")
	protected int number_of_cnodes;
	protected int number_of_threads;
	protected IndexType indexType;
	protected Endianess endianess;

	public Index(int ncid, int ntid, Endianess _end)
	{
		number_of_cnodes = ncid;
		number_of_threads = ntid;
		endianess = _end;
		indexType = IndexType.NONE;
	}


	public abstract int getPosition(int cid, int tid) throws IDOutOfBoundsException, MissingRowException;
	


	public void print()
	{
		System.out.println("======== Index  ============");
		System.out.println(" IndexType: " + indexType.toString());
		System.out.println(" Cnodes : " + number_of_cnodes);
		System.out.println(" Threads: " + number_of_threads);
		System.out.println("--------- index -------------");
		printOwnIndex();
		System.out.println("============================");
	}



	protected void printOwnIndex() {} ;


}
