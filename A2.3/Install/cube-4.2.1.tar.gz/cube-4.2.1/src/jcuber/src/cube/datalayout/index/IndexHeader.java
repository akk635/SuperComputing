/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.datalayout.index;
import scalasca.cubex.cube.errors.*;
import scalasca.cubex.cube.services.transformation.*;
import java.lang.*;
import java.util.*;
import java.io.*;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public class IndexHeader
{

	private String Marker = "CUBEX.INDEX";
	private int one;
	private short version;
	private IndexType index_type;
	private Endianess endianess;
	private byte[] raw_data;

	//     @SuppressWarnings("unchecked")
	public IndexHeader( byte[] bytes ) throws BadCubeReportLayoutException
	{
		try
		{
			DataInputStream data = new DataInputStream( new ByteArrayInputStream(bytes));
			String _marker = new String(bytes,0, Marker.length());

			if ( ! _marker.equalsIgnoreCase(Marker))
				throw new BadCubeReportLayoutException("Index header doesn't start with correct marker. Expect " + Marker + " but it starts with "+ _marker);
			data.skip(Marker.length()); // shift to the first byte after marker
			one = data.readInt();

			if (one == 1)
				endianess = new NOP();
			else
				endianess = new SwapBytes();

			version = endianess.applyOn(data.readShort());
			index_type = IndexType.getIndexType(data.readByte());
			raw_data = new byte[bytes.length - size()];

			System.arraycopy(bytes, size(), raw_data, 0, raw_data.length );
			data.close();
		}catch(IOException e)
		{
			throw new BadCubeReportLayoutException("Reading error of index header: " + e.getMessage());
		}
	}


	public int size()
	{
		return Marker.length() + 4+2+1;
	}

	public Endianess getEndianess()
	{
		return endianess;
	}


	public Index getIndex(int number_of_cnodes, int number_of_threads) throws BadCubeReportLayoutException
	{
		switch (index_type)
		{
			case SPARSE:
				return new SparseIndex(number_of_cnodes, number_of_threads, raw_data, endianess);
			case DENSE:
				return new DenseIndex(number_of_cnodes, number_of_threads, endianess);
			default:
				throw new UnknownIndexTypeException(index_type );
		}
	}





	public void print()
	{
		System.out.println("======== Header ============");
		System.out.println(" Version: " + version);
		System.out.println(" Endianess: " + one + " "+ ((one == 1)? "same" : "different" ));
		System.out.println(" IndexType: " + index_type.toString());
		System.out.println("============================");
	}



}
