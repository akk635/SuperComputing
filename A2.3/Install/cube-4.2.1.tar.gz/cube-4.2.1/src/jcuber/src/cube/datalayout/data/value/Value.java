/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/
/**
* Implements a list of supported data types.
*/
package scalasca.cubex.cube.datalayout.data.value;
import scalasca.cubex.cube.errors.*;
import scalasca.cubex.cube.services.transformation.*;

import java.lang.*;
import java.util.*;
import java.io.*;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public abstract class Value
{
	public Value() {};

	public String getName()
		{
			return "_no_value_";
		}


	public abstract int size();



	public byte[] correctEndianess(byte[] bytes, Endianess endianess) throws Exception
	{

/*		byte[] new_bytes = new byte[bytes.length];
*/
		DataInputStream in = new DataInputStream( new ByteArrayInputStream(bytes));
		ByteArrayOutputStream b_out = new ByteArrayOutputStream();
		DataOutputStream out = new DataOutputStream(b_out);
		try
		{
			while (in.available()>0)
			{
				correctEndianess(endianess, in, out);
			}
			return b_out.toByteArray();
		}catch (IOException e)
		{
			throw new Exception("Cannot perform endianess correction: " + e.toString());
		}
	}


	public abstract void correctEndianess(Endianess _end, DataInputStream in, DataOutputStream out)  throws IOException;
	public abstract Value clone(); ///> makes copy of itself with "0" value
	public abstract Value copy(); ///> makes copy of itself with "same value
	public abstract Value clone(DataInputStream in)  throws IOException; ///> makes copy of itself with value comming from DataStream as row of bytes
 	public abstract String toString(); // returns string representation of the value.
	public abstract double getDouble(); // returns double representation of the value

	public abstract void setValue(String str); // initialization from String
	public abstract void setValue(byte v); // initialization from byte
	public abstract void setValue(short v); // initialization from short
	public abstract void setValue(int v); // initialization from integer
	public abstract void setValue(long v); // initialization from long
	public abstract void setValue(double v); // initialization from double

	public abstract void addValue(Value v);  // performs operation "+"
	public abstract void subtractValue(Value v);  // performs operation "-", if defined







	static public Value getValue(ValueType valueType) throws UnknownValueTypeException
	{
		switch (valueType)
		{
			case UINT8:
				return new CubeUint8();
			case INT8:
				return new CubeInt8();
			case UINT16:
				return new CubeUint16();
			case INT16:
				return new CubeInt16();
			case UINT32:
				return new CubeUint32();
			case INT32:
				return new CubeInt32();
			case UINT64:
				return new CubeUint64();
			case INT64:
				return new CubeInt64();
			case DOUBLE:
				return new CubeDouble();
			case MINDOUBLE:
				return new CubeMinDouble();
			case MAXDOUBLE:
				return new CubeMaxDouble();
			case TAU_ATOMIC_METRIC:
				return new CubeTauAtomicMetric();
			case COMPLEX:
				return new CubeComplex();
			default:
				throw new UnknownValueTypeException(valueType);
				
		}
	}


}
