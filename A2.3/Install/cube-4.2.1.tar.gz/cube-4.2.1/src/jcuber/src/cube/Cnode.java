/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube;
import java.lang.*;
import java.util.HashMap;
import java.util.Map;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public class Cnode extends NamedVertex
{
	protected Region region;
	protected Map<String, String> str_parameters = new HashMap<String, String>();
	protected Map<String, Long> num_parameters = new HashMap<String, Long>();

	//     @SuppressWarnings("unchecked")
	public Cnode() { super("Region"); }
	public Cnode(int _id, Region _region, Cnode _parent)
	{
		super(_id, (_region!=null)?_region.getName():"", _parent);
		region = _region;
	}


	public Region getRegion()
	{
		return region;
	}


	public void add_str_parameter(String key, String value)
	{
		str_parameters.put(key, value);
	}

	public void add_num_parameter(String key, long value)
	{
		num_parameters.put(key, new Long(value));
	}



	public String get_str_parameter(String key)
	{
		return str_parameters.get(key);
	}


	public long get_num_parameter(String key)
	{
		return num_parameters.get(key).longValue();
	}


	public Map <String, String> get_str_parameters()
	{
		return str_parameters;
	}



	public Map <String, Long> get_num_parameters()
	{
		return num_parameters;
	}


	public void add_str_parameters(Map <String, String> _map)
	{
		str_parameters.putAll(_map);
	}



	public void add_num_parameters(Map <String, Long> _map)
	{
		num_parameters.putAll(_map);
	}



}
