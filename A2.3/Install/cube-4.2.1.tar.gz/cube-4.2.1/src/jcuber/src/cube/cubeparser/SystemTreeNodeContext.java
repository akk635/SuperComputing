 /****************************************************************************
 **  CUBE        http://www.scalasca.org/                                   **
 **  SCALASCA    http://www.scalasca.org/                                   **
 *****************************************************************************
 **  Copyright (c) 2011-2011                                                **
 **  Forschungszentrum Juelich, Juelich Supercomputing Centre               **
 **                                                                         **
 **  See the file COPYRIGHT in the package base directory for details       **
 ****************************************************************************/

package scalasca.cubex.cube.cubeparser;
import scalasca.cubex.cube.*;
import java.util.HashMap;
import java.util.Map;

public class SystemTreeNodeContext
{
	public int id= -1;
	public String name = "";
	public String description = "";
	public String stn_class = "";
	public SystemTreeNode stn = null;
    public Map<String, String> attributes = new HashMap<String, String> ();

	SystemTreeNodeContext() {};

	public String toString()
	{

		return
			"ID: " + id + "\t" +
			"Name: " + name  + "\t" +
			"Description: " + description + "\t" + 
			"Class: " + stn_class + "\t"
			;
	}
}