/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.cubeparser;
import scalasca.cubex.cube.*;
import java.util.Map;
import java.util.HashMap;
import java.lang.String;
import java.lang.Long;

public class CnodeContext
{
	public int id= -1;
	public int region_id= -1;
	public Cnode parent = null;
	public Cnode cnode = null;
	public Map<String, String> str_parameters = new HashMap<String, String> ();
	public Map<String, Long> num_parameters = new HashMap<String, Long> ();
    public Map<String, String> attributes = new HashMap<String, String> ();
	CnodeContext() {};

	public String toString()
	{

		String _return = 
			"ID:" + id + "\t" +
			"Region ID:" + region_id + "\t" +
			"parent:" + parent + "\t" +
			"cnode:" + cnode + "\n"
			;

		for (String key : str_parameters.keySet())
		{
			_return +=
				key + " -> " + str_parameters.get(key) + "\n";
	
		}
		for (String key : num_parameters.keySet())
		{
			_return +=
				key + " -> " + num_parameters.get(key) + "\n";
		}

		return _return;
	}
}