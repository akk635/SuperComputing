/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.datalayout.data.value;
import scalasca.cubex.cube.errors.*;
import scalasca.cubex.cube.services.transformation.*;
import java.lang.*;
import java.util.*;
import java.io.*;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public class CubeDouble extends Value
{

	protected double value;

	public CubeDouble() { value = 0;};
	public CubeDouble(double _v) { value = _v;};

	public String getName()
		{
			return "DOUBLE";
		}

	public String toString()
	{
		return Double.valueOf(value).toString();
	}


	public int size() { return 8; } ;

	public void correctEndianess(Endianess _end, DataInputStream in, DataOutputStream out)  throws IOException
		{
			double _in  =  in.readDouble();
			double __in = _end.applyOn(_in);
			out.writeDouble(__in);
		}

	public Value clone()
	{
		return new CubeDouble();
	}
	public Value copy()
	{
		return new CubeDouble(value);
	}
	public Value clone(DataInputStream in)  throws IOException
	{
		return new CubeDouble(in.readDouble());
	}


 // ------------------- setXXX methods ------------------
	public  void setValue(String v) // initialization from String
	{
		value = Double.parseDouble(v);
	}
	public  void setValue(byte v) // initialization from byte
	{
		value = (double)v;
	}

	public  void setValue(short v) // initialization from short
	{
		value = (double)v;
	}
	public  void setValue(int v) // initialization from integer
	{
		value = (double)(v);
	}
	public  void setValue(long v) // initialization from long
	{
		value = (double)v;
	}
	public  void setValue(double v) // initialization from double
	{
		value = v;
	}


 // ------------------- getXXX methods ------------------
	public double getDouble()
	{
		return value;
	}

 // -------------------- lagebra -------------------------
	public void addValue(Value v)  // performs operation "+"
	{
		CubeDouble _v = (CubeDouble)v;
		value += _v.value;	
	}

	public void subtractValue(Value v)  // performs operation "-", if defined
	{
		CubeDouble _v = (CubeDouble)v;
		value -= _v.value;
	}



}
