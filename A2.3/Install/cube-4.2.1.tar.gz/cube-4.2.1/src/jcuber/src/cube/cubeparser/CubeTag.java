/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.cubeparser;

public enum CubeTag
{
UNKNOWN,
CUBE,
	ATTR,
	DOC,
		MIRRORS,
			MURL,
	METRICS,
		METRIC,
			UNIQ_NAME,
			DISP_NAME,
			DTYPE,
			UOM,
			METURL,
			METDESCR,
			METRATTR,

	PROGRAM,
		REGION,
			RNAME,
			RURL,
 			RDESCR,
 			RATTR,
		CNODE,
			CNODE_PARAMETER,
			CNODE_ATTR,

	SYSTEM,
		SYSTEMTREENODE,
 			STNNAME,
 			STNDESCR,
 			STNCLASS, 	
 			STNATTR,
			LOCATIONGROUP,
			      LGNAME,
			      LGRANK,
			      LGTYPE,		
			      LGATTR,
			      LOCATION,
				      LNAME,
				      LRANK, 
				      LTYPE, 
				      LATTR,
 		TOPOLOGIES,
			CART,
				DIM,
				COORD,
	SEVERITY,
		MATRIX,
			ROW
}





