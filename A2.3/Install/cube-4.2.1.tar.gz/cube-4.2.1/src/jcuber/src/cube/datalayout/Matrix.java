/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.datalayout;
import scalasca.cubex.cube.datalayout.data.*;
import scalasca.cubex.cube.datalayout.index.*;
import scalasca.cubex.cube.datalayout.data.value.*;
import scalasca.cubex.cube.errors.*;
import java.lang.*;
import java.io.*;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public class Matrix
{

	private Value [][] matrix;
	private Value value ;
	private int ncid;
	private int ntid;


	public Matrix(Value _val, int number_of_cnodes, int number_of_threads)
	{
		value = _val;
		ncid = number_of_cnodes;
		ntid = number_of_threads;
		matrix = new Value[ncid][];

		for (int i=0; i<ncid; i++)
		{
			matrix[i] = new Value[ntid];
			for (int j=0; j<ntid; j++)
			{
				matrix[i][j] = null;
			}
		}
	};


	public Matrix(DataRows source, Index index,  int number_of_cnodes, int number_of_threads)
	{
		value = source.getValue();
		ncid = number_of_cnodes;
		ntid = number_of_threads;
		matrix = new Value[ncid][];

		for (int i=0; i<ncid; i++)
		{
			try
			{
// 				matrix[i] = null;
				int position= index.getPosition(i, 0); // get position of the first element in row i
				matrix[i] = source.getRow(position, ntid);
			}catch (Exception e)
			{
				matrix[i] = null;
			}
		}
	};

	public void print()
	{
		System.out.println("======== Matrix "+ncid + "x" + ntid +" ============");
		for (Value[] row : matrix )
		{
			if (row != null)
			{
				for (Value value : row )
				{

					System.out.print( value.toString() + " ");
				}
			}else
			System.out.print("----------");
		
			System.out.println();
		}
		System.out.println("======== END Matrix ================================");
	}


	public Value getValue(int cid, int tid)
	{
		Value _v= null;
		if (matrix[cid] != null)
			_v = matrix[cid][tid];

		if (_v != null)
			return _v;
		return value;
	}

	public void setValue(int cid, int tid, String val)
	{
		Value _v= value.clone();
		_v.setValue(val);
		if (matrix[cid] != null)
			matrix[cid][tid] = _v;
	}

}
