/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.cubeparser;
import scalasca.cubex.cube.*;
import java.util.HashMap;
import java.util.Map;

public class MetricContext
{
	public int id= -1;
	public String uniq_name= "";
	public String disp_name= "";
	public String dtype= "";
	public String uom= "";
	public String url= "";
	public String descr= "";
	public MetricType metricType = MetricType.EXCLUSIVE;
	public Metric parent = null;
	public Metric metric = null;
    public Map<String, String> attributes = new HashMap<String, String> ();

	MetricContext() {};

	public String toString()
	{

		return
			"ID:" + id + "\t" +
			"Uniq Name:" + uniq_name + "\t" +
			"Disp Name:" + disp_name + "\t" +
			"Dtype:" + dtype + "\t" +
			"UOM:" + uom + "\t" +
			"url:" + url + "\t" +
			"description:" + descr + "\t" + 
			"metricType:" + metricType.toString() +  "\t" + 
			"parent:" + parent + "\t" +
			"metric:" + metric + "\t"
			;
	}
}