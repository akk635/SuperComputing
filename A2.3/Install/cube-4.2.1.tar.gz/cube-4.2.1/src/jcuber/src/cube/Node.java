/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube;
import java.lang.*;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public class Node extends SystemTreeNode
{

//     @SuppressWarnings("unchecked")
	public Node() {super(); }
	public Node(int _id, Machine parent) {super(_id, parent); }
	public Node(int _id, String _name, Machine parent) {super(_id, _name, "node", parent); }
	public Node(int _id, String _name, String _description, Machine parent) {super(_id, _name, _description, "node", parent); }
	public Node(SystemTreeNode _clone, SystemTreeNode _parent) 
	{
	  super( _clone.getId(),
		 _clone.getName(),
		 _clone.getDescription(),
		 "node",
		_parent
	    );
	  for ( Vertex _process: _clone.getAllGroups())
	  {
	    children.add( new Process((LocationGroup)_process, this) );
	  }
	}
}
