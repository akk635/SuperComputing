/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.datalayout.data.value;
import scalasca.cubex.cube.errors.*;
import scalasca.cubex.cube.services.transformation.*;
import java.lang.*;
import java.util.*;
import java.io.*;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public class CubeComplex extends Value
{
	protected CubeDouble re;
	protected CubeDouble im;

	public CubeComplex() { re = new CubeDouble(); im = new CubeDouble(); };
	public CubeComplex(double _re, double _im) { re = new CubeDouble(_re); im = new CubeDouble(_im); };

	public String getName()
	{
		return "Complex";
	}


	public String toString()
	{
		return re.toString() + " + i"+im.toString();
	}

	public int size()
		{
			return -1;
		} ;

	public void correctEndianess(Endianess _end, DataInputStream in, DataOutputStream out)  throws IOException
		{
			re.correctEndianess(_end, in, out);
			im.correctEndianess(_end, in, out);
		}

	public Value clone()
	{
		return new CubeComplex();
	}
	public Value copy()
	{
		return new CubeComplex(re.getDouble(), im.getDouble());
	}
	public Value clone(DataInputStream in)  throws IOException
	{
		double _re = in.readDouble();
		double _im = in.readDouble();
		return new CubeComplex(_re, _im);
	}

 // ------------------- setXXX methods ------------------
	public  void setValue(String str) // initialization from String
	{
// 		value = 0; // here is parsing needed
	}
	public  void setValue(byte v) // initialization from byte
	{
// 		value = 0;
	}

	public  void setValue(short v) // initialization from short
	{
// 		value = Short(value).byteValue();
	}
	public  void setValue(int v) // initialization from integer
	{
// 		value = Integer(value).byteValue();
	}
	public  void setValue(long v) // initialization from long
	{
// 		value = Long(value).byteValue();
	}
	public  void setValue(double v) // initialization from double
	{
// 		value = Double(value).byteValue();
	}


 // ------------------- getXXX methods ------------------
	public double getDouble() 
	{
		return re.getDouble(); // as many-values value it should be configurable
	}

	public double getRe()
	{
		return re.getDouble(); // as many-values value it should be configurable
	}
	public double getIm()
	{
		return im.getDouble(); // as many-values value it should be configurable
	}



 // -------------------- lagebra -------------------------
	public void addValue(Value v)  // performs operation "+"
	{
		CubeComplex _v = (CubeComplex)v;
		re.addValue(_v.re);
		im.addValue(_v.im);
	}

	public void subtractValue(Value v)  // performs operation "-", if defined
	{
		CubeComplex _v = (CubeComplex)v;
		re.subtractValue(_v.re);
		im.subtractValue(_v.im);
	}


}
