/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.cubeparser;
public enum CubeRawTag
{
UNKNOWN,
CUBE,
	ATTR,
	DOC,
		MIRRORS,
			MURL,
	METRICS,
		METRIC,
			UNIQ_NAME,
			DISP_NAME,
			DTYPE,
			UOM,
			URL,
			DESCR,

	PROGRAM,
		REGION,
			NAME,
//			URL,
// 			DESCR,
		CNODE,
			CNODE_PARAMETER,

	SYSTEM,
		SYSTEMTREENODE,
// 			NAME,
// 			DESCR,
			CLASS,
			LOCATIONGROUP,
// 				NAME,
// 				RANK,
				TYPE,
				LOCATION,
// 					NAME,
					RANK,
// 					TYPE,
		TOPOLOGIES,
			CART,
				DIM,
				COORD,
	SEVERITY,
		MATRIX,
			ROW
}

