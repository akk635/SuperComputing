/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.datalayout.data.value;
import scalasca.cubex.cube.errors.*;
import scalasca.cubex.cube.services.transformation.*;
import java.lang.*;
import java.util.*;
import java.io.*;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public class CubeInt8 extends Value
{

	protected byte value;

	public CubeInt8() { value = 0; };
	public CubeInt8( byte _v) { value = _v; };

	public String getName()
	{
		return "INT8";
	}


	public String toString()
	{
		return Byte.valueOf(value).toString();
	}

	public int size() { return 1; } ;

	public void correctEndianess(Endianess _end, DataInputStream in, DataOutputStream out)  throws IOException
	{
		byte _in  = in.readByte();
		byte __in = _end.applyOn(_in);
		out.writeByte(__in);
	}



	public Value clone()
	{
		return new CubeInt8();
	}
	public Value copy()
	{
		return new CubeInt8(value);
	}

	public Value clone(DataInputStream in)  throws IOException
	{
		return new CubeInt8(in.readByte());
	}
 // ------------------- setXXX methods ------------------
	public  void setValue(String v) // initialization from String
	{
		value = Byte.parseByte(v);
	}
	public  void setValue(byte v) // initialization from byte
	{
		value = (byte)v;
	}

	public  void setValue(short v) // initialization from short
	{
		value = (byte)v;
	}
	public  void setValue(int v) // initialization from integer
	{
		value = (byte)v;
	}
	public  void setValue(long v) // initialization from long
	{
		value = (byte)v;
	}
	public  void setValue(double v) // initialization from double
	{
		value = (byte)v;
	}


 // ------------------- getXXX methods ------------------
	public double getDouble()
	{
		return Byte.valueOf(value).doubleValue();
	}


 // -------------------- lagebra -------------------------
	public void addValue(Value v)  // performs operation "+"
	{
		CubeInt8 _v = (CubeInt8)v;
		value += _v.value;
	}

	public void subtractValue(Value v)  // performs operation "-", if defined
	{
		CubeInt8 _v = (CubeInt8)v;
		value -= _v.value;
	}




}
