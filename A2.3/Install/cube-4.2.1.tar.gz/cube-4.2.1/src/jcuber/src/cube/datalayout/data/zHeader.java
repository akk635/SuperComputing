/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 2011-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2011-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

package scalasca.cubex.cube.datalayout.data;
import scalasca.cubex.cube.datalayout.data.value.*;
import scalasca.cubex.cube.errors.*;
import scalasca.cubex.cube.services.transformation.*;
import java.lang.*;
import java.util.*;
import java.io.*;
/*
 * Class , delivers file structure of CubeX
 * 
 */
public class zHeader
{
	private ArrayList<zTriplet> triplets = new ArrayList<zTriplet>();
	public zHeader(DataInputStream in, Endianess _endianess) throws IOException
	{
		long number_of_rows = _endianess.applyOn(in.readLong());
		for (int i=0; i< number_of_rows; i++)
		{
			long start_uncompressed = _endianess.applyOn(in.readLong());
			long start_compressed   = _endianess.applyOn(in.readLong());
			long size_compressed    = _endianess.applyOn(in.readLong());
			triplets.add(new zTriplet(start_uncompressed, start_compressed, size_compressed ));
		}
	};

	public void print()
		{
			System.out.println("======== List Of zTriples ============");
			System.out.println("======== Sze : "+ triplets.size() + " ============");

			for (zTriplet triplet : triplets)
			{
				System.out.print(triplet.toString());
			}
			System.out.println();
		}

	public ArrayList<zTriplet> getTriplets()
	{
		return triplets;
	}

}
