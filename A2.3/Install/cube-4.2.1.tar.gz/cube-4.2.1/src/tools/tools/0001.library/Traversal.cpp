/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

#include "Traversal.h"

#include "CnodeSubForest.h"

using namespace cube;

Traversal::Traversal()
    : traversal_stopped( false )
{
}

Traversal::~Traversal()
{
}

bool
Traversal::is_constant()
const
{
    return false;
}

void
Traversal::run( CnodeSubForest* forest )
{
    forest->traverse( this );
}

void
Traversal::initialize( CnodeSubForest* forest )
{
    traversal_stopped = false;
}

void
Traversal::initialize_tree( CnodeSubTree* tree )
{
}

void
Traversal::node_handler( CnodeSubTree* node )
{
}

void
Traversal::finalize_tree( CnodeSubTree* tree )
{
}

void
Traversal::finalize( CnodeSubForest* forest )
{
}

void
Traversal::stop_traversing()
{
    traversal_stopped = true;
}

void
Traversal::unstop_traversing()
{
    traversal_stopped = false;
}
