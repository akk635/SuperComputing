/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

#include "MdAggrCube.h"

#include "CnodeSubForest.h"
#include "AggregatedMetric.h"
#include "VisitorsMetric.h"
#include "CnodeMetric.h"
#include "PrintableCCnode.h"


#include "CCnode.h"
#include "CRegion.h"

#include "Cube.h"
#include "AggrCube.h"
#include "CubeError.h"
#include "CubeRegion.h"
#include "CubeMachine.h"
#include "CubeNode.h"
#include "CubeProcess.h"
#include "CubeThread.h"
#include "CubeCartesian.h"

using namespace cube;
using namespace std;

MdAggrCube::MdAggrCube()
    : AggrCube()
{
}

MdAggrCube::MdAggrCube( Cube& copy,
                        int   cache_size )
    : AggrCube()
{
    map<Metric*, Metric* >  metric_map_copy2new;
    map<Region*, Region* >  region_map_copy2new;
    map<Cnode*,  Cnode*  >  cnode_map_copy2new;
    map<Machine*, Machine*> machine_map_copy2new;
    map<Node*,   Node*   >  node_map_copy2new;
    map<Process*, Process*> process_map_copy2new;
    map<Thread*, Thread* >  thread_map_copy2new;

    // Copy metrics vector.
    for ( vector<Metric*>::const_iterator m = copy.get_metv().begin(); m != copy.get_metv().end(); ++m )
    {
        metric_map_copy2new[ *m ] =
            def_met( ( *m )->get_disp_name(), ( *m )->get_uniq_name(), ( *m )->get_dtype(),
                     ( *m )->get_uom(), ( *m )->get_val(), ( *m )->get_url(), ( *m )->get_descr(),
                     ( ( *m )->get_parent() == NULL ? NULL : metric_map_copy2new[ ( *m )->get_parent() ] ),
                     ( *m )->get_id() );
    }
    // Copy region vector.
    for ( vector<Region*>::const_iterator r = copy.get_regv().begin(); r != copy.get_regv().end(); ++r )
    {
        region_map_copy2new[ *r ] =
            def_region( ( *r )->get_name(), ( *r )->get_begn_ln(), ( *r )->get_end_ln(),
                        ( *r )->get_url(), ( *r )->get_descr(), ( *r )->get_mod(), ( *r )->get_id(),
                        cache_size );
    }
    // Copy callnode vector
    for ( vector<Cnode*>::const_iterator c = copy.get_cnodev().begin(); c != copy.get_cnodev().end(); ++c )
    {
        cnode_map_copy2new[ *c ] =
            def_cnode( region_map_copy2new[ ( *c )->get_callee() ], ( *c )->get_mod(),
                       ( *c )->get_line(),
                       ( ( *c )->get_parent() == NULL ? NULL : cnode_map_copy2new[ ( *c )->get_parent() ] ),
                       ( *c )->get_id(), cache_size );
    }
    // Copy machines vector
    for ( vector<Machine*>::const_iterator m = copy.get_machv().begin(); m != copy.get_machv().end(); ++m )
    {
        machine_map_copy2new[ *m ] =
            def_mach( ( *m )->get_name(), ( *m )->get_desc(), ( *m )->get_id() );
    }
    // Copy nodes vector
    for ( vector<Node*>::const_iterator n = copy.get_nodev().begin(); n != copy.get_nodev().end(); ++n )
    {
        node_map_copy2new[ *n ] =
            def_node( ( *n )->get_name(), machine_map_copy2new[ ( *n )->get_parent() ],
                      ( *n )->get_id() );
    }
    // Copy process vector
    for ( vector<Process*>::const_iterator p = copy.get_procv().begin(); p != copy.get_procv().end(); ++p )
    {
        process_map_copy2new[ *p ] =
            def_proc( ( *p )->get_name(), ( *p )->get_rank(),
                      node_map_copy2new[ ( *p )->get_parent() ], ( *p )->get_id() );
    }
    // Copy thread vector
    for ( vector<Thread*>::const_iterator t = copy.get_thrdv().begin(); t != copy.get_thrdv().end(); ++t )
    {
        thread_map_copy2new[ *t ] =
            def_thrd( ( *t )->get_name(), ( *t )->get_rank(),
                      process_map_copy2new[ ( *t )->get_parent() ], ( *t )->get_id() );
    }
    // Copy the cartesian vector.
    for ( vector<Cartesian*>::const_iterator c = copy.get_cartv().begin(); c != copy.get_cartv().end(); ++c )
    {
        def_cart( ( *c )->get_ndims(), ( *c )->get_dimv(), ( *c )->get_periodv() );
    }
    // Copy severity data
    for ( vector<Metric*>::const_iterator m = copy.get_metv().begin(); m != copy.get_metv().end(); ++m )
    {
        for ( vector<Cnode*>::const_iterator c = copy.get_cnodev().begin(); c != copy.get_cnodev().end(); ++c )
        {
            for ( vector<Thread*>::const_iterator t = copy.get_thrdv().begin(); t != copy.get_thrdv().end(); ++t )
            {
                set_sev( metric_map_copy2new[ *m ], cnode_map_copy2new[ *c ], thread_map_copy2new[ *t ],
                         copy.get_sev( *m, *c, *t ) );
            }
        }
    }
    original_address = &copy;
}

MdAggrCube::~MdAggrCube()
{
    for ( map< string, CnodeMetric* >::iterator it = cnode_metrics.begin();
          it != cnode_metrics.end(); ++it )
    {
        delete it->second;
    }
}

CnodeMetric*
MdAggrCube::add_cnode_metric( CnodeMetric* metric )
{
    CnodeMetric*                        already_there = NULL;
    metric->register_with( this );
    string                              metric_str = metric->stringify();
    map<string, CnodeMetric*>::iterator it         = cnode_metrics.find( metric_str );
    if ( it != cnode_metrics.end() )
    {
        already_there = it->second;
    }

    if ( already_there == NULL )
    {
        cnode_metrics.insert( pair<string, CnodeMetric*>(
                                  metric_str, metric ) );
        return metric;
    }
    else
    {
        delete metric;
        return already_there;
    }
}

CnodeMetric*
MdAggrCube::get_cnode_metric( std::string metric_str )
{
    map<string, CnodeMetric*>::iterator it = cnode_metrics.find( metric_str );
    if ( it == cnode_metrics.end() )
    {
        string::size_type pos = 0;
        if ( ( pos = metric_str.find( "@" ) ) != string::npos )
        {
            string handler = metric_str.substr( 0, pos );
            if ( handler == "basic" )
            {
                return add_cnode_metric(
                           new AggregatedMetric( metric_str ) );
            }
            else if ( handler == "visitors" )
            {
                return add_cnode_metric(
                           new VisitorsMetric( metric_str ) );
            }
            else
            {
                throw RuntimeError( "Do not know how to handle type " + handler );
            }
        }

        return add_cnode_metric( new AggregatedMetric( metric_str ) );
    }
    else
    {
        return it->second;
    }
}

CnodeSubForest*
MdAggrCube::get_forest()
{
    return new CnodeSubForest( this );
}

CubeMapping*
MdAggrCube::get_cube_mapping( unsigned int id )
const
{
    if ( id >= get_number_of_cubes() )
    {
        throw RuntimeError( "Invalid Mapping requested." );
    }
    return NULL;
}

unsigned int
MdAggrCube::get_number_of_cubes()
const
{
    return 1;
}

Region*
MdAggrCube::def_region( const string& name,
                        long          begln,
                        long          endln,
                        const string& url,
                        const string& descr,
                        const string& mod,
                        uint32_t      id,
                        int           cache_size )
{
    Region* reg = new CRegion( name, begln, endln, url, descr, mod, id,
                               cache_size );
    if ( regv.size() <= id )
    {
        regv.resize( id + 1 );
    }
    else if ( regv[ id ] )
    {
        throw RuntimeError( "Region with this ID exists" );
    }

    regv[ id ]    = reg;
    cur_region_id = regv.size();

    return reg;
}

Cnode*
MdAggrCube::def_cnode( Region*       callee,
                       const string& mod,
                       int           line,
                       Cnode*        parent,
                       uint32_t      id,
                       int           cache_size )
{
    Cnode* cnode = new PrintableCCnode( callee, mod, line, parent, id,
                                        cache_size );
    if ( !parent )
    {
        root_cnodev.push_back( cnode );
    }

    callee->add_cnode( cnode );
    if ( cnodev.size() <= id )
    {
        cnodev.resize( id + 1 );
        fullcnodev.resize( id + 1 );
    }
    else if ( cnodev[ id ] )
    {
        throw RuntimeError( "Cnode with this ID exists" );
    }

    cnodev[ id ]     = cnode;
    fullcnodev[ id ] = cnode;
    cur_cnode_id     = fullcnodev.size();

    return cnode;
}
