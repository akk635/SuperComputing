/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

#ifndef __CUBE_STAT_PRETTY_PLAIN_PRINTER_H
#define __CUBE_STAT_PRETTY_PLAIN_PRINTER_H


#include <vector>

#include "AggrCube.h"
#include "CubeMetric.h"
#include "CubeCnode.h"

#include "PlainPrinter.h"

using namespace std;



/*-------------------------------------------------------------------------*/
/**
 * @class   PrettyPlainPrinter
 * @brief   Class for printing pretty human readable tables
 */
/*-------------------------------------------------------------------------*/
class PrettyPlainPrinter : public PlainPrinter
{
public:
    /// @name Constructor & destructor
    /// @{
    PrettyPlainPrinter( AggrCube*             cubeObj,
                        vector<string> const &metNames,
                        vector<string> const &cnodeNames );
    virtual
    ~PrettyPlainPrinter()
    {
    }
    /// @}
    /// @name Print methods used by clients
    /// @{
    virtual void
    PrintLegend() const;
    virtual void
    GatherAndPrint( Cnode* cnode ) const;

    /// @}
private:
    AggrCube*   cubeObject;
    size_t      maxCnodeNameLength;
    vector<int> columnWidthes;

    /// Private helper method for gathering and printing the data
    /// (without names)
    void
    PrintValues( Cnode*   cnode,
                 inclmode cnodeMode = INCL ) const;
};

/**
 * Creates a new PrettyPlainPrinter instance from the given CUBE object and the
 * names of the requested metrics and cnodes.
 *
 * @param cubeObj The CUBE object used to parse the CUBE file to be analyzed.
 * @param metNames A vector containing all metric names for which data is to be
 * gathered and printed.
 * @param cnodeNames A vector containing all region names for which data is to
 * be gathered and printed.
 */
PrettyPlainPrinter::PrettyPlainPrinter( AggrCube*             cubeObj,
                                        vector<string> const &metNames,
                                        vector<string> const &cnodeNames )
    : PlainPrinter( cubeObj, metNames, cnodeNames ), cubeObject( cubeObj ),
      maxCnodeNameLength( strlen( "routine" ) )
{
    //Calculate the width of the cnode name column
    vector<Cnode*> const &_requestedCnodeVec = GetRequestedCnodes();
    for ( vector<Cnode*>::const_iterator it = _requestedCnodeVec.begin();
          it != _requestedCnodeVec.end(); ++it )
    {
        maxCnodeNameLength = max( maxCnodeNameLength,
                                  ( *it )->get_callee()->get_name().length() + strlen( "INCL()" ) );
        for ( unsigned int i = 0; i < ( *it )->num_children(); ++i )
        {
            maxCnodeNameLength = max( maxCnodeNameLength,
                                      ( *it )->get_child( i )->get_callee()->get_name().length() + 2 );
        }
    }
    ++maxCnodeNameLength;

    //Calculate column widthes for the different metric columns
    for ( vector<string>::const_iterator it = metNames.begin();
          it != metNames.end(); ++it )
    {
        columnWidthes.push_back( max<size_t>( it->length() + 1, 13 ) );
    }
}



/**
 * Prints the legend for the data using the column widthes and the width for
 * the cnode name column calculated in the constructor
 */
void
PrettyPlainPrinter::PrintLegend() const
{
    cout << setw( maxCnodeNameLength ) << left << "Routine";
    vector<Metric*> const &_requestedMetricVec = GetRequestedMetrics();
    for ( size_t i = 0; i < _requestedMetricVec.size(); ++i )
    {
        cout << setw( columnWidthes[ i ] ) << right
             << _requestedMetricVec[ i ]->get_uniq_name();
    }
    cout << endl;
    cout << fixed << showpoint << setprecision( 6 );
}



/**
 * Method for gathering and printing data about the severity of certain metrics
 * with respect to given cnodes and their children. This method gathers and
 * prints data about the requested metrics for the given Cnode cnode and all
 * cnodes called by cnode
 *
 * @param cnode The data is gathered for this cnode and all it's child cnodes.
 */
void
PrettyPlainPrinter::GatherAndPrint( Cnode* cnode ) const
{
    //First print data for the given cnode inclusively
    //and exclusively its children
    inclmode modes[] = { INCL, EXCL };
    for ( size_t i = 0; i < sizeof( modes ) / sizeof( inclmode ); ++i )
    {
        cout << setw( maxCnodeNameLength ) << left;
        if ( modes[ i ] == INCL )
        {
            cout << ( "INCL(" + cnode->get_callee()->get_name() + ")" );
        }
        else
        {
            cout << ( "  EXCL(" + cnode->get_callee()->get_name() + ")" );
        }
        PrintValues( cnode, modes[ i ] );
    }

    //Print data for all children of the given cnode
    for ( unsigned int i = 0; i < cnode->num_children(); ++i )
    {
        cout << setw( maxCnodeNameLength ) << left
             << ( "  " + cnode->get_child( i )->get_callee()->get_name() );
        PrintValues( cnode->get_child( i ), INCL );
    }
}




/**
 * Private helper method for gathering and printing the data (without names)
 * for a given cnode
 *
 * @param cnode The data is gathered for this cnode.
 * @param cnodeMode Determines the inclusion mode. If it is INCL, the
 * severities of the child cnodes are added. If it is EXCL, they are not.
 */
void
PrettyPlainPrinter::PrintValues( Cnode* cnode, inclmode cnodeMode ) const
{
    vector<Metric*> const &_requestedMetricVec = GetRequestedMetrics();
    vector<Thread*> const &threadVec           = cubeObject->get_thrdv();
    for ( size_t i = 0; i < _requestedMetricVec.size(); ++i )
    {
        double severity = 0.0;
        for ( vector<Thread*>::const_iterator threadIT = threadVec.begin();
              threadIT != threadVec.end(); ++threadIT )
        {
            severity += cubeObject->get_vcsev( INCL, cnodeMode, EXCL,
                                               _requestedMetricVec[ i ], cnode, *threadIT );
        }
        cout << setw( columnWidthes[ i ] ) << right;
        if ( _requestedMetricVec[ i ]->get_dtype() == "INTEGER" )
        {
            cout << noshowpoint << setprecision( 0 ) << severity;
        }
        else
        {
            cout << fixed << severity;
        }
        cout << showpoint << setprecision( 6 );
    }
    cout << endl;
}




#endif
