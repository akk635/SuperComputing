/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

#ifndef __CUBE_STAT_CSV_PLAIN_PRINTER_H
#define __CUBE_STAT_CSV_PLAIN_PRINTER_H


#include <vector>

#include "AggrCube.h"
#include "CubeMetric.h"
#include "CubeCnode.h"

#include "PlainPrinter.h"

using namespace std;





/*-------------------------------------------------------------------------*/
/**
 * @class   CSVPlainPrinter
 * @brief   Class for printing data about severities of a metric on a chosen
 *          cnode as a comma seperated value file
 */
/*-------------------------------------------------------------------------*/
class CSVPlainPrinter : public PlainPrinter
{
public:
    /// @name Constructor & destructor
    /// @{
    CSVPlainPrinter( AggrCube*             cubeObj,
                     vector<string> const &metNames,
                     vector<string> const &cnodeNames );
    virtual
    ~CSVPlainPrinter()
    {
    }
    /// @}
    /// @name Print methods used by clients
    /// @{
    virtual void
    PrintLegend() const;
    virtual void
    GatherAndPrint( Cnode* cnode ) const;

    /// @}
private:
    AggrCube* cubeObject;

    /// Private helper method for gathering and printing the data
    /// (without names)
    void
    PrintValues( Cnode*   cnode,
                 inclmode cnodeMode = INCL ) const;
};



/**
 * Creates a new CSVPlainPrinter instance from the given CUBE object and the
 * names of the requested metrics and cnodes.
 *
 * @param cubeObj The CUBE object used to parse the CUBE file to be analyzed.
 * @param metNames A vector containing all metric names for which data is to
 * be gathered and printed.
 * @param cnodeNames A vector containing all region names for which data is to
 * be gathered and printed.
 */
CSVPlainPrinter::CSVPlainPrinter( AggrCube*             cubeObj,
                                  vector<string> const &metNames,
                                  vector<string> const &cnodeNames )
    : PlainPrinter( cubeObj, metNames, cnodeNames ), cubeObject( cubeObj )
{
}

/**
 * Prints the legend for the statistics as a line of a comma seperated value
 * file
 */
void
CSVPlainPrinter::PrintLegend() const
{
    vector<Metric*> const &_requestedMetricVec = GetRequestedMetrics();
    cout << "Routine";
    for ( vector<Metric*>::const_iterator it = _requestedMetricVec.begin();
          it != _requestedMetricVec.end(); ++it )
    {
        cout << ',' << ( *it )->get_uniq_name();
    }
    cout << endl;
}

/**
 * Method for gathering and printing data about the severity of certain metrics
 * with respect to given cnodes and their children. This method gathers and
 * prints data about the requested metrics for the given Cnode cnode and all
 * cnodes called by cnode.
 *
 * @param cnode The data is gathered for this cnode and all it's child cnodes.
 */
void
CSVPlainPrinter::GatherAndPrint( Cnode* cnode ) const
{
    //First print data for the given cnode inclusively and
    //exclusively its children
    inclmode modes[] = { INCL, EXCL };
    for ( size_t i = 0; i < sizeof( modes ) / sizeof( inclmode ); ++i )
    {
        if ( modes[ i ] == INCL )
        {
            cout << ( "INCL(" + cnode->get_callee()->get_name() + ")" );
        }
        else
        {
            cout << ( "EXCL(" + cnode->get_callee()->get_name() + ")" );
        }
        PrintValues( cnode, modes[ i ] );
    }

    //Print data for all children of the given cnode
    for ( unsigned int i = 0; i < cnode->num_children(); ++i )
    {
        cout << cnode->get_child( i )->get_callee()->get_name();
        PrintValues( cnode->get_child( i ), INCL );
    }
}

/**
 * Private helper method for gathering and printing the data (without names)
 * for a given cnode
 *
 * @param cnode The data is gathered for this cnode.
 * @param cnodeMode Determines the inclusion mode. If it is INCL, the
 * severities of the child cnodes are added. If it is EXCL, they are not.
 */
void
CSVPlainPrinter::PrintValues( Cnode* cnode, inclmode cnodeMode ) const
{
    vector<Metric*> const &_requestedMetricVec = GetRequestedMetrics();
    vector<Thread*> const &threadVec           = cubeObject->get_thrdv();
    for ( vector<Metric*>::const_iterator reqMetIT = _requestedMetricVec.begin();
          reqMetIT != _requestedMetricVec.end(); ++reqMetIT )
    {
        double severity = 0.0;
        for ( vector<Thread*>::const_iterator threadIT = threadVec.begin();
              threadIT != threadVec.end(); ++threadIT )
        {
            severity += cubeObject->get_vcsev( INCL, cnodeMode, EXCL, *reqMetIT,
                                               cnode, *threadIT );
        }
        cout << ',';
        if ( ( *reqMetIT )->get_dtype() == "INTEGER" )
        {
            cout << fixed << noshowpoint << setprecision( 0 );
        }
        cout << severity;
        cout.setf( ios_base::fmtflags( 0 ), ios_base::floatfield );
        cout << showpoint << setprecision( 6 );
    }
    cout << endl;
}







#endif
