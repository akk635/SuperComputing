/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

#ifndef __CUBE_STAT_PRINTER_H
#define __CUBE_STAT_PRINTER_H


#include <vector>

#include "Cube.h"
#include "AggrCube.h"
#include "CubeMetric.h"
#include "CubeCnode.h"

#include "stat_calls.h"

using namespace std;
using namespace cube;

/*-------------------------------------------------------------------------*/
/**
 * @class   Printer
 * @brief   Abstract base class of all Printer classes.
 *          Used to extract the CUBE Metric and Cnode objects based on the
 *          names entered by the user.
 *
 * This is the common base class of all Printer classes. It's purpose is to
 * provide access to the CUBE Metric and Cnode objects based on given names.
 * It also prints warnings if there are no Metrics or Cnodes for a given name.
 */
/*-------------------------------------------------------------------------*/
class Printer
{
public:
    /// @name Constructor & destructor
    /// @{
    Printer( AggrCube*             cubeObject,
             vector<string> const &metNames,
             vector<string> const &cnodeNames );
    virtual
    ~Printer()
    {
    }
    /// @}
    /// @name Getters for cube objects
    /// @{
    vector<Metric*> const&
    GetRequestedMetrics() const
    {
        return requestedMetricVec;
    }
    vector<Cnode*>  const&
    GetRequestedCnodes() const
    {
        return requestedCnodeVec;
    }
    /// @}
private:
    vector<Metric*> requestedMetricVec;
    vector<Cnode*>  requestedCnodeVec;
};




/**
 * Creates a new Printer instance from the given CUBE object and the names of
 * the requested metrics and cnodes.
 *
 * @param cubeObject The CUBE object used to parse the CUBE file to be analyzed.
 * @param metNames A vector containing all metric names for which data is to be
 * gathered and printed.
 * @param cnodeNames A vector containing all region names for which data is to
 * be gathered and printed.
 */
Printer::Printer( AggrCube*             cubeObject,
                  vector<string> const &metNames,
                  vector<string> const &cnodeNames )
{
    for ( vector<string>::const_iterator metNameIT = metNames.begin();
          metNameIT != metNames.end(); ++metNameIT )
    {
        if ( Metric * m = findMetric( cubeObject, *metNameIT ) )
        {
            requestedMetricVec.push_back( m );
        }
        else
        {
            cerr << "WARNING: Metric " << *metNameIT << " doesn't exist"
                 << endl;
        }
    }

    vector<Cnode*> const &cnodeVec = cubeObject->get_cnodev();
    for ( vector<string>::const_iterator cnodeNameIT = cnodeNames.begin();
          cnodeNameIT != cnodeNames.end(); ++cnodeNameIT )
    {
        bool cnodeFound = false;
        for ( vector<Cnode*>::const_iterator cnodeIT = cnodeVec.begin();
              cnodeIT != cnodeVec.end(); ++cnodeIT )
        {
            if ( *cnodeNameIT == ( *cnodeIT )->get_callee()->get_name() )
            {
                requestedCnodeVec.push_back( *cnodeIT );
                cnodeFound = true;
            }
        }
        if ( !cnodeFound )
        {
            cerr << "WARNING: Cnode with name " << *cnodeNameIT
                 << " doesn't exist" << endl;
        }
    }
}


#endif
