/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 *
 * \file remap_calls.h
 * \brief Contains a cube_remap spezific calls
 *
 ************************************************/


#ifndef __REMAP_CALLS_H
#define __REMAP_CALLS_H


#include "algebra4.h"
#include "algebra4-internals.h"
#include "Predicates.h"
#include "ReMapDriver.h"

// #define VERSION "remap-dev"
#define PATTERNS_URL "@mirror@scalasca_patterns-" VERSION ".html#"


using namespace std;

namespace cube

{
/**
   *An attempt to use xtprocadmin mapfile to remap Cray XT nodenames
 * and generate topologies (based on cabinets and mesh)
 */
void
node_remap( Cube& newCube, string dirname )
{
    // verify first node has (unmapped) name in expected format "node<NID>"
    const vector<Node*>&          nodev = newCube.get_nodev();
    vector<Node*>::const_iterator nit   = nodev.begin();
    if ( nit == nodev.end() ) // no nodes - perhaps flexible system tree - no node remap is needed
    {
        return;
    }

    string node_name = ( *nit )->get_name();
    if ( node_name.substr( 0, 4 ) != "node" )
    {
        //cerr << "First node has unexpected name " << node_name << endl;
        return;
    }

    string   mapname = "./xtnids";
    ifstream in( mapname.c_str() );
    if ( !in )   // no map found in current directory
    {
        if ( dirname.empty() )
        {
            return;
        }
        mapname.erase( 0, 1 );
        mapname.insert( 0, dirname );
        in.clear();
        in.open( mapname.c_str() );
        if ( !in )
        {
            return;     // no map found in given (epik) directory
        }
        // XXXX should also check installdir
    }
    cout << "Remapping " << nodev.size() << " nodes using " << mapname << endl;

    const string header1 = "   NID    (HEX)    NODENAME     TYPE ARCH        OS CORES";
    const string header2 = "   NID    (HEX)    NODENAME     TYPE ARCH        OS CPUS";
    char         linebuf[ 1024 ];

    in.getline( linebuf, 1024 );
    if ( ( strncmp( linebuf, header1.c_str(), header1.length() ) != 0 ) &&
         ( strncmp( linebuf, header2.c_str(), header2.length() ) != 0 ) )
    {
        cerr << "Error: Map header mismatch:" << endl << linebuf << endl;
        return;
    }

    unsigned      CagesPerCbnt = 3; // typical cabinet configuration, but may need to be adjusted
    unsigned      SlotsPerCage = 8; // "
    unsigned      NodesPerSlot = 4; // "
    unsigned      CoresPerNode = 0;
    unsigned      minCABX      = 1000;
    unsigned      maxCABX      = 0, maxCABY = 0;
    vector<char*> xtnidnames( 1024, ( char* )NULL );
    char          nodetype[ 16 ], nodearch[ 16 ], nodeos[ 16 ];

    // parse each map entry for nid & nodename to store in vector of xtnidnames
    // additionally parse each nodename to determine cabinet ranges

    while ( !in.eof() )
    {
        in.getline( linebuf, 1024 );
        if ( in.gcount() == 0 )
        {
            continue;
        }

        unsigned nid, hex, cores;
        char*    nodename = ( char* )calloc( 16, 1 );
        if ( 7 != sscanf( linebuf, "%u %x %16s %s %s %s %u", &nid, &hex,
                          nodename, nodetype, nodearch, nodeos, &cores ) )
        {
            // down compute nodes ('X' in xtstat) have incomplete data
            if ( 4 == sscanf( linebuf, "%u %x %16s %s", &nid, &hex,
                              nodename, nodetype ) )
            {
                cerr << "Info: skipping down compute node " << nodename << endl;
            }
            else
            {
                cerr << "Error: Invalid map entry:" << endl << linebuf << endl;
            }
        }
        else if ( nid != hex )
        {
            cerr << "Error: Inconsistent nid " << nid << "<>" << hex << endl;
        }
        else
        {
            //cout << "Parsed: nid=" << nid << " name=" << (nodename ? nodename : "(nil)")
            //     << " cores=" << cores << endl;
            while ( nid >= xtnidnames.size() )
            {
                xtnidnames.resize( xtnidnames.size() + 1024, ( char* )NULL );
            }
            xtnidnames[ nid ] = nodename;
            if ( cores > CoresPerNode )
            {
                CoresPerNode = cores;
            }
            unsigned CABX, CABY, CAGE, SLOT, NODE;
            if ( nodename[ 0 ] == 'r' ) // x2 compute node?
            {                           //cerr << "Ignoring unexpected nodename " << nodename << " for nid " << nid << endl;
            }
            else
            if ( 5 != sscanf( nodename, "c%u-%uc%us%un%u", &CABX, &CABY, &CAGE, &SLOT, &NODE ) )
            {
                cerr << "Error: Unparsable nodename " << nodename << " for nid " << nid << endl;
            }
            else
            {
                if ( CABY > maxCABY )
                {
                    maxCABY = CABY;
                }
                if ( CABX > maxCABX )
                {
                    maxCABX = CABX;
                }
                if ( CABX < minCABX )
                {
                    minCABX = CABX;
                }
                if ( CAGE >= CagesPerCbnt )
                {
                    CagesPerCbnt = CAGE + 1;
                }
                if ( SLOT >= SlotsPerCage )
                {
                    SlotsPerCage = SLOT + 1;
                }
                if ( NODE >= NodesPerSlot )
                {
                    NodesPerSlot = NODE + 1;
                }
            }
        }
    }

    // Define new topologies
    vector<bool>   periodv( 3 ), altperiodv( 6 );
    vector<long>   dimv( 3 ), altdimv( 6 ), coordv( 3 ), altcoordv( 6 );
    vector<string> altnamev( 6 );

    char*          env = getenv( "XT_NODE_CORES" );
    if ( env )
    {
        int cores = atoi( env );
        if ( cores > 0 )
        {
            CoresPerNode = cores;
            cout << "Using XT_NODE_CORES=" << CoresPerNode << endl;
        }
        else
        {
            cerr << "Ignoring invalid XT_NODE_CORES=" << env << endl;
        }
    }
    cout << "Using " << CoresPerNode << " cores per XT node" << endl;
    // plain topology with separate dimensions
    altperiodv[ 0 ] = false;
    altnamev[ 0 ]   = "CabX";
    altdimv[ 0 ]    = maxCABX + 1;
    altperiodv[ 1 ] = false;
    altnamev[ 1 ]   = "CabY";
    altdimv[ 1 ]    = maxCABY + 1;
    altperiodv[ 2 ] = false;
    altnamev[ 2 ]   = "Cage";
    altdimv[ 2 ]    = CagesPerCbnt;
    altperiodv[ 3 ] = false;
    altnamev[ 3 ]   = "Slot";
    altdimv[ 3 ]    = SlotsPerCage;
    altperiodv[ 4 ] = false;
    altnamev[ 4 ]   = "Node";
    altdimv[ 4 ]    = NodesPerSlot;
    altperiodv[ 5 ] = false;
    altnamev[ 5 ]   = "Core";
    altdimv[ 5 ]    = CoresPerNode;
    Cartesian* xtTopoCart = newCube.def_cart( 6, altdimv, altperiodv );
    xtTopoCart->set_name( "XT Topology" );
    xtTopoCart->set_namedims( altnamev );
    // cabinet topology

    periodv[ 0 ] = false;
    dimv[ 0 ]    = ( ( maxCABY + 1 ) * SlotsPerCage ) * CoresPerNode;
    periodv[ 1 ] = false;
    dimv[ 1 ]    = CagesPerCbnt * NodesPerSlot;
    periodv[ 2 ] = false;
    dimv[ 2 ]    = maxCABX + 1;              // (max) number of cabinets
    Cartesian* xtCabsCart = newCube.def_cart( 3, dimv, periodv );
    xtCabsCart->set_name( "XT NodeStat" );

    cout << "Generating " << dimv[ 0 ] << "*" << dimv[ 1 ] << "*" << dimv[ 2 ]
         << " topology for " << maxCABX + 1 << "*" << maxCABY + 1
         << " Cray XT cabinets (" << CagesPerCbnt << " cages, "
         << SlotsPerCage << " slots, " << NodesPerSlot << " nodes)" << endl;
    // Remap nodes
    while ( nit != nodev.end() )
    {
        string   node_name = ( *nit )->get_name();
        unsigned nid       = atoi( node_name.substr( 4 ).c_str() );
        if ( node_name.substr( 0, 4 ) != "node" )
        {
            cerr << "Leaving node with unexpected name " << node_name << endl;
        }
        else if ( ( nid >= xtnidnames.size() ) || !xtnidnames[ nid ] )
        {
            cerr << "Skipping " << node_name << " without nid mapping" << endl;
        }
        else
        {
            unsigned CABX, CABY, CAGE, SLOT, NODE;
            sscanf( xtnidnames[ nid ], "c%u-%uc%us%un%u", &CABX, &CABY, &CAGE, &SLOT, &NODE );
            ( *nit )->set_name( xtnidnames[ nid ] );

            unsigned cabsX = CABY * SlotsPerCage + SLOT;
            unsigned cabsY = CAGE * NodesPerSlot + NODE;
            unsigned cabsZ = CABX;


            unsigned processesOnNode = ( *nit )->num_groups();
            for ( unsigned p = 0; p < processesOnNode; p++ )
            {
                Process* proc    = ( *nit )->get_location_group( p );
                unsigned threads = proc->num_children();
                for ( unsigned t = 0; t < threads; t++ )
                {
                    unsigned core = ( t * processesOnNode ) + p;
                    if ( core >= CoresPerNode )
                    {
                        cout << core << ">=" << CoresPerNode
                             << ": Skipping coordinate mapping for over-subscribed compute node!" << endl;
                        continue;
                    }
                    Thread* thrd = proc->get_child( t );
                    coordv[ 0 ] = cabsX * CoresPerNode + core;
                    coordv[ 1 ] = cabsY;
                    coordv[ 2 ] = cabsZ;
                    // NB: coord checks only valid for single topology
                    if ( coordv[ 0 ] >= dimv[ 0 ] )
                    {
                        cerr << xtnidnames[ nid ] << ": " << coordv[ 0 ] << ">=" << dimv[ 0 ]
                             << ": Skipping x-coordinate out of range!" << endl;
                        continue;
                    }
                    if ( coordv[ 1 ] >= dimv[ 1 ] )
                    {
                        cerr << xtnidnames[ nid ] << ": " << coordv[ 1 ] << ">=" << dimv[ 1 ]
                             << ": Skipping y-coordinate out of range!" << endl;
                        continue;
                    }
                    if ( coordv[ 2 ] >= dimv[ 2 ] )
                    {
                        cerr << xtnidnames[ nid ] << ": " << coordv[ 2 ] << ">=" << dimv[ 2 ]
                             << ": Skipping z-coordinate out of range!" << endl;
                        continue;
                    }
                    xtCabsCart->def_coords( thrd, coordv );
                    // plain topology
                    altcoordv[ 0 ] = CABX;
                    altcoordv[ 1 ] = CABY;
                    altcoordv[ 2 ] = CAGE;
                    altcoordv[ 3 ] = SLOT;
                    altcoordv[ 4 ] = NODE;
                    altcoordv[ 5 ] = core;
                    xtTopoCart->def_coords( thrd, altcoordv );
                }
            }
#if DEBUG
            cout << node_name << " : " << xtnidnames[ nid ]
                 << " : " << CABX << "/" << CABY << "/" << CAGE << "/" << SLOT << "/" << NODE
                 << " (" << cabsX << "," << cabsY << "," << cabsZ << ")"
                 << endl;
#endif
        }
        ++nit;
    }
}










/**
 * Creates a new cube with manually specified list of metrics. Calculates
   exclusive and inclusive values for metrics and fills severities.
 *
 * only for DOUBLE METRIC
 *
 */
void
cube_remap( AggrCube* outCube, Cube* inCube, const std::string& specname, const std::string& dirname, bool convert, bool add_scalasca_threads, bool skip_omp, bool copy_cube_structure )
{
    AggrCube*                 tmpCube = NULL;
    remapparser::ReMapDriver* driver  = NULL;
    try
    {
        cout << "Create cube according the remapping specification..." << endl;
        AggrCube* working_cube;

        if ( copy_cube_structure )
        {
            tmpCube = new AggrCube( *inCube );
        }
        else
        {
            tmpCube = new AggrCube();
        }

        if ( !convert )
        {
            working_cube = outCube; // we do not convert derived metrics into data
        }
        else
        {
            working_cube = tmpCube; // we convert derived metrics into data. Working via temporary cube.
        }

        if ( !copy_cube_structure )
        {
            istream* specin;

            if ( specname.compare( "__NO_SPEC__" ) == 0 )
            {
                string       speccontent;
                string       name    = "remapping.spec";
                vector<char> content = inCube->get_misc_data( name );
                if ( content.size() == 0 )
                {
                    throw RuntimeError( "No remapping specification found inside of the cube." );
                }
                else
                {
                    cout << "Found remapping specification file inside of cube. Use it." << endl;
                }


                for ( vector<char>::iterator _iter = content.begin(); _iter != content.end(); _iter++ )
                {
                    speccontent += *_iter;
                }


                stringstream* _specin = new stringstream( speccontent );
                specin = _specin;
            }
            else
            {
                ifstream* _specin = new ifstream();
                _specin->open( specname.c_str(), ios::in );
                if ( _specin->fail() )
                {
                    throw RuntimeError( "No remapping specification file (" + specname + ") found." );
                }
                specin = _specin;
            }




            driver = new remapparser::ReMapDriver();
            working_cube->set_post_initialization( true );

            driver->parse_stream( *specin, *working_cube );


            delete driver;
            delete specin;
        }
        // Define mirror & attributes
        std::vector<std::string> _mirrors = working_cube->get_mirrors();
        if ( _mirrors.size() == 0 )
        {
            std::vector<std::string> _mirrors = inCube->get_mirrors();
            for ( std::vector<std::string>::iterator mir_iter = _mirrors.begin(); mir_iter != _mirrors.end(); mir_iter++ )
            {
                working_cube->def_mirror( *mir_iter );
            }
//        working_cube->def_mirror( "http://www.fz-juelich.de/jsc/datapool/scalasca/" );
        }
        working_cube->def_attr( "CUBE_CT_AGGR", "SUM" );
        // Copy severities & topology
        CubeMapping inMap;
        // Re-map or merge hierarchies
        metric_remap( *working_cube, *inCube, inMap );      // false -> do not convert derived metrics, but create first a copy.
        cnode_merge( *working_cube, *inCube, inMap, true ); // true -> we copy ids. and do not create new
        set_region_urls( *working_cube );
        sysres_merge( *working_cube, *inCube, inMap, false, false );

        node_remap( *working_cube, dirname ); // update nodes and topologies



//         createMapping( *working_cube, *inCube, inMap, false );


        add_top( *working_cube, *inCube, inMap );
        working_cube->setup_cubepl1_memory();
        working_cube->compile_derived_metric_expressions();
        working_cube->set_post_initialization( false );

        set_sev( *working_cube, *inCube, inMap );



        if ( add_scalasca_threads ) // here one calculates scalsca metrics "idle threads" and "limited parallelizm" and adds their value to metric "time"
        {
            cout << " Add scalasca specific metrics ..." << endl;
            bool                           includes_omp = true;

            const vector<Cnode*>&          cnodev = working_cube->get_cnodev();
            vector<Cnode*>::const_iterator it     = cnodev.begin();
#undef VOIDING_METRICS
#ifdef VOIDING_METRICS
            cout << " Voiding empty metrics...." << flush;
            bool includes_mpi = true, includes_rma = true, includes_io = true;

            skip_omp = ( working_cube->get_met( "omp_management" ) == NULL );
            // Divide "Time" metric


            while ( it != cnodev.end() )
            {
                const Region* region = ( *it )->get_callee();
                if ( is_omp( region ) ) // OMP
                {
                    includes_omp = true;
                }

                if ( is_mpi( region ) ) // MPI
                {
                    includes_mpi = true;
                    std::string name        =  lowercase( region->get_name() );
                    bool        is_rma_sync = is_mpi_sync_rma( name );
                    if ( is_rma_sync ) // RMA synchronization
                    {
                        includes_rma = true;
                    }
                    if ( is_mpi_io( name ) ) // File I/O
                    {
                        includes_io = true;
                    }
                }
                ++it;
            }

            if ( !includes_mpi ) /* hide unused MPI metrics */
            {
                Metric* mpi   = working_cube->get_met( "mpi" );
                Metric* syncs = working_cube->get_met( "syncs" );
                Metric* comms = working_cube->get_met( "comms" );
                Metric* bytes = working_cube->get_met( "bytes" );

                if ( mpi != NULL )
                {
                    mpi->set_val( "VOID" );
                }
                if ( syncs != NULL )
                {
                    syncs->set_val( "VOID" );
                }
                if ( comms != NULL )
                {
                    comms->set_val( "VOID" );
                }
                if ( bytes != NULL )
                {
                    bytes->set_val( "VOID" );
                }
            }

            if ( !includes_rma ) /* hide unused MPI RMA metrics */
            {
                Metric* rma     = working_cube->get_met( "mpi_rma_communication" );
                Metric* srma    = working_cube->get_met( "mpi_rma_synchronization" );
                Metric* brma    = working_cube->get_met( "bytes_rma" );
                Metric* rcomms  = working_cube->get_met( "comms_rma" );
                Metric* rsyncs  = working_cube->get_met( "syncs_rma" );
                Metric* pwsyncs = working_cube->get_met( "mpi_rma_pairsync_count" );

                if ( rma != NULL )
                {
                    rma->set_val( "VOID" );
                }
                if ( srma != NULL )
                {
                    srma->set_val( "VOID" );
                }
                if ( brma != NULL )
                {
                    brma->set_val( "VOID" );
                }
                if ( rcomms != NULL )
                {
                    rcomms->set_val( "VOID" );
                }
                if ( rsyncs != NULL )
                {
                    rsyncs->set_val( "VOID" );
                }
                if ( pwsyncs != NULL )
                {
                    pwsyncs->set_val( "VOID" );
                }
            }

            if ( !includes_io ) /* hide unused MPI File I/O metrics */
            {
                Metric* io       = working_cube->get_met( "mpi_io" );
                Metric* file_ops = working_cube->get_met( "mpi_file_ops" );
                if ( io != NULL )
                {
                    io->set_val( "VOID" );
                }
                if ( file_ops != NULL )
                {
                    file_ops->set_val( "VOID" );
                }
            }
            cout << done;
#endif
//
            if ( includes_omp && skip_omp )
            {
                cout << "Skipping OpenMP metrics." << endl;
            }
            else
            if ( includes_omp ) // Calculate idle threads heuristic
            {
                cout << " Add metrics \"idle threads\" and \"limited parallelism\"..." << flush;
                Metric*                       time     = working_cube->get_met( "time" );
                Metric*                       limpar   = working_cube->get_met( "omp_limited_parallelism" );
                Metric*                       idleth   = working_cube->get_met( "omp_idle_threads" );
                Metric*                       omp_time = working_cube->get_met( "omp_time" );

                const vector<LocationGroup*> &procv     = working_cube->get_location_groupv();
                size_t                        num_procs = procv.size();


                // scan call-tree for OpenMP parallel regions
                bool           in_parallel = false;
                size_t         preg_level  = UINT_MAX;
                size_t         num_thrds   = working_cube->get_locationv().size();
                vector<double> tvalues( num_thrds );
                Cnode*         preg = NULL;
                it = cnodev.begin();
                while ( it != cnodev.end() )
                {
                    const Region* region = ( *it )->get_callee();
                    const size_t  level  = ( *it )->indent().length() / 2;
                    if ( level <= preg_level )
                    {
                        if ( is_omp( region ) )
                        {
                            preg_level = level;
                        }
                        else
                        {
                            preg_level = UINT_MAX;
                        }
                        if ( preg )
                        {
                            //const Region* region = preg->get_callee();
                            //printf("%s inclusive times:\n", region->get_name().c_str());
                            for ( size_t t = 0; t < num_thrds; ++t )
                            {
                                Location* thread = working_cube->get_locationv()[ t ];
                                Location* master = thread->get_parent()->get_child( 0 );
                                double    mvalue = tvalues[ master->get_id() ];
                                double    idled  = mvalue - tvalues[ t ];
                                if ( idled < 1e-10 )
                                {
                                    continue;      // ignore values below measurement threshold
                                }
                                working_cube->set_sev( limpar, preg, thread, idled );
                                working_cube->add_sev( idleth, preg, thread, idled );
                                working_cube->add_sev( time,   preg, thread, idled );
                            }
                            preg = NULL; // no longer in parallel region
                        }
                    }
                    in_parallel = ( preg_level != UINT_MAX );
                    //printf("%d-%s:%d %s%s\n", level, region->get_descr().c_str(), in_parallel,
                    //         (*it)->indent().c_str(), region->get_name().c_str());

                    if ( in_parallel ) // accumulate inclusive execution time in parallel region
                    {
                        if ( !preg )
                        {
                            preg = *it; // stash current parallel region
                            //const Region* region = preg->get_callee();
                            //printf("%s stashed at level %d\n", region->get_name().c_str(), preg_level);
                            for ( size_t t = 0; t < num_thrds; ++t )
                            {
                                tvalues[ t ] = 0.0;
                            }
                        }
                        for ( size_t t = 0; t < num_thrds; ++t )
                        {
                            Location* thread = working_cube->get_locationv()[ t ];
                            double    value  = working_cube->get_sev( time, *it, thread );
                            tvalues[ thread->get_id() ] += value;
                        }
                    }
                    else  // master's serial time is idle time for workers
                    {
                        for ( size_t p = 0; p < num_procs; ++p )
                        {
                            LocationGroup* proc       = procv[ p ];
                            const size_t   proc_thrds = proc->num_children();
                            Location*      master     = proc->get_child( 0 );
                            double         value      = working_cube->get_sev( time, *it, master );
                            //printf("    %s %.6f\n", master->get_name().c_str(), value);

                            for ( size_t t = 1; t < proc_thrds; ++t )
                            {
                                Location* worker = proc->get_child( t );
                                working_cube->set_sev( idleth, *it, worker, value );
                                working_cube->add_sev( time, *it, worker, value );
                                //printf("    %s -> %.6f\n", worker->get_name().c_str(), value);
                            }
                        }
                    }

                    ++it;
                }

                if ( preg ) // still have last parallel region stashed
                {           //const Region* region = preg->get_callee();
                    //printf("%s inclusive times:\n", region->get_name().c_str());
                    for ( size_t t = 0; t < num_thrds; ++t )
                    {
                        Thread* thread = working_cube->get_thrdv()[ t ];
                        Thread* master = thread->get_parent()->get_child( 0 );
                        double  mvalue = tvalues[ master->get_id() ];
                        double  idled  = mvalue - tvalues[ t ];
                        if ( idled < 1e-10 )
                        {
                            continue;      // ignore values below measurement threshold
                        }
                        working_cube->set_sev( limpar, preg, thread, idled );
                        working_cube->add_sev( idleth, preg, thread, idled );
                        working_cube->add_sev( time, preg, thread, idled );
                    }
                }

                // remove VOID tags to make metrics visible
                if ( idleth != NULL )
                {
                    idleth->set_val( "" );
                }
                if ( omp_time != NULL )
                {
                    omp_time->set_val( "" );
                }
            }
            cout << "done." << endl; // idle threads and limited parallelism output


// imbalance heuristics
//             First get some metrics:
            cout << " Add metrics \"load imbalance\"..." << endl;
            Metric* exec   = working_cube->get_met( "execution" );
            Metric* visits = working_cube->get_met( "visits" );
            Metric* imbal  = working_cube->get_met( "imbalance" );
            Metric* above  = working_cube->get_met( "imbalance_above" );
            Metric* single = working_cube->get_met( "imbalance_above_single" );
            Metric* below  = working_cube->get_met( "imbalance_below" );
            Metric* bypass = working_cube->get_met( "imbalance_below_bypass" );
            Metric* bysing = working_cube->get_met( "imbalance_below_singularity" );


            // Calculate load imbalance heuristic
            vector<double> average;
            vector<double> dummy;
            size_t         num_cnodes  = working_cube->get_cnodev().size();
            size_t         num_threads = working_cube->get_thrdv().size();
            size_t         num_procs   = working_cube->get_procv().size();

            cout << "      Determine numbers of void processes and threads to ignore..." << endl;
            ;
            size_t void_procs = 0, void_thrds = 0;
            for ( size_t p = 0; p < working_cube->get_procv().size(); p++ )
            {
                Process* proc = working_cube->get_procv()[ p ];
                if ( proc->get_name().find( "VOID" ) != string::npos )
                {
                    void_procs++;
                    void_thrds += proc->num_children();
                }
            }

            if ( num_threads == 1 )
            {
                if ( imbal != NULL )
                {
                    imbal->set_val( "VOID" );
                }
            }

            cout << "      Calculate average exclusive execution time..." << flush;
            working_cube->get_cnode_tree( average, dummy, EXCL, INCL, exec, NULL );
            cout << "done" << endl;
            for ( size_t cid = 0; cid < num_cnodes; ++cid )
            {
                Cnode* cnode = cnodev[ cid ];

                /* Inside parallel region? */
                bool is_parallel = false;
                if ( includes_omp && !skip_omp )
                {
                    while ( cnode && !is_parallel )
                    {
                        is_parallel = is_omp_parallel( cnode->get_callee()->get_name() );
                        cnode       = cnode->get_parent();
                    }
                }

                if ( is_parallel )
                {
                    average[ cid ] = average[ cid ] / ( num_threads - void_thrds );
                }
                else
                {
                    average[ cid ] = average[ cid ] / ( num_procs - void_procs );
                }
            }

            cout << "      Calculate difference to average value..." << flush;
            for ( size_t tid = 0; tid < num_threads; ++tid )
            {
                Thread* thread = working_cube->get_thrdv()[ tid ];

                /* Skip threads on void processes */
                if ( thread->get_parent()->get_name().find( "VOID" ) != string::npos )
                {
                    continue;
                }

                /* Skip worker threads for pure MPI */
                if ( ( !includes_omp || skip_omp ) && thread->get_rank() != 0 )
                {
                    continue;
                }

                for ( size_t cid = 0; cid < num_cnodes; ++cid )
                {
                    Cnode* cnode = cnodev[ cid ];

                    /* Inside parallel region? */
                    bool   is_parallel = false;
                    Cnode* tmp_cnode   = cnode;
                    while ( tmp_cnode && !is_parallel )
                    {
                        is_parallel = is_omp_parallel( tmp_cnode->get_callee()->get_name() );
                        tmp_cnode   = tmp_cnode->get_parent();
                    }

                    /* Ignore worker threads when outside parallel region */
                    if ( !is_parallel && thread->get_rank() != 0 )
                    {
                        continue;
                    }

                    double sev  = working_cube->get_vcsev( EXCL, EXCL, EXCL, exec, cnode, ( Sysres* )thread );
                    double diff = sev - average[ cid ];

                    if ( diff > 0 )
                    {
                        working_cube->set_sev( imbal, cnode, thread, diff );
                        working_cube->set_sev( above, cnode, thread, diff );
                    }
                    else if ( diff < 0 )
                    {
                        working_cube->set_sev( imbal, cnode, thread, -diff );
                        working_cube->set_sev( below, cnode, thread, -diff );
                    }
                }
            }

            cout << "done." << endl << " Add metrics \"imbalance due to singularities and imperfect parallelization\"..." << flush;

            // resolve computational imbalance due to singularities and imperfect parallelization
            for ( size_t cid = 0; cid < num_cnodes; ++cid )
            {
                unsigned visitors = 0;
                Cnode*   cnode    = cnodev[ cid ];
                double   imbsev   = average[ cid ];

                if ( imbsev == 0.0 )
                {
                    continue;
                }

                if ( includes_omp )
                {
                    /* Inside parallel region? */
                    bool   is_parallel = false;
                    Cnode* tmp_cnode   = cnode;
                    while ( tmp_cnode && !is_parallel )
                    {
                        is_parallel = is_omp_parallel( tmp_cnode->get_callee()->get_name() );
                        tmp_cnode   = tmp_cnode->get_parent();
                    }

                    /* Ignore OpenMP threads when outside parallel region */
                    if ( !is_parallel )
                    {
                        continue;
                    }
                }

                for ( size_t tid = 0; tid < num_threads; ++tid )
                {
                    Thread* thread = working_cube->get_thrdv()[ tid ];
                    if ( thread->get_parent()->get_name().find( "VOID" ) != string::npos )
                    {
                        continue;
                    }
                    int nvisits = ( int )working_cube->get_sev( visits, cnode, thread );
                    if ( nvisits )
                    {
                        visitors++;
                    }
                }

                if ( visitors == ( num_threads - void_thrds ) )
                {
                    continue;
                }

                for ( size_t tid = 0; tid < num_threads; ++tid )
                {
                    Thread* thread = working_cube->get_thrdv()[ tid ];
                    if ( thread->get_parent()->get_name().find( "VOID" ) != string::npos )
                    {
                        continue;
                    }
                    int nvisits = ( int )working_cube->get_sev( visits, cnode, thread );
                    if ( nvisits == 0 )
                    {
                        working_cube->set_sev( bypass, cnode, thread, imbsev );
                    }
                    if ( visitors == 1 ) // executed by a single participant
                    {
                        if ( nvisits == 0 )
                        {
                            working_cube->set_sev( bysing, cnode, thread, imbsev );
                        }
                        else
                        {
                            working_cube->set_sev( single, cnode, thread, imbsev * ( num_threads - void_thrds - 1 ) );
                        }
                    }
                }
            }
            cout << "done." << endl;
        }   // if (add_scalasca_threads)


        if ( convert ) // here we have to recalculate values and fill the output cube
        {
            cout << "Copy values of derived metric into target cube... " << endl;
            // here we copy final hierarchy without derived metrics  (using old copy_tree call)
            CubeMapping inMap2;
            for ( vector<Metric*>::const_iterator miter = working_cube->get_root_metv().begin(); miter != working_cube->get_root_metv().end(); miter++ )
            {
                Metric* _met = outCube->def_met( ( *miter )->get_disp_name(), ( *miter )->get_uniq_name(),
                                                 ( *miter )->get_dtype(), ( *miter )->get_uom(), ( *miter )->get_val(),
                                                 ( *miter )->get_url(), ( *miter )->get_descr(), NULL, CUBE_METRIC_INCLUSIVE );
                if ( _met == NULL )
                {
                    _met = outCube->def_met( ( *miter )->get_disp_name(), ( *miter )->get_uniq_name(),
                                             ( *miter )->get_dtype(), ( *miter )->get_uom(), ( *miter )->get_val(),
                                             ( *miter )->get_url(), ( *miter )->get_descr(), NULL, CUBE_METRIC_EXCLUSIVE );
                }
                inMap2.metm[ ( *miter ) ] = _met;
                inMap2.r_metm[ _met ]     = ( *miter );
                copy_tree( *outCube, *( *miter ), inMap2, COPY_TO_INCLUSIFY );
            }
/*
          metric_remap( *outCube, *workingCube, convert );*/


            cnode_merge( *outCube, *working_cube, inMap2, true  ); // true -> we copy ids...
            set_region_urls( *outCube );
            sysres_merge( *outCube, *working_cube, inMap2, false, false );

            node_remap( *outCube, dirname ); // update nodes and topologies


            // Copy severities & topology
//             CubeMapping inMap2;
//             createMapping( *outCube, *working_cube, inMap2, false );


            add_top( *outCube, *working_cube, inMap2 );
            set_sev( *outCube, *working_cube, inMap2 );
        }   // if ( convert )




        delete tmpCube; // we do not use tmpCube in this case
//
//     */*/*/
    }
    catch ( RuntimeError e )
    {
        cerr << e;
        delete tmpCube; // we do not use tmpCube in this case
        throw;
    }

    return;
}
} /* namespace cube */


#endif          // REMAP_CALLS
