/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/



#include "CubeCartesian.h"
#include "Cube.h"
#include "CubeProcess.h"
#include "CubeThread.h"

using namespace std;
using namespace cube;


void
write_cube( Cube* inCube );
void
create_topology( Cube* inCube );
void
rename_topology( Cube* inCube );
void
rename_dimensions( Cube* inCube );
void
show_topologies( std::vector<Cartesian*> topologies );
