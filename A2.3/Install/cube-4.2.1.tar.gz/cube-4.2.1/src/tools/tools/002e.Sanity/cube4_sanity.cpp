/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file cube_sanity.cpp
 * \brief Runs some sanity checks on a .cube file and reports eventual errors.
 *
 */

// #ifdef CUBE_COMPRESSED
#include "CubeZfstream.h"
// #endif
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <iostream>
#include <unistd.h>
#if 0
#  include <getopt.h>
#endif

#include "MdAggrCube.h"
#include "CnodeConstraint.h"
#include "RegionConstraint.h"
#include "PrintableCCnode.h"
#include "CCnode.h"
#include "CRegion.h"
#include "Filter.h"

#include "Cube.h"
#include "CubeCnode.h"
#include "CubeRegion.h"
#include "CubeError.h"
#include "CubeServices.h"

#define CUBE_SANITY_INTERNAL_ERROR -1
#define CUBE_SANITY_OK 0
#define CUBE_SANITY_TESTS_FAILED 1

using namespace std;
using namespace cube;



#include "sanity_calls.h"











int
main( int argc, char* argv[] )
{
    int             ch   = 0;
    MdAggrCube*     cube = NULL;
    map<char, bool> settings;
    settings[ 'n' ] = false;
    settings[ 'l' ] = false;
    Filter   filter;
    string   output_filename;
    ofstream out;

#if 0
    int          option_index = 0;
    const string USAGE        = "Usage: " + string( argv[ 0 ] ) + " [ flags ] <cube experiment>\n"
                                "where flags basically turns certains tests on or off:\n"
                                "  -h, --help                    Help; Output a brief help message.\n"
                                "  -n, --no-negative-values      Disables the (time consuming) ckeck for negative\n"
                                "                                metric values.\n"
                                "  -l, --no-line-numbers         Disables checks for line numbers.\n"
                                "  -f, --filter <file.filt>      Checks whether a node's name is matched by a\n"
                                "                                pattern in file.filt.\n"
                                "  -o, --output <output_file>    Path of the output file. If no output file is\n"
                                "                                given, detailed output will be surpressed. A\n"
                                "                                summary will always be printed out to stdout.\n";

    static struct option long_options[] = {
        { "help",               no_argument,                   0,                   'h'                   },
        { "no-negative-values", no_argument,                   0,                   'n'                   },
        { "no-line-numbers",    no_argument,                   0,                   'l'                   },
        { "filter",             required_argument,             0,                   'f'                   },
        { "output",             required_argument,             0,                   'o'                   }
    };
#else
    const string         USAGE = "Usage: " + string( argv[ 0 ] ) + " [ flags ] <cube experiment>\n"
                                 "where flags basically turns certains tests on or off:\n"
                                 "  -h                   Help; Output a brief help message.\n"
                                 "  -n                   Disables the (time consuming) ckeck for negative\n"
                                 "                          metric values.\n"
                                 "  -l                   Disables checks for line numbers.\n"
                                 "  -f <file.filt>       Checks whether a node's name is matched by a\n"
                                 "                          pattern in file.filt.\n"
                                 "  -o <output_file>     Path of the output file. If no output file is\n"
                                 "                          given, detailed output will be surpressed. A\n"
                                 "                          summary will always be printed out to stdout.\n";
#endif
    const char* short_options = "o:f:nlh?";

#if 0
    while ( ( ch = getopt_long( argc, argv, short_options, long_options, &option_index ) ) != -1 )
#else
    while ( ( ch = getopt( argc, argv, short_options ) ) != -1 )
#endif
    {
        switch ( ch )
        {
            case 'n':
                settings[ 'n' ] = true;
                break;
            case 'l':
                settings[ 'l' ] = true;
                break;
            case 'f':
                filter.add_file( string( optarg ) );
                break;
            case 'o':
                output_filename = string( optarg );
                break;
            case 'h':
                cout << USAGE;
                return 0;
            default:
                cout << USAGE
                     << "Error: Unknown option -" << ch << endl;
                return 1;
        }
    }

    try
    {
        if ( argc - optind != 1 )
        {
            cout << USAGE << endl;
            return CUBE_SANITY_INTERNAL_ERROR;
        }

        /* XXX: BAD HACK! The >> operator is not overloaded for MdAggrCube and
         *                Cube is not virtual.
         */
        Cube* _cube = openCubeFile( argv[ optind ] );
        cube = new MdAggrCube( *_cube );
        delete _cube;

        CnodeSubForest*   all = cube->get_forest();

        RegionConstraint* non_empty = new NameNotEmptyOrUnknown( all );

        if ( filter.empty() == false )
        {
            ( new ProperlyFiltered( all, filter ) )->set_parent( non_empty );
        }

        ( new NoAnonymousFunctions( all ) )->set_parent( non_empty );
        ( new NoTruncatedFunctions( all ) )->set_parent( non_empty );

        RegionConstraint* filename_not_empty = new FilenameNotEmpty( all );
        filename_not_empty->set_parent( non_empty );

        if ( settings[ 'l' ] == false )
        {
            RegionConstraint* proper_line_numbers = new ProperLineNumbers( all );
            proper_line_numbers->set_parent( filename_not_empty );
        }

        CnodeConstraint* no_tracing_outside_init_and_finalize
            = new NoTracingOutsideInitAndFinalize( all );
        no_tracing_outside_init_and_finalize->set_parent( non_empty );

        if ( settings[ 'n' ] == false )
        {
            NoNegativeMetrics( cube ).check();
        }

        if ( output_filename.empty() == false )
        {
            out.open( output_filename.c_str(), ios::out );
            non_empty->set_details_stream( out, true );
            non_empty->set_verbosity( FAILVERB_ERRORS, true );
        }
        non_empty->check();
        if ( output_filename.empty() == false )
        {
            out.close();
        }

        delete non_empty;
        delete cube;
    }
    catch ( Error& e )   // Does this pointer have to be deleted? Memory allocated not in stack, but in heap...
    {
        cerr << "Error: " << e.get_msg() << endl;
        return CUBE_SANITY_INTERNAL_ERROR;
    }
//     catch (RuntimeError& err)
//     {
//         cerr << err.get_msg() << endl;
//         return CUBE_SANITY_INTERNAL_ERROR;
//     }
}
