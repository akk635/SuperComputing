/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

#ifndef CUBE_DUMP_PRINTER
#define CUBE_DUMP_PRINTER

#include <cstdlib>
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <unistd.h>

#include "Cube.h"
#include "CubeCnode.h"
#include "CubeMachine.h"
#include "CubeMetric.h"
#include "CubeRegion.h"
#include "CubeServices.h"
#include "CubeTypes.h"
#include "algebra4.h"

typedef vector<uint64_t> bitstring_t;





class Printer
{
protected:
    ostream & fout;
    Cube*     cube;


    bool
    is_bit_set( bitstring_t & bits,
                unsigned      bitnum );

    void
    set_bit( bitstring_t & bits,
             unsigned      bitnum );

    void
    dump_cube_attributes( const std::map<std::string, std::string> &attrs ) const;

    void
    dump_cube_mirrors( const std::vector<std::string> & mirrors ) const;

    void
    dump_metric_dimension( const vector<Metric*> &metrics );

    void
    dump_calltree_dimension( const vector<Region*>&regn,
                             const vector<Cnode*> &metrics );

    void
    dump_system_dimension( const vector<Machine*> &metrics );

    void
    dump_topologies( const std::vector<Cartesian*>& topologies,
                     bool                           show_coordinates ) const;
    void
    dump_topology( Cartesian* topology,
                   bool       show_coordinates ) const;

    void
    dump_misc_data( string data,
                    bool   selected_data ) const;


    void
    dump_metric( Metric*     metric,
                 int         level,
                 bitstring_t childrenmarkers );

    void
    dump_region( Region* region );

    void
    dump_cnode( Cnode*      cnode,
                int         level,
                bitstring_t childrenmarkers );

    void
    dump_location( Location*   loc,
                   int         level,
                   bitstring_t childrenmarkers );

    void
    dump_location_group( LocationGroup* lg,
                         int            level,
                         bitstring_t    childrenmarkers );

//     void
//     dump_node( Node*       node,
//                int         level,
//                bitstring_t childrenmarkers );

    void
    dump_stn( SystemTreeNode* stn,
              int             level,
              bitstring_t     childrenmarkers );

public:
    Printer( ostream & _out,
             Cube*     _cube ) : fout( _out ), cube( _cube )
    {
    }
    virtual
    ~Printer()
    {
    };

    void
    print_header( string& data,
                  bool    selected_data,
                  bool    show_coords );

    virtual
    void
    dump_data( std::vector < Metric* >& _metrics,
               std::vector < Cnode* >&  _cnodes,
               std::vector < Thread* >& _threads,
               CalculationFlavour       _mf,
               CalculationFlavour       _cf,
               bool                     stored,
               bool                     selected_all_threads ) const;

    virtual
    void
    dump_flat_profile(  std::vector < Metric* >& _metrics,
                        std::vector < Region* >& regions,
                        std::vector < Thread* >& _threads,
                        CalculationFlavour       _mf,
                        bool                     selected_all_threads ) const;
};

#endif
