/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

/**
 * \file cube4_merge.cpp
 * \brief Merges several cubes into single one.
 *
 */
/******************************************

   Performance Algebra Operation: MERGE

 *******************************************/

#include <cstdlib>
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <unistd.h>

#include "Cube.h"
#include "CubeCnode.h"
#include "CubeMachine.h"
#include "CubeMetric.h"
#include "CubeRegion.h"
#include "CubeServices.h"
#include "CubeTypes.h"
#include "algebra4.h"

#include "cube4_dump_Printer.h"
#include "cube4_dump_GnuPlotPrinter.h"
#include "cube4_dump_CSVPrinter.h"

#include "cube4_dump_CommandOption.h"

using namespace std;
using namespace cube;
using namespace services;


enum OutputFormat { HUMAN_READABLE_FORMAT = 0, GNUPLOT_FORMAT = 1, CSV_FORMAT = 2 };




/**
 * Main program.
 * - Check the calling parameters.
 * - For every filename it does
 * - Read the  .cube file. and saves it on alternate way either in 0-th,
   or 1th place in cube[] array.
 * - Calls cube_merge(...) with previous cube (merged) and the current one.
 * - Saves a created merged cube in either "-o output" or "merge.cube|.gz" file.
 * - end.
 */
int
main( int argc, char* argv[] )
{
    int                   ch;
    vector <string>       inputs;

    bool                  selected_metric      = false;
    bool                  selected_cnode       = false;
    bool                  selected_thread      = false;
    bool                  selected_all_threads = false;

    bool                  selected_header       = false;
    bool                  selected_data         = false;
    bool                  selected_flat_profile = false;
    bool                  disable_clustering    = false;
    string                data;
    CalculationFlavour    mf     = cube::CUBE_CALCULATE_INCLUSIVE;
    CalculationFlavour    cf     = cube::CUBE_CALCULATE_EXCLUSIVE;
    bool                  stored = false;
    string                metric;
    std::vector<string>   metricv;
    std::vector<string>   new_metricv;
    bool                  check_newmet = false;
    bool                  check_all    = false;
    string                tempmet;
    unsigned              cnode_id;
    std::vector<unsigned> cnode_idv;
    unsigned              thread_id;
    std::vector<unsigned> thread_idv;
    stringstream          sstr_c, sstr_t;
    bool                  show_coords = false;
    string                output      = "-";
    OutputFormat          format      = HUMAN_READABLE_FORMAT;




    const string USAGE = "Usage: " + string( argv[ 0 ] ) + "[-m <metrics>|<new metrics>|all [-c <cnode ids>] [-x incl|excl] [-z incl|excl|stored] [-t thread_id]  [-r] ] [-f name]  [-w] [-s gnuplot|human ] [-h] [-o output] <cube experiment>\n"
                         "  -m <metrics>|<new metrics>|all        Select one or more of metrics (unique names) for data dump.Define one or more new metrics by giving correspond formula. All - all metrics will be printed.The Combination of these three is possible.\n"
                         "  -c <cnode ids>|all                    Select one or more callpaths to be printed out .\n"
                         "  -x incl|excl                          Selects, if the data along the metric tree should be calculated as an inclusive or an exclusive value.\n"
                         "                                        (Default value: incl).\n"
                         "  -z incl|excl|stored                   Selects, if the data along the call tree should be calculated as an inclusive or an exclusive value.\n"
                         "                                        (Default value: excl).\n"
                         "  -t <thread id>|aggr                   Show data for one or more selected threads or aggregated over system tree. \n"
                         "  -r                                    Prints aggregated values for every region (flat profile), sorted by id.\n"
                         "  -f <name>                             Selects a stored data with the name <name> to display\n"
                         "  -d                                    Shows the coordinates for every topology as well.\n"
                         "  -y                                    Disables expansion of clusters and shows bare stored meta structure.\n"
                         "  -w                                    Prints out the information about structure of the cube.\n"
                         "  -o <filename>|-                       Uses a device or STDOUT for the output. If omit, STDOUT is used.\n"
                         "  -s human|gnuplot|csv                  Uses either GNUPLOT format, CSV format or human readable form for data export.\n"
                         "  -h                                    Help; Output a brief help message.\n"

    ;

    while ( ( ch = getopt( argc, argv, "s:o:f:z:x:m:c:t:rdwhy?" ) ) != -1 )
    {
        switch ( ch )
        {
            case 'h':
            case '?':
                cerr << USAGE << endl;
                exit( 0 );
                break;
            case 's':

                if ( strcmp( optarg, "gnuplot" ) == 0 )
                {
                    format = GNUPLOT_FORMAT;
                }
                else if ( strcmp( optarg, "csv" ) == 0 )
                {
                    format = CSV_FORMAT;
                }
                break;
            case 'o':
                output = optarg;
                break;
            case 'f':
                data          = optarg;
                selected_data = true;
                break;
            case 'm':
                selected_metric = true;
                tempmet         = optarg;
                //parseMetrics( optarg, metricv, new_metricv, check_newmet, check_all );
                break;
            case 'c':
                // sstr_c << optarg;
                if ( strcmp( optarg, "all" ) == 0 )
                {
                    selected_cnode = false;
                }
                else
                {
                    //  sstr_c >> cnode_id;
                    selected_cnode = true;
                    parseCallPaths_Threads( optarg, cnode_idv );
                }
                break;
            case 't':
                //sstr_t << optarg;
                if ( strcmp( optarg, "aggr" ) == 0 )
                {
                    selected_all_threads = true;
                }
                else
                {
                    // sstr_t >> thread_id;
                    selected_thread = true;
                    parseCallPaths_Threads( optarg, thread_idv );
                }
                break;
            case 'd':
                show_coords = true;
                break;
            case 'w':
                selected_header = true;
                break;
            case 'y':
                disable_clustering = true;
                break;
            case 'r':
                selected_flat_profile = true;
                break;
            case 'x':
                if ( strcmp( optarg, "excl" ) == 0 )
                {
                    mf = cube::CUBE_CALCULATE_EXCLUSIVE;
                }
                else
                if ( strcmp( optarg, "incl" ) == 0 )
                {
                    mf = cube::CUBE_CALCULATE_INCLUSIVE;
                }
                else
                {
                    cerr << USAGE << "\nError: Wrong arguments.\n";
                    exit( 0 );
                }
                break;
            case 'z':
                if ( strcmp( optarg, "stored" ) == 0 )
                {
                    stored = true;
                }
                else
                if ( strcmp( optarg, "excl" ) == 0 )
                {
                    cf = cube::CUBE_CALCULATE_EXCLUSIVE;
                }
                else
                if ( strcmp( optarg, "incl" ) == 0 )
                {
                    cf = cube::CUBE_CALCULATE_INCLUSIVE;
                }
                else
                {
                    cerr << USAGE << "\nError: Wrong arguments.\n";
                    exit( 0 );
                }
                break;
            default:
                cerr << USAGE << "\nError: Wrong arguments.\n";
                exit( 0 );
        }
    }

    if ( argc - optind < 1 )
    {
        cerr << USAGE << "\nError: Wrong arguments.\n";
        exit( 0 );
    }

    for ( int i = optind; i < argc; i++ )
    {
        inputs.push_back( argv[ i ] );
    }

    fstream    _fout;
    ostream &  fout = cout;
    streambuf* buf  = NULL;
    if ( ( output.compare( "-" ) != 0 ) )
    {
        _fout.open(  output.c_str(),  fstream::in | fstream::out | fstream::trunc );
        if ( !_fout.is_open() )
        {
            cerr << "Cannot open " << output << " to use as an output device. " << endl;
            exit( -1 );
        }
        buf = fout.rdbuf();
        fout.rdbuf( _fout.rdbuf() );
    }

    int      num  = inputs.size();
    Cube**   cube = new Cube *[ num ];

    Printer* printer = NULL;


    //_______________________________________________________________________
    //num is the number of files

    for ( int i = 0; i < num; i++ )
    {
        if ( check_file( inputs[ i ].c_str() ) != 0 )
        {
            exit( -1 );
        }

        cube[ i ] = new Cube();
        try
        {
            cube[ i ]->openCubeReport( inputs[ i ].c_str(), disable_clustering );

            if ( selected_metric == true )
            {
                parseMetrics( tempmet, metricv, new_metricv, check_newmet, check_all, cube[ i ] );
            }

            if ( check_newmet == true ) //add new metric to cube[i]
            {
                parseNewMetric( new_metricv, cube[ i ] );
            }

            if ( format == GNUPLOT_FORMAT )
            {
                printer = new GnuPlotPrinter( fout, cube[ i ] );
            }
            else
            if ( format == HUMAN_READABLE_FORMAT )
            {
                printer = new Printer( fout, cube[ i ] );
            }
            else
            if ( format == CSV_FORMAT )
            {
                printer = new CSVPrinter( fout, cube[ i ] );
            }

            std::vector<Metric*>    root_metrics = cube[ i ]->get_root_metv();
            std::vector<Metric*>    metrics      = cube[ i ]->get_metv();
            std::vector<Cnode*>     root_cnodes  = cube[ i ]->get_root_cnodev();
            std::vector<Cnode*>     cnodes       = cube[ i ]->get_cnodev();
            std::vector<Machine*>   machines     = cube[ i ]->get_machv();
            std::vector<Node*>      nodes        = cube[ i ]->get_nodev();
            std::vector<Process*>   processs     = cube[ i ]->get_procv();
            std::vector<Thread*>    threads      = cube[ i ]->get_thrdv();
            std::vector<Cartesian*> cartv        = cube[ i ]->get_cartv();
            std::vector<Region*>    regions      = cube[ i ]->get_regv();
            if ( selected_header )
            {
                printer->print_header( data, selected_data, show_coords );
            }

            if ( selected_metric )
            {
                std::vector < Metric* > _metrics;
                if ( check_all == true ) // show all metrics
                {
                    _metrics = metrics;
                }
                else
                {
                    for ( size_t mv_iter = 0; mv_iter != metricv.size(); mv_iter++ )
                    {
                        metric = metricv[ mv_iter ];
                        for ( vector<Metric*>::iterator m_iter = metrics.begin(); m_iter != metrics.end(); m_iter++ )
                        {
                            if ( ( *m_iter )->get_uniq_name().compare( metric ) == 0 )
                            {
                                _metrics.push_back( *m_iter );
                            }
                        }
                    }
                }

                std::vector < Cnode* > _cnodes;
                if ( selected_cnode )
                {
                    for ( size_t cv_iter = 0; cv_iter != cnode_idv.size(); cv_iter++ )
                    {
                        cnode_id = cnode_idv[ cv_iter ];
                        for ( vector<Cnode*>::iterator c_iter = cnodes.begin(); c_iter != cnodes.end(); c_iter++ )
                        {
                            if ( ( *c_iter )->get_id() == cnode_id )
                            {
                                _cnodes.push_back( *c_iter );
                            }
                        }
                    }
                }
                else
                {
                    _cnodes = cnodes;
                }
                std::vector < Thread* > _threads;
                if ( selected_thread )
                {
                    for ( size_t tv_iter = 0; tv_iter != thread_idv.size(); tv_iter++ )
                    {
                        thread_id = thread_idv[ tv_iter ];
                        for ( vector<Thread*>::iterator t_iter = threads.begin(); t_iter != threads.end(); t_iter++ )
                        {
                            if ( ( *t_iter )->get_id() == thread_id )
                            {
                                _threads.push_back( *t_iter );
                            }
                        }
                    }
                }
                else
                {
                    _threads = threads;
                }

                if ( selected_flat_profile )
                {
                    printer->dump_flat_profile( _metrics, regions, _threads, mf, selected_all_threads );
                }
                else
                {
                    printer->dump_data( _metrics, _cnodes, _threads, mf, cf, stored, selected_all_threads );
                }
            }
        }
        catch ( RuntimeError err )
        {
            cerr << err.get_msg() << endl;
        }
        delete printer;
    }

    for ( int i = 0; i < num; i++ )
    {
        delete cube[ i ];
    }
    delete[] cube;
    if ( _fout.is_open() )
    {
        fout.rdbuf( buf );
        _fout.close();
    }
}

void
dump_data( Cube*&cube, vector<Metric*> &metrics, vector<Cnode*> &cnodes, vector<Thread*> &threads, CalculationFlavour mf, CalculationFlavour cf, bool stored  )
{
    size_t max_cnode_padding = 0;
    for ( vector<Cnode*>::iterator c_iter = cnodes.begin(); c_iter != cnodes.end(); c_iter++ )
    {
        stringstream sstr;
        string       _str;
        sstr << "(id=" << ( *c_iter )->get_id() << ")" << endl;
        ;
        sstr >> _str;
        if ( ( ( ( *c_iter )->get_callee() )->get_name() + _str ).length() > max_cnode_padding )
        {
            max_cnode_padding = ( ( ( *c_iter )->get_callee() )->get_name() + _str ).length();
        }
    }

    std::vector < int > thread_paddings;

    for ( vector<Thread*>::iterator t_iter = threads.begin(); t_iter != threads.end(); t_iter++ )
    {
        thread_paddings.push_back( ( *t_iter )->get_name().length() );
    }




    for ( vector<Metric*>::iterator m_iter = metrics.begin(); m_iter != metrics.end(); m_iter++ )
    {
        cout << "Print out the data of the metric " << ( ( *m_iter )->get_uniq_name() ) << endl << endl;
        size_t i = 0;
        while ( i++ <= max_cnode_padding + 1 )
        {
            cout << ' ';
        }
        for ( vector<Thread*>::iterator t_iter = threads.begin(); t_iter != threads.end(); t_iter++ )
        {
            cout << ( ( *t_iter )->get_name() ) << "             ";
        }
        cout << endl << "-------------------------------------------------------------------------------" << endl;
        for ( vector<Cnode*>::iterator c_iter = cnodes.begin(); c_iter != cnodes.end(); c_iter++ )
        {
            stringstream sstr;
            string       _str;
            sstr << "(id=" << ( *c_iter )->get_id() << ")";
            sstr >> _str;
            string _caption = ( ( ( *c_iter )->get_callee() )->get_name() + _str );
            cout << _caption;
            size_t i = _caption.length();
            while ( i++ <= max_cnode_padding + 1 )
            {
                cout << ' ';
            }
            int t_index = 0;
            for ( vector<Thread*>::iterator t_iter = threads.begin(); t_iter != threads.end(); t_iter++, t_index++ )
            {
                Value* _v = NULL;
                if ( stored )
                {
                    _v = cube->get_saved_sev_adv( *m_iter, *c_iter, *t_iter );
                }
                else
                {
                    _v = cube->get_sev_adv( *m_iter, mf, *c_iter, cf, *t_iter, cube::CUBE_CALCULATE_EXCLUSIVE );
                }

                string _value;
                if ( _v == NULL )
                {
                    _value = "0.";
                }
                else
                {
                    _value = _v->getString();
                }
                delete _v;
                cout << _value;
                int i = _value.length();
                while ( i++ <= thread_paddings[ t_index ] + 12 )
                {
                    cout << ' ';
                }
            }
            cout << endl;
        }
    }
}
