#include "cube4_dump_CommandOption.h"

void
parseMetrics( string _optarg, vector<string> &metric, vector<string> &new_metric, bool &check_newmet, bool &check_all, cube::Cube*    _cube )
{
    string::iterator it;
    string           temp;
    int              count = 0;      //counting new metrics
    cube::Metric*    met;

    if ( !_optarg.compare( "all" ) ) //there is no need to go through string
    {
        check_all = true;
        return;
    }

    for ( it = _optarg.begin(); it != _optarg.end(); it++ )
    {
        if ( ( *it ) != ',' )
        {
            temp += ( *it );
        }
        else if ( !temp.empty() )
        {
            met = _cube->get_met( temp );
            if ( met == NULL && temp.compare( "all" ) )
            {
                check_newmet = true;
                count++;
                string            s = "New Metric";
                std::stringstream ss;
                ss << count;
                s.append( ss.str() );
                metric.push_back( s );
                new_metric.push_back( temp );
            }
            else if ( temp == "all" )
            {
                check_all = true;
            }
            else
            {
                metric.push_back( temp );
            }

            temp.clear();
        }
    }
    if ( !temp.empty() )
    {
        met = _cube->get_met( temp );
        if ( met == NULL && temp.compare( "all" ) )
        {
            check_newmet = true;
            count++;
            string            s = "New Metric";
            std::stringstream ss;
            ss << count;
            s.append( ss.str() );
            metric.push_back( s );
            new_metric.push_back( temp );
        }
        else if ( temp == "all" )
        {
            check_all = true;
        }
        else
        {
            metric.push_back( temp );
        }
    }
    return;
}

void
parseNewMetric( vector<string> newmetricv, cube::Cube*   _cube )
{
    string _optarg;
    int    count = 0;
    while ( !newmetricv.empty() )
    {
        _optarg = newmetricv.back();
        newmetricv.pop_back();

        std::string _to_test      = std::string( "<cubepl>" ) + _optarg + std::string( "</cubepl>" );
        std::string error_message = "";


        cube::Metric* created_metric = NULL;

        if ( cubeplparser::CubePL1Driver::test( _to_test, error_message ) )
        {
            count++;
            string            s = "New Metric";
            std::stringstream ss;
            ss << count;
            s.append( ss.str() );
            created_metric = _cube->def_met(
                s, s, "DOUBLE", "",
                "",
                "",
                "",
                NULL,
                cube::CUBE_METRIC_POSTDERIVED, //CUBE_INCLUSIVE
                _optarg,
                "" );
        }
        else
        {
            cerr << "Cannot create metric. Please check the formula." << endl;
        }

        if ( created_metric == NULL )
        {
            cout << "sorry we can not create metric" << endl;
        }
    }
}

void
parseCallPaths_Threads( string _optarg, vector<unsigned> &call_id )
{
    string::iterator it;
    unsigned         temp;
    string           temps;

    unsigned         first = 0, last = 0;
    bool             flag  = false;

    for ( it = _optarg.begin(); it != _optarg.end(); it++ )
    {
        if ( ( *it ) != ',' )
        {
            if ( ( *it ) == '-' )
            {
                first = atoi( temps.c_str() );
                flag  = true;
                temps.clear();
            }
            else
            {
                temps += ( *it );
            }
        }
        else if ( !temps.empty() )
        {
            if ( flag == false )
            {
                temp = atoi( temps.c_str() );
                call_id.push_back( temp );
            }
            else
            {
                last = atoi( temps.c_str() );
                for ( unsigned i = first; i <= last; i++ )
                {
                    call_id.push_back( i );
                }
                flag = false;
            }
            temps.clear();
        }
    }
    if ( !temps.empty() )
    {
        if ( flag == false )
        {
            temp = atoi( temps.c_str() );
            call_id.push_back( temp );
        }
        else
        {
            last = atoi( temps.c_str() );
            for ( unsigned i = first; i <= last; i++ )
            {
                call_id.push_back( i );
            }
            flag = false;
        }
        temps.clear();
    }
}
