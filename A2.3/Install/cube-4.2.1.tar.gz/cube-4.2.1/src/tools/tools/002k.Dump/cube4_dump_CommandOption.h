#ifndef CUBE4_DUMP_COMMANDOPTION_H
#define CUBE4_DUMP_COMMANDOPTION_H

//#include <cstdlib>
//#include <iostream>
//#include <string>
//#include <sstream>
//#include <unistd.h>

#include "Cube.h"
#include "CubePL1Driver.h"

void
parseMetrics( string          _optarg,
              vector<string> &metric,
              vector<string> &new_metric,
              bool &          check_newmet,
              bool &          check_all,
              cube::Cube*     _cube );
void
parseCallPaths_Threads( string            _optarg,
                        vector<unsigned> &cnodeId );

void
parseNewMetric( vector<string> newmetricv,
                cube::Cube*    _cube );


#endif // CUBE4_DUMP_COMMANDOPTION_H
