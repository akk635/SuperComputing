/****************************************************************************
**  CUBE        http://www.score-p.org/                                    **
**  SCALASCA    http://www.scalasca.org/                                   **
*****************************************************************************
**  Copyright (c) 1998-2013                                                **
**  Forschungszentrum Juelich GmbH, Juelich Supercomputing Centre          **
**                                                                         **
**  Copyright (c) 2009-2013                                                **
**  German Research School for Simulation Sciences GmbH,                   **
**  Laboratory for Parallel Programming                                    **
**                                                                         **
**  This software may be modified and distributed under the terms of       **
**  a BSD-style license.  See the COPYING file in the package base         **
**  directory for details.                                                 **
****************************************************************************/

#ifndef __CUBE_ALGEBRA4_INTERNALS_H
#define __CUBE_ALGEBRA4_INTERNALS_H
/**
 *
 * \file algebra4-internals.h
 * \brief Contains a set of functions , which are used by algebra4 internally, but shouldn't be used by external tools
 *
 ************************************************/
/******************************************

   Performance Algebra

 *******************************************/

#include <climits>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>

#include "AggrCube.h"
#include "CubeCnode.h"
#include "CubeCartesian.h"
#include "CubeMachine.h"
#include "CubeMetric.h"
#include "CubeNode.h"
#include "CubeProcess.h"
#include "CubeRegion.h"
#include "CubeThread.h"
#include "CubeError.h"

//#include "Predicates.h"
// #include "algebra4.h"

#include "Filter.h"

using namespace std;
using namespace cube;

#define VERSION "dev"
#define REGIONS_URL "@mirror@scalasca_regions-" VERSION ".html#"

enum CallTreeCopy { COPY_SAME_FLAVOUR = 0, COPY_TO_EXCLUSIFY = 1, COPY_TO_INCLUSIFY = 2 };

namespace cube
{
/**
 * A general structure of the mapping of one Cube on another.
 */
typedef struct
{
    std::map<Metric*, Metric*>                 metm;
    std::map<Cnode*,  Cnode*>                  cnodem;
    std::map<Location*, Location*>             sysm;
    std::map<LocationGroup*, LocationGroup*>   lgm;
    std::map<SystemTreeNode*, SystemTreeNode*> stnm;

    std::map<Metric*, Metric*>                 r_metm;
    std::map<Cnode*,  Cnode*>                  r_cnodem;
    std::map<Location*, Location*>             r_sysm;
    std::map<LocationGroup*, LocationGroup*>   r_lgm;
    std::map<SystemTreeNode*, SystemTreeNode*> r_stnm;
} CubeMapping;


/*
 *  three valued logic, designed specialy for system tree analysis
 */
typedef struct
{
    bool is_machine;
    bool is_node;
} SystemTreeLogical;


/* Prototypes */
/* Metric dimension */
/// @cond PROTOTYPES
bool
metric_merge( Cube&        newCube,
              const Cube&  input,
              CubeMapping& cubeMap );
void
metric_remap( Cube&        newCube,
              const Cube&  input,
              CubeMapping& cubeMap
              );
void
copy_tree( Cube&        newCube,
           Metric&      rhs,
           CubeMapping& cubeMap,
           CallTreeCopy modifier = COPY_SAME_FLAVOUR
           );
bool
compare_tree( Cube&        newCube,
              Metric&      lhs,
              Metric&      rhs,
              CubeMapping& cubeMap );

/* Program dimension */
bool
cnode_merge( Cube&        newCube,
             const Cube&  input,
             CubeMapping& cubeMap,
             bool         copy_ids = false );
bool
cnode_reroot( Cube&          newCube,
              const Cube&    input,
              string         cn_newrootname,
              vector<string> cn_prunes,
              CubeMapping&   cubeMap,
              bool           copy_ids = false
              );
void
copy_tree( Cube&          newCube,
           Cnode&         rhs,
           Cnode&         parent,
           vector<string> cn_prunes,
           CubeMapping&   cubeMap,
           bool           copy_ids = false );
void
copy_tree( Cube&        newCube,
           Cnode&       rhs,
           Cnode&       parent,
           CubeMapping& cubeMap,
           bool         copy_ids = false );
bool
compare_tree( Cube&        newCube,
              Cnode&       lhs,
              Cnode&       rhs,
              CubeMapping& cubeMap,
              bool         copy_ids = false );
Cnode*
def_cnode( Cube&  newCube,
           Cnode& rhs,
           Cnode* parent,
           bool   copy_ids = false );


// --------------- flexible system tree merge routines - start
bool
sysres_merge( Cube&        newCube,
              const Cube&  rhs,
              CubeMapping& cubeMap,
              bool         reduce,
              bool         collapse );
bool
is_subset( const Cube&  lhs,
           const Cube&  rhs,
           CubeMapping* cubeMap = NULL );

bool
is_subset( SystemTreeNode* lhs,
           SystemTreeNode* rhs,
           CubeMapping*    cubeMap = NULL );

bool
is_subset( LocationGroup* lhs,
           LocationGroup* rhs,
           CubeMapping*   cubeMap = NULL );

void
collapsed_merge( Cube&        newCube,
                 const Cube&  lhs,
                 CubeMapping& cubeMap );

void
reduced_merge( Cube&        newCube,
               const Cube&  lhs,
               CubeMapping& cubeMap );

void
copy_system_tree( Cube&        cube,
                  const Cube&  lhs,
                  CubeMapping& cubeMap );


void
merge( Cube&           newCube,
       SystemTreeNode* new_stn,
       SystemTreeNode* to_copy,
       CubeMapping&    cubeMap,
       CubeMapping*    midCubeMap = NULL
       );

void
merge( Cube&          newCube,
       LocationGroup* new_lg,
       LocationGroup* to_copy,
       CubeMapping&   cubeMap,
       CubeMapping*   midCubeMap = NULL  );


std::vector<SystemTreeNode*>
get_reduced_system_tree( const Cube & cube,
                         CubeMapping& cubeMap );


SystemTreeLogical
is_reducable_tree( SystemTreeNode* to_copy );

void
get_reduced_system_tree( SystemTreeNode*               to_copy,
                         SystemTreeNode*               root,
                         std::vector<SystemTreeNode*>& stns,
                         CubeMapping&                  cubeMap );

void
delete_system_tree_node( SystemTreeNode* root );

void
copy_location_groups( SystemTreeNode* to_copy,
                      SystemTreeNode* root,
                      CubeMapping&    cubeMap );
void
delete_location_groups( SystemTreeNode* root );

void
copy_locations( LocationGroup* to_copy,
                LocationGroup* root,
                CubeMapping&   cubeMap );
void
delete_locations( LocationGroup* root );

// --------------- flexible system tree merge routines  - end


bool
is_subset( Cube&       lhs,
           const Cube& rhs,
           bool&       bigger_left,
           bool&       is_equal );


bool
is_subset( const vector<Node*>& mnodes,
           const vector<Node*>& snodes,
           bool&                is_equal );
bool
is_subset( const vector<Process*>& big,
           const vector<Process*>& small,
           bool &                  is_equal );
void
merge( Cube&                   newCube,
       const vector<Machine*>& big,
       bool                    subset,
       bool                    collapse );

//   void plain_merge (Cube& newCube, Cube& lhs, const Cube& rhs);// original
void
plain_merge( Cube&       newCube,
             const Cube& rhs );
void
copy_tree( Cube&    newCube,
           Machine& oldMach,
           Machine& newMach,
           bool     subset,
           bool     collapse );
void
copy_tree( Cube& newCube,
           Node& oldNode,
           Node& newNode );
void
def_pro( Cube&    newCube,
         Process& lhs,
         Node&    rhs );

/* Mapping */
void
createMapping( Cube&        newCube,
               Cube&        oldCube,
               CubeMapping& cubeMap,
               bool         collapse );                                                   // old

void
createMappingMetric( Cube&        newCube,
                     Cube&        comp,
                     CubeMapping& cubeMap );
void
createMappingCnode( Cube&        newCube,
                    Cube&        comp,
                    CubeMapping& cubeMapping );
void
createMappingSystem( Cube&        newCube,
                     Cube&        comp,
                     CubeMapping& cubeMap,
                     bool         collapse );
void
createMappingSystem( Cube&        newCube,
                     Cube&        comp,
                     CubeMapping& cubeMap );


/* Topologies */
void
add_top( Cube&        newCube,
         Cube&        oldCube,
         CubeMapping& cubeMap );
void
merge_top( Cube& newCube,
           Cube& cube1,
           Cube& cube2 );


/* Data set operations */
void
add_sev( Cube&        newCube,
         Cube&        oldCube,
         CubeMapping& cubeMapw,
         double       fac );
void
set_sev( Cube&        newCube,
         Cube&        oldCube,
         CubeMapping& cubeMap );
bool
check_sev( Cube&        newCube,
           Cube&        oldCube,
           CubeMapping& cubeMap );
void
copy_sev( Cube&   newCube,
          Metric* src,
          Metric* dest,
          Cnode*  cnode );
void
add_sev( Cube&   newCube,
         Metric* src,
         Metric* dest,
         Cnode*  cnode );

void
add_sev( Cube&        newCube,
         Cube&        oldCube,
         CubeMapping& old2new,
         Cnode*       oldCnode,
         bool         with_visits = true );

void
diff_sevs( Cube &       outCube,
           Cube&        minCube,
           CubeMapping& lhsmap,
           Cube&        subCube,
           CubeMapping& rhsmap );


/* Another realisations of compare */
bool
compare_metric_dimensions( Cube&,
                           Cube& );
bool
compare_calltree_dimensions( Cube&,
                             Cube& );
bool
compare_system_dimensions( Cube&,
                           Cube& );

template <class T>
bool
compareTrees( vector<T*>&,
              vector<T*>& );

template <class T>
void
createTreeEnumeration( vector<T*>& );

template <class T>
bool
compareVertices( vector<T*>&,
                 vector<T*>& );

bool
id_compare( IdentObject*,
            IdentObject* );
bool
hash_compare( IdentObject*,
              IdentObject* );

bool
createFastMapping( Cube&        lhsCube,
                   Cube&        rhsCube,
                   CubeMapping& cubeMap );

/* Filtering operations */
void
_cube_apply_filter( Cube&        lhs,
                    Cube&        rhs,
                    Cnode*       lhs_parent,
                    Cnode*       rhs_parent,
                    CubeMapping& mapping,
                    Filter&      filter );


void
set_region_urls( Cube& cube );
}


#endif
