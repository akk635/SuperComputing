/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2009-2013,
 *    RWTH Aachen University, Germany
 *    Gesellschaft fuer numerische Simulation mbH Braunschweig, Germany
 *    Technische Universitaet Dresden, Germany
 *    University of Oregon, Eugene, USA
 *    Forschungszentrum Juelich GmbH, Germany
 *    German Research School for Simulation Sciences GmbH, Juelich/Aachen, Germany
 *    Technische Universitaet Muenchen, Germany
 *
 * See the COPYING file in the package base directory for details.
 *
 */

/**
 * @file       SCOREP_Instrumenter.hpp
 * @maintainer Daniel Lorenz  <d.lorenz@fz-juelich.de>
 *
 * @brief      Class to steer the instrumentation of the user code.
 */

#ifndef SCOREP_INSTRUMENTER_H_
#define SCOREP_INSTRUMENTER_H_

#include "scorep_instrumenter_cmd_line.hpp"

#include <iostream>
#include <string>
#include <deque>

class SCOREP_Instrumenter_Adapter;
class SCOREP_Instrumenter_CobiAdapter;
class SCOREP_Instrumenter_CompilerAdapter;
class SCOREP_Instrumenter_CudaAdapter;
class SCOREP_Instrumenter_OpariAdapter;
class SCOREP_Instrumenter_PreprocessAdapter;
class SCOREP_Instrumenter_PdtAdapter;
class SCOREP_Instrumenter_UserAdapter;

/* ****************************************************************************
   Class SCOREP_Instrumenter
******************************************************************************/
/**
 *  @brief performes instrumentation stage
 *
 *  This class examines the available compiler settings and the type of
 *  instrumentation. Makes the necessary modifications to the user command
 *  for instrumentation and executed the user command.
 */
class SCOREP_Instrumenter
{
    /* ****************************************************** Public methods */
public:

    /**
       Creates a new SCOREP_Instrumenter object.
     */
    SCOREP_Instrumenter( SCOREP_Instrumenter_InstallData& install_data,
                         SCOREP_Instrumenter_CmdLine&     command_line );

    /**
       Destroys a SCOREP_Instrumenter object.
     */
    virtual
    ~SCOREP_Instrumenter();

    /**
       Performs the instrumentation of an application
     */
    virtual int
    Run( void );

    /**
       Executes the command specified by @ command. It checks verbosity level
       and whether it is a dry run.
     */
    void
    executeCommand( const std::string& command );

    void
    addTempFile( const std::string& filename );

    std::string
    getCompilerFlags( void );

    std::string
    getInputFiles( void );

    void
    prependInputFile( std::string filename );

    std::string
    getConfigBaseCall( void );

    /* ***************************************************** Private methods */
private:

    /**
       Executes the linking command. Aborts if an error occurs.
     */
    void
    link_step( void );

    /**
       Constructs calls to the config tools.
       @param input_file The input file for which the calls are generated.
     */
    void
    prepare_config_tool_calls( const std::string& input_file );

    /**
       Compiles a users source file. If the original command compile and
       link in one step, we need to split compilation and linking, because
       we need to run the script on the object files. Thus, we do already
       compile the source. It uses the compiler used by the user command,
       appends compiler flags given by the user.
       @param input_file  Source file which is compiled.
       @param output_file Filename for the obejct file.
     */
    void
    compile_source_file( const std::string& input_file,
                         const std::string& output_file );

    /**
       Removes temorarily created files.
     */
    void
    clean_temp_files( void );

    /**
       Invokes the adapters' precompile step on the current file.
       @param current_file The currently processed file.
       @returns The filename of the source file that should be compiled.
     */
    std::string
    precompile( std::string current_file );

    /**
       Invokes the adapters' precompile step.
     */
    void
    prelink( void );

    /**
       Invokes the adapters' postcompile step.
     */
    void
    postlink( void );

    /* ***************************************************** Private members */
private:

    /**
       Installation configuration data set.
     */
    SCOREP_Instrumenter_InstallData& m_install_data;

    /**
       The command line parser.
     */
    SCOREP_Instrumenter_CmdLine& m_command_line;

    /**
       input file names. Need to be separated because OPARI may
       perform source code modifications which take these as input and
       the original command needs the result from the OPRI output. Thus,
       they are then substituted by the OPRI output.
     */
    std::string m_input_files;

    /**
       A list of temorarily created files that are deleted at the end of a
       successful execution, if @a keep_files is false.
     */
    std::string m_temp_files;

    /**
       The base config call without action parameter.
     */
    std::string m_config_base;

    /**
       Additional compiler flgas added by the instrumenter
     */
    std::string m_compiler_flags;

    /**
       Additional linker flags added by the instrumenter
     */
    std::string m_linker_flags;

    SCOREP_Instrumenter_CobiAdapter*       m_cobi_adapter;
    SCOREP_Instrumenter_CompilerAdapter*   m_compiler_adapter;
    SCOREP_Instrumenter_CudaAdapter*       m_cuda_adapter;
    SCOREP_Instrumenter_OpariAdapter*      m_opari_adapter;
    SCOREP_Instrumenter_PreprocessAdapter* m_preprocess_adapter;
    SCOREP_Instrumenter_PdtAdapter*        m_pdt_adapter;
    SCOREP_Instrumenter_UserAdapter*       m_user_adapter;

    std::deque<SCOREP_Instrumenter_Adapter*> m_precompile_adapters;
    std::deque<SCOREP_Instrumenter_Adapter*> m_prelink_adapters;
    std::deque<SCOREP_Instrumenter_Adapter*> m_postlink_adapters;
};
#endif /*SCOREP_INSTRUMENTER_H_*/
